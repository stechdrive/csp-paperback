# celcodec

CLIP STUDIO PAINTの `.clip` ファイルを扱う非公式TypeScriptライブラリ。

- レイヤー素材・音声・タイムラインの読み取りと復元
- レイヤー・タイムライン・キーフレームの編集と保存
- マスク・効果・合成モードを反映した描画
- 文書・指定領域・アニメーションフレームの描画とPNG出力

一部の機能には近似・未対応があります。

---

An unofficial TypeScript library for CLIP STUDIO PAINT `.clip` files.

- Read and extract layer content, audio, and timelines
- Edit and save layers, timelines, and keyframes
- Render masks, effects, and blend modes
- Render documents, regions, and animation frames, with PNG output

Some features are approximate or unsupported.

[MIT License](LICENSE) · [第三者ライセンス / Third-party notices](THIRD_PARTY_NOTICES.md)
