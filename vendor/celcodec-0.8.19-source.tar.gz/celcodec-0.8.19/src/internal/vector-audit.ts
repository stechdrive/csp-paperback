import { check, Reader } from './binary.js'
import { num, type ClipRow } from './records.js'
import { inspectBrushDynamics } from './vector-dynamics.js'
import { errorCode, type DiagnosticCode } from '../diagnostics.js'
import {
  brushInputFields,
  brushInputOmission,
  activeBrushPattern,
  knownBrushRotation,
  renderedBrushStyleFlags,
  renderedTextureComposites,
  renderedTextureFlags,
  textureApplication,
  type BrushInputField,
} from './vector-settings.js'

/** Data use is distinct from pixel fidelity and does not replace render diagnostics. */
export interface BrushFieldUse {
  field: string
  usage: 'rendered' | 'partial' | 'inactive' | 'retained' | 'unresolved'
  reason?: string
  flags?: number
  unknownFlags?: number
  consumedBytes?: number
  remainingBytes?: number
  missingGraphs?: number[]
  error?: DiagnosticCode
}

const metadata = new Set(['_PW_ID', 'MainId', 'CanvasId', 'NextIndex', 'PenRadius'])
const rendered = new Set([
  'FlowBase',
  'AntiAlias',
  'Hardness',
  'IntervalBase',
  'AutoIntervalType',
  'ThicknessBase',
  'RotationBase',
  'RotationRandom',
  'PatternStyle',
  'TexturePattern',
  'TextureScale',
  'TextureRotate',
  'TextureOffsetX',
  'TextureOffsetY',
  'TextureDensityBase',
  'TextureBrightness',
  'TextureContrast',
])
const inputs = new Set<string>(brushInputFields)
const mixing = new Set([
  'WaterColorType',
  'MixColorBase',
  'MixColorEffector',
  'MixAlphaBase',
  'MixAlphaEffector',
  'ColorExtension',
  'BlurKind',
  'BlurBase',
  'BlurEffector',
])

/** Complete inventory of the supplied row, including newer columns we do not know.
 * No names, bitmap identities, or production-specific constants select a rule. */
export function inspectBrushStyle(style: ClipRow, graphs: Map<number, ClipRow>): BrushFieldUse[] {
  return Object.keys(style).map((field): BrushFieldUse => {
    // A malformed blob is evidence, not a reason to omit every later column.
    try {
      return inspectBrushField(style, graphs, field)
    } catch (error) {
      return { field, usage: 'unresolved', reason: 'invalid-saved-data', error: errorCode(error) }
    }
  })
}

function inspectBrushField(
  style: ClipRow,
  graphs: Map<number, ClipRow>,
  field: string,
): BrushFieldUse {
  if (metadata.has(field)) return { field, usage: 'retained' }
  if (field === 'PatternStyle' && num(style, field) && !activeBrushPattern(style))
    return { field, usage: 'inactive', reason: 'image-tip-disabled' }
  if (field === 'Hardness' && activeBrushPattern(style))
    return { field, usage: 'inactive', reason: 'image-tip' }
  if (field === 'IntervalBase' && num(style, 'AutoIntervalType', 2))
    return { field, usage: 'inactive', reason: 'automatic-interval' }
  if (field === 'RotationRandom' && !(num(style, 'RotationEffector', 3) & 128))
    return { field, usage: 'inactive', reason: 'fixed-rotation' }
  if (mixing.has(field) && style.UseWaterColor === 0)
    return { field, usage: 'inactive', reason: 'color-mixing-disabled' }
  if (inputs.has(field)) {
    const inactive = brushInputOmission(style, field as BrushInputField)
    if (inactive && inactive !== 'round-thickness-input-not-connected')
      return { field, usage: 'inactive', reason: inactive }
    const info = inspectBrushDynamics(style[field], graphs)
    const active = !!(info.flags & ~1)
    const partial = !!(
      info.unknownFlags ||
      info.remainingBytes ||
      info.missingGraphs.length ||
      info.flags & 32 ||
      (field !== 'FlowEffector' && info.flags & 128)
    )
    return {
      field,
      usage:
        inactive && active ? 'unresolved' : partial ? 'partial' : active ? 'rendered' : 'inactive',
      ...info,
      ...(inactive && active
        ? { reason: inactive }
        : info.flags & 32
          ? { reason: 'legacy-input-axis-unverified' }
          : {}),
    }
  }
  if (field === 'StyleFlag') {
    const unknownFlags = (num(style, field) & ~renderedBrushStyleFlags) >>> 0
    return { field, usage: unknownFlags ? 'partial' : 'rendered', unknownFlags }
  }
  if (field === 'RotationEffector') {
    const flags = num(style, field),
      known = knownBrushRotation(flags, !!activeBrushPattern(style))
    return {
      field,
      usage: known ? 'rendered' : 'partial',
      ...(known ? {} : { reason: 'rotation-input-unresolved' }),
    }
  }
  if (field.startsWith('Texture') && textureApplication(style) === 'disabled')
    return { field, usage: 'inactive' }
  if (field === 'TextureFlag') {
    const unknownFlags = (num(style, field) & ~renderedTextureFlags) >>> 0
    return { field, usage: unknownFlags ? 'partial' : 'rendered', unknownFlags }
  }
  if (field === 'TextureComposite')
    return {
      field,
      usage: renderedTextureComposites.includes(num(style, field)) ? 'rendered' : 'unresolved',
    }
  if (field === 'CompositeMode')
    return { field, usage: [0, 27, 31].includes(num(style, field)) ? 'rendered' : 'unresolved' }
  if (rendered.has(field)) return { field, usage: 'rendered' }
  if (field.includes('Spray') && style.SprayFlag === 0) return { field, usage: 'inactive' }
  if (field.startsWith('WaterEdge') && style.WaterEdgeFlag === 0)
    return { field, usage: 'inactive' }
  if (field.endsWith('Effector')) {
    const info = inspectBrushDynamics(style[field], graphs)
    return {
      field,
      usage:
        info.flags & ~1 || info.remainingBytes || info.unknownFlags ? 'unresolved' : 'inactive',
      reason: 'not-connected-to-renderer',
      ...info,
    }
  }
  if (field === 'UseWaterColor' && !num(style, field)) return { field, usage: 'inactive' }
  return { field, usage: 'unresolved', reason: 'activation-or-semantics-unverified' }
}

/** Inspect the complete native pattern list even while rendering uses one image. */
export function inspectBrushPattern(row: ClipRow): {
  images: number[]
  declaredImages: number
  order: number
  reverse: number
  unresolved: string[]
} {
  const bytes = row.ImageIndex
  const images: number[] = [],
    unresolved: string[] = []
  if (bytes instanceof Uint8Array) {
    check(bytes.length <= 65536 * 4, 'LIMIT_BRUSH_BYTES')
    const r = new Reader(bytes)
    while (r.position + 4 <= bytes.length) images.push(r.u32())
    if (r.position !== bytes.length) unresolved.push('image-index-tail')
  }
  const declaredImages = num(row, 'ImageNumber'),
    order = num(row, 'OrderType'),
    reverse = num(row, 'Reverse2')
  // Callers may supply a partial material table. Only compare a saved count
  // when that column is present; an empty image list is invalid in either case.
  if (!images.length || (row.ImageNumber !== undefined && declaredImages !== images.length))
    unresolved.push('image-count-mismatch')
  if (images.length > 1 || order) unresolved.push('image-sequence')
  if (
    !Number.isInteger(reverse) ||
    reverse < 0 ||
    reverse > 255 ||
    (reverse & 15) > 1 ||
    reverse >>> 4 > 1
  )
    unresolved.push('reverse-mode')
  return { images, declaredImages, order, reverse, unresolved }
}
