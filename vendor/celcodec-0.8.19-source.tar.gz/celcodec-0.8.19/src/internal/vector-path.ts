// Curve sampling adapted from animeops/clip-tools (MIT); see THIRD_PARTY_NOTICES.md.
import { check } from './binary.js'
import { requiredAt, numberAt } from './indexed.js'
import type { VectorPoint, VectorStroke } from './vector.js'

export interface PathSample extends VectorPoint {
  tangentX?: number
  tangentY?: number
  segment?: number
  parameter?: number
}

/** Six-point interpolating spline, with duplicated endpoint and saved corner controls. */
function spline(points: VectorPoint[], i: number, t: number, derivative = false): [number, number] {
  // Bit 0 marks a corner. Controls across it must not pull this segment into a curve.
  // Only the six-point window matters; do not scan the full stroke for each sample.
  let first = Math.max(0, i - 2),
    last = Math.min(points.length - 1, i + 3)
  for (let k = i; k > first; k--)
    if (requiredAt(points, k).flags & 1) {
      first = k
      break
    }
  for (let k = i + 1; k < last; k++)
    if (requiredAt(points, k).flags & 1) {
      last = k
      break
    }
  const q = t * t
  const w = derivative
    ? t >= 0.5
      ? [4 * t - 6, -32 * t + 44, 192 * t - 260, -328 * t + 328, 192 * t - 124, -28 * t + 18]
      : [-28 * t + 10, 192 * t - 68, -328 * t, 192 * t + 68, -32 * t - 12, 4 * t + 2]
    : t >= 0.5
      ? [
          2 * q - 6 * t + 4,
          -16 * q + 44 * t - 28,
          96 * q - 260 * t + 164,
          -164 * q + 328 * t - 65,
          96 * q - 124 * t + 28,
          -14 * q + 18 * t - 4,
        ]
      : [
          -14 * q + 10 * t,
          96 * q - 68 * t,
          -164 * q + 99,
          96 * q + 68 * t,
          -16 * q - 12 * t,
          2 * q + 2 * t,
        ]
  let x = 0,
    y = 0
  for (let j = 0; j < 6; j++) {
    const p = requiredAt(points, Math.max(first, Math.min(last, i + j - 2)))
    x += numberAt(w, j) * p.x
    y += numberAt(w, j) * p.y
  }
  return [x / 99, y / 99]
}

/** One geometry/input evaluator, shared by compatibility sampling and stamp research.
 * Locations refer to the outgoing segment at a real control, without inventing controls. */
export function createVectorPath(stroke: VectorStroke) {
  const pts = stroke.points
  const kind = stroke.flags & 240
  const tangent = (i: number, t: number): [number, number] => {
    const a = requiredAt(pts, i),
      b = requiredAt(pts, i + 1),
      u = 1 - t
    if (kind === 128) return spline(pts, i, t, true)
    if (kind === 32 && a.handles.length >= 2)
      return [
        2 * (u * (numberAt(a.handles, 0) - a.x) + t * (b.x - numberAt(a.handles, 0))),
        2 * (u * (numberAt(a.handles, 1) - a.y) + t * (b.y - numberAt(a.handles, 1))),
      ]
    if (kind === 64)
      return [
        3 *
          (u * u * (numberAt(a.handles, 0) - a.x) +
            2 * u * t * (numberAt(a.handles, 2) - numberAt(a.handles, 0)) +
            t * t * (b.x - numberAt(a.handles, 2))),
        3 *
          (u * u * (numberAt(a.handles, 1) - a.y) +
            2 * u * t * (numberAt(a.handles, 3) - numberAt(a.handles, 1)) +
            t * t * (b.y - numberAt(a.handles, 3))),
      ]
    return [b.x - a.x, b.y - a.y]
  }
  function direction(i: number, t: number) {
    // The last sample of a segment is the next control's outgoing direction.
    const [tangentX, tangentY] = t === 1 && i + 2 < pts.length ? tangent(i + 1, 0) : tangent(i, t)
    return { tangentX, tangentY }
  }
  return {
    segments: Math.max(0, pts.length - 1),
    direction,
    evaluate(i: number, t: number, directions = false): PathSample {
      check(
        Number.isInteger(i) &&
          i >= 0 &&
          i + 1 < pts.length &&
          Number.isFinite(t) &&
          t >= 0 &&
          t <= 1,
        'INVALID_VECTOR_COORDINATE',
      )
      const a = requiredAt(pts, i),
        b = requiredAt(pts, i + 1)
      const u = 1 - t
      const lerp = (x: number, y: number) => u * x + t * y
      let x = lerp(a.x, b.x),
        y = lerp(a.y, b.y)
      if (kind === 128) [x, y] = spline(pts, i, t)
      else if (kind === 32 && a.handles.length >= 2) {
        x = u * u * a.x + 2 * u * t * numberAt(a.handles, 0) + t * t * b.x
        y = u * u * a.y + 2 * u * t * numberAt(a.handles, 1) + t * t * b.y
      } else if (kind === 64) {
        check(a.handles.length === 4, 'INVALID_VECTOR_HANDLE')
        x =
          u * u * u * a.x +
          3 * u * u * t * numberAt(a.handles, 0) +
          3 * u * t * t * numberAt(a.handles, 2) +
          t * t * t * b.x
        y =
          u * u * u * a.y +
          3 * u * u * t * numberAt(a.handles, 1) +
          3 * u * t * t * numberAt(a.handles, 3) +
          t * t * t * b.y
      }
      // A control belongs to its outgoing segment. In particular, a saved
      // corner must not inherit the direction of the preceding stamp chord.
      const heading = directions ? direction(i, t) : undefined
      return {
        x,
        y,
        flags: t < 0.5 ? a.flags : b.flags,
        handles: [],
        pressure: lerp(a.pressure, b.pressure),
        velocity: lerp(a.velocity, b.velocity),
        smooth: lerp(a.smooth, b.smooth),
        direction: lerp(a.direction, b.direction),
        tilt: lerp(a.tilt, b.tilt),
        size: lerp(a.size, b.size),
        flow: lerp(a.flow, b.flow),
        ...(heading
          ? {
              ...heading,
              segment: t === 1 && i + 2 < pts.length ? i + 1 : i,
              parameter: t === 1 && i + 2 < pts.length ? 0 : t,
            }
          : {}),
        ...((t === 0 ? a : t === 1 ? b : undefined)?.dabState
          ? { dabState: (t === 0 ? a : b).dabState! }
          : {}),
      }
    },
  }
}

/** The public point list keeps its established subdivisions and object shape. */
export function sampleVectorStroke(stroke: VectorStroke, directions = false): PathSample[] {
  return samplePath(stroke, directions, 1)
}

/** Short image splines need at least four intervals to localize native markers.
 * Longer segments retain their finer distance integration; forcing every segment
 * to four intervals breaks otherwise matching marker positions. One interval is
 * retained only for internal comparisons with the previous approximation. */
export function sampleImageVectorStroke(
  stroke: VectorStroke,
  minimumSplineIntervals: 1 | 4 = 4,
): PathSample[] {
  return samplePath(stroke, true, minimumSplineIntervals)
}

function samplePath(
  stroke: VectorStroke,
  directions: boolean,
  minimumSplineIntervals: number,
): PathSample[] {
  const pts = stroke.points,
    out: PathSample[] = []
  if (pts.length === 1) return [{ ...requiredAt(pts, 0) }]
  const path = createVectorPath(stroke)
  for (let i = 0; i < path.segments; i++) {
    const a = requiredAt(pts, i),
      b = requiredAt(pts, i + 1)
    const length =
      Math.hypot(b.x - a.x, b.y - a.y) +
      a.handles.reduce(
        (sum, v, j) => (j % 2 ? sum : sum + Math.hypot(v - a.x, numberAt(a.handles, j + 1) - a.y)),
        0,
      )
    const minimum = (stroke.flags & 240) === 128 ? minimumSplineIntervals + 1 : 2
    const count = Math.max(minimum, Math.ceil(length * 2))
    check(out.length + count <= 1000000, 'LIMIT_VECTOR_SAMPLES')
    for (let j = i ? 1 : 0; j < count; j++) out.push(path.evaluate(i, j / (count - 1), directions))
  }
  return out
}
