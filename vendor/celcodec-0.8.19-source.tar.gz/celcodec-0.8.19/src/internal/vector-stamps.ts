// Brush spacing adapted from animeops/clip-tools (MIT); see THIRD_PARTY_NOTICES.md.
import { check } from './binary.js'
import { requiredAt } from './indexed.js'
import type { VectorPoint } from './vector.js'
import { StrokePlacementState } from './vector-state.js'
import { brushSpacingDistance, type BrushSpacing } from './vector-spacing.js'

export interface Stamp {
  x: number
  y: number
  diameter: number
  alpha: number
  opacity: number
  thickness: number
  spacingDiameter: number
  randomFlow: number
  interval?: number
  textureDensity?: number
  segment?: number
  parameter?: number
  dabState?: VectorPoint['dabState']
  seed?: number
  tangentX?: number
  tangentY?: number
  /** A directionless initial dab consumed randomness but produced no pixels. */
  skippedInitialDab?: boolean
}

/** Carry arc length across subdivisions; honor native continuation at real controls. */
export function spaceStamps(
  samples: Stamp[],
  spacing: BrushSpacing,
  useNativeState: boolean,
  observeResume?: (
    point: Stamp,
    state: NonNullable<VectorPoint['dabState']>,
    placed: number,
    predictedRemaining: number,
  ) => void,
  followPath = false,
  evaluateLocation?: (
    segment: number,
    parameter: number,
  ) => { x?: number; y?: number; tangentX?: number; tangentY?: number },
): Stamp[] {
  const first = requiredAt(samples, 0),
    out: Stamp[] = []
  const gap = (p: Stamp) =>
    brushSpacingDistance(spacing, p.spacingDiameter, p.thickness, p.interval)
  const directional = followPath && samples.length > 1
  const continuation = new StrokePlacementState(gap(first))
  const push = (p: Stamp) => {
    check(out.length < 1000000, 'LIMIT_VECTOR_STAMPS')
    out.push({ ...p, ...continuation.take() })
  }
  function resume(p: Stamp): void {
    const state = useNativeState ? p.dabState : undefined
    if (!state) return
    const predictedRemaining = continuation.remaining
    continuation.resume(state, p === first)
    observeResume?.(p, state, out.length, predictedRemaining)
    if (continuation.remaining === 0) {
      if (directional && p === first) {
        // Native direction-following tips wait for a one-pixel / quarter-diameter
        // run-up. Positive saved residuals already include that decision.
        continuation.waitForDirection(first.diameter)
        return
      }
      const last = out.at(-1)
      if (!last || Math.hypot(p.x - last.x, p.y - last.y) > 1e-7) push(p)
      // A regular dab already at this control must not be stamped twice.
      else {
        last.seed = state.randomState
        continuation.pendingSeed = undefined
      }
      continuation.remaining = gap(p)
    }
  }
  if (useNativeState && first.dabState) resume(first)
  else if (directional) {
    continuation.waitForDirection(first.diameter)
  } else push(first)
  for (let i = 1; i < samples.length; i++) {
    const a = requiredAt(samples, i - 1),
      b = requiredAt(samples, i),
      length = Math.hypot(b.x - a.x, b.y - a.y)
    if (i > 1) resume(a)
    if (length === 0) continue
    let distance = continuation.remaining
    // Native directional strokes use a half-open final segment. A zero saved
    // residual at the last control does not request a new directionless dab.
    while (
      distance <= length &&
      (!directional || i < samples.length - 1 || distance < length - 1e-7)
    ) {
      const t = distance / length,
        lerp = (x: number, y: number) => x + (y - x) * t
      const location =
        a.segment === undefined
          ? undefined
          : {
              segment: a.segment,
              parameter: lerp(a.parameter ?? 0, b.segment === a.segment ? (b.parameter ?? 1) : 1),
            }
      const evaluated = location && evaluateLocation?.(location.segment, location.parameter)
      const p = {
        ...location,
        x: evaluated?.x ?? lerp(a.x, b.x),
        y: evaluated?.y ?? lerp(a.y, b.y),
        diameter: lerp(a.diameter, b.diameter),
        alpha: lerp(a.alpha, b.alpha),
        opacity: lerp(a.opacity, b.opacity),
        thickness: lerp(a.thickness, b.thickness),
        spacingDiameter: lerp(a.spacingDiameter, b.spacingDiameter),
        randomFlow: lerp(a.randomFlow, b.randomFlow),
        interval: lerp(a.interval ?? 1, b.interval ?? 1),
        textureDensity: lerp(a.textureDensity ?? 1, b.textureDensity ?? 1),
        ...(directional
          ? {
              tangentX:
                evaluated?.tangentX ?? lerp(a.tangentX ?? b.x - a.x, b.tangentX ?? b.x - a.x),
              tangentY:
                evaluated?.tangentY ?? lerp(a.tangentY ?? b.y - a.y, b.tangentY ?? b.y - a.y),
            }
          : {}),
      }
      push(p)
      distance += gap(p)
    }
    continuation.remaining = distance - length
  }
  // The final native control can request a terminal dab with zero remaining
  // distance. Positive residuals do not imply an extra dab at the endpoint.
  if (samples.length > 1 && !directional) resume(requiredAt(samples, samples.length - 1))
  return out
}
