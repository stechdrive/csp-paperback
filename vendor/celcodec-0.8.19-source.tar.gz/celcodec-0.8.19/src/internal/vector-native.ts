// Native record boundaries adapted from the parser in vector.ts; see THIRD_PARTY_NOTICES.md.
import { check, Reader } from './binary.js'
import { checkCancelled } from '../diagnostics.js'
import type { VectorPoint, VectorStroke } from './vector.js'

export interface NativeVectorField {
  name: string
  offset: number
  bytes: number
  usage: 'rendered' | 'retained' | 'unresolved'
}

export interface NativeVectorRecord {
  kind: 'stroke' | 'point'
  stroke: number
  point?: number
  offset: number
  /** Borrowed, immutable input. Neither inspection nor rendering modifies it. */
  bytes: Uint8Array
  fields: readonly NativeVectorField[]
}

const field = (
  name: string,
  offset: number,
  bytes: number,
  usage: NativeVectorField['usage'],
): NativeVectorField => ({ name, offset, bytes, usage })

const commonStroke = [
  field('layout', 0, 20, 'retained'),
  field('flags', 20, 4, 'rendered'),
  field('storedBounds', 24, 16, 'retained'),
  field('mainColorWords', 40, 12, 'rendered'),
  field('subColorWords', 52, 12, 'retained'),
  field('opacity', 64, 8, 'rendered'),
]
const legacyStroke = [
  ...commonStroke,
  field('brush', 72, 4, 'rendered'),
  field('radius', 76, 8, 'rendered'),
  field('randomSeed', 84, 4, 'rendered'),
]
const modernStroke = [
  ...commonStroke,
  field('additionalWord', 72, 4, 'unresolved'),
  field('brush', 76, 4, 'rendered'),
  field('radius', 80, 8, 'rendered'),
  field('randomSeed', 88, 4, 'rendered'),
]
const pointFields = [
  field('position', 0, 16, 'rendered'),
  field('storedBounds', 16, 16, 'retained'),
  field('flags', 32, 4, 'rendered'),
  field('pressure', 36, 4, 'rendered'),
  field('velocityInput', 40, 4, 'unresolved'),
  field('smoothInput', 44, 4, 'rendered'),
  field('directionInput', 48, 4, 'retained'),
  field('tiltInput', 52, 4, 'rendered'),
  field('size', 56, 4, 'rendered'),
  field('flow', 60, 4, 'rendered'),
  field('additionalInputs', 64, 12, 'unresolved'),
  field('remainingDistance', 76, 4, 'rendered'),
  field('randomState', 80, 4, 'rendered'),
  field('count', 84, 4, 'unresolved'),
]
const pointLayouts = new Map([
  [88, pointFields],
  [104, [...pointFields, field('curveControls', 88, 16, 'rendered')]],
  [120, [...pointFields, field('curveControls', 88, 32, 'rendered')]],
])

/** Visits only validated records, with every byte assigned to a field.
 * This does not make retained/unknown data safe to edit or render. */
export function inspectNativeVector(
  bytes: Uint8Array,
  observe: (record: NativeVectorRecord) => void,
  signal?: AbortSignal,
): void {
  decodeVectorStrokes(bytes, signal, observe)
}

/** Validate boundaries before allocation; unsupported records never become guessed strokes. */
export function decodeVectorStrokes(
  bytes: Uint8Array,
  signal?: AbortSignal,
  observe?: (record: NativeVectorRecord) => void,
): VectorStroke[] {
  checkCancelled(signal)
  const r = new Reader(bytes),
    strokes: VectorStroke[] = []
  let totalPoints = 0
  while (r.position < bytes.length) {
    checkCancelled(signal)
    const start = r.position,
      header = r.u32(),
      section = r.u32(),
      stride = r.u32(),
      base = r.u32()
    check(
      ((header === 88 && section === 72) || (header === 92 && section === 76)) &&
        base === 88 &&
        [88, 104, 120].includes(stride),
      'UNSUPPORTED_VECTOR_LAYOUT',
    )
    const count = r.u32(),
      flags = r.u32()
    check((flags & 13) === 1 && [16, 32, 64, 128].includes(flags & 240), 'UNSUPPORTED_VECTOR_CURVE')
    check(
      totalPoints + count <= 1000000 && strokes.length < 50000 && count > 0,
      'LIMIT_VECTOR_POINTS',
    )
    totalPoints += count
    check(start + header + count * stride <= bytes.length, 'TRUNCATED_DATA')
    r.take(16)
    const color = [r.u32() >>> 24, r.u32() >>> 24, r.u32() >>> 24]
    r.take(12)
    const opacity = r.number('f64')
    let brush = r.u32()
    if (header === 92) brush = r.u32()
    const diameter = 2 * r.number('f64')
    const randomSeed = r.u32()
    check(
      opacity >= 0 && opacity <= 1 && diameter >= 0 && diameter <= 4096,
      'INVALID_VECTOR_STROKE',
    )
    const points: VectorPoint[] = []
    for (let i = 0; i < count; i++) {
      const p = new Reader(r.take(stride)),
        x = p.number('f64'),
        y = p.number('f64')
      check(Math.abs(x) <= 1000000 && Math.abs(y) <= 1000000, 'INVALID_VECTOR_COORDINATE')
      p.take(16)
      const pointFlags = p.u32(),
        pressure = p.number('f32'),
        velocity = p.number('f32'),
        smooth = p.number('f32')
      const direction = p.number('f32')
      const tilt = p.number('f32'),
        size = p.number('f32'),
        flow = p.number('f32')
      check(size >= 0 && size <= 64 && flow >= 0 && flow <= 64, 'INVALID_VECTOR_FACTOR')
      p.take(12)
      const remainingDistance = p.number('f32'),
        randomState = p.u32(),
        savedCount = p.u32()
      check(remainingDistance >= 0, 'INVALID_VECTOR_FACTOR')
      const handles = Array.from({ length: (stride - 88) / 8 }, () => p.number('f64'))
      check(
        handles.every((v) => Math.abs(v) <= 1000000),
        'INVALID_VECTOR_HANDLE',
      )
      if (observe)
        observe({
          kind: 'point',
          stroke: strokes.length,
          point: i,
          offset: start + header + i * stride,
          bytes: p.bytes,
          fields: pointLayouts.get(stride)!,
        })
      points.push({
        x,
        y,
        flags: pointFlags,
        pressure,
        velocity,
        smooth,
        direction,
        tilt,
        size,
        flow,
        handles,
        dabState: { remainingDistance, randomState, count: savedCount },
      })
    }
    if (observe)
      observe({
        kind: 'stroke',
        stroke: strokes.length,
        offset: start,
        bytes: bytes.subarray(start, start + header),
        fields: header === 92 ? modernStroke : legacyStroke,
      })
    strokes.push({ flags, brush, diameter, opacity, randomSeed, color, points })
  }
  return strokes
}
