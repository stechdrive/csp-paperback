import { isArrayValue } from '../internal/indexed.js'
import { openNativeStore, type NativeLayer, type OpenOptions } from './store.js'
import type { LayerRasterOptions } from './store.js'
import type { RasterSource } from '../material/raster-source.js'
export type { LayerRasterOptions } from './store.js'
import { check } from '../internal/binary.js'
import { validateCanvasPixels } from '../internal/canvas-limits.js'
import { resolveImageLimits, resourceLimit } from '../image-resources.js'
import { readContainerLimits } from '../native/container-read.js'
import { num, str } from '../internal/records.js'
import { normalizedUuid } from '../native/layer-metadata.js'
import { isLightTableReference } from '../internal/layer-metadata.js'
import { readAnimation } from '../native/read-animation.js'
import { readKeyframeTrack } from '../native/keyframes.js'
import { animationFrame } from './canvas.js'
import { animationPaper } from './paper.js'
import { readScene3D } from './scene3d.js'
import { readMediaSources } from './media.js'
import { compilePlayback, type TimelinePlayback } from './playback.js'
import { readAudioFrom } from '../native/audio.js'
import type { SqlJsStatic } from '../native/sql.js'
import type { MaterialDecoderOptions } from '../internal/material.js'
import {
  checkCancelled,
  rethrowFatal,
  serializeClipError,
  type ClipDiagnostic,
} from '../diagnostics.js'
import { applyEdits } from '../edit/engine.js'
import type { EditOperation, EditOptions } from '../edit/operations.js'
import { captureOperations } from '../edit/operations.js'
import type {
  BinaryHandle,
  DocumentView,
  LayerView,
  EditPlan,
  SaveResult,
  EditImpact,
} from './types.js'
import { createBytes, validateSeed } from './create.js'
import type { ClipCanvasSettings } from '../native/model.js'

export type * from './types.js'
export type {
  AnimationPaperSettings,
  AnimationPaperView,
  FrameAnchor,
  FrameInsets,
  FrameRectangle,
} from './paper.js'
export type { MediaSourceView } from './media.js'
export type { LayerProperties, StoredOffset } from './properties.js'
export type {
  PlaybackPolicy,
  PlaybackApplication,
  PlaybackLayerOverride,
} from './playback-policy.js'
export type { NativeMetadata, Camera3DView, Object3DView, Layer3DView } from './scene3d.js'
export type {
  PlaybackTransform,
  PlaybackFrameOptions,
  PlaybackChannel,
  PlaybackLayer,
  PlaybackFrame,
  TimelinePlayback,
} from './playback.js'
export type {
  EditOperation,
  EditOptions,
  LayerAttributes,
  EditableKeyframeProperty,
  PropertyKeyTarget,
  TimelineFrameEdit,
  TrackTarget,
} from '../edit/operations.js'
export type { SqlJsStatic } from '../native/sql.js'
export type { ClipCanvasSettings, ClipAudioTimeline, ExportTrackFrame } from '../native/model.js'
export type { Pixels } from '../native/raster.js'
export { sampleKeyframeCurve } from '../native/keyframes.js'
export type {
  KeyframeTimeRange,
  PropertyKeyframe,
  KeyframeUnit,
  KeyframeCurve,
  KeyframeParameter,
  KeyframeClip,
  KeyframeTrack,
  KeyframeReadOptions,
  KeyframeSample,
} from '../native/keyframes.js'
export { serializeClipError, deserializeClipError } from '../diagnostics.js'
export interface SessionOptions extends OpenOptions {
  /** Default copy; borrow requires immutable input until dispose. Transfer input to a Worker before borrowing. */
  ownership?: 'copy' | 'borrow'
  maxPlanBytes?: number
  /** Aggregate native uncompressed mixer bytes retained by live playback evaluators. Default 64 MiB. */
  maxPlaybackBytes?: number
}
function freeze<T>(value: T): T {
  if (value && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child)
    Object.freeze(value)
  }
  return value
}
const emptyImpact: EditImpact = freeze({
  changedRows: [],
  addedExternalBlobs: 0,
  invalidatedLayerIds: [],
  preservation: 'original-bytes',
})
const digest = async (bytes: Uint8Array) =>
  new Uint8Array(await crypto.subtle.digest('SHA-256', bytes as Uint8Array<ArrayBuffer>))
const equal = (a: Uint8Array, b: Uint8Array) =>
  a.length === b.length && a.every((v, i) => v === b[i])

/** Immutable source revision. Saving consumes a plan, returns owned bytes, and never mutates the source session. */
export function openDocument(
  SQL: SqlJsStatic,
  input: Uint8Array,
  initialOptions: SessionOptions = {},
) {
  const options = {
    ...initialOptions,
    ...(initialOptions.imageLimits
      ? { imageLimits: resolveImageLimits(initialOptions.imageLimits) }
      : {}),
    ...(initialOptions.limits ? { limits: { ...initialOptions.limits } } : {}),
  }
  check(input instanceof Uint8Array, 'INVALID_EDIT')
  checkCancelled(options.signal)
  check(
    options.ownership === undefined || ['copy', 'borrow'].includes(options.ownership),
    'INVALID_EDIT',
  )
  const maxPlanBytes = resourceLimit(
    options.maxPlanBytes ?? Math.max(512 * 1024 * 1024, options.imageLimits?.maxBytes ?? 0),
  )
  const maxPlaybackBytes = options.maxPlaybackBytes ?? 64 * 1024 * 1024
  check(
    Number.isSafeInteger(maxPlaybackBytes) &&
      maxPlaybackBytes >= 0 &&
      maxPlaybackBytes <= 256 * 1024 * 1024,
    'INVALID_LIMIT',
  )
  check(Number.isSafeInteger(maxPlanBytes) && maxPlanBytes >= 0, 'INVALID_LIMIT')
  // Check the container ceiling before the ownership copy.
  check(input.length <= (options.limits?.inputBytes ?? 1024 * 1024 * 1024), 'LIMIT_INPUT_BYTES')
  let source: Uint8Array | undefined =
    options.ownership === 'borrow' ? input : new Uint8Array(input)
  check(source.buffer instanceof ArrayBuffer, 'INVALID_EDIT')
  const borrowedFingerprint = options.ownership === 'borrow' ? digest(source) : undefined
  const lifetime = new AbortController(),
    signal = options.signal ? AbortSignal.any([lifetime.signal, options.signal]) : lifetime.signal
  let store: ReturnType<typeof openNativeStore> | undefined = openNativeStore(SQL, source, {
    ...options,
    signal,
  })
  const plans = new Map<
      EditPlan,
      { result: SaveResult | undefined; hash: Uint8Array | undefined }
    >(),
    handles = new Map<BinaryHandle, () => Uint8Array | undefined>()
  const layers = new Map<string, NativeLayer>(),
    tracks = new Map<
      number,
      {
        track: (typeof store.document.timelines)[number]['tracks'][number]
        timeline: (typeof store.document.timelines)[number]
      }
    >()
  const playbacks = new Set<TimelinePlayback>()
  const rasters = new Set<RasterSource>()
  let playbackBytes = 0
  let busy = false,
    decoding = false,
    closed = false
  const active = () => {
    check(!closed && store && source, 'CLOSED_DOCUMENT')
    checkCancelled(signal)
  }
  const binary = (
    kind: BinaryHandle['kind'],
    id: string,
    bytes: Uint8Array | undefined,
    get: () => Uint8Array | undefined,
  ) => {
    if (!bytes) return undefined
    const handle = Object.freeze({ kind, id, byteLength: bytes.length })
    handles.set(handle, get)
    return handle
  }
  const binaries: BinaryHandle[] = []
  binaries.push(
    binary('database', 'database', store.container.database, () => store?.container.database)!,
  )
  const externals = new Map<string, BinaryHandle>()
  for (const [id, bytes] of store.container.external) {
    const h = binary('external', id, bytes, () => store?.container.external.get(id))!
    binaries.push(h)
    externals.set(id, h)
  }
  store.container.chunks.forEach((chunk, index) => {
    binaries.push(
      binary('chunk', String(index), chunk.bytes, () => store?.container.chunks[index]?.bytes)!,
    )
  })
  const tree = (nodes: NativeLayer[], parentId: string | null): LayerView[] =>
    nodes.map((node) => {
      layers.set(node.id, node)
      const r = node.attributes
      const number = (key: string) => (typeof r[key] === 'number' ? r[key] : undefined)
      const visibility = number('LayerVisibility'),
        opacity = number('LayerOpacity'),
        folder = number('LayerFolder')
      return {
        id: node.id,
        nativeId: node.nativeId,
        parentId,
        name: node.name,
        role: isLightTableReference(r) ? 'light-table-reference' : 'artwork',
        reference: isLightTableReference(r)
          ? {
              kind: 'light-table',
              sourceLayerId: /^[0-9a-f]{32}$/.test(normalizedUuid(r.LinkLayerUUID))
                ? normalizedUuid(r.LinkLayerUUID)
                : undefined,
              storedFlag: Number(r.LightTableReferCell),
            }
          : undefined,
        kind: node.kind,
        animation: !!r.AnimationFolder,
        folder: node.isFolder,
        children: tree(node.children, node.id),
        visible: visibility === undefined ? undefined : !!(visibility & 1),
        opacity: opacity === undefined ? undefined : opacity / 256,
        blendMode: number('LayerComposite'),
        locked:
          r.LayerType === 1584
            ? true
            : r.LayerLock === undefined || r.LayerLock === null
              ? undefined
              : !!r.LayerLock,
        expanded: node.isFolder && folder !== undefined ? !(folder & 16) : undefined,
        labelColor: node.paletteColor,
        mask: node.maskState,
        stored: { type: number('LayerType'), visibility, opacity, folder },
      }
    })
  const document: DocumentView = freeze({
    canvas: {
      animationPaper: animationPaper(
        store.document.canvas,
        store.document.width,
        store.document.height,
        store.document.dpi,
      ),
      animationFrame: animationFrame(
        store.document.canvas,
        store.document.width,
        store.document.height,
        store.document.dpi,
      ),
      width: store.document.width,
      height: store.document.height,
      dpi: store.document.dpi,
      unit:
        typeof store.document.canvas.CanvasUnit === 'number'
          ? store.document.canvas.CanvasUnit
          : undefined,
    },
    layers: tree(store.document.layers, null),
    timelines: store.document.timelines.map((time) => ({
      id: normalizedUuid(time.attributes.TimeLineUuid),
      nativeId: num(time.attributes, 'MainId'),
      name: str(time.attributes.TimeLineName),
      fps: num(time.attributes, 'FrameRate'),
      startFrame: num(time.attributes, 'StartFrame'),
      endFrame: num(time.attributes, 'EndFrame'),
      durationFrames: num(time.attributes, 'EndFrame') - num(time.attributes, 'StartFrame'),
      durationSeconds:
        (num(time.attributes, 'EndFrame') - num(time.attributes, 'StartFrame')) /
        num(time.attributes, 'FrameRate'),
      currentFrame: num(time.attributes, 'CurrentFrame'),
      labels: time.labels.map((l) => ({
        id: num(l, 'MainId'),
        frame: num(l, 'LabelFrame'),
        type: num(l, 'LabelType'),
        name: str(l.LabelName),
        length: typeof l.LabelLength === 'number' ? l.LabelLength : null,
      })),
      tracks: time.tracks.map((track) => {
        const id = num(track.attributes, 'MainId')
        tracks.set(id, { track, timeline: time })
        return {
          id,
          uuid: normalizedUuid(track.attributes.TrackUuid),
          layerId: normalizedUuid(track.attributes.LayerUuidWithTrack),
          kind: num(track.attributes, 'TrackKind'),
          labels: track.labels.map((l) => ({
            id: num(l, 'MainId'),
            frame: num(l, 'LabelFrame'),
            type: num(l, 'LabelType'),
            name: str(l.LabelName),
            length: typeof l.LabelLength === 'number' ? l.LabelLength : null,
          })),
          primary: externals.get(str(track.attributes.TrackActionMixer)),
          secondary: externals.get(str(track.attributes.TrackActionMixer2)),
        }
      }),
    })),
    defaultTimelineId: store.document.timelines.find(
      (t) => t.attributes.MainId === store!.document.defaultTimelineId,
    )
      ? normalizedUuid(
          store.document.timelines.find(
            (t) => t.attributes.MainId === store!.document.defaultTimelineId,
          )!.attributes.TimeLineUuid,
        )
      : undefined,
    compatibility: store.document.compatibility,
    binaries,
  })
  const session = {
    document,
    imageLimits: options.imageLimits,
    /** Raw native offscreen coordinates: no layer placement, transform or effects.
     * Select the slot explicitly when reading an original or mask. Sources borrow
     * the session's immutable bytes and close automatically with the session. */
    openLayerRaster(id: string, input: LayerRasterOptions = {}): RasterSource {
      active()
      const source = store!.openLayerRaster(id, {
          ...input,
          signal: input.signal ? AbortSignal.any([signal, input.signal]) : signal,
        }),
        close = source.dispose.bind(source)
      source.dispose = () => {
        close()
        rasters.delete(source)
      }
      rasters.add(source)
      return Object.freeze(source)
    },
    /** Session snapshots are immutable. Reopen saved bytes to start the next revision. */
    revision: 0 as const,
    /** Compile native curves once, then evaluate arbitrary frames without SQLite or pixel decoding. */
    createPlayback(timelineId: string): TimelinePlayback {
      active()
      check(playbacks.size < 32, 'LIMIT_PLAYBACK_BYTES')
      const timeline = document.timelines.find((t) => t.id === timelineId)
      check(timeline, 'MISSING_ROW')
      const native = store!.document.timelines.find(
        (t) => t.attributes.MainId === timeline.nativeId,
      )!
      let bytes = 0
      for (const t of native.tracks) {
        const size = num(
          t.attributes,
          (t.primary ? 'TrackActionMixer' : 'TrackActionMixer2') + 'Size',
        )
        check(Number.isSafeInteger(size) && size >= 0, 'INVALID_BINC_SIZE')
        bytes += size
        check(playbackBytes + bytes <= maxPlaybackBytes, 'LIMIT_PLAYBACK_BYTES', {
          limit: maxPlaybackBytes,
        })
      }
      const playback = compilePlayback(
        document,
        timeline,
        native,
        layers,
        bytes,
        active,
        () => {
          if (playbacks.delete(playback)) playbackBytes -= bytes
        },
        signal,
      )
      playbackBytes += bytes
      playbacks.add(playback)
      return playback
    },
    copyBinary(handle: BinaryHandle) {
      active()
      const get = handles.get(handle)
      check(get, 'INVALID_EDIT')
      const bytes = get()
      check(bytes, 'MISSING_BINARY_COLUMN')
      return new Uint8Array(bytes)
    },
    inspectLayer(id: string) {
      active()
      const row = layers.get(id)?.attributes
      check(row, 'MISSING_ROW')
      return Object.fromEntries(
        Object.entries(row).map(([key, value]) => [
          key,
          value instanceof Uint8Array ? new Uint8Array(value) : value,
        ]),
      )
    },
    read3DLayer(id: string) {
      active()
      const row = layers.get(id)
      check(row, 'MISSING_ROW')
      check(row.kind === '3d', 'INVALID_EXISTING_LAYER_KIND')
      return readScene3D(store!, row.attributes, (id) => externals.get(id), signal)
    },
    readLayerProperties(id: string) {
      active()
      const row = layers.get(id)
      check(row, 'MISSING_ROW')
      return store!.readLayerProperties(id)
    },
    /** Inspect every channel, including transform/mask/opacity/cel/audio and unknown names. */
    readKeyframes(id: number, source: 'primary' | 'secondary' = 'primary') {
      active()
      check(source === 'primary' || source === 'secondary', 'INVALID_EDIT')
      const item = tracks.get(id)
      check(item, 'MISSING_TRACK')
      const { track, timeline } = item,
        field = source === 'primary' ? 'TrackActionMixer' : 'TrackActionMixer2',
        body = source === 'primary' ? track.primary : track.secondary
      check(body, 'MISSING_BINARY_COLUMN', { field })
      return readKeyframeTrack(body, num(track.attributes, `${field}Size`), {
        fps: num(timeline.attributes, 'FrameRate'),
        startFrame: num(timeline.attributes, 'StartFrame'),
        signal,
      })
    },
    readCelTrack(id: number) {
      active()
      const item = tracks.get(id)
      check(item, 'MISSING_TRACK')
      check(item.track.attributes.TrackKind === 2000, 'UNSUPPORTED_CEL_CURVE')
      const { track, timeline } = item,
        r = timeline.attributes,
        field = track.primary ? 'TrackActionMixer' : 'TrackActionMixer2',
        body = field === 'TrackActionMixer' ? track.primary : track.secondary
      check(body, 'MISSING_CEL_DATA')
      return readAnimation(
        body,
        num(track.attributes, `${field}Size`),
        num(r, 'FrameRate'),
        num(r, 'StartFrame'),
        num(r, 'EndFrame'),
      )
    },
    readTimeline(id: string) {
      active()
      const time = document.timelines.find((t) => t.id === id)
      check(time, 'MISSING_ROW')
      return {
        timeline: time,
        tracks: time.tracks
          .filter((t) => t.kind === 2000)
          .map((t) => {
            try {
              return {
                trackId: t.id,
                layerId: t.layerId,
                frames: session.readCelTrack(t.id),
                diagnostics: [] as ClipDiagnostic[],
              }
            } catch (error) {
              rethrowFatal(error)
              return {
                trackId: t.id,
                layerId: t.layerId,
                frames: [],
                diagnostics: [
                  { ...serializeClipError(error), layerId: t.layerId, part: 'timeline' as const },
                ],
              }
            }
          }),
      }
    },
    readAudio(layerId: string, timelineId: string) {
      active()
      const row = layers.get(layerId)
      check(row, 'MISSING_ROW')
      return readAudioFrom(store!, row.nativeId, timelineId)
    },
    /** Inspect linked audio/movie sources without accessing the filesystem or decoding media. */
    readMediaSources(layerId: string) {
      active()
      const row = layers.get(layerId)
      check(row, 'MISSING_ROW')
      return readMediaSources(store!, row.attributes, (id) => externals.get(id))
    },
    materialCapabilities(id: string) {
      active()
      const row = layers.get(id)
      check(row, 'MISSING_ROW')
      return freeze({
        kind: row.kind,
        media: row.kind === 'audio' || row.kind === 'video',
        /** Reference exists; decode diagnostics determine whether its payload is available. */
        savedPixels: !!num(row.attributes, 'LayerRenderMipmap'),
        savedComposite: row.isFolder || row.kind === 'video',
        originalPixels:
          !!num(row.attributes, 'TimeLineOriginalMipmap') ||
          !!num(row.attributes, 'ResizableOriginalMipmap'),
        decode: 'inspect-result-diagnostics' as const,
      })
    },
    async decodeLayer(id: string, decodeOptions: MaterialDecoderOptions = {}) {
      active()
      check(!decoding, 'BUSY_DOCUMENT')
      decoding = true
      const operationSignal = decodeOptions.signal
        ? AbortSignal.any([signal, decodeOptions.signal])
        : signal
      try {
        return await store!.decodeLayer(id, { ...decodeOptions, signal: operationSignal })
      } finally {
        decoding = false
      }
    },
    async planEdits(
      operations: readonly EditOperation[],
      editOptions: EditOptions = {},
    ): Promise<EditPlan> {
      active()
      check(!busy, 'BUSY_DOCUMENT')
      check(plans.size === 0, 'LIMIT_PENDING_PLANS')
      busy = true
      const operationSignal = editOptions.signal
        ? AbortSignal.any([signal, editOptions.signal])
        : signal
      try {
        check(isArrayValue(operations) && operations.length <= 100000, 'LIMIT_DOCUMENT_ITEMS')
        // Capture operation values, including pixel/audio bytes, before yielding to caller code.
        const owned = captureOperations(operations, maxPlanBytes, operationSignal)
        check(
          !editOptions.seed || editOptions.seed.length <= 512 * 1024 * 1024,
          'LIMIT_INPUT_BYTES',
        )
        if (editOptions.seed)
          check(
            editOptions.seed instanceof Uint8Array && editOptions.seed.length <= 512 * 1024 * 1024,
            'LIMIT_INPUT_BYTES',
          )
        const seed = editOptions.seed ? new Uint8Array(editOptions.seed) : undefined,
          hash = await borrowedFingerprint
        if (seed) validateSeed(SQL, seed, operationSignal)
        active()
        if (hash) check(equal(hash, await digest(source!)), 'SOURCE_CHANGED')
        checkCancelled(operationSignal)
        const result = owned.length
          ? await applyEdits(SQL, source!, owned, {
              ...(options.imageLimits ? { imageLimits: options.imageLimits } : {}),
              maxContainerBytes: Math.max(
                512 * 1024 * 1024,
                maxPlanBytes,
                options.limits?.inputBytes ?? 0,
              ),
              ...(seed ? { seed } : {}),
              ...(options.maxCanvasPixels === undefined
                ? {}
                : { maxCanvasPixels: options.maxCanvasPixels }),
              signal: operationSignal,
            })
          : undefined
        active()
        checkCancelled(operationSignal)
        if (hash) check(equal(hash, await digest(source!)), 'SOURCE_CHANGED')
        active()
        check((result?.bytes.length ?? 0) <= maxPlanBytes, 'LIMIT_PENDING_PLANS')
        if (result?.changed) {
          const verified = openNativeStore(SQL, result.bytes, {
            ...options,
            // The bounded output is verified under the output budget, independently
            // of the acceptance policy for the original compressed input.
            limits: {
              ...(options.limits ?? readContainerLimits),
              inputBytes: Math.max(
                options.limits?.inputBytes ?? readContainerLimits.inputBytes,
                maxPlanBytes,
              ),
            },
            signal: operationSignal,
          })
          verified.dispose()
        }
        const plan: EditPlan = freeze({
          allowed: true,
          diagnostics: [],
          revision: 0,
          operations: operations.length,
          impact: result?.impact ?? emptyImpact,
        })
        plans.set(plan, { result, hash })
        return plan
      } catch (error) {
        rethrowFatal(error)
        return freeze({
          allowed: false,
          diagnostics: [serializeClipError(error)],
          revision: 0,
          operations: operations.length,
          impact: undefined,
        })
      } finally {
        busy = false
      }
    },
    async save(plan: EditPlan): Promise<SaveResult> {
      active()
      const payload = plans.get(plan)
      check(payload && plan.allowed && plan.revision === 0, 'INVALID_EDIT_PLAN')
      if (payload.hash) {
        check(equal(payload.hash, await digest(source!)), 'SOURCE_CHANGED')
        active()
        check(plans.get(plan) === payload, 'INVALID_EDIT_PLAN')
      }
      plans.delete(plan)
      return (
        payload.result ?? { bytes: new Uint8Array(source!), changed: false, impact: emptyImpact }
      )
    },
    discardPlan(plan: EditPlan) {
      plans.delete(plan)
    },
    resources() {
      return Object.freeze({
        closed,
        inputBytes: source?.byteLength ?? 0,
        metadataLayers: layers.size,
        metadataTracks: tracks.size,
        pendingPlanBytes: [...plans.values()].reduce(
          (sum, p) => sum + (p.result?.bytes.length ?? 0),
          0,
        ),
        activeDecodes: Number(decoding),
        decodedCacheBytes: 0,
        materialCacheBytes: store?.materialCache.bytes ?? 0,
        materialCacheEntries: store?.materialCache.size ?? 0,
        rasterSources: rasters.size,
        playbackBytes,
        playbacks: playbacks.size,
      })
    },
    dispose() {
      if (closed) return
      closed = true
      lifetime.abort()
      for (const playback of playbacks) playback.dispose()
      for (const raster of rasters) raster.dispose()
      store?.dispose()
      store = undefined
      source = undefined
      layers.clear()
      tracks.clear()
      handles.clear()
      externals.clear()
      plans.clear()
    },
  }
  return Object.freeze(session)
}
export type DocumentSession = ReturnType<typeof openDocument>

/** New documents use a caller-provided empty animation template; no CLIP binary is bundled. */
export async function createDocument(
  SQL: SqlJsStatic,
  seed: Uint8Array,
  canvas: ClipCanvasSettings,
  options: SessionOptions = {},
) {
  validateCanvasPixels(canvas.width, canvas.height, options.maxCanvasPixels)
  check(seed instanceof Uint8Array && seed.length <= 512 * 1024 * 1024, 'LIMIT_INPUT_BYTES')
  const bytes = await createBytes(SQL, new Uint8Array(seed), { ...canvas }, options.signal)
  return openDocument(SQL, bytes, options)
}
