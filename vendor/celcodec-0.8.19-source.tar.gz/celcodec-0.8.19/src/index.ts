export * from './material/index.js'
export {
  openDocument,
  createDocument,
  serializeClipError,
  deserializeClipError,
} from './document/index.js'
export type {
  DocumentSession,
  SessionOptions,
  LayerRasterOptions,
  EditOperation,
  EditOptions,
  LayerAttributes,
  EditableKeyframeProperty,
  PropertyKeyTarget,
  TimelineFrameEdit,
  TrackTarget,
  DocumentView,
  CanvasView,
  AnimationFrameView,
  AnimationPaperSettings,
  AnimationPaperView,
  FrameAnchor,
  FrameInsets,
  FrameRectangle,
  LayerView,
  TimelineView,
  TrackView,
  MediaSourceView,
  BinaryHandle,
  EditPlan,
  EditImpact,
  SaveResult,
  Capability,
  LayerProperties,
  StoredOffset,
  NativeMetadata,
  Camera3DView,
  Object3DView,
  Layer3DView,
  PlaybackPolicy,
  PlaybackApplication,
  PlaybackLayerOverride,
  PlaybackTransform,
  PlaybackFrameOptions,
  PlaybackChannel,
  PlaybackLayer,
  PlaybackFrame,
  TimelinePlayback,
} from './document/index.js'
export { ClipError, diagnostic } from './diagnostics.js'
export { sampleKeyframeCurve } from './native/keyframes.js'
export type {
  KeyframeTimeRange,
  PropertyKeyframe,
  KeyframeUnit,
  KeyframeCurve,
  KeyframeParameter,
  KeyframeClip,
  KeyframeTrack,
  KeyframeReadOptions,
  KeyframeSample,
} from './native/keyframes.js'
export { diagnosticKinds } from './diagnostics.js'
export type { ClipDiagnostic, DiagnosticCode, DiagnosticKind } from './diagnostics.js'
export { DEFAULT_IMAGE_LIMITS, imageByteLength } from './image-resources.js'
export type { ImageResourceLimits, ImageRegion } from './image-resources.js'
