import { check } from '../internal/binary.js'
import { readAttribute } from '../internal/raster.js'
import { decodeRasterPixels } from '../internal/raster-decode.js'
import { readVectorStrokes, renderVectors } from '../internal/vector.js'
import {
  checkCancelled,
  diagnostic,
  type ClipDiagnostic,
  type DiagnosticCode,
} from '../diagnostics.js'
import type { ClipPixels, Inflate } from '../types.js'
import type { VectorBrushes, VectorStroke } from '../internal/vector.js'
import { resolveImageLimits, resourceLimit, type ImageResourceLimits } from '../image-resources.js'
export { DEFAULT_IMAGE_LIMITS, imageByteLength } from '../image-resources.js'
export type { ImageResourceLimits, ImageRegion } from '../image-resources.js'
export { createRasterSource } from './raster-source.js'
export type { RasterSource } from './raster-source.js'

export { ClipError, diagnostic } from '../diagnostics.js'
export type { ClipDiagnostic, DiagnosticCode, DiagnosticKind } from '../diagnostics.js'
export type { ClipPixels, Inflate } from '../types.js'
export type { ClipRow, ClipValue } from '../internal/records.js'
export type { VectorBrushes, VectorPoint, VectorStroke, BrushPattern } from '../internal/vector.js'
export type { OffscreenAttribute } from '../internal/raster.js'
export { readAttribute, readRaster } from '../internal/raster.js'
export { readVectorStrokes, renderVectors, sampleVectorStroke } from '../internal/vector.js'
export { VectorSurface } from '../internal/vector-surface.js'
export { createBrushTexture } from '../internal/vector-texture.js'
export type { BrushTexture } from '../internal/vector-texture.js'
export { readBrushDynamics, brushRandom } from '../internal/vector-dynamics.js'
export type { BrushDynamics } from '../internal/vector-dynamics.js'
export { cropPixels } from '../internal/pixels.js'
export {
  createMaterialDecoder,
  readMaterialEffects,
  readMaterialQuad,
  materialOffscreen,
} from '../internal/material.js'
export type { MaterialTables, MaterialDecoderOptions } from '../internal/material.js'
export { readTextObjects, readTextAttributes } from '../internal/text.js'
export { readGradient, readGradientKind, readSolidFillColor } from '../internal/gradient.js'
export { readAdjustment } from '../internal/adjustment.js'
export {
  readLayerKind,
  readMediaItemKind,
  readPaletteColor,
  isPaper,
  hasLayerMask,
} from '../internal/layer-metadata.js'
export { layerRenderingDiagnostics } from './diagnostics.js'
export type {
  ClipLayer,
  LayerContentKind,
  TextObject,
  MaterialQuad,
  MaterialEffects,
  MaterialAdjustment,
  EdgeEffect,
  WatercolorEffect,
} from './types.js'

/** Default per-operation budgets, not runtime ceilings or document acceptance policies. */
export const MATERIAL_LIMITS = Object.freeze({
  inputBytes: 1024 * 1024 * 1024,
  rasterPixels: 64 * 1024 * 1024,
  vectorPixels: 16 * 1024 * 1024,
  vectorSurfaceBytes: 256 * 1024 * 1024,
  brushPixels: 4 * 1024 * 1024,
  brushBytes: 512 * 1024 * 1024,
})

export interface DecodeOptions {
  signal?: AbortSignal
  /** Overrides the default input budget. */
  maxInputBytes?: number
  imageLimits?: ImageResourceLimits
}
export interface RasterOptions extends DecodeOptions {
  /** Decode only this source-local rectangle. Other tile payloads are not inflated. */
  region?: import('../image-resources.js').ImageRegion
  mask?: boolean
  crop?: boolean
  brushPattern?: boolean
  /** Maximum restored rectangle area; with crop, independent of offscreen dimensions. */
  maxPixels?: number
  inflate?: Inflate
}
export interface VectorOptions extends DecodeOptions {
  offsetX?: number
  offsetY?: number
  maxPixels?: number
  maxSurfaceBytes?: number
  maxBrushBytes?: number
  maxWork?: number
}
export interface MaterialResult {
  /** Missing raster data is returned explicitly as undefined; preserve that result shape. */
  pixels?: ClipPixels | undefined
  /** Inspect even when pixels exist: unsupported brushes can fall back or omit strokes. */
  diagnostics: ClipDiagnostic[]
}

function limit(value: number | undefined, maximum: number): number {
  const resolved = value ?? maximum
  return resourceLimit(resolved)
}
function checkInput(bytes: number, options: DecodeOptions): void {
  checkCancelled(options.signal)
  const maximum = limit(options.maxInputBytes, MATERIAL_LIMITS.inputBytes)
  check(bytes <= maximum, 'LIMIT_INPUT_BYTES', { actual: bytes, limit: maximum })
}

/** Parse one Offscreen.Attribute blob; no pixels, database or canvas is allocated. */
export function readRasterAttribute(
  bytes: Uint8Array,
  options: DecodeOptions & { brushPattern?: boolean } = {},
) {
  checkInput(bytes.byteLength, options)
  return readAttribute(bytes)
}

/** Restore one native offscreen. Inputs are read-only; output coordinates are local to it. */
export async function decodeRaster(
  attribute: Uint8Array,
  body?: Uint8Array,
  options: RasterOptions = {},
): Promise<MaterialResult> {
  checkInput(attribute.byteLength + (body?.byteLength ?? 0), options)
  const a = readAttribute(attribute)
  const limits = resolveImageLimits(options.imageLimits)
  const maximum = limit(options.maxPixels, limits.maxPixels)
  const pixels = await decodeRasterPixels(
    a,
    body,
    options.mask ?? false,
    options.crop ?? false,
    options,
    { maxPixels: maximum, maxBytes: limits.maxBytes },
  )
  return { pixels, diagnostics: pixels ? [] : [diagnostic('MISSING_RASTER_DATA')] }
}

/** Retain native positions, handles, flags, brush IDs and random state without rendering. */
export function decodeVectorStrokes(
  bytes: Uint8Array,
  options: DecodeOptions = {},
): VectorStroke[] {
  checkInput(bytes.byteLength, options)
  return readVectorStrokes(bytes, options.signal)
}

/** Approximate software rendering of raw native strokes; no DOM or Canvas dependency. */
export function renderVectorMaterial(
  bytes: Uint8Array,
  brushes: VectorBrushes,
  width: number,
  height: number,
  options: VectorOptions = {},
): MaterialResult {
  checkInput(bytes.byteLength, options)
  const imageLimits = resolveImageLimits(options.imageLimits, {
    maxPixels: MATERIAL_LIMITS.vectorPixels,
    maxBytes: MATERIAL_LIMITS.brushBytes,
  })
  const maximum = limit(options.maxPixels, imageLimits.maxPixels)
  const maxSurfaceBytes = limit(
    options.maxSurfaceBytes,
    options.imageLimits ? imageLimits.maxBytes : MATERIAL_LIMITS.vectorSurfaceBytes,
  )
  const maxBrushBytes = limit(options.maxBrushBytes, imageLimits.maxBytes)
  check(
    Number.isSafeInteger(width) && Number.isSafeInteger(height) && width > 0 && height > 0,
    'INVALID_IMAGE_DIMENSIONS',
  )
  for (const [brushId, style] of brushes.styles)
    for (const [field, value] of Object.entries(style)) {
      check(typeof value !== 'number' || Number.isFinite(value), 'INVALID_BRUSH_NUMBER', {
        brushId,
        field,
      })
    }
  // These guards lived in the original material-table resolver. Preserve them at
  // this new standalone boundary, including shared images counted only once.
  let brushBytes = 0
  const seen = new Set<Uint8Array>()
  for (const images of [brushes.patterns, brushes.textures])
    for (const image of images?.values() ?? []) {
      checkCancelled(options.signal)
      check(
        Number.isSafeInteger(image.width) &&
          Number.isSafeInteger(image.height) &&
          image.width > 0 &&
          image.height > 0 &&
          image.alpha instanceof Uint8Array &&
          image.alpha.byteLength === image.width * image.height,
        'INVALID_BRUSH_PATTERN',
      )
      check(
        image.width * image.height <=
          (options.imageLimits ? imageLimits.maxPixels : MATERIAL_LIMITS.brushPixels),
        'LIMIT_BRUSH_PIXELS',
      )
      if (!seen.has(image.alpha)) {
        // Reserve RGBA-equivalent source bytes as the original material decoder did.
        brushBytes += image.alpha.byteLength * 4
        seen.add(image.alpha)
      }
      check(brushBytes <= maxBrushBytes, 'LIMIT_BRUSH_BYTES', {
        actual: brushBytes,
        limit: maxBrushBytes,
      })
    }
  const diagnostics = bytes.byteLength ? [diagnostic('APPROXIMATE_VECTOR')] : []
  const report = (code: DiagnosticCode) => {
    const item = diagnostic(code)
    if (item.kind === 'resource-limit' || item.kind === 'malformed') item.severity = 'error'
    diagnostics.push(item)
  }
  const pixels = renderVectors(
    readVectorStrokes(bytes, options.signal),
    brushes,
    width,
    height,
    options.offsetX ?? 0,
    options.offsetY ?? 0,
    report,
    { ...options, imageLimits: { ...imageLimits, maxPixels: maximum }, maxSurfaceBytes },
  )
  return { pixels, diagnostics }
}
export type { ClipTextObject } from '../internal/text.js'

export type { AdjustmentChannels, AdjustmentCurve, AdjustmentLevels } from '../material/types.js'
