# Third-party notices

celcodec's own code is covered by [LICENSE](LICENSE). Adapted code retains its
original copyright notices. The sources and runtime dependency listed below are
MIT-licensed; their copyright notices and the common MIT permission and warranty
text below must accompany copies or substantial portions of that software.

## Adapted code

celcodec contains adapted MIT-licensed CLIP format, material and regression
tests from these repositories, inspected at the following revisions:

- csp-paperback: `9256c0326dcbb628ed8c601bf17253c3ca2300dd`,
  https://github.com/stechdrive/csp-paperback.
  [Original MIT license](https://github.com/stechdrive/csp-paperback/blob/9256c0326dcbb628ed8c601bf17253c3ca2300dd/LICENSE).
  Copyright (c) 2025 stechdrive.
- xsheet-remap: `6fb67280fdebb2ecd93e0fd0e369b47b4f29a6e8`,
  https://github.com/stechdrive/xsheet-remap.
  [Original MIT license](https://github.com/stechdrive/xsheet-remap/blob/6fb67280fdebb2ecd93e0fd0e369b47b4f29a6e8/LICENSE).
  Copyright (c) 2026 stechdrive.

Later empty-vector and diagnostic changes from csp-paperback
`864c39c9d38ee1517f1cc533df260bbaac932342` retain the
[same MIT license and copyright](https://github.com/stechdrive/csp-paperback/blob/864c39c9d38ee1517f1cc533df260bbaac932342/LICENSE).

The extraction covers containers, BINC, native layer/timeline/audio editing,
raster tiles, text/gradients, brush resolution, vector strokes, effects and
Canvas helpers. Types, diagnostics,
environment boundaries and resource cleanup have been adapted. Per-file source
hashes, comparison results and test omissions are recorded in the source
repository's `docs/provenance.json` and `docs/extraction.md`.

xsheet-remap originally adapted these modules from csp-paperback
`2809271ba06b6ed03322abbc45f8a4e7a81c44ff`, with later effect/diagnostic updates at
`a4547482bcad1a65ca1515072bb7a14269c502f2`. That older port is a comparison source,
not assumed to be equivalent to the current csp-paperback repository.

## Adapted algorithms and format research

The original sources also use implementations and format research from these MIT
projects. This includes adapted algorithms, not only research references; for
example, `src/internal/vector.ts` retains curve-sampling and brush-stamping code
adapted from animeops/clip-tools through csp-paperback. These projects are not
installed runtime dependencies. Their notices are retained here alongside the
attributions in the source files.

- wamsoft/clipparse, `322a273c0e059d1dee9132af78289efa12a59522`:
  https://github.com/wamsoft/clipparse — Offscreen layout, raster tile permutation
  and reference color blend equations. Native alpha/opacity behavior in
  `src/render` was independently measured; see `docs/compositing.md`.
  Copyright (c) 2026 wamsoft.
  [Original MIT license](https://github.com/wamsoft/clipparse/blob/322a273c0e059d1dee9132af78289efa12a59522/LICENSE).
- animeops/clip-tools, `8807134932a39a009c980fb29acd1ae934354a7c`:
  https://github.com/animeops/clip-tools — adapted vector curve sampling and brush
  stamping; BINC, CLIP structure, brush dynamics and text-layout research.
  Copyright (c) 2026 AnimeOps.
  [Original MIT license](https://github.com/animeops/clip-tools/blob/8807134932a39a009c980fb29acd1ae934354a7c/LICENSE).
- Aodaruma/clipfile-rs, `bd88467fa80e63ad48c6c713fbfb5a8a116d798a` and
  `b3c4aefe3ba944f47f27aaf0777cbffc1038e75c` (`clipfile-svg-v0.2.0`):
  https://github.com/Aodaruma/clipfile-rs — CLIP container, database, timeline and
  vector layouts, including the modern 92-byte header.
  Copyright (c) 2026 Aodaruma.
  [Original MIT license](https://github.com/Aodaruma/clipfile-rs/blob/bd88467fa80e63ad48c6c713fbfb5a8a116d798a/LICENSE)
  and [the SVG release license](https://github.com/Aodaruma/clipfile-rs/blob/b3c4aefe3ba944f47f27aaf0777cbffc1038e75c/LICENSE).
- dobrokot/clip_to_psd, `e8db68c768f52ec91ba7530820f52537261cbad0`:
  https://github.com/dobrokot/clip_to_psd — text attributes, fill and image-effect
  layout research. The upstream MIT notice reads "Copyright (c) 2024" without
  an additional author name.
  [Original MIT license](https://github.com/dobrokot/clip_to_psd/blob/e8db68c768f52ec91ba7530820f52537261cbad0/LICENSE).
- al3ks1s/clip-tools, `e1d3d7ed4701ac84e9220127daa73c2cf90dd803`:
  https://github.com/al3ks1s/clip-tools — CLIP container and SQLite extraction
  research referenced by xsheet-remap. The upstream MIT notice reads
  "Copyright (c) 2024" without an additional author name.
  [Original MIT license](https://github.com/al3ks1s/clip-tools/blob/e1d3d7ed4701ac84e9220127daa73c2cf90dd803/LICENCE).

## Runtime dependency

fflate 0.8.3, https://github.com/101arrowz/fflate, MIT.
Copyright (c) 2026 Arjun Barrett.
[Original MIT license](https://github.com/101arrowz/fflate/blob/v0.8.3/LICENSE).

This is celcodec's only declared runtime package dependency, with no transitive
runtime dependencies in the lockfile. It is installed as a separate package;
celcodec uses its bounded streaming zlib decoder and compression helpers. The
same MIT permission below applies. sql.js/WASM is supplied by the consumer and
is not bundled by celcodec; its own licenses and notices remain applicable when
the consumer distributes it.

## MIT permission notice for the above sources

This text applies separately to each source above, together with its listed
copyright notice.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Test data and development tools

Native CLIP templates, vector/effect goldens, timeline/media captures and their
provenance are retained in a private external corpus. No CLIP, captured JSON,
image or encoded copy of these assets is included in this repository or the npm
tarball. Tests and programmatic fixture builders remain in the repository;
they obtain native expectations through the private corpus accessor. The
source-only test suite does not require that corpus. See `docs/publication.md`
and `docs/development.md` for the separation and verification workflow.

Development tools are installed separately. Their code, browser binaries and
native libraries are not included in this repository or celcodec's package.
The direct development dependencies declare the following licenses:

- TypeScript, the TypeScript 6 compatibility package and Playwright: Apache-2.0.
- Vitest, Vite, Prettier, Oxlint, oxlint-tsgolint, Node.js and sql.js type
  definitions, sql.js and @napi-rs/canvas: MIT.

These tools and their transitive dependencies retain their own licenses and
notices. Fixed versions and integrity records are in `package-lock.json`; this
list does not relicense or redistribute them under celcodec's MIT notice.
