# Third-party notices

Copyright (c) 2025-2026 stechdrive. celcodec is licensed under the
[GNU General Public License](LICENSE), version 3 or (at your option) any later
version published by the Free Software Foundation (`GPL-3.0-or-later`).
The following attributions cover the adapted code, format research and runtime dependency.
The common MIT permission and warranty notice appears below.

## Adapted code

The container, raster, vector, text, effects, timeline and audio implementations
include code adapted from the following projects.

- **csp-paperback** — Copyright (c) 2025 stechdrive.
  [Original MIT license](https://github.com/stechdrive/csp-paperback/blob/9256c0326dcbb628ed8c601bf17253c3ca2300dd/LICENSE)
  and [license for later vector and diagnostic changes](https://github.com/stechdrive/csp-paperback/blob/864c39c9d38ee1517f1cc533df260bbaac932342/LICENSE).
- **xsheet-remap** — Copyright (c) 2026 stechdrive.
  [Original MIT license](https://github.com/stechdrive/xsheet-remap/blob/6fb67280fdebb2ecd93e0fd0e369b47b4f29a6e8/LICENSE).

xsheet-remap originally adapted these modules from csp-paperback
`2809271ba06b6ed03322abbc45f8a4e7a81c44ff`, with later effect/diagnostic updates at
`a4547482bcad1a65ca1515072bb7a14269c502f2`.

## Adapted algorithms and format research

- **wamsoft/clipparse** — Offscreen layout, raster tile permutation and reference
  color blend equations.
  Copyright (c) 2026 wamsoft.
  [Original MIT license](https://github.com/wamsoft/clipparse/blob/322a273c0e059d1dee9132af78289efa12a59522/LICENSE).
- **animeops/clip-tools** — Vector curve sampling and brush stamping adapted
  through csp-paperback. Also used for BINC, CLIP structure, brush dynamics
  and text-layout research.
  Copyright (c) 2026 AnimeOps.
  [Original MIT license](https://github.com/animeops/clip-tools/blob/8807134932a39a009c980fb29acd1ae934354a7c/LICENSE).
- **nekomimianko/clipvec** — CLIP format research on closed strokes, pen
  inputs and corner records.
  Copyright (c) 2026 nekomimianko.
  [Format study](https://github.com/nekomimianko/clipvec/blob/29130f54311b35f7d8bd4c1d1d357a5a9253f1cd/docs/CLIP_FORMAT_SPEC.md)
  and [original MIT license](https://github.com/nekomimianko/clipvec/blob/29130f54311b35f7d8bd4c1d1d357a5a9253f1cd/LICENSE).
- **Aodaruma/clipfile-rs** — CLIP container, database, timeline and vector
  layouts, including the 92-byte stroke header.
  Copyright (c) 2026 Aodaruma.
  [Original MIT license](https://github.com/Aodaruma/clipfile-rs/blob/bd88467fa80e63ad48c6c713fbfb5a8a116d798a/LICENSE)
  and [the SVG release license](https://github.com/Aodaruma/clipfile-rs/blob/b3c4aefe3ba944f47f27aaf0777cbffc1038e75c/LICENSE).
- **dobrokot/clip_to_psd** — Text attributes, fill and image-effect layouts.
  The upstream copyright notice reads “Copyright (c) 2024”.
  [Original MIT license](https://github.com/dobrokot/clip_to_psd/blob/e8db68c768f52ec91ba7530820f52537261cbad0/LICENSE).
- **al3ks1s/clip-tools** — CLIP container and SQLite extraction research used
  by xsheet-remap. The upstream copyright notice reads “Copyright (c) 2024”.
  [Original MIT license](https://github.com/al3ks1s/clip-tools/blob/e1d3d7ed4701ac84e9220127daa73c2cf90dd803/LICENCE).

## Runtime dependency

**fflate 0.8.3** provides streaming zlib decompression and compression.
Copyright (c) 2026 Arjun Barrett.
[Original MIT license](https://github.com/101arrowz/fflate/blob/v0.8.3/LICENSE).

The caller supplies sql.js and its WASM runtime separately, under their own
licenses.

## MIT permission notice for the above sources

This text applies separately to each source above, together with its listed
copyright notice.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
