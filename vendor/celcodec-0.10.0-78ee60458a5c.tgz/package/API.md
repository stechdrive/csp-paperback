# celcodec API

`openDocument(SQL, bytes)` は `DocumentSession` を返します。新規作成の `createDocument` は `Promise<DocumentSession>` を返します。`SQL` は利用側で初期化した sql.js、`bytes` は CLIP の `Uint8Array` です。文書の読み取り・編集は DOM なしで使えます。

| 目的                                   | 公開API                                                                                        | 選ぶときの目安                                                                                                   |
| -------------------------------------- | ---------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| レイヤー階層・タイムライン・音声を読む | `celcodec` の `openDocument` → `session.document`、`session.readTimeline`、`session.readAudio` | 階層とタイムラインの ID は `session.document` から取得できます。                                                 |
| レイヤーの生画素を領域単位で読む       | `session.openLayerRaster` → `readRegion` / `tiles`                                             | 座標は保存ラスタ上の位置です。配置・変形・効果を適用する前の画素を返します。                                     |
| 1レイヤーの素材を復元する              | `session.decodeLayer`                                                                          | 復元した素材と診断を返します。テキストや複数の画像断片として返る場合もあります。                                 |
| 保存された階層を文書画像に合成する     | `celcodec/render` の `createDocumentRenderer`                                                  | 用紙・マスク・効果を含む文書座標の描画です。`layerId` でサブツリーを指定できます。                               |
| アニメーションの指定フレームを扱う     | `session.createPlayback` / `celcodec/render` の `createFrameRenderer`                          | 前者は表示状態の評価、後者は画素の描画に使います。フレーム位置は再生開始からの相対値です。                       |
| 独自のレイヤー構成を合成する           | `celcodec/render` の `createCompositionRenderer`                                               | `RenderNode.id` は配置ごとに一意、`layerId` は元レイヤーの UUID です。                                           |
| 既存文書を編集して保存する             | `session.planEdits` → `session.save`                                                           | 同じセッションで許可された計画を1回保存できます。続けて編集するには、返った `bytes` を開き直します。             |
| 新規文書を作る                         | `celcodec` の `createDocument(SQL, seed, canvas)`                                              | 用紙・アニメーションフォルダー・空のラスターセル・タイムラインを各1つ持つ空の CLIP を用意し、`seed` に渡します。 |

## 所有権と診断

- 入力は既定でコピーします。`ownership: 'borrow'` の場合は `session.dispose()` まで元のバイト列を変更しないでください。レンダラーを使い終えたら `renderer.dispose()` を呼び、最後に `session.dispose()` で文書を解放します。
- 編集操作は `EditOperation` の `type` で選びます。`planEdits` は呼び出し時に操作をコピーします。編集の拒否は `allowed: false` と `diagnostics` で返り、資源上限とキャンセルでは例外が発生します。保持できる許可済み計画は1件です。保存せず手放すには `discardPlan` を使います。
- 文書・フレーム・構成のレンダラーには `canvas` ファクトリーを渡します。描画結果は `status` と `diagnostics[].code` を確認します。画素を返した結果にも近似の診断が付くことがあります。

低水準の入口は `celcodec/read`（コンテナ・タイムライン）、`celcodec/write`（ラスタ符号化など）、`celcodec/material`（素材復元）、`celcodec/canvas`（Canvas・効果）、`celcodec/binary`（バイナリ操作）です。文書セッションの型とファクトリーは `celcodec/document` からもインポートできます。各入口の型定義は [package.json の exports](package.json) から辿れます。
