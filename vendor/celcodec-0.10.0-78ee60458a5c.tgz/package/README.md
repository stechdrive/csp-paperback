# celcodec

CLIP STUDIO PAINTの `.clip` ファイルを読み取り、編集・保存・描画する非公式TypeScriptライブラリです。一部の素材や効果には近似・未対応があります。

An unofficial TypeScript library for reading, editing, saving, and rendering CLIP STUDIO PAINT `.clip` files. Some materials and effects are approximated or unsupported.

[API](API.md) · [GPL-3.0-or-later](LICENSE) · [第三者ライセンス / Third-party notices](THIRD_PARTY_NOTICES.md)
