import { existsSync, lstatSync, rmSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import assert from 'node:assert/strict'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..'),
  output = resolve(root, 'dist')
assert.equal(dirname(output), root)
if (existsSync(output)) {
  assert.ok(!lstatSync(output).isSymbolicLink(), 'Refuse a linked build directory')
  rmSync(output, { recursive: true })
}
const compiler = fileURLToPath(new URL('./bin/tsc', import.meta.resolve('typescript/package.json')))
const result = spawnSync(process.execPath, [compiler], {
  cwd: root,
  stdio: 'inherit',
  windowsHide: true,
})
if (result.error) throw result.error
process.exitCode = result.status ?? 1
