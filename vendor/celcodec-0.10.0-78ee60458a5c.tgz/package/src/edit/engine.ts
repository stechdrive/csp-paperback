import { isArrayValue, requiredAt } from '../internal/indexed.js'
import { check, layerUuid, utf8, externalId } from '../native/binary.js'
import { ClipContainer, type Row } from '../native/container.js'
import type { SqlJsStatic } from '../native/sql.js'
import { normalizedUuid, optionalRows } from '../native/layer-metadata.js'
import { createLayer, mipmapChain } from '../native/layers.js'
import { placePixels } from '../native/raster.js'
import {
  checkImageAllocation,
  resolveImageLimits,
  type ImageResourceLimits,
} from '../image-resources.js'
import {
  ensureAnimationStorage,
  ensureAnimationFolderStorage,
} from '../native/animation-storage.js'
import { animationMixer, packedMixer, trackValueMap } from '../native/animation.js'
import { createLabelEditor } from '../features/labels.js'
import { writeAudioTimeline } from '../native/audio-writer.js'
import {
  renameCelReferences,
  referencedCelNames,
  newCelClip,
  insertCelClip,
  removeTrackClip,
  setCelKeys,
  hasSingleCelClip,
} from '../features/cel-track.js'
import { BincDocument, bincWriteLimits } from '../native/binc.js'
import { child } from '../features/mixer-edit.js'
import { isLightTableReference } from '../internal/layer-metadata.js'
import { readAttribute } from '../internal/raster.js'
import { setAnimationState } from '../features/animation-state.js'
import { replaceRasterPixels } from '../features/raster-edit.js'
import { editCanvas } from '../features/canvas-edit.js'
import {
  timelineRange,
  editTrackClip,
  preserveTrackFrames,
  scaleFrame,
} from '../features/timeline.js'
import { readAnimation } from '../native/read-animation.js'
import { editClipStructure } from '../features/clip-structure.js'
import { editTimelineStructure } from '../features/timeline-structure.js'
import { editTimelineFrames } from '../features/timeline-frames.js'
import { editPropertyKey } from '../features/property-keys.js'
import { checkCancelled, ClipError } from '../diagnostics.js'
import type { SaveResult } from '../document/types.js'
import type { EditOperation, EditOptions, LayerAttributes, TrackTarget } from './operations.js'

const idBytes = (id: string) => {
  check(/^[0-9a-f]{32}$/.test(id), 'INVALID_UUID')
  return Uint8Array.from(id.match(/../g)!, (v) => parseInt(v, 16))
}
const string = (value: unknown) =>
  check(typeof value === 'string' && value.length <= 65535, 'INVALID_EDIT')
const integer = (value: unknown) => check(Number.isSafeInteger(value), 'INVALID_EDIT')
const fields: Record<EditOperation['type'], readonly string[]> = {
  resizeCanvas: ['type', 'width', 'height', 'anchor'],
  setAnimationPaper: ['type', 'settings', 'contentAnchor'],
  renameLayer: ['type', 'layerId', 'name'],
  setLayerAttributes: ['type', 'layerId', 'attributes'],
  replaceRasterPixels: ['type', 'layerId', 'pixels', 'left', 'top'],
  setCameraDisplay: ['type', 'layerId', 'mode'],
  setLayerKeyframesEnabled: ['type', 'layerId', 'enabled'],
  addLayer: ['type', 'id', 'parentId', 'index', 'name', 'kind', 'pixels', 'left', 'top'],
  moveLayer: ['type', 'layerId', 'parentId', 'index', 'celReferences', 'crossAnimationTracks'],
  removeLayer: ['type', 'layerId', 'recursive'],
  createTimeline: ['type', 'id', 'name', 'fps', 'startFrame', 'endFrame'],
  setTimeline: ['type', 'timelineId', 'name', 'fps', 'startFrame', 'endFrame', 'timingPolicy'],
  setTimelineFrameRate: ['type', 'timelineId', 'fps', 'timingPolicy', 'mediaTiming'],
  setActiveTimeline: ['type', 'timelineId'],
  duplicateTimeline: ['type', 'timelineId', 'id', 'name', 'index'],
  removeTimeline: ['type', 'timelineId'],
  moveTimeline: ['type', 'timelineId', 'index'],
  insertTimelineFrames: [
    'type',
    'timelineId',
    'frameOrigin',
    'frame',
    'count',
    'trackIds',
    'trackLabels',
    'timelineLabels',
    'playbackRange',
    'crossingClips',
  ],
  removeTimelineFrames: [
    'type',
    'timelineId',
    'frameOrigin',
    'frame',
    'count',
    'trackIds',
    'trackLabels',
    'timelineLabels',
    'playbackRange',
    'crossingClips',
  ],
  moveTrackClip: ['type', 'trackId', 'clipIndex', 'frameOrigin', 'startFrame'],
  trimTrackClip: ['type', 'trackId', 'clipIndex', 'frameOrigin', 'startFrame', 'endFrame'],
  extendTrackClip: ['type', 'trackId', 'clipIndex', 'frameOrigin', 'startFrame', 'endFrame'],
  splitTrackClip: ['type', 'trackId', 'clipIndex', 'frameOrigin', 'frame'],
  joinTrackClips: ['type', 'trackId', 'clipIndex', 'nextClipIndex'],
  setPropertyKey: [
    'type',
    'trackId',
    'clipIndex',
    'property',
    'axis',
    'frameOrigin',
    'frame',
    'value',
    'interpolation',
    'leftSlope',
    'rightSlope',
    'handleMode',
  ],
  movePropertyKey: [
    'type',
    'trackId',
    'clipIndex',
    'property',
    'axis',
    'frameOrigin',
    'frame',
    'toFrame',
  ],
  removePropertyKey: ['type', 'trackId', 'clipIndex', 'property', 'axis', 'frameOrigin', 'frame'],
  setCelKeys: ['type', 'timelineId', 'layerId', 'clipIndex', 'frameOrigin', 'keys'],
  insertCelClip: ['type', 'timelineId', 'layerId', 'frameOrigin', 'startFrame', 'endFrame', 'keys'],
  removeTrackClip: ['type', 'trackId', 'clipIndex'],
  setTrackLabel: ['type', 'trackId', 'frame', 'kind', 'labelId'],
  removeTrackLabel: ['type', 'trackId', 'labelId'],
  replaceAudio: ['type', 'timelineId', 'audio', 'namespace'],
}
for (const names of Object.values(fields))
  if (names.includes('trackId')) (names as string[]).push('timelineId', 'layerId')

/** Execute on an isolated write database. No caller-visible result escapes before every operation succeeds. */
export async function applyEdits(
  SQL: SqlJsStatic,
  source: Uint8Array,
  operations: readonly EditOperation[],
  options: EditOptions & {
    maxCanvasPixels?: number
    imageLimits?: ImageResourceLimits
    maxContainerBytes?: number
  } = {},
): Promise<SaveResult> {
  check(isArrayValue(operations) && operations.length <= 100000, 'LIMIT_DOCUMENT_ITEMS')
  checkCancelled(options.signal)
  if (!operations.length)
    return {
      bytes: new Uint8Array(source),
      changed: false,
      impact: {
        changedRows: [],
        addedExternalBlobs: 0,
        invalidatedLayerIds: [],
        preservation: 'original-bytes',
      },
    }
  const clip = new ClipContainer(SQL, source, options.signal, options)
  let seed: ClipContainer | undefined
  const getSeed = () => {
    check(options.seed, 'MISSING_ANIMATION_TEMPLATE')
    return (seed ??= new ClipContainer(SQL, options.seed, options.signal, options))
  }
  try {
    const canvas = requiredAt(clip.rows('Canvas'), 0)
    const layers = new Map(clip.rows('Layer').map((row) => [normalizedUuid(row.LayerUuid), row]))
    const byId = new Map([...layers.values()].map((row) => [Number(row.MainId), row]))
    const root = byId.get(Number(canvas.CanvasRootFolder))
    check(root, 'MISSING_ROOT_LAYER')
    const rootAttribute = root.LayerRenderMipmap
      ? mipmapChain(clip, root.LayerRenderMipmap)[0]?.off.Attribute
      : undefined
    const dimensions =
      rootAttribute instanceof Uint8Array ? readAttribute(rootAttribute) : undefined
    check(dimensions || !canvas.CanvasUnit, 'UNSUPPORTED_CANVAS_UNIT')
    let width = dimensions?.width ?? Number(canvas.CanvasWidth),
      height = dimensions?.height ?? Number(canvas.CanvasHeight)
    const parent = new Map<number, number>(),
      children = new Map<number, number[]>()
    const refreshLayers = () => {
      for (const row of clip.rows('Layer')) {
        const current = byId.get(Number(row.MainId)) ?? row
        Object.assign(current, row)
        layers.set(normalizedUuid(current.LayerUuid), current)
        byId.set(Number(current.MainId), current)
      }
      parent.clear()
      children.clear()
      for (const row of layers.values()) {
        let next = Number(row.LayerFirstChildIndex)
        const ids: number[] = [],
          seen = new Set<number>()
        while (next) {
          check(!seen.has(next) && byId.has(next), 'INVALID_REFERENCE_CHAIN')
          seen.add(next)
          check(!parent.has(next), 'INVALID_LAYER_TREE')
          parent.set(next, Number(row.MainId))
          ids.push(next)
          next = Number(byId.get(next)!.LayerNextIndex)
        }
        children.set(Number(row.MainId), ids.reverse())
      }
    }
    refreshLayers()
    let timelines = optionalRows(clip, 'TimeLine'),
      tracks = optionalRows(clip, 'Track')
    const dirty = new Set<number>(),
      detached = new Set<number>()
    let editLabel = createLabelEditor(clip)
    const layer = (id: string) => {
      const row = layers.get(id)
      check(row && row !== root && !detached.has(Number(row.MainId)), 'MISSING_ROW')
      check(!isLightTableReference(row), 'UNSUPPORTED_EDIT', {
        reason: 'light-table-reference-edit',
      })
      return row
    }
    const timeline = (id: string) => {
      const row = timelines.find((row) => normalizedUuid(row.TimeLineUuid) === id)
      check(row, 'MISSING_ROW')
      const bank = optionalRows(clip, 'AnimationCutBank').find((b) => b.MainId === row.BankId)
      check(bank && orderedTimelines(bank).includes(row), 'MISSING_ROW')
      return row
    }
    const patch = (table: string, row: Row, changes: Record<string, Row[string] | undefined>) => {
      check(
        Object.keys(changes).every((key) => Object.hasOwn(row, key)),
        'UNSUPPORTED_EDIT',
        { table },
      )
      clip.update(table, row.MainId, changes)
      Object.assign(row, changes)
    }
    const selectBank = (bank: Row) => {
      const projects = clip.rows('Project'),
        project = projects[0]
      check(
        projects.length === 1 && project && Object.hasOwn(project, 'ProjectCutBank'),
        'UNSUPPORTED_EDIT',
      )
      if (project.ProjectCutBank === bank.MainId) return
      if (Object.hasOwn(project, 'MainId'))
        patch('Project', project, { ProjectCutBank: bank.MainId })
      else {
        // Native Project uses _PW_ID rather than MainId in current PAINT saves.
        check(Number.isSafeInteger(project._PW_ID), 'MISSING_ROW_ID')
        clip.db.run('UPDATE Project SET ProjectCutBank=? WHERE _PW_ID=?', [
          bank.MainId!,
          project._PW_ID!,
        ])
        clip.changes.set(`Project:${String(project._PW_ID)}`, {
          table: 'Project',
          id: Number(project._PW_ID),
        })
      }
    }
    const invalidate = (id: number) => {
      const seen = new Set<number>()
      while (id) {
        check(!seen.has(id), 'INVALID_LAYER_CYCLE')
        seen.add(id)
        dirty.add(id)
        id = parent.get(id) ?? 0
      }
    }
    const invalidateClippingContext = (id: number) => {
      const siblings = children.get(parent.get(id) ?? 0) ?? []
      // Changing a base can switch clipped pass-through siblings between
      // isolation and backdrop composition. Descendant folder caches also
      // depend on that context, even when their own saved attributes are unchanged.
      for (let i = siblings.indexOf(id); i >= 0; i--) {
        const sibling = siblings[i]!
        if (sibling !== id && !byId.get(sibling)!.LayerClip) break
        const pending = [sibling]
        while (pending.length) {
          const child = pending.pop()!
          if (!(Number(byId.get(child)!.LayerFolder) & 1)) continue
          dirty.add(child)
          for (const next of children.get(child) ?? []) pending.push(next)
        }
      }
    }
    const orderedTracks = (time: Row) => {
      const map = new Map(
          tracks
            .filter((t) => t.BankId === time.BankId && t.ItemId === time.MainId)
            .map((t) => [Number(t.MainId), t]),
        ),
        result: Row[] = [],
        seen = new Set<number>()
      let next = Number(time.FirstTrack)
      while (next) {
        const row = map.get(next)
        check(row && !seen.has(next), 'INVALID_REFERENCE_CHAIN')
        seen.add(next)
        result.push(row)
        next = Number(row.TrackNextIndex)
      }
      return result
    }
    const detachLayerTracks = (uuids: ReadonlySet<string>) => {
      for (const time of timelines) {
        const ordered = orderedTracks(time),
          retained = ordered.filter((t) => !uuids.has(normalizedUuid(t.LayerUuidWithTrack)))
        for (const t of ordered.filter((t) => uuids.has(normalizedUuid(t.LayerUuidWithTrack))))
          check([1000, 2000, 2003, 2005, 4001].includes(Number(t.TrackKind)), 'UNSUPPORTED_EDIT', {
            trackId: Number(t.MainId),
          })
        if (retained.length !== ordered.length) {
          patch('TimeLine', time, { FirstTrack: retained[0]?.MainId ?? 0 })
          retained.forEach((t, i) =>
            patch('Track', t, { TrackNextIndex: retained[i + 1]?.MainId ?? 0 }),
          )
        }
      }
    }
    const orderedTimelines = (bank: Row) => {
      const result: Row[] = [],
        seen = new Set<number>()
      let next = Number(bank.FirstTimeLine)
      while (next) {
        const row = timelines.find((t) => t.MainId === next && t.BankId === bank.MainId)
        check(row && !seen.has(next), 'INVALID_REFERENCE_CHAIN')
        seen.add(next)
        result.push(row)
        next = Number(row.NextTimeLine)
      }
      return result
    }
    const invalidateTimeline = (time: Row) => {
      for (const track of orderedTracks(time)) {
        const affected = layers.get(normalizedUuid(track.LayerUuidWithTrack))
        if (affected) invalidate(Number(affected.MainId))
      }
    }
    const trackTarget = (target: TrackTarget) => {
      let id = target.trackId
      if (id === undefined) {
        check(
          typeof target.timelineId === 'string' && typeof target.layerId === 'string',
          'INVALID_EDIT',
        )
        const time = timeline(target.timelineId)
        layer(target.layerId)
        const matches = orderedTracks(time).filter(
          (t) => normalizedUuid(t.LayerUuidWithTrack) === target.layerId,
        )
        check(matches.length <= 1, 'DUPLICATE_LAYER_TRACK')
        check(matches.length === 1, 'MISSING_TRACK')
        id = Number(matches[0]!.MainId)
      } else {
        check(
          Number.isSafeInteger(id) &&
            target.timelineId === undefined &&
            target.layerId === undefined,
          'INVALID_EDIT',
        )
      }
      const track = tracks.find((t) => t.MainId === id),
        time =
          track && timelines.find((t) => t.MainId === track.ItemId && t.BankId === track.BankId)
      check(track && time && orderedTracks(time).includes(track), 'MISSING_TRACK')
      timeline(normalizedUuid(time.TimeLineUuid))
      return { track, time }
    }
    const activeTracks = () =>
      optionalRows(clip, 'AnimationCutBank').flatMap((bank) =>
        orderedTimelines(bank).flatMap(orderedTracks),
      )
    const celTracks = (row: Row) =>
      activeTracks().filter(
        (t) => normalizedUuid(t.LayerUuidWithTrack) === normalizedUuid(row.LayerUuid),
      )
    const effectiveCel = (p: Row, name: string) =>
      (children.get(Number(p.MainId)) ?? []).findLast((id) => {
        const row = byId.get(id)!
        return !isLightTableReference(row) && row.LayerName === name
      })
    const changeReferences = (p: Row, names: ReadonlyMap<string, string | null>) => {
      for (const t of celTracks(p)) {
        check(t.TrackKind === 2000, 'UNSUPPORTED_CEL_EDIT')
        renameCelReferences(clip, t, names)
        Object.assign(t, clip.row('Track', t.MainId))
      }
      invalidate(Number(p.MainId))
    }
    const ancestors = (row: Row) => {
      const list: Row[] = []
      let id = parent.get(Number(row.MainId))
      while (id) {
        check(list.length < 100, 'LIMIT_LAYER_DEPTH')
        const p = byId.get(id)!
        list.push(p)
        id = parent.get(id)
      }
      return list
    }
    // PAINT traverses ordinary folder tracks to reach nested animation tracks.
    // A valid cel mixer alone is insufficient: missing ancestors hide the timeline.
    const ensureFolderTrack = (time: Row, row: Row) => {
      if (
        row === root ||
        row.AnimationFolder ||
        detached.has(Number(row.MainId)) ||
        isLightTableReference(row) ||
        ancestors(row).some((a) => a.AnimationFolder) ||
        orderedTracks(time).some(
          (t) => normalizedUuid(t.LayerUuidWithTrack) === normalizedUuid(row.LayerUuid),
        )
      )
        return
      check(row.LayerFolder === 1 && row.LayerType === 0, 'UNSUPPORTED_EDIT', {
        reason: 'missing-ancestor-track-kind',
        layerId: normalizedUuid(row.LayerUuid),
      })
      const s = getSeed(),
        template = s.rows('Track').find((t) => t.TrackKind === 2003)
      check(template, 'MISSING_ANIMATION_TEMPLATE')
      const attrs: Row = {}
      for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
        const raw = animationMixer(
          s.body(template[field])!,
          [{ frame: Number(time.StartFrame), value: null }],
          Number(time.EndFrame),
          Number(time.FrameRate),
        )
        attrs[field] = clip.addExternal(packedMixer(raw))
        attrs[`${field}Size`] = raw.length
      }
      const previous = orderedTracks(time).at(-1)
      const track = clip.insert('Track', template, {
        ...attrs,
        BankId: time.BankId,
        ItemId: time.MainId,
        TrackUuid: idBytes(crypto.randomUUID().replaceAll('-', '')),
        LayerUuidWithTrack: idBytes(normalizedUuid(row.LayerUuid)),
        TrackKind: 1000,
        TrackOpen: 1,
        TrackNextIndex: 0,
        TrackLabelFirstIndex: 0,
      })
      if (previous) patch('Track', previous, { TrackNextIndex: track.MainId })
      else patch('TimeLine', time, { FirstTrack: track.MainId })
      tracks.push(track)
    }
    const renameReferences = (row: Row, name: string | null) => {
      const p = byId.get(parent.get(Number(row.MainId)) ?? 0)
      if (!p?.AnimationFolder || isLightTableReference(row)) return
      // CSP retains the old name while any sibling still owns it, even if the renamed cel was displayed.
      const remaining = (children.get(Number(p.MainId)) ?? []).some(
        (id) =>
          id !== row.MainId &&
          !isLightTableReference(byId.get(id)!) &&
          byId.get(id)!.LayerName === row.LayerName,
      )
      if (name !== null)
        check(
          !(children.get(Number(p.MainId)) ?? []).some(
            (id) =>
              id !== row.MainId &&
              !isLightTableReference(byId.get(id)!) &&
              byId.get(id)!.LayerName === name,
          ),
          'INVALID_CEL_KEYS',
        )
      if (!remaining) changeReferences(p, new Map([[String(row.LayerName), name]]))
    }
    const link = (parentId: number) => {
      const ids = [...(children.get(parentId) ?? [])].reverse(),
        p = byId.get(parentId)!
      const changed =
        p.LayerFirstChildIndex !== (ids[0] ?? 0) ||
        ids.some((id, index) => byId.get(id)!.LayerNextIndex !== (ids[index + 1] ?? 0))
      patch('Layer', p, { LayerFirstChildIndex: ids[0] ?? 0 })
      ids.forEach((id, index) =>
        patch('Layer', byId.get(id)!, { LayerNextIndex: ids[index + 1] ?? 0 }),
      )
      if (changed) invalidate(parentId)
    }
    const attributes = (row: Row, attrs: LayerAttributes) => {
      check(
        attrs &&
          Object.keys(attrs).every((key) =>
            [
              'visible',
              'opacity',
              'blendMode',
              'clipping',
              'locked',
              'expanded',
              'labelColor',
              'maskEnabled',
              'maskLinked',
            ].includes(key),
          ),
        'INVALID_LAYER_ATTRIBUTE',
      )
      const values: Row = {}
      for (const key of [
        'visible',
        'clipping',
        'locked',
        'expanded',
        'maskEnabled',
        'maskLinked',
      ] as const)
        if (attrs[key] !== undefined)
          check(typeof attrs[key] === 'boolean', 'INVALID_LAYER_ATTRIBUTE')
      if (attrs.visible !== undefined)
        values.LayerVisibility = (Number(row.LayerVisibility) & ~1) | Number(attrs.visible)
      if (attrs.clipping !== undefined) {
        // Do not silently invent or normalize a future/unknown clipping encoding.
        check(row.LayerClip === 0 || row.LayerClip === 1, 'UNSUPPORTED_EDIT')
        values.LayerClip = Number(attrs.clipping)
      }
      if (attrs.maskEnabled !== undefined) {
        check(Number(row.LayerLayerMaskMipmap) > 0, 'UNSUPPORTED_EDIT')
        values.LayerVisibility =
          (Number(values.LayerVisibility ?? row.LayerVisibility) & ~2) | (attrs.maskEnabled ? 2 : 0)
      }
      if (attrs.maskLinked !== undefined) {
        check(
          Number(row.LayerLayerMaskMipmap) > 0 || Number(row.TimeLineOriginalMaskMipmap) > 0,
          'UNSUPPORTED_EDIT',
        )
        const selection = row.LayerSelect
        check(
          typeof selection === 'number' &&
            Number.isInteger(selection) &&
            selection >= 0 &&
            selection <= 0xffffffff,
          'UNSUPPORTED_EDIT',
        )
        // Native A/B: the link checkbox changes only this bit, not LayerMasking or mask coordinates.
        values.LayerSelect = ((selection & ~0x100) | (attrs.maskLinked ? 0x100 : 0)) >>> 0
      }
      if (attrs.opacity !== undefined) {
        check(
          Number.isFinite(attrs.opacity) && attrs.opacity >= 0 && attrs.opacity <= 1,
          'INVALID_LAYER_ATTRIBUTE',
        )
        values.LayerOpacity = Math.round(attrs.opacity * 256)
      }
      if (attrs.blendMode !== undefined) {
        integer(attrs.blendMode)
        values.LayerComposite = attrs.blendMode
      }
      if (attrs.locked !== undefined) {
        check(row.LayerType !== 1584 || attrs.locked, 'UNSUPPORTED_EDIT')
        values.LayerLock = Number(attrs.locked)
      }
      if (attrs.expanded !== undefined) {
        check(Number(row.LayerFolder) & 1, 'UNSUPPORTED_EDIT')
        values.LayerFolder = (Number(row.LayerFolder) & ~16) | (attrs.expanded ? 0 : 16)
      }
      if (attrs.labelColor !== undefined) {
        check(
          attrs.labelColor === null || /^#[0-9a-f]{6}$/i.test(attrs.labelColor),
          'INVALID_PALETTE_COLOR',
        )
        values.LayerUsePaletteColor = Number(attrs.labelColor !== null)
        if (attrs.labelColor) {
          const c = attrs.labelColor
            .slice(1)
            .match(/../g)!
            .map((c) => parseInt(c, 16) * 0x01010101)
          Object.assign(values, {
            LayerPaletteRed: c[0],
            LayerPaletteGreen: c[1],
            LayerPaletteBlue: c[2],
          })
        }
      }
      const renderingChanged = [
        'LayerVisibility',
        'LayerOpacity',
        'LayerComposite',
        'LayerClip',
      ].some((key) => Object.hasOwn(values, key) && row[key] !== values[key])
      const clippingChanged = values.LayerClip !== undefined && row.LayerClip !== values.LayerClip
      patch('Layer', row, values)
      if (renderingChanged) invalidate(Number(row.MainId))
      if (clippingChanged) invalidateClippingContext(Number(row.MainId))
    }
    for (const [index, operation] of operations.entries()) {
      checkCancelled(options.signal)
      try {
        check(
          operation &&
            Object.hasOwn(fields, operation.type) &&
            Object.keys(operation).every((key) => fields[operation.type].includes(key)),
          'INVALID_EDIT',
        )
        switch (operation.type) {
          case 'resizeCanvas':
          case 'setAnimationPaper': {
            const result = editCanvas(
              {
                clip,
                canvas,
                width,
                height,
                layers: layers.values(),
                patch,
                invalidate,
                signal: options.signal,
                maxCanvasPixels: options.maxCanvasPixels,
              },
              operation,
            )
            width = result.width
            height = result.height
            // Canvas translation rewrites mixers on every timeline, including inactive tracks.
            tracks = optionalRows(clip, 'Track')
            break
          }
          case 'renameLayer': {
            const row = layer(operation.layerId)
            string(operation.name)
            if (row.LayerName !== operation.name) {
              renameReferences(row, operation.name)
              patch('Layer', row, { LayerName: operation.name })
            }
            break
          }
          case 'setLayerAttributes':
            attributes(layer(operation.layerId), operation.attributes)
            break
          case 'replaceRasterPixels': {
            const row = layer(operation.layerId)
            patch(
              'Layer',
              row,
              replaceRasterPixels(
                clip,
                row,
                operation.pixels,
                operation.left,
                operation.top,
                width,
                height,
                ancestors(row),
              ),
            )
            invalidate(Number(row.MainId))
            invalidateClippingContext(Number(row.MainId))
            break
          }
          case 'setCameraDisplay':
          case 'setLayerKeyframesEnabled': {
            const isCamera = operation.type === 'setCameraDisplay'
            check(
              isCamera
                ? ['apply', 'ignore'].includes(operation.mode)
                : typeof operation.enabled === 'boolean',
              'INVALID_EDIT',
            )
            setAnimationState(
              { clip, byId, children, tracks, ancestors, patch, invalidate },
              layer(operation.layerId),
              isCamera ? 'camera' : 'keyframes',
              isCamera ? operation.mode === 'apply' : operation.enabled,
            )
            break
          }
          case 'addLayer': {
            idBytes(operation.id)
            check(!layers.has(operation.id), 'DUPLICATE_LAYER_UUID')
            string(operation.name)
            check(
              ['folder', 'animation', 'raster'].includes(operation.kind),
              'UNSUPPORTED_NEW_LAYER',
            )
            const p = operation.parentId === null ? root : layer(operation.parentId)
            check(Number(p.LayerFolder) & 1, 'INVALID_LAYER_TREE')
            if (operation.kind === 'animation') {
              check(
                !p.AnimationFolder && !ancestors(p).some((a) => a.AnimationFolder),
                'UNSUPPORTED_NESTED_ANIMATION',
              )
              ensureAnimationFolderStorage(clip)
            }
            const target = children.get(Number(p.MainId)) ?? [],
              at = operation.index ?? 0
            integer(at)
            check(at >= 0 && at <= target.length, 'INVALID_LAYER_TREE')
            const pixels = operation.pixels
            if (pixels !== undefined)
              check(
                pixels &&
                  Number.isInteger(pixels.width) &&
                  Number.isInteger(pixels.height) &&
                  pixels.width > 0 &&
                  pixels.height > 0 &&
                  (pixels.channels === 1 || pixels.channels === 4) &&
                  pixels.data instanceof Uint8Array &&
                  pixels.data.length === pixels.width * pixels.height * pixels.channels,
                'INVALID_PIXEL_LENGTH',
              )
            if (pixels)
              checkImageAllocation(
                pixels.width,
                pixels.height,
                resolveImageLimits(options.imageLimits, {
                  maxPixels: 120000000,
                  maxBytes: 512 * 1024 * 1024,
                }),
                'LIMIT_MATERIAL_BYTES',
                pixels.channels,
              )
            const left = operation.left ?? 0,
              top = operation.top ?? 0
            integer(left)
            integer(top)
            const row = createLayer(clip, getSeed(), {
              name: operation.name,
              uuid: layerUuid(idBytes(operation.id)),
              parentId: Number(p.MainId),
              kind: operation.kind,
              width,
              height,
              ...(pixels
                ? { pixels: placePixels(pixels, width, height, left, top, options.imageLimits) }
                : {}),
            })
            layers.set(operation.id, row)
            byId.set(Number(row.MainId), row)
            parent.set(Number(row.MainId), Number(p.MainId))
            children.set(Number(row.MainId), [])
            target.splice(at, 0, Number(row.MainId))
            children.set(Number(p.MainId), target)
            link(Number(p.MainId))
            break
          }
          case 'moveLayer': {
            const row = layer(operation.layerId),
              p = operation.parentId === null ? root : layer(operation.parentId),
              old = parent.get(Number(row.MainId))!
            check(
              Number(p.LayerFolder) & 1 && p !== row && !ancestors(p).includes(row),
              'INVALID_LAYER_TREE',
            )
            const oldCel = ancestors(row).find((a) => a.AnimationFolder),
              newCel = p.AnimationFolder ? p : ancestors(p).find((a) => a.AnimationFolder)
            const policy = operation.celReferences ?? 'preserve',
              trackPolicy = operation.crossAnimationTracks ?? 'reject'
            check(['preserve', 'clear', 'follow-layer-order'].includes(policy), 'INVALID_EDIT')
            check(['reject', 'detach'].includes(trackPolicy), 'INVALID_EDIT')
            const subtree = (id: number): number[] => [
              id,
              ...(children.get(id) ?? []).flatMap(subtree),
            ]
            const moved = subtree(Number(row.MainId))
            check(
              !newCel || !moved.some((id) => byId.get(id)!.AnimationFolder),
              'UNSUPPORTED_NESTED_ANIMATION',
            )
            if (oldCel !== newCel) {
              const ids = new Set(moved.map((id) => normalizedUuid(byId.get(id)!.LayerUuid)))
              check(
                trackPolicy === 'detach' ||
                  !activeTracks().some((t) => ids.has(normalizedUuid(t.LayerUuidWithTrack))),
                'UNSUPPORTED_EDIT',
                { reason: 'tracked-layer-cross-animation-boundary' },
              )
              if (trackPolicy === 'detach') detachLayerTracks(ids)
            }
            const affected = [
              ...new Set([byId.get(old), p].filter((r): r is Row => !!r?.AnimationFolder)),
            ]
            const bindings = affected.map((folder) => {
              const names = new Set(
                celTracks(folder).flatMap((t) => [...referencedCelNames(clip, t)]),
              )
              return {
                folder,
                selected: new Map([...names].map((name) => [name, effectiveCel(folder, name)])),
              }
            })
            const previous = children.get(old)!,
              target =
                old === p.MainId
                  ? previous.filter((id) => id !== row.MainId)
                  : children.get(Number(p.MainId))!
            integer(operation.index)
            check(operation.index >= 0 && operation.index <= target.length, 'INVALID_LAYER_TREE')
            children.set(
              old,
              previous.filter((id) => id !== row.MainId),
            )
            target.splice(operation.index, 0, Number(row.MainId))
            children.set(Number(p.MainId), target)
            for (const { folder, selected } of bindings) {
              const changed = [...selected].filter(
                ([name, id]) => effectiveCel(folder, name) !== id,
              )
              check(!changed.length || policy !== 'preserve', 'UNSUPPORTED_CEL_EDIT', {
                reason: 'cel-reference-change',
                layerId: normalizedUuid(folder.LayerUuid),
              })
              if (policy === 'clear' && changed.length)
                changeReferences(folder, new Map(changed.map(([name]) => [name, null])))
            }
            parent.set(Number(row.MainId), Number(p.MainId))
            link(old)
            if (old !== p.MainId) link(Number(p.MainId))
            break
          }
          case 'removeLayer': {
            const row = layer(operation.layerId),
              ids: number[] = [],
              walk = (id: number) => {
                ids.push(id)
                for (const child of children.get(id) ?? []) walk(child)
              }
            check(
              operation.recursive === undefined || typeof operation.recursive === 'boolean',
              'INVALID_EDIT',
            )
            check(
              operation.recursive || !children.get(Number(row.MainId))?.length,
              'INVALID_LAYER_TREE',
            )
            walk(Number(row.MainId))
            const uuids = new Set(ids.map((id) => normalizedUuid(byId.get(id)!.LayerUuid)))
            check(
              ![...layers.values()].some(
                (r) =>
                  !detached.has(Number(r.MainId)) &&
                  isLightTableReference(r) &&
                  !ids.includes(Number(r.MainId)) &&
                  uuids.has(normalizedUuid(r.LinkLayerUUID)),
              ),
              'UNSUPPORTED_EDIT',
              { reason: 'light-table-source-removal' },
            )
            renameReferences(row, null)
            detachLayerTracks(uuids)
            const p = parent.get(Number(row.MainId))!
            children.set(
              p,
              children.get(p)!.filter((id) => id !== row.MainId),
            )
            link(p)
            for (const id of ids) detached.add(id)
            if (ids.includes(Number(canvas.CanvasCurrentLayer)))
              patch('Canvas', canvas, { CanvasCurrentLayer: root.MainId })
            break
          }
          case 'createTimeline': {
            idBytes(operation.id)
            string(operation.name)
            timelineRange(operation.fps, operation.startFrame, operation.endFrame)
            check(
              !timelines.some((t) => normalizedUuid(t.TimeLineUuid) === operation.id),
              'INVALID_TIMELINE_RANGE',
            )
            const s = getSeed()
            ensureAnimationStorage(clip, s)
            const project = requiredAt(clip.rows('Project'), 0)
            const banks = optionalRows(clip, 'AnimationCutBank')
            let bank = banks.find((b) => b.MainId === project.ProjectCutBank) ?? banks[0]
            if (!bank) {
              bank = clip.insert('AnimationCutBank', requiredAt(s.rows('AnimationCutBank'), 0), {
                FirstTimeLine: 0,
                CurrentIndex: 0,
                Enable: 1,
              })
              selectBank(bank)
            }
            const row = clip.insert('TimeLine', requiredAt(s.rows('TimeLine'), 0), {
              BankId: bank.MainId,
              TimeLineUuid: idBytes(operation.id),
              TimeLineName: operation.name,
              FrameRate: operation.fps,
              StartFrame: operation.startFrame,
              EndFrame: operation.endFrame,
              CurrentFrame: operation.startFrame,
              SmallestStartFrame: 0,
              BiggestEndFrame: operation.endFrame,
              FirstTrack: 0,
              NextTimeLine: 0,
            })
            const last = orderedTimelines(bank).at(-1)
            if (last) patch('TimeLine', last, { NextTimeLine: row.MainId })
            else patch('AnimationCutBank', bank, { FirstTimeLine: row.MainId })
            patch('AnimationCutBank', bank, { Enable: 1 })
            timelines.push(row)
            break
          }
          case 'setTimeline': {
            const row = timeline(operation.timelineId),
              fps = operation.fps ?? Number(row.FrameRate),
              start = operation.startFrame ?? Number(row.StartFrame),
              end = operation.endFrame ?? Number(row.EndFrame)
            timelineRange(fps, start, end)
            if (operation.name !== undefined) string(operation.name)
            check(
              operation.timingPolicy === undefined || operation.timingPolicy === 'preserve-time',
              'INVALID_EDIT',
            )
            check(
              fps === row.FrameRate || operation.timingPolicy === 'preserve-time',
              'UNSUPPORTED_EDIT',
              { reason: 'fps-requires-time-policy' },
            )
            const current = Number(row.CurrentFrame),
              nextCurrent =
                operation.startFrame !== undefined || operation.endFrame !== undefined
                  ? Math.max(start, Math.min(end - 1, current))
                  : current
            if (nextCurrent !== current) invalidateTimeline(row)
            patch('TimeLine', row, {
              FrameRate: fps,
              StartFrame: start,
              EndFrame: end,
              CurrentFrame: nextCurrent,
              BiggestEndFrame: Math.max(end, Number(row.BiggestEndFrame)),
              ...(operation.name !== undefined ? { TimeLineName: operation.name } : {}),
            })
            break
          }
          case 'setActiveTimeline': {
            const row = timeline(operation.timelineId)
            const bank = optionalRows(clip, 'AnimationCutBank').find((b) => b.MainId === row.BankId)
            check(bank, 'INVALID_REFERENCE_CHAIN')
            const index = orderedTimelines(bank).indexOf(row)
            check(index >= 0, 'INVALID_REFERENCE_CHAIN')
            const project = clip.rows('Project')[0]
            if (
              bank.CurrentIndex !== index ||
              project?.ProjectCutBank !== bank.MainId ||
              !bank.Enable
            ) {
              for (const b of optionalRows(clip, 'AnimationCutBank')) {
                if (b.MainId !== project?.ProjectCutBank) continue
                const previous = orderedTimelines(b)[Number(b.CurrentIndex)]
                if (previous) invalidateTimeline(previous)
              }
              invalidateTimeline(row)
            }
            patch('AnimationCutBank', bank, { CurrentIndex: index, Enable: 1 })
            selectBank(bank)
            break
          }
          case 'duplicateTimeline':
          case 'moveTimeline':
          case 'removeTimeline': {
            const time = timeline(operation.timelineId)
            if (operation.type === 'removeTimeline') invalidateTimeline(time)
            editTimelineStructure(clip, time, operation, options.signal)
            timelines = clip.rows('TimeLine')
            tracks = optionalRows(clip, 'Track')
            editLabel = createLabelEditor(clip)
            if (operation.type === 'removeTimeline') {
              const bank = optionalRows(clip, 'AnimationCutBank').find(
                (b) => b.MainId === time.BankId,
              )!
              const selected = orderedTimelines(bank)[Number(bank.CurrentIndex)]
              if (selected) invalidateTimeline(selected)
            }
            break
          }
          case 'insertTimelineFrames':
          case 'removeTimelineFrames': {
            const time = timeline(operation.timelineId),
              active = orderedTracks(time)
            const changed = editTimelineFrames(clip, time, active, operation, options.signal)
            if (clip.row('TimeLine', time.MainId).CurrentFrame !== time.CurrentFrame)
              invalidateTimeline(time)
            for (const track of active.filter((t) => changed.includes(Number(t.MainId)))) {
              const affected = layers.get(normalizedUuid(track.LayerUuidWithTrack))
              if (affected) invalidate(Number(affected.MainId))
            }
            timelines = clip.rows('TimeLine')
            tracks = optionalRows(clip, 'Track')
            editLabel = createLabelEditor(clip)
            break
          }
          case 'setTimelineFrameRate': {
            const row = timeline(operation.timelineId),
              oldFps = Number(row.FrameRate)
            timelineRange(operation.fps, Number(row.StartFrame), Number(row.EndFrame))
            check(
              ['preserve-time', 'preserve-frames'].includes(operation.timingPolicy) &&
                (operation.mediaTiming === undefined || operation.mediaTiming === 'preserve-time'),
              'INVALID_EDIT',
            )
            if (operation.fps === oldFps) break
            check(Number.isFinite(oldFps) && oldFps > 0, 'INVALID_TIMELINE_RANGE')
            const activeTracks = orderedTracks(row),
              changes: Row = { FrameRate: operation.fps }
            if (operation.timingPolicy === 'preserve-frames') {
              check(
                !activeTracks.some((t) => t.TrackKind === 4000 || t.TrackKind === 4001) ||
                  operation.mediaTiming === 'preserve-time',
                'UNSUPPORTED_TIMELINE_EDIT',
                { reason: 'media-timing-policy-required' },
              )
              for (const t of activeTracks) {
                if (t.TrackKind === 4000 || t.TrackKind === 4001) continue
                preserveTrackFrames(clip, t, row, operation.fps, options.signal)
              }
              invalidateTimeline(row)
            } else {
              const ratio = operation.fps / oldFps
              for (const key of [
                'StartFrame',
                'EndFrame',
                'CurrentFrame',
                'SmallestStartFrame',
                'BiggestEndFrame',
              ])
                changes[key] = scaleFrame(Number(row[key]), ratio)
              // Native PAINT upper-clamps the playhead to end - 1 after scaling,
              // even when a very short window is now less than one frame long.
              const current = Number(changes.CurrentFrame)
              changes.CurrentFrame = Math.min(current, Number(changes.EndFrame) - 1)
              if (changes.CurrentFrame !== current) invalidateTimeline(row)
              timelineRange(operation.fps, Number(changes.StartFrame), Number(changes.EndFrame))
              // CSP keeps label frame coordinates even when total frame count changes.
            }
            patch('TimeLine', row, changes)
            break
          }
          case 'moveTrackClip':
          case 'trimTrackClip': {
            const { track, time } = trackTarget(operation)
            const changed = editTrackClip(clip, track, time, operation, options.signal)
            const affected = layers.get(normalizedUuid(track.LayerUuidWithTrack))
            if (changed && affected) invalidate(Number(affected.MainId))
            break
          }
          case 'extendTrackClip':
          case 'splitTrackClip':
          case 'joinTrackClips':
          case 'setPropertyKey':
          case 'movePropertyKey':
          case 'removePropertyKey': {
            const { track, time } = trackTarget(operation)
            const changed =
              operation.type === 'extendTrackClip' ||
              operation.type === 'splitTrackClip' ||
              operation.type === 'joinTrackClips'
                ? editClipStructure(clip, track, time, operation, options.signal)
                : editPropertyKey(clip, track, time, operation, options.signal)
            const affected = layers.get(normalizedUuid(track.LayerUuidWithTrack))
            if (changed && affected) invalidate(Number(affected.MainId))
            break
          }
          case 'removeTrackClip': {
            const { track, time } = trackTarget(operation)
            removeTrackClip(clip, track, time, operation.clipIndex, options.signal)
            const affected = layers.get(normalizedUuid(track.LayerUuidWithTrack))
            if (affected) invalidate(Number(affected.MainId))
            break
          }
          case 'setCelKeys':
          case 'insertCelClip': {
            const time = timeline(operation.timelineId),
              row = layer(operation.layerId)
            check(row.AnimationFolder, 'UNSUPPORTED_CEL_EDIT')
            timelineRange(Number(time.FrameRate), Number(time.StartFrame), Number(time.EndFrame))
            for (const ancestor of ancestors(row).reverse()) ensureFolderTrack(time, ancestor)
            const matches = orderedTracks(time).filter(
              (t) => normalizedUuid(t.LayerUuidWithTrack) === operation.layerId,
            )
            check(matches.length <= 1, 'DUPLICATE_LAYER_TRACK')
            let track = matches[0]
            const creating = !track
            check(
              isArrayValue(operation.keys) && operation.keys.length <= 100000,
              'INVALID_CEL_KEYS',
            )
            if (!track) {
              check(
                operation.type === 'insertCelClip' || operation.clipIndex === undefined,
                'INVALID_TIMELINE_CLIP',
              )
              const s = getSeed(),
                template = s.rows('Track').find((t) => t.TrackKind === 2000)
              check(template, 'MISSING_ANIMATION_TEMPLATE')
              const attrs: Row = {}
              for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
                let raw = animationMixer(
                  s.body(template[field])!,
                  [{ frame: Number(time.StartFrame), value: null }],
                  Number(time.EndFrame),
                  Number(time.FrameRate),
                )
                const empty = new BincDocument(raw, bincWriteLimits)
                child(empty.root, 'General').children = []
                raw = empty.encode()
                attrs[field] = clip.addExternal(packedMixer(raw))
                attrs[`${field}Size`] = raw.length
              }
              track = clip.insert('Track', template, {
                ...attrs,
                BankId: time.BankId,
                ItemId: time.MainId,
                TrackUuid: idBytes(crypto.randomUUID().replaceAll('-', '')),
                LayerUuidWithTrack: idBytes(operation.layerId),
                TrackKind: 2000,
                TrackNextIndex: time.FirstTrack,
                TrackLabelFirstIndex: 0,
                TrackValueMap: trackValueMap(null),
              })
              patch('TimeLine', time, { FirstTrack: track.MainId })
              tracks.push(track)
            }
            check(track.TrackKind === 2000, 'UNSUPPORTED_CEL_EDIT')
            const cels = new Set(
              (children.get(Number(row.MainId)) ?? [])
                .filter((id) => !isLightTableReference(byId.get(id)!))
                .map((id) => String(byId.get(id)!.LayerName)),
            )
            check(
              operation.keys.every((k) => k && (k.value === null || cels.has(k.value))),
              'INVALID_CEL_KEYS',
            )
            const currentField = clip.body(track.TrackActionMixer)
                ? 'TrackActionMixer'
                : 'TrackActionMixer2',
              currentBody = clip.body(track[currentField])
            check(currentBody, 'MISSING_CEL_DATA')
            const current = readAnimation(
              currentBody,
              Number(track[`${currentField}Size`]),
              Number(time.FrameRate),
              Number(time.StartFrame),
              Number(time.EndFrame),
            )
            if (
              !creating &&
              operation.type === 'setCelKeys' &&
              operation.clipIndex === undefined &&
              operation.keys.length > 0 &&
              operation.frameOrigin !== 'timeline-zero' &&
              current.length === operation.keys.length &&
              current.every(
                (key, i) =>
                  key.frame === requiredAt(operation.keys, i).frame &&
                  key.value === requiredAt(operation.keys, i).value,
              ) &&
              hasSingleCelClip(currentBody, Number(track[`${currentField}Size`]))
            )
              break
            const origin = operation.frameOrigin === 'timeline-zero' ? 0 : Number(time.StartFrame)
            let clipIndex = operation.type === 'setCelKeys' ? operation.clipIndex : undefined
            if (operation.type === 'insertCelClip') {
              const start = operation.startFrame + origin,
                end = operation.endFrame + origin
              clipIndex = insertCelClip(
                clip,
                track,
                time,
                start - Number(time.StartFrame),
                end - Number(time.StartFrame),
                (secondary) => newCelClip(getSeed(), secondary, start, end, Number(time.FrameRate)),
                options.signal,
              )
            }
            const changed = setCelKeys(
              clip,
              track,
              operation.keys,
              Number(time.FrameRate),
              Number(time.StartFrame),
              Number(time.EndFrame),
              clipIndex,
              operation.frameOrigin,
              options.signal,
              (secondary) =>
                newCelClip(
                  getSeed(),
                  secondary,
                  operation.keys[0]!.frame + origin,
                  Math.max(Number(time.EndFrame), operation.keys.at(-1)!.frame + origin + 1),
                  Number(time.FrameRate),
                ),
            )
            Object.assign(track, clip.row('Track', track.MainId))
            if (changed || creating || operation.type === 'insertCelClip')
              invalidate(Number(row.MainId))
            break
          }
          case 'setTrackLabel':
          case 'removeTrackLabel': {
            const { track: t, time } = trackTarget(operation)
            editLabel(t, time, operation)
            break
          }
          case 'replaceAudio': {
            string(operation.namespace)
            check(
              operation.audio &&
                isArrayValue(operation.audio.assets) &&
                isArrayValue(operation.audio.tracks) &&
                isArrayValue(operation.audio.replacedLayerIds),
              'INVALID_EDIT',
            )
            check(
              operation.audio.tracks.every((t) => t && isArrayValue(t.clips)),
              'INVALID_EDIT',
            )
            check(
              operation.audio.assets.length <= 10000 &&
                operation.audio.tracks.length <= 10000 &&
                operation.audio.tracks.reduce((sum, t) => sum + t.clips.length, 0) <= 100000,
              'LIMIT_DOCUMENT_ITEMS',
            )
            const assets = new Set<string>(),
              audioTracks = new Set<string>(),
              clips = new Set<string>()
            for (const asset of operation.audio.assets) {
              check(asset, 'INVALID_EDIT')
              string(asset.id)
              string(asset.name)
              check(
                !assets.has(asset.id) &&
                  Number.isFinite(asset.durationFrames) &&
                  asset.durationFrames > 0 &&
                  asset.durationFrames <= 1000000 &&
                  asset.bytes instanceof Uint8Array &&
                  (asset.sourceItemId === undefined || /^[0-9a-f]{32}$/.test(asset.sourceItemId)),
                'INVALID_AUDIO_SOURCE',
              )
              assets.add(asset.id)
            }
            for (const track of operation.audio.tracks) {
              check(track && isArrayValue(track.clips), 'INVALID_EDIT')
              string(track.id)
              string(track.name)
              check(
                !audioTracks.has(track.id) &&
                  typeof track.muted === 'boolean' &&
                  (track.sourceLayerId === undefined ||
                    (Number.isSafeInteger(track.sourceLayerId) && track.sourceLayerId > 0)),
                'INVALID_AUDIO_TARGET',
              )
              audioTracks.add(track.id)
              for (const placement of track.clips) {
                check(placement, 'INVALID_EDIT')
                string(placement.id)
                check(
                  !clips.has(placement.id) && assets.has(placement.assetId),
                  'INVALID_AUDIO_PLACEMENT',
                )
                clips.add(placement.id)
              }
            }
            check(
              operation.audio.replacedLayerIds.every(Number.isSafeInteger),
              'INVALID_AUDIO_TARGET',
            )
            await writeAudioTimeline(
              clip,
              getSeed(),
              timeline(operation.timelineId),
              operation.audio,
              operation.namespace,
            )
            // Audio can add root layers and tracks in several timelines. Refresh all transaction indices.
            refreshLayers()
            tracks = clip.rows('Track')
            timelines = clip.rows('TimeLine')
            editLabel = createLabelEditor(clip)
            invalidate(Number(root.MainId))
            break
          }
          default:
            check(false, 'INVALID_EDIT')
        }
      } catch (error) {
        if (error instanceof ClipError)
          throw new ClipError(
            error.diagnostic.code,
            {
              ...error.diagnostic.data,
              operation: operation?.type ?? 'unknown',
              operationIndex: index,
              ...(operation && typeof operation === 'object' && 'layerId' in operation
                ? { layerId: String(operation.layerId) }
                : {}),
            },
            { cause: error },
          )
        throw error
      }
    }
    // Only rendering dependencies of changed layers are invalidated. Raw payloads remain available.
    for (const id of dirty) {
      const row = byId.get(id)
      if (!row) continue
      if (Number(row.LayerFolder) & 1 && row.LayerRenderMipmap)
        for (const { off } of mipmapChain(clip, row.LayerRenderMipmap))
          clip.update('Offscreen', off.MainId, { BlockData: utf8.encode(externalId()) })
    }
    for (const thumb of clip.rows('LayerThumbnail'))
      if (dirty.has(Number(thumb.LayerId))) {
        clip.update('Offscreen', thumb.ThumbnailOffscreen, { BlockData: utf8.encode(externalId()) })
        const keys = Object.keys(thumb).filter((key) => key.includes('NeedRefresh'))
        clip.update(
          'LayerThumbnail',
          thumb.MainId,
          Object.fromEntries(keys.map((key) => [key, Number(thumb[key]) + 1])),
        )
      }
    checkCancelled(options.signal)
    const changed = clip.changes.size > 0 || clip.additions.size > 0
    const impact = {
      changedRows: [...clip.changes.values()],
      addedExternalBlobs: clip.additions.size,
      invalidatedLayerIds: [...dirty].map((id) => normalizedUuid(byId.get(id)!.LayerUuid)),
      preservation: changed
        ? ('untouched-payloads-and-references' as const)
        : ('original-bytes' as const),
    }
    return { bytes: changed ? clip.bytes() : new Uint8Array(source), changed, impact }
  } finally {
    clip.close()
    seed?.close()
  }
}
