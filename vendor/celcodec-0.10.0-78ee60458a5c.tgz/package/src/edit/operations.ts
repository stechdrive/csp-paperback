import type { Pixels } from '../native/raster.js'
import type { ClipAudioTimeline, ExportTrackFrame } from '../native/model.js'
import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import type { AnimationPaperSettings, FrameAnchor } from '../document/paper.js'

export interface LayerAttributes {
  visible?: boolean
  opacity?: number
  blendMode?: number
  /** Change the stored clipping flag without changing the layer's blend mode. */
  clipping?: boolean
  locked?: boolean
  expanded?: boolean
  labelColor?: string | null
  maskEnabled?: boolean
  /** Link the existing mask to future layer transforms without moving its pixels. */
  maskLinked?: boolean
}

/** Native channel names; edits require an existing parameter and never enable a track implicitly. */
export type EditableKeyframeProperty =
  'ImagePosition' | 'ImageCenter' | 'ImageScale' | 'ImageAspectScale' | 'ImageRotation' | 'Opacity'
/** Resolve against the current transaction, including newly created/duplicated tracks. */
export type TrackTarget =
  | { trackId: number; timelineId?: never; layerId?: never }
  | { trackId?: never; timelineId: string; layerId: string }
export type PropertyKeyTarget = TrackTarget & {
  clipIndex: number
  property: EditableKeyframeProperty
  axis?: 'X' | 'Y'
  frameOrigin?: 'playback-start' | 'timeline-zero'
  frame: number
}
export interface TimelineFrameEdit {
  timelineId: string
  frameOrigin?: 'playback-start' | 'timeline-zero'
  /** Insert before this frame, or remove [frame, frame + count). */
  frame: number
  count: number
  trackIds: 'all' | readonly number[]
  trackLabels: 'shift' | 'preserve'
  timelineLabels: 'shift' | 'preserve'
  playbackRange: 'resize' | 'preserve'
  /** Shift source keys like CSP, or cut the crossing clip to preserve source curves. */
  crossingClips: 'shift-keys' | 'split'
}
/** Ordered operations. IDs are native UUIDs/row IDs, never application cell keys. */
export type EditOperation =
  /** Expand the pixel canvas without resampling or discarding off-canvas artwork.
   * Existing animation frames move with the artwork; expansion adds outer margins. */
  | { type: 'resizeCanvas'; width: number; height: number; anchor: FrameAnchor }
  /** Set animation paper geometry. Canvas size follows drawing/basis + margins.
   * contentAnchor explicitly selects whether artwork follows the basis frame. */
  | {
      type: 'setAnimationPaper'
      settings: AnimationPaperSettings
      contentAnchor: 'canvas' | 'basis'
    }
  | { type: 'renameLayer'; layerId: string; name: string }
  | { type: 'setLayerAttributes'; layerId: string; attributes: LayerAttributes }
  /** Replace the whole original RGBA surface. left/top are canvas coordinates before animation.
   * Existing UUID, layer offsets, masks, properties and timeline references are retained. */
  | { type: 'replaceRasterPixels'; layerId: string; pixels: Pixels; left: number; top: number }
  /** Change saved camera display, preserving its curves. Unsupported material trees are refused. */
  | { type: 'setCameraDisplay'; layerId: string; mode: 'apply' | 'ignore' }
  /** Toggle an existing track; does not create/delete keys or change cel assignment. */
  | { type: 'setLayerKeyframesEnabled'; layerId: string; enabled: boolean }
  | {
      type: 'addLayer'
      id: string
      parentId: string | null
      index?: number
      name: string
      kind: 'folder' | 'animation' | 'raster'
      pixels?: Pixels
      left?: number
      top?: number
    }
  | {
      type: 'moveLayer'
      layerId: string
      parentId: string | null
      index: number
      /** Default preserve refuses changes to cel identity. Clear removes affected assignments;
       * follow-layer-order explicitly permits name-based rebinding, including in other timelines. */
      celReferences?: 'preserve' | 'clear' | 'follow-layer-order'
      /** Default reject refuses moving independently tracked descendants across an animation
       * boundary. Detach removes their known tracks from every active timeline chain while
       * retaining the original track rows, labels and external data. It does not restore them
       * on a later move; unknown track kinds and nested animation folders remain unsupported. */
      crossAnimationTracks?: 'reject' | 'detach'
    }
  | { type: 'removeLayer'; layerId: string; recursive?: boolean }
  | {
      type: 'createTimeline'
      id: string
      name: string
      fps: number
      startFrame: number
      endFrame: number
    }
  | {
      type: 'setTimeline'
      timelineId: string
      name?: string
      fps?: number
      startFrame?: number
      endFrame?: number
      timingPolicy?: 'preserve-time'
    }
  | {
      /** Native FPS conversion for playback bounds and clip timing. Label frame numbers stay unchanged. */
      type: 'setTimelineFrameRate'
      timelineId: string
      fps: number
      timingPolicy: 'preserve-time' | 'preserve-frames'
      /** Required for preserve-frames when audio/movie tracks exist: CSP keeps their real-time timing. */
      mediaTiming?: 'preserve-time'
    }
  | { type: 'setActiveTimeline'; timelineId: string }
  | { type: 'duplicateTimeline'; timelineId: string; id: string; name: string; index?: number }
  | { type: 'removeTimeline'; timelineId: string }
  | { type: 'moveTimeline'; timelineId: string; index: number }
  | ({ type: 'insertTimelineFrames' | 'removeTimelineFrames' } & TimelineFrameEdit)
  | ({
      type: 'moveTrackClip'
      /** Index in readKeyframes(trackId).clips; both native mixers are updated. */
      clipIndex: number
      /** Coordinate origin for startFrame. Defaults to playback-start for compatibility. */
      frameOrigin?: 'playback-start' | 'timeline-zero'
      /** Signed timeline frames. May precede absolute frame zero or exceed playback end. */
      startFrame: number
    } & TrackTarget)
  | ({
      /** Shorten the existing clip without deleting its hidden keys or changing source speed. */
      type: 'trimTrackClip'
      clipIndex: number
      /** Coordinate origin for both bounds. Defaults to playback-start for compatibility. */
      frameOrigin?: 'playback-start' | 'timeline-zero'
      /** Signed timeline frames; endFrame is exclusive. Extension is not supported. */
      startFrame: number
      endFrame: number
    } & TrackTarget)
  | ({
      /** Extend a drawing clip at unchanged source speed. Media extension is refused. */
      type: 'extendTrackClip'
      clipIndex: number
      frameOrigin?: 'playback-start' | 'timeline-zero'
      startFrame: number
      endFrame: number
    } & TrackTarget)
  | ({
      type: 'splitTrackClip'
      clipIndex: number
      frameOrigin?: 'playback-start' | 'timeline-zero'
      frame: number
    } & TrackTarget)
  | ({
      /** Join touching clips with compatible source timing and identical non-cel channels. */
      type: 'joinTrackClips'
      clipIndex: number
      nextClipIndex: number
    } & TrackTarget)
  | ({ type: 'removeTrackClip'; clipIndex: number } & TrackTarget)
  | ({
      type: 'setPropertyKey'
      value: number
      interpolation?: 'constant' | 'linear' | 'smooth' | 'hermite'
      /** Property units per timeline frame, converted to native source ticks by the writer. */
      leftSlope?: number
      rightSlope?: number
      handleMode?: 'coupled' | 'split'
    } & PropertyKeyTarget)
  | ({ type: 'movePropertyKey'; toFrame: number } & PropertyKeyTarget)
  | ({ type: 'removePropertyKey' } & PropertyKeyTarget)
  | {
      type: 'setCelKeys'
      timelineId: string
      layerId: string
      /** Required for tracks containing multiple clips. An explicit index preserves clip bounds. */
      clipIndex?: number
      /** Defaults to playback-start. Keys outside the clip are retained as hidden keys. */
      frameOrigin?: 'playback-start' | 'timeline-zero'
      keys: readonly ExportTrackFrame[]
    }
  | {
      /** Add an independent cel clip without rebuilding existing clips or property curves. */
      type: 'insertCelClip'
      timelineId: string
      layerId: string
      frameOrigin?: 'playback-start' | 'timeline-zero'
      startFrame: number
      endFrame: number
      keys: readonly ExportTrackFrame[]
    }
  | ({
      type: 'setTrackLabel'
      frame: number
      kind: 'inbetween' | 'reverse'
      labelId?: number
    } & TrackTarget)
  | ({ type: 'removeTrackLabel'; labelId: number } & TrackTarget)
  | { type: 'replaceAudio'; timelineId: string; audio: ClipAudioTimeline; namespace: string }

export interface EditOptions {
  signal?: AbortSignal
  /** Caller-provided empty animation CLIP used to create native structures. Its bytes are read-only. */
  seed?: Uint8Array
}

/** Bound both graph traversal and binary ownership before copying untrusted edit inputs. */
export function captureOperations(
  operations: readonly EditOperation[],
  maxBytes: number,
  signal?: AbortSignal,
): EditOperation[] {
  let bytes = 0,
    nodes = 0
  const ancestors = new Set<object>()
  function copy(value: unknown, depth: number): unknown {
    checkCancelled(signal)
    check(++nodes <= 1000000 && depth <= 32, 'LIMIT_DOCUMENT_ITEMS')
    if (
      value === null ||
      value === undefined ||
      typeof value === 'boolean' ||
      typeof value === 'number'
    )
      return value
    if (typeof value === 'string') {
      check(value.length <= 65535, 'INVALID_EDIT')
      bytes += value.length * 2
      check(bytes <= maxBytes, 'LIMIT_PENDING_PLANS')
      return value
    }
    check(typeof value === 'object', 'INVALID_EDIT')
    if (value instanceof Uint8Array) {
      bytes += value.byteLength
      check(bytes <= maxBytes, 'LIMIT_PENDING_PLANS')
      return new Uint8Array(value)
    }
    check(!ancestors.has(value), 'INVALID_EDIT')
    ancestors.add(value)
    let result: unknown
    if (Array.isArray(value)) {
      check(value.length <= 100000, 'LIMIT_DOCUMENT_ITEMS')
      result = value.map((v) => copy(v, depth + 1))
    } else {
      check(
        Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null,
        'INVALID_EDIT',
      )
      const entries = Object.entries(value)
      check(entries.length <= 64, 'INVALID_EDIT')
      result = Object.fromEntries(entries.map(([key, v]) => [key, copy(v, depth + 1)]))
    }
    ancestors.delete(value)
    return result
  }
  return copy(operations, 0) as EditOperation[]
}
