// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
import type { ClipContainer, Row } from './container.js'

export const normalizedUuid = (value: Row[string] | undefined) =>
  value instanceof Uint8Array
    ? Array.from(value, (byte) => byte.toString(16).padStart(2, '0')).join('')
    : String(value ?? '')
        .replaceAll('-', '')
        .toLowerCase()

/** Media/animation tables can be absent from illustration documents. */
export function optionalRows(
  clip: ClipContainer,
  table:
    | 'CanvasItem'
    | 'CanvasItemBinary'
    | 'LayerObject'
    | 'CameraInfo'
    | 'Project'
    | 'AnimationCutBank'
    | 'TimeLine'
    | 'TimeLineLabel'
    | 'Track'
    | 'VectorObjectList',
): Row[] {
  return clip.db.exec(`SELECT name FROM sqlite_master WHERE type='table' AND name='${table}'`)[0]
    ? clip.rows(table)
    : []
}
