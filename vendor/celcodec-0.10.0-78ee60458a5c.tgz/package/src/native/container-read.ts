import { Reader, check } from '../internal/binary.js'
import { checkCancelled, ClipError } from '../diagnostics.js'
export interface ContainerLimits {
  inputBytes: number
  chunks: number
  externalIdBytes: number
  databaseBytes: number
  strictHeader: boolean
}
/** Import acceptance inherited from Paperback. Editing uses a separate strict profile. */
export const readContainerLimits: Readonly<ContainerLimits> = Object.freeze({
  inputBytes: 1024 ** 3,
  chunks: 100000,
  externalIdBytes: 256,
  databaseBytes: 256 * 1024 ** 2,
  strictHeader: false,
})
export const writeContainerLimits: Readonly<ContainerLimits> = Object.freeze({
  inputBytes: 512 * 1024 ** 2,
  chunks: 999999,
  externalIdBytes: 128,
  databaseBytes: 512 * 1024 ** 2,
  strictHeader: true,
})
export interface ContainerData {
  database: Uint8Array
  external: Map<string, Uint8Array>
  externalOffsets: Map<string, number>
  chunks: { tag: string; bytes: Uint8Array; offset: number }[]
}
/** Views borrow the immutable input. Unknown chunks, order and external payloads are retained. */
export function readContainer(
  bytes: Uint8Array,
  limits: Readonly<ContainerLimits> = readContainerLimits,
  signal?: AbortSignal,
): ContainerData {
  checkCancelled(signal)
  for (const key of ['inputBytes', 'chunks', 'externalIdBytes', 'databaseBytes'] as const)
    check(Number.isSafeInteger(limits[key]) && limits[key] > 0, 'INVALID_LIMIT')
  check(bytes.length <= limits.inputBytes, 'LIMIT_CONTAINER_BYTES', {
    actual: bytes.length,
    limit: limits.inputBytes,
  })
  // Keep borrowed views, but normalize Buffer subclasses: their slice() aliases
  // input instead of copying, including when sql.js takes its database snapshot.
  const r = new Reader(new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength))
  check(r.text(8) === 'CSFCHUNK', 'INVALID_CONTAINER_HEADER')
  if (limits.strictHeader)
    check(r.number('u64') === bytes.length && r.number('u64') === 24, 'INVALID_CONTAINER_HEADER')
  else r.take(16)
  const external = new Map<string, Uint8Array>(),
    externalOffsets = new Map<string, number>(),
    chunks: ContainerData['chunks'] = []
  let database: Uint8Array | undefined
  while (r.position < bytes.length) {
    checkCancelled(signal)
    check(chunks.length < limits.chunks, 'LIMIT_CONTAINER_CHUNKS')
    const offset = r.position,
      tag = r.text(8),
      payload = r.take(r.number('u64'))
    if (limits.strictHeader) check(/^[\x20-\x7e]{8}$/.test(tag), 'UNSUPPORTED_CONTAINER_LAYOUT')
    chunks.push({ tag, bytes: payload, offset })
    if (tag === 'CHNKSQLi') {
      check(!database, 'DUPLICATE_DATABASE')
      check(payload.length <= limits.databaseBytes, 'LIMIT_DATABASE_BYTES')
      check(
        new TextDecoder().decode(payload.subarray(0, 16)) === 'SQLite format 3\0',
        'INVALID_DATABASE',
      )
      database = payload
    } else if (tag === 'CHNKExta') {
      const p = new Reader(payload),
        length = p.number('u64')
      check(length > 0 && length <= limits.externalIdBytes, 'INVALID_EXTERNAL_ID')
      const rawId = p.take(length)
      let id: string
      try {
        id = new TextDecoder('utf-8', { fatal: limits.strictHeader }).decode(rawId)
      } catch (error) {
        throw new ClipError('INVALID_EXTERNAL_ID', undefined, { cause: error })
      }
      const body = p.take(p.number('u64'))
      check(p.position === payload.length && !external.has(id), 'INVALID_EXTERNAL_DATA')
      external.set(id, body)
      externalOffsets.set(id, offset)
    }
  }
  check(database, 'MISSING_DATABASE')
  if (limits.strictHeader)
    check(
      chunks[0]?.tag === 'CHNKHead' &&
        chunks[0].bytes.length >= 16 &&
        chunks.at(-2)?.tag === 'CHNKSQLi' &&
        chunks.at(-1)?.tag === 'CHNKFoot',
      'UNSUPPORTED_CONTAINER_LAYOUT',
    )
  return { database, external, externalOffsets, chunks }
}
