import { check } from '../internal/binary.js'
import { requiredAt } from '../internal/indexed.js'
import { compareFrame } from '../internal/frame-boundary.js'
import { sampleKeyframeSegment } from '../internal/keyframe-sampling.js'
import { checkCancelled, diagnostic, type ClipDiagnostic } from '../diagnostics.js'
import { BincDocument, bincReadLimits, type BincNode } from './binc.js'
import { inflateBounded } from './compression.js'
import { view } from './binary.js'

export interface KeyframeTimeRange {
  /** Native ticks, not timeline frames. */
  readonly start: number
  readonly end: number
  readonly rate: number
}
export interface PropertyKeyframe {
  readonly tick: number
  /** Timeline frames relative to playback start; fractional/negative values are retained. */
  readonly frame: number
  readonly value: number
  readonly interpolation: string | undefined
  /** Stored derivative in value/native-tick units; independent of playback FPS/stretch. */
  readonly leftSlope: number | undefined
  /** Stored derivative in value/native-tick units. */
  readonly rightSlope: number | undefined
  /** Native handle coupling flag: 0 coupled, 1 split. Evaluation uses the stored slopes. */
  readonly breakKey?: number | undefined
  readonly reviseConstant: number | undefined
  readonly tag: string | undefined
}
export type KeyframeUnit = 'pixels' | 'percent' | 'degrees' | 'seconds' | 'tag-index' | 'unknown'
export interface KeyframeCurve {
  /** Native property name. New names are retained without assigning a guessed meaning. */
  readonly property: string
  readonly axis: string | undefined
  readonly unit: KeyframeUnit
  readonly keys: readonly PropertyKeyframe[]
}
export interface KeyframeParameter {
  readonly property: string
  readonly kind: string
  /** Stored current value, NOT an initial value to use before the first key. */
  readonly values: readonly (number | string)[]
  readonly tag: string | undefined
}
export interface KeyframeClip {
  readonly name: string
  readonly time: KeyframeTimeRange
  readonly motion: KeyframeTimeRange
  readonly curveRate: number
  /** Signed timeline frames relative to playback start, including positions before absolute zero. */
  readonly startFrame: number
  /** Exclusive clip boundary, independent of the playback range. */
  readonly endFrame: number
  /** Raw MotionBlend metadata. Its corresponding PAINT UI operation is not established. */
  readonly blend: Readonly<{ enabled: boolean; shift: number; next: number }> | undefined
  readonly parameters: readonly KeyframeParameter[]
  readonly curves: readonly KeyframeCurve[]
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface KeyframeTrack {
  readonly format: '0100' | '0110'
  readonly version: string | undefined
  readonly fps: number
  readonly startFrame: number
  readonly clips: readonly KeyframeClip[]
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface KeyframeReadOptions {
  readonly fps: number
  readonly startFrame: number
  readonly signal?: AbortSignal | undefined
}

const units: Readonly<Record<string, KeyframeUnit>> = Object.freeze({
  ImagePosition: 'pixels',
  ImageCenter: 'pixels',
  MaskPosition: 'pixels',
  MaskCenter: 'pixels',
  ImageScale: 'percent',
  ImageAspectScale: 'percent',
  MaskScale: 'percent',
  MaskAspectScale: 'percent',
  ImageRotation: 'degrees',
  MaskRotation: 'degrees',
  Opacity: 'percent',
  AudioVolume: 'percent',
  PlayTime: 'seconds',
  ImageCelName: 'tag-index',
  AudioPlayer: 'tag-index',
})
function child(node: BincNode, name: string): BincNode | undefined {
  const found = node.children.filter((item) => item.name === name)
  check(found.length <= 1, 'INVALID_KEYFRAME_STRUCTURE', { field: name })
  return found[0]
}
function scalar(node: BincNode, name: string): number {
  const values = child(node, name)?.values
  check(
    values?.length === 1 && typeof values[0] === 'number' && Number.isFinite(values[0]),
    'INVALID_TIME_VALUE',
    { field: name },
  )
  return values[0]
}
function range(node: BincNode, name: string): KeyframeTimeRange {
  const value = child(node, name)
  check(value, 'MISSING_TIME_INFO', { field: name })
  const start = scalar(value, 'Start'),
    end = scalar(value, 'End'),
    rate = scalar(value, 'Rate')
  check(rate > 0, 'INVALID_TIME_RATE')
  check(end > start, 'INVALID_TIME_RANGE')
  return { start, end, rate }
}
function array(
  node: BincNode,
  name: string,
  length: number,
  kind: 'number' | 'string',
  optional = false,
) {
  const values = child(node, name)?.values
  if (optional && !values) return undefined
  check(
    values &&
      values.length === length &&
      values.every((v) => typeof v === kind && (typeof v !== 'number' || Number.isFinite(v))),
    'INVALID_KEYFRAME_KEYS',
    { field: name },
  )
  return values
}
function unknownChildren(node: BincNode, known: readonly string[], diagnostics: ClipDiagnostic[]) {
  for (const item of node.children) {
    if (!known.includes(item.name))
      diagnostics.push(diagnostic('UNSUPPORTED_KEYFRAME_STRUCTURE', { field: item.name }))
  }
}

/** Inspect all channels in a bounded native mixer. Unknown semantics are reported, never rewritten. */
export function readKeyframeTrack(
  bytes: Uint8Array,
  unpackedSize: number,
  options: KeyframeReadOptions,
): KeyframeTrack {
  checkCancelled(options.signal)
  const { fps, startFrame } = options
  check(
    Number.isFinite(fps) && fps > 0 && fps <= 1000 && Number.isFinite(startFrame),
    'INVALID_TIMELINE_RANGE',
  )
  check(
    bytes.length >= 5 && view(bytes).getUint32(0, true) === bytes.length - 4,
    'INVALID_PACKED_BINC_SIZE',
  )
  check(
    Number.isSafeInteger(unpackedSize) &&
      unpackedSize >= 16 &&
      unpackedSize <= bincReadLimits.bytes,
    'LIMIT_BINC_BYTES',
  )
  const raw = inflateBounded(bytes.subarray(4), unpackedSize, options.signal)
  check(raw.length === unpackedSize, 'INVALID_BINC_SIZE')
  const doc = new BincDocument(raw, bincReadLimits, options.signal),
    general = child(doc.root, 'General')
  check(general, 'INVALID_KEYFRAME_STRUCTURE', { field: 'General' })
  const version = general.attrs.Version,
    diagnostics: ClipDiagnostic[] = []
  if (version !== (doc.secondary ? '2.1.0' : '2.0.0'))
    diagnostics.push(diagnostic('UNSUPPORTED_KEYFRAME_VERSION', { version: version ?? '' }))
  unknownChildren(general, ['ActionNodeClip'], diagnostics)
  const clips: KeyframeClip[] = []
  for (const node of general.children) {
    checkCancelled(options.signal)
    if (node.name !== 'ActionNodeClip') continue
    const time = range(node, 'TimeClip'),
      motion = range(node, 'MotionClip'),
      info = child(node, 'TimeInfo'),
      anim = child(node, 'AnimInfo')
    check(info && anim, 'MISSING_TIME_INFO')
    const curveRate = scalar(info, 'Rate')
    check(curveRate > 0, 'INVALID_TIME_RATE')
    const timeStart = time.start / time.rate,
      duration = (time.end - time.start) / time.rate,
      motionStart = motion.start / motion.rate,
      motionDuration = (motion.end - motion.start) / motion.rate
    const toFrame = (tick: number) => {
      const frame =
        (timeStart + ((tick / curveRate - motionStart) * duration) / motionDuration) * fps -
        startFrame
      check(
        Number.isFinite(frame) && Math.abs(frame) <= Number.MAX_SAFE_INTEGER,
        'INVALID_TIME_VALUE',
      )
      return frame
    }
    const issues: ClipDiagnostic[] = []
    unknownChildren(node, ['TimeClip', 'MotionClip', 'MotionBlend', 'TimeInfo', 'AnimInfo'], issues)
    unknownChildren(anim, ['Param', 'FCurve'], issues)
    const nativeBlend = child(node, 'MotionBlend'),
      blend = nativeBlend
        ? {
            enabled: scalar(nativeBlend, 'BlendEnable') !== 0,
            shift: scalar(nativeBlend, 'ShiftBlend'),
            next: scalar(nativeBlend, 'NextBlend'),
          }
        : undefined
    if (blend?.enabled) issues.push(diagnostic('UNSUPPORTED_KEYFRAME_BLEND'))
    const parameters: KeyframeParameter[] = [],
      curves: KeyframeCurve[] = [],
      seen = new Set<string>()
    for (const item of anim.children) {
      checkCancelled(options.signal)
      if (item.name === 'Param') {
        const property = item.attrs.Name
        check(property, 'INVALID_KEYFRAME_STRUCTURE', { field: 'Param.Name' })
        check(!seen.has(`param:${property}`), 'INVALID_KEYFRAME_STRUCTURE', { property })
        seen.add(`param:${property}`)
        parameters.push({
          property,
          kind: item.kind,
          values: item.values.slice(),
          tag: item.attrs.Tag,
        })
      } else if (item.name === 'FCurve') {
        const property = item.attrs.Type,
          axis = item.attrs.Axis,
          frameField = child(item, 'Frame'),
          ticks = frameField?.values,
          storedStartTick =
            frameField?.kind === 'Single[]'
              ? Math.fround((motion.start / motion.rate) * curveRate)
              : undefined
        check(property && ticks, 'INVALID_KEYFRAME_STRUCTURE', { field: 'FCurve.Type/Frame' })
        const key = JSON.stringify([property, axis])
        check(!seen.has(key), 'INVALID_KEYFRAME_STRUCTURE', { property })
        seen.add(key)
        const values = array(item, 'Value', ticks.length, 'number')!,
          interp = array(item, 'Interp', ticks.length, 'string', true),
          tags = array(item, 'Tag', ticks.length, 'string', true),
          left = array(item, 'LeftSlope', ticks.length, 'number', true),
          right = array(item, 'RightSlope', ticks.length, 'number', true),
          split = array(item, 'BreakKey', ticks.length, 'number', true),
          revise = array(item, 'ReviseConstant', ticks.length, 'number', true)
        let previous = -Infinity
        const keys = ticks.map((tick, index): PropertyKeyframe => {
          checkCancelled(options.signal)
          check(
            typeof tick === 'number' && Number.isFinite(tick) && tick > previous,
            'INVALID_KEYFRAME_KEYS',
            { property },
          )
          previous = tick
          return {
            tick,
            // CSP stores some cel Frame arrays as float32 while its motion envelope
            // is float64. A carried boundary key (e.g. 4.8 -> 4.800000190734863)
            // still takes effect at the clip start. Retain the raw tick verbatim.
            frame:
              tick === storedStartTick
                ? time.start * (fps / time.rate) - startFrame
                : toFrame(tick),
            value: values[index] as number,
            interpolation: interp?.[index] as string | undefined,
            leftSlope: left?.[index] as number | undefined,
            rightSlope: right?.[index] as number | undefined,
            ...(split ? { breakKey: split[index] as number } : {}),
            reviseConstant: revise?.[index] as number | undefined,
            tag: tags?.[index] as string | undefined,
          }
        })
        for (const interpolation of new Set(keys.map((k) => k.interpolation))) {
          if (!['Linear', 'Constant', 'Default', 'Hermite'].includes(interpolation ?? ''))
            issues.push(
              diagnostic('UNSUPPORTED_KEYFRAME_INTERPOLATION', {
                property,
                interpolation: interpolation ?? '',
              }),
            )
        }
        unknownChildren(
          item,
          [
            'Frame',
            'Value',
            'Interp',
            'Tag',
            'LeftSlope',
            'RightSlope',
            'BreakKey',
            'ReviseConstant',
          ],
          issues,
        )
        curves.push({
          property,
          axis,
          unit: Object.hasOwn(units, property) ? units[property]! : 'unknown',
          keys,
        })
      }
    }
    for (const property of new Set([...parameters, ...curves].map((p) => p.property))) {
      if (!Object.hasOwn(units, property))
        issues.push(diagnostic('UNSUPPORTED_KEYFRAME_PROPERTY', { property }))
    }
    // Convert each native boundary directly: start + duration can leak past an exclusive end.
    const clipStart = time.start * (fps / time.rate) - startFrame,
      clipEnd = time.end * (fps / time.rate) - startFrame
    check(
      [clipStart, clipEnd].every(
        (v) => Number.isFinite(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER,
      ) && clipEnd > clipStart,
      'INVALID_TIME_RANGE',
    )
    clips.push({
      name: node.attrs.Name ?? '',
      time,
      motion,
      curveRate,
      startFrame: clipStart,
      endFrame: clipEnd,
      blend,
      parameters,
      curves,
      diagnostics: issues,
    })
  }
  const ordered = [...clips].sort((a, b) => a.startFrame - b.startFrame)
  let lastEnd = -Infinity
  for (const clip of ordered) {
    if (compareFrame(clip.startFrame, lastEnd, startFrame) < 0)
      diagnostics.push(diagnostic('UNSUPPORTED_KEYFRAME_OVERLAP'))
    lastEnd = Math.max(lastEnd, clip.endFrame)
  }
  return { format: doc.secondary ? '0110' : '0100', version, fps, startFrame, clips, diagnostics }
}

export type KeyframeSample =
  | Readonly<{ status: 'value'; value: number; tag: string | undefined }>
  | Readonly<{ status: 'unavailable'; diagnostics: readonly ClipDiagnostic[] }>

/** Sample one numeric curve only: no hierarchy, MotionBlend interpretation, camera inversion or extrapolation. */
export function sampleKeyframeCurve(curve: KeyframeCurve, frame: number): KeyframeSample {
  check(Number.isFinite(frame), 'INVALID_TIME_VALUE')
  const keys = curve.keys
  check(keys.length <= bincReadLimits.array, 'LIMIT_BINC_ARRAY')
  let previous = -Infinity
  for (const key of keys) {
    check(
      Number.isFinite(key.frame) && key.frame > previous && Number.isFinite(key.value),
      'INVALID_KEYFRAME_KEYS',
    )
    previous = key.frame
  }
  const exact = keys.find((key) => key.frame === frame)
  if (exact) return { status: 'value', value: exact.value, tag: exact.tag }
  const next = keys.findIndex((key) => key.frame > frame)
  if (next <= 0)
    return {
      status: 'unavailable',
      diagnostics: [diagnostic('UNSUPPORTED_KEYFRAME_EXTRAPOLATION')],
    }
  const a = requiredAt(keys, next - 1),
    b = requiredAt(keys, next)
  const result = sampleKeyframeSegment(a, b, frame)
  check(
    result.status !== 'unavailable' ||
      !result.diagnostics.some((d) => d.code === 'INVALID_KEYFRAME_KEYS'),
    'INVALID_KEYFRAME_KEYS',
  )
  return result
}
