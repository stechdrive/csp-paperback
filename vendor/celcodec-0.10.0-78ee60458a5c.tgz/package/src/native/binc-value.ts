import { requiredAt } from '../internal/indexed.js'
import { BincDocument, type BincNode } from './binc.js'
import { inflateBounded } from './compression.js'
import { Reader, check } from '../internal/binary.js'
type Value = null | number | string | Value[]
export interface BincValueNode {
  name: string
  value: Value
  attrs: Record<string, string>
  children: BincValueNode[]
}
function valueNode(node: BincNode): BincValueNode {
  const base = node.kind.replace(/\[\]$/, ''),
    size =
      (
        { Float2: 2, Float3: 3, Double2: 2, Double3: 3, Quat: 4, Matrix44: 16 } as Record<
          string,
          number
        >
      )[base] ?? 1
  const values: Value[] =
    size === 1
      ? node.values
      : Array.from({ length: node.values.length / size }, (_, i) =>
          node.values.slice(i * size, (i + 1) * size),
        )
  return {
    name: node.name,
    value: node.kind === 'null' ? null : node.kind.endsWith('[]') ? values : requiredAt(values, 0),
    attrs: node.attrs,
    children: node.children.map(valueNode),
  }
}
/** Evaluation projection; use BincDocument to retain native kind/version/layout for editing. */
export function readBinc(bytes: Uint8Array): BincValueNode {
  return valueNode(new BincDocument(bytes).root)
}
export async function readActionMixer(bytes: Uint8Array): Promise<BincValueNode> {
  const r = new Reader(bytes, true)
  check(r.u32() === bytes.length - 4, 'INVALID_PACKED_BINC_SIZE')
  return readBinc(inflateBounded(r.take(bytes.length - 4), 16 * 1024 * 1024))
}
export function nodesNamed(node: BincValueNode, name: string): BincValueNode[] {
  return [
    ...(node.name === name ? [node] : []),
    ...node.children.flatMap((n) => nodesNamed(n, name)),
  ]
}
export function field(node: BincValueNode, name: string): Value | undefined {
  return node.children.find((n) => n.name === name)?.value
}
