import { requiredAt } from '../internal/indexed.js'
// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
import type { Database, SqlJsStatic, SqlValue, Statement } from './sql.js'
import { check, concat, concatParts, externalId, text, u64, uint64, utf8, view } from './binary.js'
import { readContainer, writeContainerLimits } from './container-read.js'
import { ClipError, checkCancelled, errorCode } from '../diagnostics.js'
export type Row = Record<string, SqlValue>
type RowChanges = Record<string, SqlValue | undefined>

function column(row: RowChanges, name: string): SqlValue {
  const value = row[name]
  check(value !== undefined, 'MISSING_COLUMN_VALUE', { column: name })
  return value
}

function checkTriggers(db: Database): void {
  for (const [name, table, sql] of db.exec(
    "SELECT name,tbl_name,sql FROM sqlite_master WHERE type='trigger'",
  )[0]?.values ?? []) {
    // CSP recreates these garbage-collection triggers when saving a document.
    // Permit their exact operation, not arbitrary SQL with a familiar name.
    const parts =
      /^External(Update|Delete)Of([A-Za-z_][A-Za-z_0-9]*)On([A-Za-z_][A-Za-z_0-9]*)$/.exec(
        String(name),
      )
    check(parts && parts[3] === table, 'UNSUPPORTED_SQL_TRIGGER')
    const [, operation, column, target] = parts
    const event = operation === 'Update' ? `UPDATE OF ${column}` : 'DELETE'
    const expected = `CREATE TRIGGER ${String(name)} ${event} ON ${target} BEGIN INSERT INTO RemovedExternal(ExternalID) VALUES(OLD.${column}); END`
    const normalize = (value: string) => value.replace(/\s+/g, '').replace(/;$/, '').toLowerCase()
    check(normalize(String(sql)) === normalize(expected), 'UNSUPPORTED_SQL_TRIGGER')
  }
}

export class ClipContainer {
  readonly imageLimits: import('../image-resources.js').ImageResourceLimits | undefined
  private readonly maxContainerBytes: number
  readonly db: Database
  readonly chunks: { tag: string; bytes: Uint8Array }[] = []
  readonly external = new Map<string, Uint8Array>()
  readonly additions = new Map<string, Uint8Array>()
  private externalOffsets = new Map<string, number>()
  private addedBytes = 0
  private readonly inputSize: number
  private rowStatements = new Map<string, Statement>()
  private schemaVersion = -1
  private schemaColumns = new Map<string, string[]>()
  private releaseStatements(): void {
    for (const statement of this.rowStatements.values()) statement.free()
    this.rowStatements.clear()
  }
  private columns(table: string): string[] {
    const version = Number(this.db.exec('PRAGMA schema_version')[0]?.values[0]?.[0])
    if (version !== this.schemaVersion) {
      this.schemaColumns.clear()
      this.releaseStatements()
      this.schemaVersion = version
    }
    const hit = this.schemaColumns.get(table)
    if (hit) return hit
    const columns = (this.db.exec(`PRAGMA table_info("${table}")`)[0]?.values ?? []).map((row) =>
      String(row[1]),
    )
    this.schemaColumns.set(table, columns)
    return columns
  }
  constructor(
    SQL: SqlJsStatic,
    bytes: Uint8Array,
    private readonly signal?: AbortSignal,
    options: {
      imageLimits?: import('../image-resources.js').ImageResourceLimits
      maxContainerBytes?: number
    } = {},
  ) {
    this.imageLimits = options.imageLimits
    this.maxContainerBytes = options.maxContainerBytes ?? writeContainerLimits.inputBytes
    this.inputSize = bytes.length
    const parsed = readContainer(
      bytes,
      { ...writeContainerLimits, inputBytes: this.maxContainerBytes },
      signal,
    )
    this.chunks = parsed.chunks
    this.external = parsed.external
    this.externalOffsets = parsed.externalOffsets
    const database = parsed.database
    this.db = new SQL.Database(database)
    try {
      this.db.run('PRAGMA trusted_schema=OFF')
      check(this.db.exec('PRAGMA quick_check')[0]?.values[0]?.[0] === 'ok', 'INVALID_DATABASE')
      checkTriggers(this.db)
      for (const row of this.rows('ExternalChunk'))
        check(
          this.externalOffsets.get(String(row.ExternalID)) === row.Offset,
          'INVALID_EXTERNAL_OFFSET',
        )
      check(this.rows('Canvas').length === 1, 'UNSUPPORTED_MULTI_CANVAS')
    } catch (error) {
      this.db.close()
      if (error instanceof ClipError || error instanceof TypeError) throw error
      if (error instanceof RangeError) errorCode(error)
      throw new ClipError('INVALID_DATABASE', undefined, { cause: error })
    }
  }
  private closed = false
  readonly changes = new Map<string, { table: string; id: number }>()
  private active(): void {
    check(!this.closed, 'CLOSED_DOCUMENT')
    checkCancelled(this.signal)
  }
  rows(table: string): Row[] {
    this.active()
    check(/^[A-Za-z_][A-Za-z_0-9]*$/.test(table), 'INVALID_TABLE_NAME')
    const statement = this.db.prepare(`SELECT * FROM "${table}"`),
      result: Row[] = []
    try {
      while (statement.step()) {
        checkCancelled(this.signal)
        check(result.length < 1_000_000, 'LIMIT_DATABASE_ROWS')
        result.push(statement.getAsObject())
      }
    } finally {
      statement.free()
    }
    return result
  }
  row(table: string, id: SqlValue | undefined): Row {
    this.active()
    check(id !== undefined, 'MISSING_ROW_ID')
    check(/^[A-Za-z_][A-Za-z_0-9]*$/.test(table), 'INVALID_TABLE_NAME')
    const statement =
      this.rowStatements.get(table) ?? this.db.prepare(`SELECT * FROM "${table}" WHERE MainId=?`)
    if (statement.reset) this.rowStatements.set(table, statement)
    try {
      statement.bind([id])
      check(statement.step(), 'MISSING_ROW')
      return statement.getAsObject()
    } finally {
      if (statement.reset) statement.reset()
      else statement.free()
    }
  }
  update(table: string, id: SqlValue | undefined, changes: RowChanges): void {
    check(id !== undefined, 'MISSING_ROW_ID')
    const original = this.row(table, id),
      columns = Object.keys(original)
    const equal = (a: SqlValue, b: SqlValue) =>
      a === b ||
      (a instanceof Uint8Array &&
        b instanceof Uint8Array &&
        a.length === b.length &&
        a.every((v, i) => v === b[i]))
    const entries = Object.keys(changes)
      .filter((key) => columns.includes(key))
      .map((key): [string, SqlValue] => [key, column(changes, key)])
      .filter(([key, value]) => !equal(column(original, key), value))
    check(
      entries.every(([key]) => /^[A-Za-z_][A-Za-z_0-9]*$/.test(key)),
      'INVALID_COLUMN_NAME',
    )
    if (entries.length) {
      this.db.run(
        `UPDATE "${table}" SET ${entries.map(([key]) => `"${key}"=?`).join(',')} WHERE MainId=?`,
        [...entries.map(([, value]) => value), id],
      )
      this.changes.set(`${table}:${String(id)}`, { table, id: Number(id) })
    }
  }
  insert(table: string, template: Row, changes: RowChanges = {}): Row {
    this.active()
    check(/^[A-Za-z_][A-Za-z_0-9]*$/.test(table), 'INVALID_TABLE_NAME')
    const columns = this.columns(table)
    const next = (column: string) =>
      Number(
        requiredAt(
          requiredAt(this.db.exec(`SELECT COALESCE(MAX("${column}"),0)+1 FROM "${table}"`), 0)
            .values,
          0,
        )[0],
      )
    const row: Row = Object.fromEntries(
      Object.entries({
        ...template,
        ...changes,
        MainId: next('MainId'),
        _PW_ID: next('_PW_ID'),
      }).filter(([key]) => columns.includes(key)),
    )
    const keys = Object.keys(row)
    check(
      keys.every((key) => /^[A-Za-z_][A-Za-z_0-9]*$/.test(key)),
      'INVALID_COLUMN_NAME',
    )
    check(
      keys.every((key) => row[key] !== undefined),
      'MISSING_COLUMN_VALUE',
    )
    this.db.run(
      `INSERT INTO "${table}" (${keys.map((key) => `"${key}"`).join(',')}) VALUES (${keys.map(() => '?').join(',')})`,
      keys.map((key) => column(row, key)),
    )
    this.db.run('UPDATE ElemScheme SET MaxIndex=? WHERE TableName=?', [
      column(row, 'MainId'),
      table,
    ])
    this.changes.set(`${table}:${String(row.MainId)}`, { table, id: Number(row.MainId) })
    return row
  }
  addExternal(body: Uint8Array): Uint8Array {
    this.active()
    this.addedBytes += body.length + 80
    check(this.inputSize + this.addedBytes <= this.maxContainerBytes, 'LIMIT_CONTAINER_BYTES')
    const id = externalId()
    this.additions.set(id, body)
    this.db.run('INSERT INTO ExternalChunk (ExternalID,Offset) VALUES (?,0)', [id])
    return utf8.encode(id)
  }
  body(id: SqlValue | undefined): Uint8Array | undefined {
    this.active()
    const key = id instanceof Uint8Array ? text.decode(id) : String(id)
    return this.additions.get(key) ?? this.external.get(key)
  }
  bytes(): Uint8Array {
    this.active()
    const chunks = this.chunks.slice(0, -2).map((chunk) => ({ ...chunk }))
    for (const [id, bytes] of this.additions)
      chunks.push({
        tag: 'CHNKExta',
        bytes: concat(u64(id.length), utf8.encode(id), u64(bytes.length), bytes),
      })
    let offset = 24
    for (const chunk of chunks) {
      if (chunk.tag === 'CHNKExta') {
        const length = uint64(chunk.bytes, 0),
          id = text.decode(chunk.bytes.subarray(8, 8 + length))
        if (this.externalOffsets.get(id) !== offset)
          this.db.run('UPDATE ExternalChunk SET Offset=? WHERE ExternalID=?', [offset, id])
      }
      offset += 16 + chunk.bytes.length
    }
    requiredAt(chunks, 0).bytes = requiredAt(chunks, 0).bytes.slice()
    view(requiredAt(chunks, 0).bytes).setBigUint64(8, BigInt(offset))
    check(this.db.exec('PRAGMA quick_check')[0]?.values[0]?.[0] === 'ok', 'INVALID_DATABASE')
    // sql.js export closes its statements; invalidate owned handles before exporting.
    this.releaseStatements()
    chunks.push({ tag: 'CHNKSQLi', bytes: this.db.export() }, { ...this.chunks.at(-1)! })
    check(
      24 + chunks.reduce((sum, chunk) => sum + 16 + chunk.bytes.length, 0) <=
        this.maxContainerBytes,
      'LIMIT_CONTAINER_BYTES',
    )
    const length = 24 + chunks.reduce((sum, chunk) => sum + 16 + chunk.bytes.length, 0)
    return concatParts([
      utf8.encode('CSFCHUNK'),
      u64(length),
      u64(24),
      ...chunks.flatMap((chunk) => [utf8.encode(chunk.tag), u64(chunk.bytes.length), chunk.bytes]),
    ])
  }
  close(): void {
    if (!this.closed) {
      this.closed = true
      this.releaseStatements()
      this.schemaColumns.clear()
      this.db.close()
      this.external.clear()
      this.additions.clear()
      this.externalOffsets.clear()
      this.changes.clear()
      this.addedBytes = 0
      this.chunks.length = 0
    }
  }
}
export function blob(value: SqlValue | undefined): Uint8Array {
  check(value instanceof Uint8Array, 'MISSING_BINARY_COLUMN')
  return value
}
