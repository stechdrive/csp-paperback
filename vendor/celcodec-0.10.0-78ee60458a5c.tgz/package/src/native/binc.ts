// BINC field research from csp-paperback and xsheet-remap. See THIRD_PARTY_NOTICES.md.
import { Reader, check } from '../internal/binary.js'
import { requiredAt } from '../internal/indexed.js'
import { checkCancelled } from '../diagnostics.js'
import { concat, concatParts, crc32, u32, utf8, view } from './binary.js'

export interface BincNode {
  name: string
  kind: string
  values: (number | string)[]
  attrs: Record<string, string>
  children: BincNode[]
}
export interface BincLimits {
  bytes: number
  strings: number
  depth: number
  nodes: number
  attributes: number
  children: number
  array: number
}
export const bincReadLimits: Readonly<BincLimits> = Object.freeze({
  bytes: 16 * 1024 * 1024,
  strings: 65536,
  depth: 64,
  nodes: 100000,
  attributes: 1024,
  children: 100000,
  array: 1000000,
})
export const bincWriteLimits: Readonly<BincLimits> = Object.freeze({
  bytes: 15999999,
  strings: 99999,
  depth: 99,
  nodes: 100000,
  attributes: 9999,
  children: 9999,
  array: 999999,
})
const scalars = {
  Byte: 'u8',
  SByte: 'i8',
  UInt16: 'u16',
  Int16: 'i16',
  UInt32: 'u32',
  Int32: 'i32',
  Single: 'f32',
  Double: 'f64',
} as const
const vectors: Record<string, number> = {
  Float2: 2,
  Float3: 3,
  Double2: 2,
  Double3: 3,
  Quat: 4,
  Matrix44: 16,
}
const width = (base: string): number => (Object.hasOwn(vectors, base) ? (vectors[base] ?? 1) : 1)

/** Mutable native tree with lossless no-edit serialization, including 0110 layout words. */
export class BincDocument {
  root: BincNode
  secondary: boolean
  private readonly original: Uint8Array
  private readonly snapshot: string
  private writable = true
  constructor(
    bytes: Uint8Array,
    readonly limits: Readonly<BincLimits> = bincReadLimits,
    signal?: AbortSignal,
  ) {
    checkCancelled(signal)
    check(
      Object.values(limits).every((value) => Number.isSafeInteger(value) && value > 0),
      'INVALID_LIMIT',
    )
    check(bytes.length <= limits.bytes, 'LIMIT_BINC_BYTES')
    const r = new Reader(bytes, true),
      header = r.text(12)
    check(header === 'cmt 0100binc' || header === 'cmt 0110binc', 'UNSUPPORTED_BINC_VERSION')
    this.secondary = header === 'cmt 0110binc'
    check(r.u32() === crc32(bytes.subarray(16)), 'INVALID_BINC_CHECKSUM')
    const count = r.u32()
    check(count <= limits.strings, 'LIMIT_BINC_STRINGS')
    const strings = Array.from({ length: count }, () => r.text(r.number('u8')))
    const str = () => {
      const id = r.u32()
      check(id === 0xffffffff || id < strings.length, 'INVALID_BINC_STRING')
      return id === 0xffffffff ? '' : requiredAt(strings, id)
    }
    let nodes = 0
    const node = (depth: number): BincNode => {
      checkCancelled(signal)
      check(depth <= limits.depth, 'LIMIT_BINC_DEPTH')
      check(++nodes <= limits.nodes, 'LIMIT_BINC_NODES')
      const layout = this.secondary ? [r.u32(), r.u32(), r.u32()] : undefined
      const name = str(),
        kind = str(),
        values: BincNode['values'] = []
      const start = r.position
      if (kind !== 'null') {
        const base = kind.replace(/\[\]$/, ''),
          length = kind.endsWith('[]') ? r.u32() : 1
        check(length <= limits.array, 'LIMIT_BINC_ARRAY')
        check(
          base === 'String' || Object.hasOwn(scalars, base) || Object.hasOwn(vectors, base),
          'UNSUPPORTED_BINC_VALUE',
          { type: base },
        )
        for (let i = 0; i < length * width(base); i++)
          values.push(
            base === 'String'
              ? str()
              : r.number(
                  Object.hasOwn(scalars, base)
                    ? scalars[base as keyof typeof scalars]
                    : base.startsWith('Double')
                      ? 'f64'
                      : 'f32',
                ),
          )
      }
      const valueBytes = r.position - start,
        attrs: Record<string, string> = Object.create(null)
      const attrCount = r.u32()
      check(attrCount <= limits.attributes, 'LIMIT_BINC_ATTRIBUTES')
      for (let i = 0; i < attrCount; i++) {
        const key = str()
        check(!Object.hasOwn(attrs, key), 'INVALID_BINC_ATTRIBUTES')
        attrs[key] = str()
      }
      const childCount = r.u32()
      check(childCount <= limits.children, 'LIMIT_BINC_NODES')
      if (
        layout &&
        (layout[0] !== 16 ||
          layout[1] !== 20 + valueBytes ||
          layout[2] !== 24 + valueBytes + attrCount * 8)
      )
        this.writable = false
      return {
        name,
        kind,
        values,
        attrs,
        children: Array.from({ length: childCount }, () => node(depth + 1)),
      }
    }
    this.root = node(0)
    check(r.position === bytes.length, 'INVALID_BINC_TRAILING_DATA')
    this.original = bytes.slice()
    this.snapshot = JSON.stringify([this.secondary, this.root])
  }
  walk(
    fn: (node: BincNode, parent: BincNode | undefined) => void,
    node = this.root,
    parent?: BincNode,
  ): void {
    fn(node, parent)
    for (const child of node.children) this.walk(fn, child, node)
  }
  encode(): Uint8Array {
    // Bound edited trees before fingerprinting or allocating arrays. Callers can
    // mutate the public tree, including accidentally adding a cycle.
    const ancestors = new Set<BincNode>()
    let checked = 0
    const validate = (node: BincNode, depth: number): void => {
      check(depth <= this.limits.depth, 'LIMIT_BINC_DEPTH')
      check(++checked <= this.limits.nodes && !ancestors.has(node), 'LIMIT_BINC_NODES')
      check(
        node &&
          typeof node.name === 'string' &&
          typeof node.kind === 'string' &&
          Array.isArray(node.values) &&
          Array.isArray(node.children) &&
          node.attrs &&
          typeof node.attrs === 'object',
        'INVALID_BINC_SIZE',
      )
      const base = node.kind.replace(/\[\]$/, '')
      check(node.values.length <= this.limits.array * width(base), 'LIMIT_BINC_ARRAY')
      check(node.children.length <= this.limits.children, 'LIMIT_BINC_NODES')
      const attrs = Object.entries(node.attrs)
      check(attrs.length <= this.limits.attributes, 'LIMIT_BINC_ATTRIBUTES')
      for (const value of [node.name, node.kind, ...attrs.flat()])
        check(
          typeof value === 'string' && value.length <= 255 && utf8.encode(value).length <= 255,
          'LIMIT_BINC_STRING_LENGTH',
        )
      for (const value of node.values)
        if (typeof value === 'string')
          check(value.length <= 255 && utf8.encode(value).length <= 255, 'LIMIT_BINC_STRING_LENGTH')
      ancestors.add(node)
      for (const child of node.children) validate(child, depth + 1)
      ancestors.delete(node)
    }
    validate(this.root, 0)
    if (JSON.stringify([this.secondary, this.root]) === this.snapshot) return this.original.slice()
    check(this.writable, 'UNSUPPORTED_BINC_LAYOUT')
    const strings: string[] = [],
      ids = new Map<string, number>()
    let nodes = 0,
      allocated = 20
    const str = (s: string) => {
      if (!ids.has(s)) {
        check(strings.length < this.limits.strings, 'LIMIT_BINC_STRINGS')
        ids.set(s, strings.length)
        strings.push(s)
      }
      return u32(ids.get(s)!, true)
    }
    const encodeNode = (node: BincNode, depth: number): Uint8Array => {
      check(depth <= this.limits.depth, 'LIMIT_BINC_DEPTH')
      check(++nodes <= this.limits.nodes, 'LIMIT_BINC_NODES')
      const name = str(node.name),
        kind = str(node.kind),
        base = node.kind.replace(/\[\]$/, '')
      check(
        node.kind === 'null' ||
          base === 'String' ||
          Object.hasOwn(scalars, base) ||
          Object.hasOwn(vectors, base),
        'UNSUPPORTED_BINC_VALUE',
        { type: base },
      )
      check(
        node.kind === 'null'
          ? node.values.length === 0
          : node.values.length % width(base) === 0 &&
              (node.kind.endsWith('[]')
                ? node.values.length / width(base) <= this.limits.array
                : node.values.length === width(base)),
        'INVALID_BINC_SIZE',
      )
      const type =
        base === 'String'
          ? 'u32'
          : Object.hasOwn(scalars, base)
            ? scalars[base as keyof typeof scalars]
            : base.startsWith('Double')
              ? 'f64'
              : 'f32'
      const size = { u8: 1, i8: 1, u16: 2, i16: 2, u32: 4, i32: 4, f32: 4, f64: 8 }[type]
      const prefix = node.kind.endsWith('[]') ? 4 : 0,
        valueLength = prefix + node.values.length * size
      check(allocated + valueLength <= this.limits.bytes, 'LIMIT_BINC_BYTES')
      const values = new Uint8Array(valueLength),
        v = view(values)
      if (prefix) v.setUint32(0, node.values.length / width(base), true)
      node.values.forEach((value, index) => {
        const offset = prefix + index * size
        if (base === 'String') {
          check(typeof value === 'string', 'UNSUPPORTED_BINC_VALUE')
          values.set(str(value), offset)
          return
        }
        check(typeof value === 'number' && Number.isFinite(value), 'INVALID_NUMBER')
        if (type[0] !== 'f')
          check(
            Number.isInteger(value) &&
              value >= (type[0] === 'i' ? -(2 ** (size * 8 - 1)) : 0) &&
              value < 2 ** (size * 8 - (type[0] === 'i' ? 1 : 0)),
            'INVALID_NUMBER',
          )
        switch (type) {
          case 'u8':
            v.setUint8(offset, value)
            break
          case 'i8':
            v.setInt8(offset, value)
            break
          case 'u16':
            v.setUint16(offset, value, true)
            break
          case 'i16':
            v.setInt16(offset, value, true)
            break
          case 'u32':
            v.setUint32(offset, value, true)
            break
          case 'i32':
            v.setInt32(offset, value, true)
            break
          case 'f32':
            check(Number.isFinite(Math.fround(value)), 'INVALID_NUMBER')
            v.setFloat32(offset, value, true)
            break
          case 'f64':
            v.setFloat64(offset, value, true)
        }
      })
      const attrs = Object.entries(node.attrs)
      check(attrs.length <= this.limits.attributes, 'LIMIT_BINC_ATTRIBUTES')
      check(node.children.length <= this.limits.children, 'LIMIT_BINC_NODES')
      allocated += 16 + values.length + attrs.length * 8 + (this.secondary ? 12 : 0)
      check(allocated <= this.limits.bytes, 'LIMIT_BINC_BYTES')
      return concatParts([
        ...(this.secondary
          ? [
              u32(16, true),
              u32(20 + values.length, true),
              u32(24 + values.length + attrs.length * 8, true),
            ]
          : []),
        name,
        kind,
        values,
        u32(attrs.length, true),
        ...attrs.map(([k, v]) => concat(str(k), str(v))),
        u32(node.children.length, true),
        ...node.children.map((n) => encodeNode(n, depth + 1)),
      ])
    }
    const root = encodeNode(this.root, 0)
    const body = concatParts([
      u32(strings.length, true),
      ...strings.map((s) => {
        const b = utf8.encode(s)
        check(b.length <= 255, 'LIMIT_BINC_STRING_LENGTH')
        return concat(new Uint8Array([b.length]), b)
      }),
      root,
    ])
    check(body.length + 16 <= this.limits.bytes, 'LIMIT_BINC_BYTES')
    return concat(
      utf8.encode(this.secondary ? 'cmt 0110binc' : 'cmt 0100binc'),
      u32(crc32(body), true),
      body,
    )
  }
}
