import { requiredAt, numberAt, u8At } from '../internal/indexed.js'
// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
import { ClipError } from '../diagnostics.js'
import type { SqlJsStatic } from './sql.js'
import { inflateBounded } from './compression.js'
import { Mixer } from './animation.js'
import { check, view } from './binary.js'
import { openNativeStore } from '../document/store.js'
import type { ClipRow as Row } from '../internal/records.js'
import type { SqlValue } from './sql.js'
import { normalizedUuid } from './layer-metadata.js'
import { frameCoordinate as frame } from '../internal/frame-coordinate.js'

export interface ClipAudioTiming {
  objectId: string
  /** Relative to playback start. Timing values retain fractional frames after FPS conversion. */
  startFrame: number
  sourceOffsetFrames: number
  durationFrames: number
  muted?: boolean
}
export interface ClipAudioReadResult {
  fps: number
  clips: (ClipAudioTiming & { assetId: string })[]
  assets: { id: string; name: string; mimeType: string; bytes: Uint8Array }[]
}
type Node = Mixer['root']
const child = (node: Node, name: string) => node.children.find((item) => item.name === name)
function number(node: Node, name: string) {
  const value = Number(child(node, name)?.values[0])
  check(Number.isFinite(value), 'INVALID_TIME_VALUE')
  return value
}
/** Only normal-speed, constant-volume clips are imported; unknown automation stays in the source CLIP. */
export function readAudioTiming(
  bytes: Uint8Array,
  size: number,
  fps: number,
  startFrame: number,
): ClipAudioTiming[] {
  check(
    Number.isFinite(fps) && fps > 0 && fps <= 1000 && Number.isFinite(startFrame),
    'INVALID_TIMELINE_RANGE',
  )
  check(
    bytes.length >= 5 && view(bytes).getUint32(0, true) === bytes.length - 4,
    'INVALID_PACKED_BINC_SIZE',
  )
  check(Number.isInteger(size) && size >= 16 && size < 16_000_000, 'LIMIT_BINC_BYTES')
  const raw = inflateBounded(bytes.subarray(4), size)
  check(raw.length === size, 'INVALID_BINC_SIZE')
  const mixer = new Mixer(raw),
    clips: ClipAudioTiming[] = []
  mixer.walk((node) => {
    if (node.name !== 'ActionNodeClip') return
    const anim = child(node, 'AnimInfo')
    const player = anim?.children.find(
      (item) => item.name === 'Param' && item.attrs.Name === 'AudioPlayer',
    )
    const playerCurve = anim?.children.find(
      (item) => item.name === 'FCurve' && item.attrs.Type === 'AudioPlayer',
    )
    if (!player && !playerCurve) return
    const tags = (playerCurve && child(playerCurve, 'Tag')?.values) || [player?.attrs.Tag]
    const ids = tags.map((tag) => normalizedUuid(String(tag ?? '')))
    check(
      ids.length > 0 && ids.every((id) => /^[0-9a-f]{32}$/.test(id) && id === ids[0]),
      'UNSUPPORTED_AUDIO_SWITCH',
    )
    check(
      !player?.attrs.Tag || normalizedUuid(player.attrs.Tag) === ids[0],
      'INVALID_AUDIO_INITIAL_VALUE',
    )
    check(
      !playerCurve || child(playerCurve, 'Frame')?.values.length === tags.length,
      'INVALID_AUDIO_CURVE',
    )
    check(
      !playerCurve || child(playerCurve, 'Interp')?.values.every((value) => value === 'Constant'),
      'UNSUPPORTED_AUDIO_INTERPOLATION',
    )
    const volume = anim!.children.find(
      (item) => item.name === 'Param' && item.attrs.Name === 'AudioVolume',
    )
    check(
      volume &&
        [0, 100].includes(Number(volume.values[0])) &&
        !anim!.children.some((item) => item.name === 'FCurve' && item.attrs.Type === 'AudioVolume'),
      'UNSUPPORTED_AUDIO_VOLUME',
    )
    const time = child(node, 'TimeClip'),
      motion = child(node, 'MotionClip'),
      info = child(node, 'TimeInfo')
    check(time && motion && info, 'MISSING_TIME_INFO')
    const timeRate = number(time, 'Rate'),
      motionRate = number(motion, 'Rate'),
      curveRate = number(info, 'Rate')
    check(timeRate > 0 && motionRate > 0 && curveRate > 0, 'INVALID_TIME_RATE')
    const timeStart = number(time, 'Start') / timeRate,
      timeEnd = number(time, 'End') / timeRate
    const motionStart = number(motion, 'Start') / motionRate,
      motionEnd = number(motion, 'End') / motionRate
    check(timeEnd > timeStart && motionEnd > motionStart, 'INVALID_TIME_RANGE')
    const blend = child(node, 'MotionBlend')
    check(!blend || !Number(child(blend, 'BlendEnable')?.values[0]), 'UNSUPPORTED_AUDIO_BLEND')
    const curve = anim!.children.find(
      (item) => item.name === 'FCurve' && item.attrs.Type === 'PlayTime',
    )
    check(curve, 'MISSING_AUDIO_POSITION')
    const frames = child(curve, 'Frame')?.values.map(Number) ?? [],
      values = child(curve, 'Value')?.values.map(Number) ?? []
    const interp = child(curve, 'Interp')?.values ?? []
    check(
      frames.length >= 2 &&
        frames.length === values.length &&
        interp.length === frames.length &&
        interp.every((value) => value === 'Linear'),
      'UNSUPPORTED_AUDIO_CURVE',
    )
    const rate = (motionEnd - motionStart) / (timeEnd - timeStart)
    for (let i = 0; i < frames.length; i++) {
      check(Number.isFinite(frames[i]) && Number.isFinite(values[i]), 'INVALID_AUDIO_POSITION')
      if (i)
        check(
          numberAt(frames, i) > numberAt(frames, i - 1) &&
            Math.abs(
              ((numberAt(values, i) - numberAt(values, i - 1)) /
                ((numberAt(frames, i) - numberAt(frames, i - 1)) / curveRate)) *
                rate -
                1,
            ) < 0.0001,
          'UNSUPPORTED_AUDIO_SPEED',
        )
    }
    const offset = numberAt(values, 0) + (motionStart - numberAt(frames, 0) / curveRate) / rate
    const sourceOffsetFrames = frame(offset * fps),
      durationFrames = frame((timeEnd - timeStart) * fps)
    check(sourceOffsetFrames >= 0 && durationFrames > 0, 'INVALID_AUDIO_RANGE')
    clips.push({
      objectId: requiredAt(ids, 0),
      startFrame: frame(timeStart * fps) - startFrame,
      sourceOffsetFrames,
      durationFrames,
      ...(Number(volume.values[0]) === 0 ? { muted: true } : {}),
    })
  })
  return clips.sort((a, b) => a.startFrame - b.startFrame)
}

function audioMimeType(bytes: Uint8Array): string {
  const text = new TextDecoder().decode(bytes.subarray(0, 12))
  if (text.startsWith('RIFF') && text.slice(8) === 'WAVE') return 'audio/wav'
  if (
    text.startsWith('ID3') ||
    (bytes.length >= 2 && bytes[0] === 0xff && (u8At(bytes, 1) & 0xe0) === 0xe0)
  )
    return 'audio/mpeg'
  throw new ClipError('UNSUPPORTED_AUDIO_FORMAT')
}

export function readClipAudio(
  SQL: SqlJsStatic,
  bytes: Uint8Array,
  layerId: number,
  timelineId: string,
): ClipAudioReadResult {
  const clip = openNativeStore(SQL, bytes)
  try {
    return readAudioFrom(clip, layerId, timelineId)
  } finally {
    clip.dispose()
  }
}
export interface AudioSource {
  rows(table: string): Row[]
  row(table: string, id: number): Row
  body(id: SqlValue | undefined): Uint8Array | undefined
}
/** Shared document indices; extracting another audio asset never reopens SQLite. */
export function readAudioFrom(
  clip: AudioSource,
  layerId: number,
  timelineId: string,
): ClipAudioReadResult {
  const layer = clip.row('Layer', layerId),
    timeline = clip
      .rows('TimeLine')
      .find((item) => normalizedUuid(item.TimeLineUuid) === timelineId)
  check(Number(layer.AudioLayer) === 1 && timeline, 'INVALID_AUDIO_SELECTION')
  const fps = Number(timeline.FrameRate)
  check(
    Number.isFinite(fps) && fps >= 1 && fps <= 120 && Number.isFinite(timeline.StartFrame),
    'INVALID_AUDIO_TIMELINE',
  )
  const trackRows = new Map(clip.rows('Track').map((r) => [Number(r.MainId), r])),
    ordered: Row[] = [],
    seen = new Set<number>()
  let next = Number(timeline.FirstTrack)
  while (next) {
    const row = trackRows.get(next)
    check(
      row && row.ItemId === timeline.MainId && row.BankId === timeline.BankId && !seen.has(next),
      'INVALID_REFERENCE_CHAIN',
    )
    seen.add(next)
    ordered.push(row)
    next = Number(row.TrackNextIndex)
  }
  const tracks = ordered.filter(
    (item) =>
      item.TrackKind === 4001 &&
      item.ItemId === timeline.MainId &&
      item.BankId === timeline.BankId &&
      normalizedUuid(item.LayerUuidWithTrack) === normalizedUuid(layer.LayerUuid),
  )
  check(tracks.length <= 1, 'INVALID_AUDIO_TRACK_COUNT')
  // A layer can exist in the document without being placed on this timeline.
  if (!tracks.length) return { fps, clips: [], assets: [] }
  const track = requiredAt(tracks, 0),
    field = clip.body(track.TrackActionMixer) ? 'TrackActionMixer' : 'TrackActionMixer2',
    body = clip.body(track[field])
  check(body, 'MISSING_AUDIO_TIMING')
  const timing = readAudioTiming(
    body,
    Number(track[`${field}Size`]),
    fps,
    Number(timeline.StartFrame),
  )
  const objects = clip
    .rows('LayerObject')
    .filter((item) => item.LayerId === layerId && Number(item.IsAudio) === 1)
  const items = clip.rows('CanvasItem'),
    binaries = clip.rows('CanvasItemBinary')
  const assets = new Map<string, ClipAudioReadResult['assets'][number]>()
  const clips = timing.flatMap((placement) => {
    const object = objects.find((item) => normalizedUuid(item.ObjectUuid) === placement.objectId)
    check(object, 'MISSING_AUDIO_REFERENCE')
    if (object.ObjectVisibility === 0) return []
    const id = normalizedUuid(object.BankItemUuid),
      item = items.find((item) => normalizedUuid(item.ItemUuid) === id)
    check(item?.ItemType === 'Audio', 'MISSING_AUDIO_MATERIAL')
    if (!assets.has(id)) {
      const binary = binaries.find(
        (binary) =>
          binary.MainId === item.ItemBinaryMainIndex &&
          binary.ItemId === item.MainId &&
          binary.BankId === item.BankId,
      )
      const data = binary && clip.body(binary.ItemBinaryData)
      check(data, 'MISSING_AUDIO_DATA')
      assets.set(id, {
        id,
        name: String(item.ItemCaption || layer.LayerName),
        mimeType: audioMimeType(data),
        bytes: data.slice(),
      })
    }
    return [{ ...placement, assetId: id }]
  })
  // An explicit empty track is native silence on this timeline, not a missing asset.
  return { fps, clips, assets: [...assets.values()] }
}
