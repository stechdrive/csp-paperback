import { requiredAt } from '../internal/indexed.js'
// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
import { inflateBounded } from './compression.js'
import type { ExportTrackFrame } from './model.js'
import { Mixer } from './animation.js'
import { check, view } from './binary.js'
import { celChannel } from './cel-channel.js'
import { frameCoordinate as frameNumber } from '../internal/frame-coordinate.js'

type Node = Mixer['root']
const child = (node: Node, name: string) => node.children.find((item) => item.name === name)
function number(node: Node, name: string): number {
  const value = Number(child(node, name)?.values[0])
  check(Number.isFinite(value), 'INVALID_TIME_VALUE')
  return value
}
/** Retain active cel assignments outside playback, relative to the playback start. */
export function readAnimation(
  bytes: Uint8Array,
  unpackedSize: number,
  fps: number,
  start: number,
  end: number,
): ExportTrackFrame[] {
  check(
    Number.isFinite(fps) &&
      fps > 0 &&
      fps <= 1000 &&
      Number.isFinite(start) &&
      Number.isFinite(end) &&
      end > start,
    'INVALID_TIMELINE_RANGE',
  )
  check(
    bytes.length >= 5 && view(bytes).getUint32(0, true) === bytes.length - 4,
    'INVALID_PACKED_BINC_SIZE',
  )
  check(
    Number.isInteger(unpackedSize) && unpackedSize >= 16 && unpackedSize < 16_000_000,
    'LIMIT_BINC_BYTES',
  )
  const raw = inflateBounded(bytes.subarray(4), unpackedSize)
  check(raw.length === unpackedSize, 'INVALID_BINC_SIZE')
  const mixer = new Mixer(raw)
  const clips: { start: number; end: number; keys: ExportTrackFrame[] }[] = []
  mixer.walk((node) => {
    if (node.name !== 'ActionNodeClip') return
    const anim = child(node, 'AnimInfo')
    const curve = anim?.children.find(
      (item) => item.name === 'FCurve' && item.attrs.Type === 'ImageCelName',
    )
    const param = anim?.children.find(
      (item) => item.name === 'Param' && item.attrs.Name === 'ImageCelName',
    )
    if (!curve && !param) return
    const time = child(node, 'TimeClip'),
      motion = child(node, 'MotionClip'),
      info = child(node, 'TimeInfo')
    check(time && motion && info, 'MISSING_TIME_INFO')
    const timeRate = number(time, 'Rate'),
      motionRate = number(motion, 'Rate'),
      curveRate = number(info, 'Rate')
    check(timeRate > 0 && motionRate > 0 && curveRate > 0, 'INVALID_TIME_RATE')
    const timeStart = number(time, 'Start') / timeRate,
      timeEnd = number(time, 'End') / timeRate
    const motionStart = number(motion, 'Start') / motionRate,
      motionEnd = number(motion, 'End') / motionRate
    check(timeEnd > timeStart && motionEnd > motionStart, 'INVALID_TIME_RANGE')
    const clipStart = frameNumber(timeStart * fps),
      clipEnd = frameNumber(timeEnd * fps)
    const blend = child(node, 'MotionBlend')
    check(!blend || !Number(child(blend, 'BlendEnable')?.values[0]), 'UNSUPPORTED_CEL_BLEND')
    const channel = curve
      ? celChannel(
          child(curve, 'Frame')?.values,
          child(curve, 'Tag')?.values,
          child(curve, 'Value')?.values,
          child(curve, 'Interp')?.values,
          !!param,
          param?.attrs.Tag,
        )
      : []
    const keys: ExportTrackFrame[] = []
    let carry: string | null = param?.attrs.Tag || null
    for (const key of channel) {
      const localTime = key.frame / curveRate,
        value = key.value
      if (localTime <= motionStart) carry = value
      if (localTime < motionStart || localTime >= motionEnd) continue
      const frame = frameNumber(
        (timeStart +
          ((localTime - motionStart) * (timeEnd - timeStart)) / (motionEnd - motionStart)) *
          fps,
      )
      keys.push({ frame, value })
    }
    if (!keys.length || requiredAt(keys, 0).frame > clipStart)
      keys.unshift({ frame: clipStart, value: carry })
    clips.push({ start: clipStart, end: clipEnd, keys })
  })
  clips.sort((a, b) => a.start - b.start)
  check(
    clips.every((clip, i) => i === 0 || requiredAt(clips, i - 1).end <= clip.start),
    'UNSUPPORTED_CEL_OVERLAP',
  )
  const workStart = Math.min(start, clips[0]?.start ?? start)
  const workEnd = clips.reduce((last, clip) => Math.max(last, clip.keys.at(-1)!.frame + 1), end)
  check(workEnd - workStart <= 1_000_000, 'LIMIT_TIMELINE_RANGE')
  const events = new Map<number, string | null>([[workStart, null]])
  for (const clip of clips) {
    for (const key of clip.keys) events.set(key.frame, key.value)
    // Preserve gaps, without expanding dummy frames to a long clip's empty tail.
    if (clip.end < workEnd) events.set(clip.end, null)
  }
  return [...events]
    .sort(([a], [b]) => a - b)
    .map(([frame, value]) => ({ frame: frame - start, value }))
}
