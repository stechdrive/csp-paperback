import { check } from './binary.js'

/** Native cel-channel decoding shared by signed editing and output-frame projections. */
export function celChannel(
  frames: unknown,
  tags: unknown,
  values: unknown,
  interpolation: unknown,
  hasParam: boolean,
  defaultTag: string | undefined,
): { frame: number; value: string | null }[] {
  check(Array.isArray(frames), 'INVALID_CEL_KEYS')
  // PAINT omits Tag only for a proved blank channel, not for a damaged named channel.
  if (
    tags === undefined &&
    hasParam &&
    !defaultTag &&
    Array.isArray(values) &&
    values.length === frames.length &&
    values.every((v) => v === 0)
  )
    tags = frames.map(() => '')
  check(Array.isArray(tags) && frames.length === tags.length, 'INVALID_CEL_KEYS')
  check(
    interpolation === undefined ||
      (Array.isArray(interpolation) &&
        (interpolation.length === 0 ||
          (interpolation.length === frames.length &&
            interpolation.every((v) => v === 'Constant')))),
    'UNSUPPORTED_CEL_CURVE',
  )
  let previous = -Infinity
  return frames.map((frame: unknown, index: number) => {
    check(
      typeof frame === 'number' &&
        Number.isFinite(frame) &&
        frame > previous &&
        typeof tags[index] === 'string',
      'INVALID_CEL_KEYS',
    )
    previous = frame
    return { frame, value: tags[index] || null }
  })
}
