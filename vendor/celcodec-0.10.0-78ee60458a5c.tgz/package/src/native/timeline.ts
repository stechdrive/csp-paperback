import { requiredAt } from '../internal/indexed.js'
// Extracted from csp-paperback (MIT); output-range evaluation is separate from raw BINC.
export interface TimelineFrame {
  frameIndex: number
  cellName: string | null
}
import { check } from './binary.js'
import { field, nodesNamed, type BincValueNode } from './binc-value.js'
import { celChannel } from './cel-channel.js'

const EPSILON = 1e-5

/** Cel switches are in motion time, bounded by TimeClip's half-open exposure interval. */
export function readCelFrames(
  root: BincValueNode,
  fps: number,
  startFrame: number,
): TimelineFrame[] {
  const clips = nodesNamed(root, 'ActionNodeClip')
  check(
    Number.isFinite(fps) && fps > 0 && fps <= 1000 && Number.isFinite(startFrame),
    'INVALID_TIMELINE_RANGE',
  )
  check(clips.length > 0 || nodesNamed(root, 'General').length === 1, 'MISSING_CEL_DATA')
  const segments = clips
    .map((clip) => {
      function time(name: string) {
        const node = clip.children.find((c) => c.name === name)
        check(node, 'MISSING_TIME_INFO')
        const start = field(node, 'Start'),
          end = field(node, 'End'),
          rate = field(node, 'Rate')
        check(
          typeof start === 'number' &&
            typeof end === 'number' &&
            typeof rate === 'number' &&
            rate > 0 &&
            end >= start,
          'INVALID_TIME_RANGE',
        )
        return { start, end, rate }
      }
      const exposure = time('TimeClip'),
        motion = time('MotionClip')
      const blend = clip.children.find((c) => c.name === 'MotionBlend')
      check(!blend || !field(blend, 'BlendEnable'), 'UNSUPPORTED_CEL_BLEND')
      check(
        Math.abs(
          (exposure.end - exposure.start) / exposure.rate -
            (motion.end - motion.start) / motion.rate,
        ) < EPSILON,
        'UNSUPPORTED_CEL_STRETCH',
      )
      const infoRate = clip.children.find((c) => c.name === 'TimeInfo')
      const rate = infoRate ? field(infoRate, 'Rate') : 60
      check(typeof rate === 'number' && rate > 0, 'INVALID_TIME_RATE')
      const curves = nodesNamed(clip, 'FCurve').filter((c) => c.attrs.Type === 'ImageCelName')
      check(curves.length <= 1, 'UNSUPPORTED_MULTIPLE_CEL_CURVES')
      const curve = curves[0]
      const param = nodesNamed(clip, 'Param').find((c) => c.attrs.Name === 'ImageCelName')
      const keys: { time: number; name: string | null }[] = []
      if (curve) {
        keys.push({
          time: (exposure.start / exposure.rate) * fps - startFrame,
          name: param?.attrs.Tag || null,
        })
        for (const key of celChannel(
          field(curve, 'Frame'),
          field(curve, 'Tag'),
          field(curve, 'Value'),
          field(curve, 'Interp'),
          !!param,
          param?.attrs.Tag,
        )) {
          const seconds =
            key.frame / rate - motion.start / motion.rate + exposure.start / exposure.rate
          const time = seconds * fps - startFrame
          if (time <= keys[0]!.time) keys[0]!.name = key.value
          else keys.push({ time, name: key.value })
        }
      } else {
        check(param, 'MISSING_CEL_DATA')
        keys.push({
          time: (exposure.start / exposure.rate) * fps - startFrame,
          name: param.attrs.Tag || null,
        })
      }
      keys.sort((a, b) => a.time - b.time)
      return {
        start: (exposure.start / exposure.rate) * fps - startFrame,
        end: (exposure.end / exposure.rate) * fps - startFrame,
        keys,
      }
    })
    .sort((a, b) => a.start - b.start)
  for (let i = 1; i < segments.length; i++)
    check(
      requiredAt(segments, i).start >= requiredAt(segments, i - 1).end - EPSILON,
      'UNSUPPORTED_CEL_OVERLAP',
    )
  // Evaluate only transition points, including frame zero and clip ends (null cells).
  const boundaries = new Set([0])
  for (const s of segments)
    for (const time of [s.start, s.end, ...s.keys.map((k) => k.time)]) {
      check(Math.abs(time) <= 10000000, 'LIMIT_TIMELINE_RANGE')
      boundaries.add(Math.max(0, Math.ceil(time - EPSILON)))
    }
  const result: TimelineFrame[] = []
  for (const frameIndex of [...boundaries].sort((a, b) => a - b)) {
    const segment = segments.find(
      (s) => frameIndex >= s.start - EPSILON && frameIndex < s.end - EPSILON,
    )
    const cellName = segment?.keys.findLast((k) => k.time <= frameIndex + EPSILON)?.name ?? null
    if (!result.length || result.at(-1)!.cellName !== cellName)
      result.push({ frameIndex, cellName })
  }
  return result
}
