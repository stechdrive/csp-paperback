import { check } from '../internal/binary.js'
import { MAX_CANVAS_DIMENSION, validateCanvasPixels } from '../internal/canvas-limits.js'

export interface ClipCanvasSettings {
  width: number
  height: number
  dpi: number
  basisWidth: number
  basisHeight: number
  offsetX: number
  offsetY: number
}
export type ClipImageFit = 'expand' | 'crop'
export interface ExportTrackFrame {
  frame: number
  value: string | null
}
export interface ClipTrackLabel {
  frame: number
  kind: 'inbetween' | 'reverse'
}
export interface ClipAudioTimeline {
  replacedLayerIds: number[]
  assets: {
    id: string
    name: string
    bytes: Uint8Array
    durationFrames: number
    sourceItemId?: string
  }[]
  tracks: {
    id: string
    name: string
    sourceLayerId?: number
    muted: boolean
    clips: {
      id: string
      assetId: string
      startFrame: number
      sourceOffsetFrames: number
      durationFrames: number
      muted?: boolean
    }[]
  }[]
}
/** Explicit center/crop operation; consumers choose the policy. */
export function clipImagePlacement(
  canvas: { width: number; height: number },
  image: { width: number; height: number },
  policy: ClipImageFit,
) {
  const width = policy === 'expand' ? Math.max(canvas.width, image.width) : canvas.width
  const height = policy === 'expand' ? Math.max(canvas.height, image.height) : canvas.height
  return {
    width,
    height,
    x: Math.ceil((width - image.width) / 2),
    y: Math.ceil((height - image.height) / 2),
  }
}
/** CSP canvas geometry; pixel allocations have independent resource limits. */
export function validateClipCanvas(settings: ClipCanvasSettings): void {
  check(
    settings &&
      ['width', 'height', 'basisWidth', 'basisHeight'].every((k) => {
        const n = settings[k as keyof ClipCanvasSettings]
        return Number.isInteger(n) && n >= 1 && n <= MAX_CANVAS_DIMENSION
      }),
    'INVALID_IMAGE_DIMENSIONS',
  )
  validateCanvasPixels(settings.width, settings.height)
  check(Number.isFinite(settings.dpi) && settings.dpi >= 1 && settings.dpi <= 1200, 'INVALID_DPI')
  check(
    [settings.offsetX, settings.offsetY].every(
      (n) => Number.isInteger(n) && Math.abs(n) <= MAX_CANVAS_DIMENSION,
    ) &&
      Math.abs(settings.offsetX) * 2 + settings.basisWidth <= settings.width &&
      Math.abs(settings.offsetY) * 2 + settings.basisHeight <= settings.height,
    'INVALID_CANVAS_FRAME',
  )
}
