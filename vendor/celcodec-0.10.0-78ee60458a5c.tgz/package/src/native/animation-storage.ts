import { requiredAt } from '../internal/indexed.js'
// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
import { check } from './binary.js'
import type { ClipContainer } from './container.js'

/** CSP omits unused animation tables/columns from illustration documents. */
export function ensureAnimationStorage(clip: ClipContainer, seed: ClipContainer): void {
  const schemes = clip.rows('ElemScheme')
  for (const table of ['AnimationCutBank', 'TimeLine', 'Track']) {
    if (
      clip.db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name=?", [table]).length
    )
      continue
    check(
      schemes.some((row) => row.TableName === table),
      'MISSING_ANIMATION_SCHEMA',
    )
    const sql = seed.db.exec("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", [
      table,
    ])[0]?.values[0]?.[0]
    check(typeof sql === 'string', 'MISSING_ANIMATION_TEMPLATE')
    clip.db.run(sql)
  }
}

export function ensureAnimationFolderStorage(clip: ClipContainer): void {
  const fields = requiredAt(clip.db.exec('PRAGMA table_info(Layer)'), 0).values.map((row) => row[1])
  if (fields.includes('AnimationFolder')) return
  check(
    clip
      .rows('ParamScheme')
      .some((row) => row.TableName === 'Layer' && row.LabelName === 'AnimationFolder'),
    'MISSING_ANIMATION_FOLDER_SCHEMA',
  )
  clip.db.run('ALTER TABLE Layer ADD COLUMN AnimationFolder INTEGER DEFAULT NULL')
}
