import { Unzlib } from 'fflate'
import { ClipError, checkCancelled } from '../diagnostics.js'
import { check } from '../internal/binary.js'
import { adler32, view } from './binary.js'

/** Incremental input prevents an attacker-controlled zlib stream allocating its full expansion. */
export function inflateBounded(bytes: Uint8Array, limit: number, signal?: AbortSignal): Uint8Array {
  checkCancelled(signal)
  check(Number.isSafeInteger(limit) && limit >= 0, 'INVALID_LIMIT')
  check(bytes.length >= 6, 'INVALID_ZLIB')
  const chunks: Uint8Array[] = []
  let length = 0
  const decoder = new Unzlib((data) => {
    checkCancelled(signal)
    length += data.length
    check(length <= limit, 'LIMIT_INFLATE', { actual: length, limit })
    chunks.push(data)
  })
  try {
    // DEFLATE's maximum expansion per byte is bounded. Each push has at most
    // 1 KiB of new compressed input plus a pending code/window (32 KiB).
    for (let offset = 0; offset < bytes.length; offset += 1024) {
      checkCancelled(signal)
      decoder.push(bytes.subarray(offset, offset + 1024), offset + 1024 >= bytes.length)
    }
  } catch (error) {
    if (error instanceof ClipError) throw error
    throw new ClipError('INVALID_ZLIB', undefined, { cause: error })
  }
  const result = new Uint8Array(length)
  let offset = 0
  for (const part of chunks) {
    result.set(part, offset)
    offset += part.length
  }
  check(adler32(result) === view(bytes).getUint32(bytes.length - 4), 'INVALID_ZLIB')
  return result
}
