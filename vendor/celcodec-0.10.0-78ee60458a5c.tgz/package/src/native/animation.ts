import { requiredAt } from '../internal/indexed.js'
// Extracted from xsheet-remap (MIT, Copyright (c) 2026 stechdrive).
// Source and extraction changes: docs/provenance.json.
// CSP BINC and TrackValueMap, checked against CSP 5.0.4 files and
// https://github.com/wamsoft/clipparse/blob/322a273c0e059d1dee9132af78289efa12a59522/docs/CLIP_FORMAT.md
// Source acknowledgements and license texts: THIRD_PARTY_NOTICES.md.
import { zlibSync } from 'fflate'
import type { ExportTrackFrame } from './model.js'
import { check, concat, named, u32, view } from './binary.js'
import { BincDocument, bincWriteLimits } from './binc.js'
import { inflateBounded } from './compression.js'
export class Mixer extends BincDocument {
  constructor(bytes: Uint8Array) {
    super(bytes, bincWriteLimits)
  }
}
export function animationMixer(
  template: Uint8Array,
  frames: ExportTrackFrame[],
  duration: number,
  fps: number,
): Uint8Array {
  check(template.length >= 5, 'INVALID_PACKED_BINC_SIZE')
  const expected = view(template).getUint32(0, true)
  check(expected === template.length - 4, 'INVALID_PACKED_BINC_SIZE')
  const mixer = new Mixer(inflateBounded(template.subarray(4), bincWriteLimits.bytes))
  const keys = frames.length ? frames : [{ frame: 0, value: null }]
  const first = requiredAt(keys, 0).frame
  mixer.walk((node, parent) => {
    if (parent?.name === 'TimeClip' || parent?.name === 'MotionClip') {
      if (node.name === 'Start') node.values = [parent.name === 'TimeClip' ? (first * 60) / fps : 0]
      if (node.name === 'End')
        node.values = [((duration - (parent.name === 'MotionClip' ? first : 0)) * 60) / fps]
    }
    if (node.name === 'Param' && node.attrs.Name === 'ImageCelName') {
      node.values = [0]
      node.attrs.Tag = requiredAt(keys, 0).value ?? ''
    }
    if (parent?.name === 'FCurve' && parent.attrs.Type === 'ImageCelName') {
      node.values = keys.map((key, index) =>
        node.name === 'Frame'
          ? ((key.frame - first) * 60) / fps
          : node.name === 'Value'
            ? index
            : node.name === 'Interp'
              ? 'Constant'
              : node.name === 'Tag'
                ? (key.value ?? '')
                : node.name === 'ReviseConstant'
                  ? 1
                  : 0,
      )
    }
  })
  return mixer.encode()
}
export function packedMixer(raw: Uint8Array): Uint8Array {
  const packed = zlibSync(raw)
  return concat(u32(packed.length, true), packed)
}
export function trackValueMap(name: string | null): Uint8Array {
  const payload = concat(named('ImageCelName'), named(name ?? ''), u32(2), u32(0))
  return concat(u32(8), u32(1), u32(payload.length + 4), payload)
}
