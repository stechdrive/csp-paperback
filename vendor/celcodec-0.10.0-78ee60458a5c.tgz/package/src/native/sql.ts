/** Structural sql.js interface. The caller owns WASM loading and initialization. */
export type SqlValue = number | string | Uint8Array | null
export interface Statement {
  bind(values: SqlValue[]): boolean | void
  step(): boolean
  getAsObject(): Record<string, SqlValue>
  /** Optional: engines without reset remain supported without statement caching. */
  reset?(): boolean | void
  free(): boolean | void
}
export interface Database {
  exec(sql: string, values?: SqlValue[]): { columns: string[]; values: SqlValue[][] }[]
  run(sql: string, values?: SqlValue[]): unknown
  prepare(sql: string): Statement
  export(): Uint8Array
  close(): void
}
export interface SqlJsStatic {
  Database: new (bytes?: Uint8Array) => Database
}
