import { check } from './internal/binary.js'
import { ClipError, type DiagnosticCode } from './diagnostics.js'

/** Caller policy, independent of document dimensions and the runtime's allocation limits. */
export interface ImageResourceLimits {
  /** Image budget inherited by decode/render/edit operations. Not a process-wide RAM cap.
   * Decode limits returned pixels; renderers additionally account for their working buffers.
   * Caller inputs, allocator/codec internals and garbage awaiting collection are excluded. */
  maxBytes?: number
  /** Optional additional limit on each restored/allocated rectangle, not the document canvas. */
  maxPixels?: number
}

/** Integer rectangle in source pixels. */
export interface ImageRegion {
  left: number
  top: number
  width: number
  height: number
}

export function validateImageRegion(region: ImageRegion, width: number, height: number): void {
  imageByteLength(region.width, region.height)
  check(
    [region.left, region.top].every((v) => Number.isSafeInteger(v) && v >= 0) &&
      region.left + region.width <= width &&
      region.top + region.height <= height,
    'INVALID_IMAGE_REGION',
  )
}

export const DEFAULT_IMAGE_LIMITS = Object.freeze({
  maxBytes: 512 * 1024 * 1024,
  maxPixels: 64 * 1024 * 1024,
})

export function resourceLimit(value: number): number {
  check(Number.isSafeInteger(value) && value >= 0, 'INVALID_LIMIT', { value })
  return value
}

/** An explicit byte budget replaces legacy pixel ceilings unless a pixel limit is also supplied. */
export function resolveImageLimits(
  limits?: ImageResourceLimits,
  defaults: Required<ImageResourceLimits> = DEFAULT_IMAGE_LIMITS,
): Readonly<Required<ImageResourceLimits>> {
  const maxBytes = resourceLimit(limits?.maxBytes ?? defaults.maxBytes)
  const maxPixels = resourceLimit(
    limits?.maxPixels ??
      (limits?.maxBytes === undefined ? defaults.maxPixels : Number.MAX_SAFE_INTEGER),
  )
  return Object.freeze({ maxBytes, maxPixels })
}

/** Exact storage of one plane, not a process-wide peak estimate. */
export function imageByteLength(width: number, height: number, bytesPerPixel = 4): number {
  check(
    [width, height, bytesPerPixel].every((v) => Number.isSafeInteger(v) && v > 0),
    'INVALID_IMAGE_DIMENSIONS',
  )
  const bytes = width * height * bytesPerPixel
  check(Number.isSafeInteger(bytes), 'LIMIT_IMAGE_PIXELS', { width, height, bytesPerPixel })
  return bytes
}

export function checkImageAllocation(
  width: number,
  height: number,
  limits: Readonly<Required<ImageResourceLimits>>,
  code: DiagnosticCode = 'LIMIT_MATERIAL_BYTES',
  bytesPerPixel = 4,
): number {
  const bytes = imageByteLength(width, height, bytesPerPixel)
  check(width * height <= limits.maxPixels, 'LIMIT_IMAGE_PIXELS', {
    width,
    height,
    limit: limits.maxPixels,
  })
  check(bytes <= limits.maxBytes, code, {
    width,
    height,
    requestedBytes: bytes,
    limit: limits.maxBytes,
  })
  return bytes
}

export function allocateImage<T>(bytes: number, create: () => T): T {
  resourceLimit(bytes)
  try {
    return create()
  } catch (error) {
    if (!(error instanceof RangeError)) throw error
    throw new ClipError('LIMIT_ALLOCATION', { requestedBytes: bytes }, { cause: error })
  }
}

export const rgbaBuffer = (bytes: number): Uint8ClampedArray =>
  allocateImage(bytes, () => new Uint8ClampedArray(bytes))
export const byteBuffer = (bytes: number): Uint8Array =>
  allocateImage(bytes, () => new Uint8Array(bytes))
