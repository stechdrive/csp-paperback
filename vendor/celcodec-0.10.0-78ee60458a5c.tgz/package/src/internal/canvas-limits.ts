import { check } from './binary.js'

/** CSP's canvas extent, independent of decoded-image allocation budgets. */
export const MAX_CANVAS_DIMENSION = 50_000
export const MAX_CANVAS_PIXELS = MAX_CANVAS_DIMENSION ** 2

export function canvasPixelLimit(value = MAX_CANVAS_PIXELS): number {
  check(Number.isSafeInteger(value) && value >= 1 && value <= MAX_CANVAS_PIXELS, 'INVALID_LIMIT')
  return value
}

export function validateCanvasPixels(width: number, height: number, maximum?: number): void {
  const limit = canvasPixelLimit(maximum)
  check(
    Number.isSafeInteger(width) &&
      Number.isSafeInteger(height) &&
      width > 0 &&
      height > 0 &&
      width <= MAX_CANVAS_DIMENSION &&
      height <= MAX_CANVAS_DIMENSION,
    'INVALID_IMAGE_DIMENSIONS',
  )
  check(width * height <= limit, 'LIMIT_IMAGE_PIXELS', { limit })
}
