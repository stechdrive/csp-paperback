import { check } from './binary.js'
import { createBrushRandom } from './vector-dynamics.js'
import type { VectorPoint } from './vector.js'

type NativeState = NonNullable<VectorPoint['dabState']>

/** Placement resumes at real controls; a saved count never advances the RNG. */
export class StrokePlacementState {
  pendingSeed: number | undefined
  /** Native resize captures count visible dabs before a control, excluding the
   * directionless initial dab. Keep it separate from random-stream draws. */
  nativeCount: number | undefined
  skippedInitialDab = false

  constructor(public remaining: number) {}

  resume(native: NativeState, first: boolean): void {
    check(
      Number.isFinite(native.remainingDistance) &&
        native.remainingDistance >= 0 &&
        Number.isInteger(native.randomState) &&
        native.randomState >= 0 &&
        native.randomState <= 0xffffffff &&
        Number.isInteger(native.count) &&
        native.count >= 0 &&
        native.count <= 0xffffffff,
      'INVALID_VECTOR_FACTOR',
    )
    this.remaining = native.remainingDistance
    this.pendingSeed = native.randomState
    this.nativeCount = native.count
    // The later authoritative seed already includes any earlier invisible dab.
    if (!first) this.skippedInitialDab = false
  }

  waitForDirection(diameter: number): void {
    this.remaining = Math.max(1, diameter / 4)
    this.skippedInitialDab = true
  }

  take(): { seed?: number; skippedInitialDab?: boolean } {
    const result = {
      ...(this.pendingSeed !== undefined ? { seed: this.pendingSeed } : {}),
      ...(this.skippedInitialDab ? { skippedInitialDab: true } : {}),
    }
    this.pendingSeed = undefined
    this.skippedInitialDab = false
    return result
  }
}

/** Replay RNG tickets emitted by placement, with observable consumption and resets. */
export class StrokeRandomState {
  private stream: ReturnType<typeof createBrushRandom>

  constructor(public seed: number) {
    this.stream = createBrushRandom(seed)
  }

  resume(seed: number | undefined, invisible: boolean, angle: boolean, density: boolean): void {
    if (seed !== undefined) {
      this.seed = seed
      this.stream = createBrushRandom(seed)
    }
    if (invisible) {
      if (angle) this.stream.next()
      if (density) this.stream.next()
    }
  }

  next(): number {
    return this.stream.next()
  }
  get state(): number {
    return this.stream.state
  }
  get draws(): number {
    return this.stream.draws
  }
}
