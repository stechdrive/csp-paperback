export type BrushSpacingMode = 'round' | 'image-manual' | 'image-auto'

export interface BrushSpacing {
  mode: BrushSpacingMode
  interval: number
  antialias?: boolean
}

/** Thickness includes the image footprint minimum. Manual spacing keeps the
 * requested distance, with a thickness-dependent floor; auto scales distance. */
export function brushSpacingDistance(
  spacing: BrushSpacing,
  diameter: number,
  thickness: number,
  response = 1,
): number {
  const distance = diameter * spacing.interval * response
  if (spacing.mode === 'image-manual')
    return spacing.antialias === false ? Math.max(1, distance) : Math.max(0.5, thickness, distance)
  const scaled = Math.max(1, distance) * thickness
  return spacing.mode === 'image-auto' ? Math.max(0.5, scaled) : scaled
}
