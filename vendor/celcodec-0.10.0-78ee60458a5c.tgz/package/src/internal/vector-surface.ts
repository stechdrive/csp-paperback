import { numberAt, floatAt } from './indexed.js'
// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
import type { ClipPixels } from './types.js'
import { check } from './binary.js'
import {
  allocateImage,
  rgbaBuffer,
  checkImageAllocation,
  resolveImageLimits,
  resourceLimit,
  type ImageResourceLimits,
} from '../image-resources.js'

const SIZE = 128
interface Tile {
  left: number
  top: number
  width: number
  height: number
  data: Float32Array
}

/** Sparse premultiplied float surface. Stroke ordering and float rounding stay unchanged. */
export class VectorSurface {
  private tiles = new Map<number, Tile>()
  private lastKey = -1
  private lastTile: Tile | undefined
  private cols: number
  private width: number
  private height: number
  private bytes = 0
  private scratchBytes = 0
  private imageLimits: Readonly<Required<ImageResourceLimits>>

  constructor(
    width: number,
    height: number,
    private limit = 256 * 1024 * 1024,
    imageLimits?: ImageResourceLimits,
  ) {
    resourceLimit(limit)
    this.imageLimits = resolveImageLimits(imageLimits)
    this.width = width
    this.height = height
    this.cols = Math.ceil(width / SIZE)
  }

  reserveScratch(bytes: number): void {
    resourceLimit(bytes)
    check(this.bytes + bytes <= this.imageLimits.maxBytes, 'LIMIT_VECTOR_SURFACE', {
      requestedBytes: this.bytes + bytes,
      limit: this.imageLimits.maxBytes,
    })
    this.scratchBytes = bytes
  }

  blend(x: number, y: number, alpha: number, color: number[], erase: boolean): void {
    const col = Math.floor(x / SIZE),
      row = Math.floor(y / SIZE),
      key = row * this.cols + col
    let tile = key === this.lastKey ? this.lastTile : this.tiles.get(key)
    if (!tile) {
      // Erasing untouched pixels cannot add coverage or color.
      if (erase) return
      const left = col * SIZE,
        top = row * SIZE
      const width = Math.min(SIZE, this.width - left),
        height = Math.min(SIZE, this.height - top)
      check(this.bytes + width * height * 16 <= this.limit, 'LIMIT_VECTOR_SURFACE', {
        limit: this.limit,
      })
      check(
        this.bytes + this.scratchBytes + width * height * 16 <= this.imageLimits.maxBytes,
        'LIMIT_VECTOR_SURFACE',
      )
      this.bytes += width * height * 16
      tile = {
        left,
        top,
        width,
        height,
        data: allocateImage(width * height * 16, () => new Float32Array(width * height * 4)),
      }
      this.tiles.set(key, tile)
    }
    this.lastKey = key
    this.lastTile = tile
    const at = ((y - tile.top) * tile.width + x - tile.left) * 4,
      remain = 1 - alpha
    for (let c = 0; c < 3; c++)
      tile.data[at + c] =
        (erase ? 0 : numberAt(color, c) * alpha) + floatAt(tile.data, at + c) * remain
    tile.data[at + 3] = (erase ? 0 : alpha) + floatAt(tile.data, at + 3) * remain
  }

  finish(): ClipPixels {
    this.scratchBytes = 0
    let left = this.width,
      top = this.height,
      right = 0,
      bottom = 0
    for (const tile of this.tiles.values()) {
      for (let y = 0; y < tile.height; y++)
        for (let x = 0; x < tile.width; x++) {
          // Match the existing byte-alpha conversion before finding crop bounds.
          if (Math.floor(floatAt(tile.data, (y * tile.width + x) * 4 + 3) * 256) > 0) {
            left = Math.min(left, tile.left + x)
            top = Math.min(top, tile.top + y)
            right = Math.max(right, tile.left + x + 1)
            bottom = Math.max(bottom, tile.top + y + 1)
          }
        }
    }
    if (right <= left || bottom <= top) {
      this.dispose()
      return {
        width: 1,
        height: 1,
        left: 0,
        top: 0,
        rgba: rgbaBuffer(checkImageAllocation(1, 1, this.imageLimits, 'LIMIT_VECTOR_SURFACE')),
      }
    }
    const width = right - left,
      height = bottom - top,
      rgba = rgbaBuffer(
        checkImageAllocation(
          width,
          height,
          { ...this.imageLimits, maxBytes: this.imageLimits.maxBytes - this.bytes },
          'LIMIT_VECTOR_SURFACE',
        ),
      )
    for (const tile of this.tiles.values()) {
      const x0 = Math.max(0, left - tile.left),
        y0 = Math.max(0, top - tile.top)
      const x1 = Math.min(tile.width, right - tile.left),
        y1 = Math.min(tile.height, bottom - tile.top)
      for (let y = y0; y < y1; y++)
        for (let x = x0; x < x1; x++) {
          const from = (y * tile.width + x) * 4,
            to = ((tile.top + y - top) * width + tile.left + x - left) * 4
          const a = floatAt(tile.data, from + 3)
          if (a > 0) for (let c = 0; c < 3; c++) rgba[to + c] = floatAt(tile.data, from + c) / a
          rgba[to + 3] = Math.min(255, Math.floor(a * 256))
        }
    }
    this.dispose()
    return { width, height, left, top, rgba }
  }

  dispose(): void {
    this.tiles.clear()
    this.lastKey = -1
    this.lastTile = undefined
    this.bytes = 0
    this.scratchBytes = 0
  }
}
