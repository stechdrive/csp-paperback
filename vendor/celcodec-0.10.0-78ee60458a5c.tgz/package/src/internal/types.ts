export type { ClipPixels } from '../types.js'
