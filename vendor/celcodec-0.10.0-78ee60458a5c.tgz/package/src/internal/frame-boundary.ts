/**
 * Compare derived frame boundaries, allowing only double-precision roundoff.
 * The origin accounts for cancellation when absolute native time is rebased.
 * The cap prevents large read-only timelines from hiding real subframe overlaps.
 * This never quantizes stored time, keys, or a caller's requested frame.
 */
export function compareFrame(a: number, b: number, origin = 0): number {
  if (a === b) return 0
  if (
    Number.isFinite(a) &&
    Number.isFinite(b) &&
    Math.abs(a - b) <=
      Math.min(1e-7, 8 * Number.EPSILON * Math.max(1, Math.abs(a), Math.abs(b), Math.abs(origin)))
  )
    return 0
  return a < b ? -1 : 1
}
