import { u8At } from './indexed.js'
import { paperCoordinates } from './vector-sampling.js'
import type { BrushPattern } from './vector.js'

interface PaperTransform {
  scale: number
  rotation: number
  offsetX: number
  offsetY: number
  pixelAligned: boolean
}

const wrap = (v: number, size: number) => ((v % size) + size) % size
const nearestOffset = (v: number) => Math.sign(v) * Math.floor(Math.abs(v) + 0.5)
const coefficientScale = 2 ** 32

/** Compile the paper grid independently of tip coverage and grain transfer.
 * Native AA image captures constrain the inverse coefficients and 8-bit
 * interpolation weights. They do not establish CSP's internal numeric type. */
export function compilePaperSampler(image: BrushPattern, transform: PaperTransform) {
  const { scale, rotation, offsetX, offsetY, pixelAligned } = transform
  const cos = Math.cos(rotation),
    sin = Math.sin(rotation),
    inverseCos = cos / scale,
    inverseSin = sin / scale
  // Negative saved angles have inconsistent native lookup behavior. Retain
  // the earlier approximation there, for AA-off, and for extreme inverses;
  // do not generalize a fitted rule from one negative-angle control.
  const measuredGrid =
    pixelAligned &&
    rotation >= 0 &&
    [inverseCos, inverseSin].every(
      (v) => Number.isFinite(v) && Math.abs(v * coefficientScale) <= Number.MAX_SAFE_INTEGER,
    )
  const qc = Math.trunc(inverseCos * coefficientScale) / coefficientScale,
    qs = Math.trunc(inverseSin * coefficientScale) / coefficientScale,
    ox = nearestOffset(offsetX),
    oy = nearestOffset(offsetY)
  const alpha = (x: number, y: number) =>
    u8At(image.alpha, wrap(y, image.height) * image.width + wrap(x, image.width)) / 255

  return (x: number, y: number): number => {
    let u: number, v: number
    if (measuredGrid) {
      const dx = Math.floor(x) - ox,
        dy = Math.floor(y) - oy
      u = dx * qc + dy * qs
      v = -dx * qs + dy * qc
    } else {
      ;[u, v] = paperCoordinates(
        x,
        y,
        offsetX,
        offsetY,
        cos,
        sin,
        scale,
        image.width,
        image.height,
        pixelAligned,
      )
    }
    const x0 = Math.floor(u),
      y0 = Math.floor(v)
    if (pixelAligned && scale <= 1) return alpha(x0, y0)
    const tx = measuredGrid ? Math.floor((u - x0) * 256) / 256 : u - x0,
      ty = measuredGrid ? Math.floor((v - y0) * 256) / 256 : v - y0
    const sampled =
      (alpha(x0, y0) * (1 - tx) + alpha(x0 + 1, y0) * tx) * (1 - ty) +
      (alpha(x0, y0 + 1) * (1 - tx) + alpha(x0 + 1, y0 + 1) * tx) * ty
    // Native grain is quantized after interpolation, before levels/composite.
    // This epsilon repairs byte-boundary floating error, not spatial phase.
    return measuredGrid ? Math.floor(sampled * 255 + 1e-9) / 255 : sampled
  }
}
