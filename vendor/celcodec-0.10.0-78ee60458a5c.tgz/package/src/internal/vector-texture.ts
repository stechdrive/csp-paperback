import { u8At } from './indexed.js'
// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
import { check } from './binary.js'
import { errorCode, type DiagnosticCode } from '../diagnostics.js'
import { num, type ClipRow } from './records.js'
import type { BrushPattern } from './vector.js'
import { compilePaperSampler } from './vector-paper-sampling.js'
import { compilePaperTransfer } from './vector-paper-transfer.js'
import {
  renderedTextureComposites,
  renderedTextureFlags,
  textureApplication,
} from './vector-settings.js'
import {
  checkImageAllocation,
  resolveImageLimits,
  type ImageResourceLimits,
} from '../image-resources.js'

export interface BrushTexture {
  /** Layer-local coverage multiplier: moving a layer moves its grain too.
   * Supply incoming alpha for nonlinear outline grain, then clamp the product. */
  sample: (x: number, y: number, coverage?: number) => number
  perDab: boolean
}

/** Input response is internal to stroke replay; keep the public sampler contract. */
export interface ProgramBrushTexture extends BrushTexture {
  sample: (x: number, y: number, coverage?: number, densityFactor?: number) => number
}

/** Native normal/multiply/outline grain; unknown effects remain diagnostic. */
export function createBrushTexture(
  style: ClipRow,
  image: BrushPattern | undefined,
  report: (code: DiagnosticCode) => void,
  pixelAligned = false,
  imageLimits?: ImageResourceLimits,
): BrushTexture | undefined {
  const texture = createBrushTextureProgram(style, image, report, pixelAligned, imageLimits)
  const effector = style.TextureDensityEffector
  // The standalone sampler has no point input. Stroke replay supplies the
  // compiled response separately and diagnoses only inputs it cannot consume.
  if (
    texture?.perDab &&
    effector instanceof Uint8Array &&
    effector.length &&
    (effector.length !== 4 || effector[0] || effector[1] || effector[2] || u8At(effector, 3) > 1)
  )
    report('APPROXIMATE_TEXTURE_EFFECTS')
  return texture
}

export function createBrushTextureProgram(
  style: ClipRow,
  image: BrushPattern | undefined,
  report: (code: DiagnosticCode) => void,
  pixelAligned = false,
  imageLimits?: ImageResourceLimits,
): ProgramBrushTexture | undefined {
  if (textureApplication(style) === 'disabled') return
  if (!image) {
    report('MISSING_TEXTURE')
    return
  }
  if (!renderedTextureComposites.includes(num(style, 'TextureComposite'))) {
    report('UNSUPPORTED_TEXTURE_COMPOSITE')
    return
  }
  try {
    const scale = num(style, 'TextureScale', 1),
      density = num(style, 'TextureDensityBase', 1)
    const rotation = (num(style, 'TextureRotate') * Math.PI) / 180
    const offsetX = num(style, 'TextureOffsetX'),
      offsetY = num(style, 'TextureOffsetY')
    check(
      Number.isFinite(scale) &&
        scale > 0 &&
        scale <= 65536 &&
        Number.isFinite(density) &&
        density >= 0 &&
        density <= 1 &&
        [rotation, offsetX, offsetY].every((v) => Number.isFinite(v) && Math.abs(v) <= 1000000),
      'INVALID_TEXTURE_PARAMETERS',
    )
    check(
      Number.isInteger(image.width) &&
        Number.isInteger(image.height) &&
        image.width > 0 &&
        image.height > 0 &&
        image.alpha.length === image.width * image.height,
      'INVALID_TEXTURE_DIMENSIONS',
    )
    checkImageAllocation(
      image.width,
      image.height,
      resolveImageLimits(imageLimits, { maxBytes: 512 * 1024 * 1024, maxPixels: 4 * 1024 * 1024 }),
      'LIMIT_BRUSH_BYTES',
      1,
    )
    const transfer = compilePaperTransfer(style)
    // Native UI captures: enable, per-dab application, and density inversion.
    if (num(style, 'TextureFlag') & ~renderedTextureFlags) {
      report('APPROXIMATE_TEXTURE_EFFECTS')
    }
    const samplePaper = compilePaperSampler(image, {
      scale,
      rotation,
      offsetX,
      offsetY,
      pixelAligned,
    })
    const composite = num(style, 'TextureComposite')
    return {
      perDab: textureApplication(style) === 'dab',
      sample(x, y, coverage = 1, densityFactor = 1) {
        const strength = Math.max(0, Math.min(1, density * densityFactor))
        const sampled = samplePaper(x, y)
        const grain = transfer ? transfer(sampled) : sampled
        // Independent constant-grain captures: outline changes alpha by
        // density * (alpha + grain - 1), then clips. Clipping before the
        // strength interpolation gives a different edge, especially below 50%.
        if (composite === 4)
          return coverage > 0 ? Math.max(0, 1 + (strength * (coverage + grain - 1)) / coverage) : 1
        // Independent constant-grain and zero-density captures: normal keeps
        // a 1.5 intercept even at zero strength. Clamp AFTER coverage multiplication.
        return (composite === 0 ? 1.5 : 1) - strength * (1 - grain)
      },
    }
  } catch (e) {
    report(errorCode(e))
    return
  }
}
