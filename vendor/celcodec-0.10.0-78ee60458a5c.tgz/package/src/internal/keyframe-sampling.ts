import { diagnostic } from '../diagnostics.js'
import type { KeyframeSample, PropertyKeyframe } from '../native/keyframes.js'

/** A validated, interior segment. Endpoint/extrapolation policy belongs to the caller. */
export function sampleKeyframeSegment(
  a: PropertyKeyframe,
  b: PropertyKeyframe,
  frame: number,
  property?: string,
): KeyframeSample {
  if (a.interpolation === 'Constant') return { status: 'value', value: a.value, tag: a.tag }
  const unsupported = (): KeyframeSample => ({
    status: 'unavailable',
    diagnostics: [
      diagnostic('UNSUPPORTED_KEYFRAME_INTERPOLATION', {
        ...(property === undefined ? {} : { property }),
        interpolation: a.interpolation ?? '',
      }),
    ],
  })
  if (a.tag !== undefined || b.tag !== undefined) return unsupported()
  const t = (frame - a.frame) / (b.frame - a.frame)
  let value: number
  if (a.interpolation === 'Linear') value = a.value * (1 - t) + b.value * t
  else if (a.interpolation === 'Default' || a.interpolation === 'Hermite') {
    const left = a.rightSlope,
      right = b.leftSlope,
      ticks = b.tick - a.tick
    // Slopes are value/native-tick, not value/frame. Time stretch must not change the curve.
    if (
      left === undefined ||
      right === undefined ||
      !Number.isFinite(left) ||
      !Number.isFinite(right) ||
      !Number.isFinite(ticks) ||
      ticks <= 0 ||
      [a, b].some(
        (k) =>
          (k.reviseConstant !== undefined && k.reviseConstant !== 1) ||
          (k.breakKey !== undefined && k.breakKey !== 0 && k.breakKey !== 1),
      )
    )
      return unsupported()
    const t2 = t * t,
      t3 = t2 * t
    value =
      (2 * t3 - 3 * t2 + 1) * a.value +
      (t3 - 2 * t2 + t) * ticks * left +
      (-2 * t3 + 3 * t2) * b.value +
      (t3 - t2) * ticks * right
  } else return unsupported()
  return Number.isFinite(value)
    ? { status: 'value', value, tag: undefined }
    : { status: 'unavailable', diagnostics: [diagnostic('INVALID_KEYFRAME_KEYS')] }
}
