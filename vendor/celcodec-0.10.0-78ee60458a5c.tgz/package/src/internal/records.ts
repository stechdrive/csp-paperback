// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
export type ClipValue = number | string | Uint8Array | null | undefined

export type ClipRow = Record<string, ClipValue>
export const num = (row: ClipRow, key: string, fallback = 0): number =>
  typeof row[key] === 'number' ? row[key] : fallback
export const str = (value: ClipValue | undefined): string =>
  value instanceof Uint8Array
    ? new TextDecoder().decode(value)
    : typeof value === 'string'
      ? value
      : ''
export const errorMessage = (e: unknown): string => (e instanceof Error ? e.message : String(e))
