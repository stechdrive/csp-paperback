// Offscreen format and tile permutation: wamsoft/clipparse (MIT).
// Sparse decoding extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// See docs/provenance.json and THIRD_PARTY_NOTICES.md.
import { check, inflate } from './binary.js'
import { u8At } from './indexed.js'
import { cropPixels } from './pixels.js'
import type { OffscreenAttribute } from './raster.js'
import type { ClipPixels, Inflate } from '../types.js'
import { checkCancelled } from '../diagnostics.js'
import { readRasterTiles, type RasterTile } from '../format/raster-tiles.js'
import { rgbaBuffer, validateImageRegion, type ImageRegion } from '../image-resources.js'

/** Internal allocation policy shared by the standalone and document material APIs. */
export async function decodeRasterPixels(
  a: OffscreenAttribute,
  body: Uint8Array | undefined,
  mask: boolean,
  crop: boolean,
  options: { signal?: AbortSignal; inflate?: Inflate; region?: ImageRegion; alphaColor?: 0 | 255 },
  limits: { maxPixels?: number; maxBytes?: number } = {},
  preparedTiles?: readonly RasterTile[],
): Promise<ClipPixels | undefined> {
  checkCancelled(options.signal)
  if (!body && !a.hasColor) return undefined
  const region = options.region ?? { left: 0, top: 0, width: a.width, height: a.height }
  validateImageRegion(region, a.width, a.height)
  const rx = region.left,
    ry = region.top,
    rr = rx + region.width,
    rb = ry + region.height
  check(
    Number.isSafeInteger(a.width) && Number.isSafeInteger(a.height) && a.width > 0 && a.height > 0,
    'INVALID_IMAGE_DIMENSIONS',
  )
  const maximum = limits.maxPixels ?? 64 * 1024 * 1024,
    maxBytes = limits.maxBytes ?? Infinity
  const fits = (width: number, height: number) =>
    width * height <= maximum && width * height * 4 <= maxBytes
  const checkSize = (width: number, height: number) => {
    check(width * height <= maximum, 'LIMIT_IMAGE_PIXELS', { width, height, limit: maximum })
    check(width * height * 4 <= maxBytes, 'LIMIT_MATERIAL_BYTES', { limit: maxBytes })
  }
  const backgroundContent = mask
    ? !a.hasColor && (a.color & 255) !== 0
    : a.hasColor && (a.color & 255) !== 0
  const fullExtent = !crop || backgroundContent
  if (!crop) checkSize(region.width, region.height)
  else checkSize(1, 1) // Even an empty material returns an origin placeholder.
  const alphaColor = options.alphaColor ?? 255
  const baseColor = mask
    ? [a.color & 255, a.color & 255, a.color & 255, 255]
    : a.channels === 0 && options.alphaColor !== undefined
      ? [alphaColor, alphaColor, alphaColor, a.color & 255]
      : [
          ...(a.rgb ?? [a.color >>> 24, (a.color >>> 16) & 255, (a.color >>> 8) & 255]),
          a.color & 255,
        ]
  let tiles = preparedTiles ?? readRasterTiles(a, body, options.signal)
  if (options.region)
    tiles = tiles.filter((t) => t.x < rr && t.x + 256 > rx && t.y < rb && t.y + 256 > ry)
  const inflateTile = async (tile: RasterTile) => {
    checkCancelled(options.signal)
    const raw = await (options.inflate ?? inflate)(tile.compressed, tile.expected, options.signal)
    checkCancelled(options.signal)
    check(raw.length === tile.expected, 'INVALID_INFLATED_SIZE')
    return raw
  }
  let left = fullExtent ? rx : rr,
    top = fullExtent ? ry : rb,
    right = fullExtent ? rr : rx,
    bottom = fullExtent ? rb : ry
  for (const tile of tiles) {
    if (tile.x < a.width && tile.y < a.height) {
      left = Math.min(left, Math.max(rx, tile.x))
      top = Math.min(top, Math.max(ry, tile.y))
      right = Math.max(right, Math.min(rr, tile.x + 256))
      bottom = Math.max(bottom, Math.min(rb, tile.y + 256))
    }
  }
  // Usually the occupied tile rectangle fits: retain the single-inflation fast path.
  // Widely separated empty tiles must not force an enormous temporary bitmap. In
  // that case inspect one bounded tile at a time, then inflate only intersecting
  // tiles again. This also preserves hidden RGB inside the final crop rectangle.
  const scan = crop && right > left && bottom > top && !fits(right - left, bottom - top)
  if (scan) {
    left = rr
    top = rb
    right = rx
    bottom = ry
    if (backgroundContent) {
      // Data tiles overwrite InitColor, so even an opaque initial color can crop
      // to one pixel after erasure. Only uncovered tiles contribute the default.
      const cols = Math.ceil(a.width / 256),
        rows = Math.ceil(a.height / 256)
      check(cols * rows <= 65536, 'INVALID_TILE_COUNT')
      const covered = new Set(
        tiles
          .filter((tile) => tile.x < a.width && tile.y < a.height)
          .map((tile) => (tile.y / 256) * cols + tile.x / 256),
      )
      for (let y = Math.floor(ry / 256); y < Math.ceil(rb / 256); y++) {
        for (let x = Math.floor(rx / 256); x < Math.ceil(rr / 256); x++) {
          if (covered.has(y * cols + x)) continue
          left = Math.min(left, Math.max(rx, x * 256))
          top = Math.min(top, Math.max(ry, y * 256))
          right = Math.max(right, Math.min(rr, (x + 1) * 256))
          bottom = Math.max(bottom, Math.min(rb, (y + 1) * 256))
        }
        if (right > left && bottom > top) checkSize(right - left, bottom - top)
      }
    }
    for (const tile of tiles) {
      const raw = await inflateTile(tile)
      for (let y = Math.max(0, ry - tile.y); y < 256 && tile.y + y < rb; y++)
        for (let x = Math.max(0, rx - tile.x); x < 256 && tile.x + x < rr; x++) {
          const pixel = y * 256 + x
          let value: number
          if (a.channels === 4) value = u8At(raw, mask ? 65536 + pixel * 4 + 2 : alphaIndex(x, y))
          else if (a.channels === 0) value = u8At(raw, pixel)
          else value = planeValue(raw, a, pixel, mask)
          if (value === (mask ? a.color & 255 : 0)) continue
          left = Math.min(left, tile.x + x)
          top = Math.min(top, tile.y + y)
          right = Math.max(right, tile.x + x + 1)
          bottom = Math.max(bottom, tile.y + y + 1)
        }
      if (right > left && bottom > top) checkSize(right - left, bottom - top)
    }
  }
  if (right <= left || bottom <= top) {
    left = rx
    top = ry
    right = rx + 1
    bottom = ry + 1
  }
  const width = right - left,
    height = bottom - top
  checkSize(width, height)
  const rgba = rgbaBuffer(width * height * 4)
  if (a.hasColor) {
    // Native-endian word built from bytes, so this works on either host byte order.
    const color = new Uint32Array(new Uint8ClampedArray(baseColor).buffer)[0]!
    new Uint32Array(rgba.buffer, rgba.byteOffset, rgba.length / 4).fill(color)
  }
  for (const tile of tiles) {
    const x0 = Math.max(0, left - tile.x),
      y0 = Math.max(0, top - tile.y),
      x1 = Math.min(256, right - tile.x),
      y1 = Math.min(256, bottom - tile.y)
    // The scan already validated every payload, including off-canvas tiles.
    if (scan && (x0 >= x1 || y0 >= y1)) continue
    const raw = await inflateTile(tile)
    for (let y = y0; y < y1; y++)
      for (let x = x0; x < x1; x++) {
        const pixel = y * 256 + x,
          dst = ((tile.y + y - top) * width + tile.x + x - left) * 4
        if (a.channels === 4) {
          const color = 65536 + pixel * 4
          rgba[dst] = u8At(raw, color + 2)
          rgba[dst + 1] = u8At(raw, color + 1)
          rgba[dst + 2] = u8At(raw, color)
          rgba[dst + 3] = u8At(
            raw,
            (Math.floor(y / 4) * 256 + (y % 4) * 64 + Math.floor(x / 4)) * 4 + (x % 4),
          )
        } else if (a.channels === 0) {
          rgba[dst] = rgba[dst + 1] = rgba[dst + 2] = mask ? u8At(raw, pixel) : alphaColor
          rgba[dst + 3] = mask ? 255 : u8At(raw, pixel)
        } else {
          const at = a.bitDepth === 1 ? Math.floor(pixel / 8) : pixel,
            alpha =
              a.bitDepth === 1 ? ((u8At(raw, at) >>> (7 - (pixel % 8))) & 1) * 255 : u8At(raw, at),
            value =
              a.bitDepth === 1
                ? ((u8At(raw, a.planeBytes + at) >>> (7 - (pixel % 8))) & 1) * 255
                : u8At(raw, a.planeBytes + at)
          rgba[dst] = rgba[dst + 1] = rgba[dst + 2] = value
          rgba[dst + 3] = alpha
        }
      }
  }
  const pixels = { width, height, left, top, rgba, defaultColor: a.color & 255 }
  if (!crop) return pixels
  const cropped = cropPixels(pixels, mask)
  if (
    cropped.width === 1 &&
    cropped.height === 1 &&
    (mask ? cropped.rgba[0] === pixels.defaultColor : cropped.rgba[3] === 0)
  ) {
    cropped.left = rx
    cropped.top = ry
  }
  return cropped
}

function alphaIndex(x: number, y: number): number {
  return (Math.floor(y / 4) * 256 + (y % 4) * 64 + Math.floor(x / 4)) * 4 + (x % 4)
}

function planeValue(raw: Uint8Array, a: OffscreenAttribute, pixel: number, color: boolean): number {
  const at = (color ? a.planeBytes : 0) + (a.bitDepth === 1 ? Math.floor(pixel / 8) : pixel)
  return a.bitDepth === 1 ? ((u8At(raw, at) >>> (7 - (pixel % 8))) & 1) * 255 : u8At(raw, at)
}
