import { num, type ClipRow } from './records.js'

/** Only bits tied to independent native captures belong in this mask. */
export const renderedBrushStyleFlags = 4 | 8 | 16 | 64 | 4096
export const renderedTextureFlags = 1 | 16 | 256
export const renderedTextureComposites: readonly number[] = [0, 1, 4]

export const brushInputFields = [
  'SizeEffector',
  'OpacityEffector',
  'FlowEffector',
  'ThicknessEffector',
  'IntervalEffector',
  'TextureDensityEffector',
] as const
export type BrushInputField = (typeof brushInputFields)[number]

/** CSP retains the image reference when the image tip is disabled (bit 16).
 * Callers supplying legacy rows without flags keep the reference-based default. */
export function activeBrushPattern(style: ClipRow): number {
  return typeof style.StyleFlag !== 'number' || style.StyleFlag & 16
    ? num(style, 'PatternStyle')
    : 0
}

export function textureApplication(style: ClipRow): 'disabled' | 'dab' | 'stroke' {
  return !num(style, 'TexturePattern') || !(num(style, 'TextureFlag') & 1)
    ? 'disabled'
    : num(style, 'TextureFlag') & 16
      ? 'dab'
      : 'stroke'
}

/** Shared by compilation and inspection. Native inactive settings and the
 * unimplemented round-thickness path have different reasons. Neither should
 * decode graphs or consume random values that replay will never use. */
export function brushInputOmission(style: ClipRow, field: BrushInputField): string | undefined {
  if (field === 'IntervalEffector' && num(style, 'AutoIntervalType', 2)) return 'automatic-interval'
  if (field === 'TextureDensityEffector' && textureApplication(style) !== 'dab')
    return 'paper-density-input-per-dab-only'
  if (field === 'ThicknessEffector' && !activeBrushPattern(style))
    return 'round-thickness-input-not-connected'
}

export function knownBrushRotation(flags: number, image: boolean): boolean {
  return (flags & ~128) === 3 || (image && (flags & ~192) === 3)
}
