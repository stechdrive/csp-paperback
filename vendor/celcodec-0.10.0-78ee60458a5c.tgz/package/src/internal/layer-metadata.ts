// Extracted from csp-paperback (MIT). See docs/provenance.json.
import type { LayerContentKind } from '../material/types.js'
import { readGradientKind } from './gradient.js'
import { num, str, type ClipRow } from './records.js'

/** Light-table entries are references, even when their saved eye flag is enabled. */
export function isLightTableReference(row: ClipRow): boolean {
  return num(row, 'LightTableReferCell') !== 0
}

export function isPaper(row: ClipRow): boolean {
  return (num(row, 'LayerType') & ~2) === 1584
}

/** CSP can save a normal vector layer before allocating any geometry records. */
export function hasUnallocatedVectorIndices(row: ClipRow): boolean {
  return (
    (row.LayerType === 0 || row.LayerType === 2) &&
    row.DrawToRenderOffscreenType === 10 &&
    row.VectorNormalType === 0 &&
    row.VectorNormalStrokeIndex === 0 &&
    row.VectorNormalFillIndex === 0 &&
    row.VectorNormalBalloonIndex === 0
  )
}

/** Keyframed layers can clear the ordinary raster/mask type bits. */
export function hasLayerMask(row: ClipRow): boolean {
  return (
    !!(num(row, 'LayerType') & 2) ||
    num(row, 'TimeLineOriginalMaskMipmap') > 0 ||
    num(row, 'LayerLayerMaskMipmap') > 0
  )
}

/** Only inspect a linked resource's type/extension, never the editable layer name. */
export function readMediaItemKind(item: ClipRow): 'audio' | 'video' | undefined {
  const type = str(item.ItemType).toLowerCase()
  if (type === 'audio') return 'audio'
  if (
    type === 'movie' ||
    type === 'video' ||
    /^(avi|mp4|mov)$/i.test(str(item.ItemFileExtension).replace(/^\./, ''))
  )
    return 'video'
}

export function readLayerKind(
  row: ClipRow,
  hasVectorObjects = false,
  mediaKind?: 'audio' | 'video',
): LayerContentKind {
  if (num(row, 'AudioLayer')) return 'audio'
  if (mediaKind) return mediaKind
  // Paper includes the camera bit; test the complete paper type first.
  if (isPaper(row)) return 'paper'
  if (num(row, 'LayerType') & 512 && num(row, 'LayerFolder') & 1) return 'camera'
  if (num(row, 'LayerFolder') & 1) return 'folder'
  if (row.FilterLayerInfo) return 'adjustment'
  if (num(row, 'Manager3D') || num(row, 'Manager3DOd')) return '3d'
  if (row.TextLayerString != null || row.TextLayerStringArray != null) return 'text'
  if (row.ResizableImageInfo) return 'image-material'
  if (num(row, 'VectorNormalStrokeIndex') || hasVectorObjects) return 'vector'
  if (row.GradationFillInfo instanceof Uint8Array) {
    const kind = readGradientKind(row.GradationFillInfo)
    if (kind) return kind
  }
  if (hasUnallocatedVectorIndices(row)) return 'vector'
  return num(row, 'LayerType') & 1 || num(row, 'TimeLineOriginalMipmap') > 0 ? 'raster' : 'other'
}

export function readPaletteColor(row: ClipRow): string | undefined {
  if (!num(row, 'LayerUsePaletteColor')) return
  const channels = ['Red', 'Green', 'Blue'].map((channel) => row['LayerPalette' + channel])
  if (
    channels.some(
      (value) =>
        typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > 0xffffffff,
    )
  )
    return
  return (
    '#' +
    (channels as number[])
      .map((value) =>
        Math.round(value / 0x01010101)
          .toString(16)
          .padStart(2, '0'),
      )
      .join('')
  )
}
