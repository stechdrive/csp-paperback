import { check } from './binary.js'
import { imageByteLength, type ImageRegion } from '../image-resources.js'
import type { PlaybackTransform } from '../document/playback.js'
import type { MaterialEffects, MaterialQuad } from '../material/types.js'
import type { ClipPixels } from '../types.js'

export function emptyRegion(mask = false, background = 0): ClipPixels {
  return {
    width: 1,
    height: 1,
    left: 0,
    top: 0,
    rgba: new Uint8ClampedArray(mask ? [background, background, background, 255] : [0, 0, 0, 0]),
    ...(mask ? { defaultColor: background } : {}),
  }
}

export function checkRegion(r: ImageRegion): void {
  check(r && typeof r === 'object', 'INVALID_IMAGE_REGION')
  imageByteLength(r.width, r.height)
  check(
    [r.left, r.top, r.left + r.width, r.top + r.height].every(Number.isSafeInteger),
    'INVALID_IMAGE_REGION',
  )
}
export function intersectRegion(a: ImageRegion, b: ImageRegion): ImageRegion | undefined {
  const left = Math.max(a.left, b.left),
    top = Math.max(a.top, b.top),
    right = Math.min(a.left + a.width, b.left + b.width),
    bottom = Math.min(a.top + a.height, b.top + b.height)
  return right > left && bottom > top
    ? { left, top, width: right - left, height: bottom - top }
    : undefined
}
export function expandRegion(r: ImageRegion, pad: number): ImageRegion {
  return {
    left: r.left - pad,
    top: r.top - pad,
    width: r.width + pad * 2,
    height: r.height + pad * 2,
  }
}
export function transformRegion(r: ImageRegion): ImageRegion {
  const size = 128,
    left = Math.floor(r.left / size) * size - 2,
    top = Math.floor(r.top / size) * size - 2
  return {
    left,
    top,
    width: Math.ceil((r.left + r.width) / size) * size + 2 - left,
    height: Math.ceil((r.top + r.height) / size) * size + 2 - top,
  }
}
export function localRegion(r: ImageRegion, x: number, y: number): ImageRegion {
  const left = Math.floor(r.left - x),
    top = Math.floor(r.top - y)
  return {
    left,
    top,
    width: Math.ceil(r.left + r.width - x) - left,
    height: Math.ceil(r.top + r.height - y) - top,
  }
}
export function effectHalo(e?: MaterialEffects): number {
  return e?.watercolor && !e.watercolor.style && e.watercolor.range && e.watercolor.opacity
    ? Math.ceil(e.watercolor.range) + Math.ceil(e.watercolor.blur) + 2
    : 0
}
export function inverseRegion(r: ImageRegion, m: PlaybackTransform, pad = 2): ImageRegion {
  const det = m[0] * m[3] - m[1] * m[2]
  // A singular transform contributes nothing; still inspect the source metadata.
  if (!det) return { left: 0, top: 0, width: 1, height: 1 }
  const points = [
      [r.left, r.top],
      [r.left + r.width, r.top],
      [r.left, r.top + r.height],
      [r.left + r.width, r.top + r.height],
    ],
    xs = points.map(([x, y]) => (m[3] * (x! - m[4]) - m[2] * (y! - m[5])) / det),
    ys = points.map(([x, y]) => (-m[1] * (x! - m[4]) + m[0] * (y! - m[5])) / det),
    left = Math.floor(Math.min(...xs)) - pad,
    top = Math.floor(Math.min(...ys)) - pad,
    result = {
      left,
      top,
      width: Math.ceil(Math.max(...xs)) + pad - left,
      height: Math.ceil(Math.max(...ys)) + pad - top,
    }
  checkRegion(result)
  return result
}

/** Inverse homography: document coordinates to the unit original image square. */
export function inverseQuad(q: MaterialQuad): number[] {
  const matrix: number[][] = []
  for (let i = 0; i < 4; i++) {
    const x = q[i * 2]!,
      y = q[i * 2 + 1]!,
      u = i === 1 || i === 2 ? 1 : 0,
      v = i >= 2 ? 1 : 0
    matrix.push([x, y, 1, 0, 0, 0, -u * x, -u * y, u], [0, 0, 0, x, y, 1, -v * x, -v * y, v])
  }
  for (let c = 0; c < 8; c++) {
    let pivot = c
    for (let r = c + 1; r < 8; r++)
      if (Math.abs(matrix[r]![c]!) > Math.abs(matrix[pivot]![c]!)) pivot = r
    ;[matrix[c], matrix[pivot]] = [matrix[pivot]!, matrix[c]!]
    const divisor = matrix[c]![c]!
    check(Math.abs(divisor) > 1e-10, 'INVALID_PLACEMENT')
    for (let j = c; j <= 8; j++) matrix[c]![j] = matrix[c]![j]! / divisor
    for (let r = 0; r < 8; r++)
      if (r !== c) {
        const scale = matrix[r]![c]!
        for (let j = c; j <= 8; j++) matrix[r]![j] = matrix[r]![j]! - matrix[c]![j]! * scale
      }
  }
  return matrix.map((row) => row[8]!)
}
export function quadSourceRegion(
  q: MaterialQuad,
  width: number,
  height: number,
  r: ImageRegion,
): ImageRegion {
  const m = inverseQuad(q),
    points = [
      [r.left, r.top],
      [r.left + r.width, r.top],
      [r.left, r.top + r.height],
      [r.left + r.width, r.top + r.height],
    ],
    denominators = points.map(([x, y]) => m[6]! * x! + m[7]! * y! + 1)
  if (Math.min(...denominators) <= 0 && Math.max(...denominators) >= 0)
    return { left: 0, top: 0, width, height }
  const xs = points.map(
      ([x, y], i) => ((m[0]! * x! + m[1]! * y! + m[2]!) / denominators[i]!) * width,
    ),
    ys = points.map(([x, y], i) => ((m[3]! * x! + m[4]! * y! + m[5]!) / denominators[i]!) * height),
    left = Math.max(0, Math.floor(Math.min(...xs)) - 2),
    top = Math.max(0, Math.floor(Math.min(...ys)) - 2),
    right = Math.min(width, Math.ceil(Math.max(...xs)) + 2),
    bottom = Math.min(height, Math.ceil(Math.max(...ys)) + 2)
  return right > left && bottom > top
    ? { left, top, width: right - left, height: bottom - top }
    : { left: 0, top: 0, width: 1, height: 1 }
}
