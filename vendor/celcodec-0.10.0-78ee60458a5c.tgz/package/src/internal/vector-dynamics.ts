import { compileCurve } from './curve.js'
import { requiredAt, numberAt } from './indexed.js'
// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
import { check, Reader } from './binary.js'
import { num, type ClipRow } from './records.js'
import type { VectorPoint } from './vector.js'

const clamp = (v: number) => Math.max(0, Math.min(1, v))
type Curve = (v: number) => number

function curve(row: ClipRow | undefined): Curve {
  const count = row && num(row, 'ControlNumber'),
    data = row?.ControlPoints
  if (!count || !(data instanceof Uint8Array)) return clamp
  check(
    Number.isSafeInteger(count) && count > 0 && count <= 256 && data.length === count * 16,
    'INVALID_BRUSH_CURVE',
  )
  const r = new Reader(data),
    points = Array.from({ length: count }, (): [number, number] => [
      r.number('f64'),
      r.number('f64'),
    ])
  check(
    points.every(
      (p, i) =>
        p.every((v) => v >= 0 && v <= 1) &&
        (!i || numberAt(p, 0) >= numberAt(requiredAt(points, i - 1), 0)),
    ),
    'INVALID_BRUSH_CURVE',
  )
  return compileCurve(points)
}

export interface BrushDynamics {
  value: (point: VectorPoint) => number
  randomMinimum?: number
}

export interface BrushDynamicsInspection {
  flags: number
  unknownFlags: number
  consumedBytes: number
  remainingBytes: number
  missingGraphs: number[]
}

export function inspectBrushDynamics(
  data: ClipRow[string],
  graphs: Map<number, ClipRow>,
): BrushDynamicsInspection {
  return decodeBrushDynamics(data, graphs).inspection
}

/** Decode once per brush, including the speed graph stored AFTER the random minimum. */
export function readBrushDynamics(
  data: ClipRow[string],
  graphs: Map<number, ClipRow>,
): BrushDynamics {
  const decoded = decodeBrushDynamics(data, graphs)
  return {
    ...(decoded.randomMinimum !== undefined ? { randomMinimum: decoded.randomMinimum } : {}),
    value: decoded.value,
  }
}

/** Internal compiler entry also keeps the consumed-byte and graph evidence. */
export function decodeBrushDynamics(
  data: ClipRow[string],
  graphs: Map<number, ClipRow>,
): BrushDynamics & { inspection: BrushDynamicsInspection } {
  if (!(data instanceof Uint8Array) || !data.length)
    return {
      value: () => 1,
      inspection: {
        flags: 0,
        unknownFlags: 0,
        consumedBytes: 0,
        remainingBytes: 0,
        missingGraphs: [],
      },
    }
  const r = new Reader(data),
    flags = r.u32(),
    factors: Array<(p: VectorPoint) => number> = []
  const missingGraphs: number[] = []
  const graph = (id: number): Curve => {
    if (id && !graphs.has(id)) missingGraphs.push(id)
    return curve(graphs.get(id))
  }
  if (flags & 16) {
    const min = r.number('f32'),
      response = graph(r.u32())
    factors.push((p) => min + (1 - min) * response(clamp(p.pressure)))
  }
  let penTilt: { min: number; response: Curve } | undefined
  if (flags & 32) penTilt = { min: r.number('f32'), response: graph(r.u32()) }
  const speedMin = flags & 64 ? r.number('f32') : undefined
  const randomMinimum = flags & 128 ? clamp(r.number('f32')) : undefined
  if (flags & 256) {
    const min = r.number('f32')
    factors.push((p) => min + (1 - min) * clamp(Math.abs(p.tilt)))
  }
  if (penTilt) {
    const { min, response } = penTilt,
      max = r.position + 4 <= data.length ? r.number('f32') : 1
    factors.push((p) => min + (max - min) * response(clamp(p.velocity)))
  }
  if (speedMin !== undefined) {
    const response = r.position + 4 <= data.length ? graph(r.u32()) : (v: number) => 1 - clamp(v)
    factors.push((p) => speedMin + (1 - speedMin) * response(clamp(p.smooth)))
  }
  return {
    ...(randomMinimum !== undefined ? { randomMinimum } : {}),
    value: (p) => clamp(factors.reduce((out, factor) => out * factor(p), 1)),
    inspection: {
      flags,
      unknownFlags: (flags & ~(1 | 16 | 32 | 64 | 128 | 256)) >>> 0,
      consumedBytes: r.position,
      remainingBytes: data.length - r.position,
      missingGraphs,
    },
  }
}

/** CLIP saved state transitions and native density/angle fixtures use this 15-bit LCG. */
export function brushRandom(seed: number): () => number {
  return createBrushRandom(seed).next
}

/** Inspectable state for the bounded internal renderer trace. */
export function createBrushRandom(seed: number) {
  let state = seed >>> 0
  let draws = 0
  return {
    get state() {
      return state
    },
    get draws() {
      return draws
    },
    next(this: void) {
      state = (Math.imul(state, 0x41c64e6d) + 0x12d687) >>> 0
      draws++
      return ((state >>> 16) & 32767) / 32768
    },
  }
}
