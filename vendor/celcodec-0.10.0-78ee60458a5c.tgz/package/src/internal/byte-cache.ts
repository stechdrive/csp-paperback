import { check } from './binary.js'

/** A byte and entry bounded LRU. Costs include a conservative key/entry allowance.
 * Values are private immutable preparations; public pixel results must never alias them. */
export class ByteCache {
  private entries = new Map<object, { value: unknown; bytes: number }>()
  private retained = 0
  hits = 0
  misses = 0
  evictions = 0

  constructor(
    readonly limit: number,
    readonly maxEntries = 16384,
  ) {
    check(
      [limit, maxEntries].every((n) => Number.isSafeInteger(n) && n >= 0),
      'INVALID_LIMIT',
    )
  }

  get<T>(key: object): T | undefined {
    const entry = this.entries.get(key)
    if (!entry) {
      this.misses++
      return undefined
    }
    this.hits++
    this.entries.delete(key)
    this.entries.set(key, entry)
    return entry.value as T
  }

  set(key: object, value: unknown, bytes: number): void {
    check(Number.isSafeInteger(bytes) && bytes >= 0, 'INVALID_LIMIT')
    this.delete(key)
    bytes += 96
    if (bytes > this.limit || !this.maxEntries) return
    while (this.retained + bytes > this.limit || this.entries.size >= this.maxEntries) {
      this.delete(this.entries.keys().next().value!)
      this.evictions++
    }
    this.entries.set(key, { value, bytes })
    this.retained += bytes
  }

  delete(key: object): void {
    const old = this.entries.get(key)
    if (old) {
      this.retained -= old.bytes
      this.entries.delete(key)
    }
  }

  get bytes(): number {
    return this.retained
  }
  get size(): number {
    return this.entries.size
  }
  clear(): void {
    this.entries.clear()
    this.retained = 0
  }
}
