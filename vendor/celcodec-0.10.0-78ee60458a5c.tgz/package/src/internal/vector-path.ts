// Curve sampling adapted from animeops/clip-tools (MIT); see THIRD_PARTY_NOTICES.md.
// Closed-stroke topology cross-checked with nekomimianko/clipvec and CSP previews.
import { check } from './binary.js'
import { requiredAt, numberAt } from './indexed.js'
import type { VectorPoint, VectorStroke } from './vector.js'

export const CLOSED_VECTOR_STROKE = 0x100

export interface PathSample extends VectorPoint {
  tangentX?: number
  tangentY?: number
  segment?: number
  parameter?: number
}

/** Six-point spline. Open ends and saved corners bound the window; closed ends wrap. */
function spline(
  pointAt: (index: number) => VectorPoint,
  length: number,
  closed: boolean,
  i: number,
  t: number,
  derivative = false,
): [number, number] {
  // Bit 0 marks a corner. Controls across it must not pull this segment into a curve.
  // Only the six-point window matters; do not scan the full stroke for each sample.
  let first = closed ? i - 2 : Math.max(0, i - 2),
    last = closed ? i + 3 : Math.min(length - 1, i + 3)
  for (let k = i; k > first; k--)
    if (pointAt(k).flags & 1) {
      first = k
      break
    }
  for (let k = i + 1; k < last; k++)
    if (pointAt(k).flags & 1) {
      last = k
      break
    }
  const q = t * t
  const w = derivative
    ? t >= 0.5
      ? [4 * t - 6, -32 * t + 44, 192 * t - 260, -328 * t + 328, 192 * t - 124, -28 * t + 18]
      : [-28 * t + 10, 192 * t - 68, -328 * t, 192 * t + 68, -32 * t - 12, 4 * t + 2]
    : t >= 0.5
      ? [
          2 * q - 6 * t + 4,
          -16 * q + 44 * t - 28,
          96 * q - 260 * t + 164,
          -164 * q + 328 * t - 65,
          96 * q - 124 * t + 28,
          -14 * q + 18 * t - 4,
        ]
      : [
          -14 * q + 10 * t,
          96 * q - 68 * t,
          -164 * q + 99,
          96 * q + 68 * t,
          -16 * q - 12 * t,
          2 * q + 2 * t,
        ]
  let x = 0,
    y = 0
  for (let j = 0; j < 6; j++) {
    const p = pointAt(Math.max(first, Math.min(last, i + j - 2)))
    x += numberAt(w, j) * p.x
    y += numberAt(w, j) * p.y
  }
  return [x / 99, y / 99]
}

/** One geometry/input evaluator, shared by compatibility sampling and stamp research.
 * Locations refer to the outgoing segment at a real control, without inventing controls. */
export function createVectorPath(stroke: VectorStroke) {
  const pts = stroke.points
  const kind = stroke.flags & 240
  const closed = pts.length > 1 && !!(stroke.flags & CLOSED_VECTOR_STROKE)
  const last = pts.at(-1)
  // An explicit copy of the start already closes the path. An outgoing Bézier
  // handle can still describe a real loop between coincident endpoints.
  const repeatedEnd =
    closed &&
    last &&
    last.x === pts[0]!.x &&
    last.y === pts[0]!.y &&
    !last.handles
      .slice(0, kind === 32 ? 2 : kind === 64 ? 4 : 0)
      .some((v, index) => v !== (index % 2 ? last.y : last.x))
  const segments = closed && !repeatedEnd ? pts.length : Math.max(0, pts.length - 1)
  function pointAt(index: number) {
    if (closed && (index < 0 || index >= pts.length))
      index = ((index % segments) + segments) % segments
    return requiredAt(pts, index)
  }
  const tangent = (i: number, t: number): [number, number] => {
    const a = pointAt(i),
      b = pointAt(i + 1),
      u = 1 - t
    if (kind === 128) return spline(pointAt, pts.length, closed, i, t, true)
    if (kind === 32 && a.handles.length >= 2)
      return [
        2 * (u * (numberAt(a.handles, 0) - a.x) + t * (b.x - numberAt(a.handles, 0))),
        2 * (u * (numberAt(a.handles, 1) - a.y) + t * (b.y - numberAt(a.handles, 1))),
      ]
    if (kind === 64)
      return [
        3 *
          (u * u * (numberAt(a.handles, 0) - a.x) +
            2 * u * t * (numberAt(a.handles, 2) - numberAt(a.handles, 0)) +
            t * t * (b.x - numberAt(a.handles, 2))),
        3 *
          (u * u * (numberAt(a.handles, 1) - a.y) +
            2 * u * t * (numberAt(a.handles, 3) - numberAt(a.handles, 1)) +
            t * t * (b.y - numberAt(a.handles, 3))),
      ]
    return [b.x - a.x, b.y - a.y]
  }
  function direction(i: number, t: number) {
    // The last sample of a segment is the next control's outgoing direction.
    if (t === 1 && (i + 1 < segments || closed)) {
      i = (i + 1) % segments
      t = 0
    }
    const [tangentX, tangentY] = tangent(i, t)
    return { tangentX, tangentY, segment: i, parameter: t }
  }
  return {
    segments,
    direction,
    evaluate(i: number, t: number, directions = false): PathSample {
      check(
        Number.isInteger(i) && i >= 0 && i < segments && Number.isFinite(t) && t >= 0 && t <= 1,
        'INVALID_VECTOR_COORDINATE',
      )
      const a = pointAt(i),
        b = pointAt(i + 1)
      const u = 1 - t
      const lerp = (x: number, y: number) => u * x + t * y
      let x = lerp(a.x, b.x),
        y = lerp(a.y, b.y)
      if (kind === 128) [x, y] = spline(pointAt, pts.length, closed, i, t)
      else if (kind === 32 && a.handles.length >= 2) {
        x = u * u * a.x + 2 * u * t * numberAt(a.handles, 0) + t * t * b.x
        y = u * u * a.y + 2 * u * t * numberAt(a.handles, 1) + t * t * b.y
      } else if (kind === 64) {
        check(a.handles.length === 4, 'INVALID_VECTOR_HANDLE')
        x =
          u * u * u * a.x +
          3 * u * u * t * numberAt(a.handles, 0) +
          3 * u * t * t * numberAt(a.handles, 2) +
          t * t * t * b.x
        y =
          u * u * u * a.y +
          3 * u * u * t * numberAt(a.handles, 1) +
          3 * u * t * t * numberAt(a.handles, 3) +
          t * t * t * b.y
      }
      // A control belongs to its outgoing segment. In particular, a saved
      // corner must not inherit the direction of the preceding stamp chord.
      const control = t === 0 ? a : t === 1 ? b : undefined
      return {
        x,
        y,
        flags: t < 0.5 ? a.flags : b.flags,
        handles: [],
        pressure: lerp(a.pressure, b.pressure),
        velocity: lerp(a.velocity, b.velocity),
        smooth: lerp(a.smooth, b.smooth),
        direction: lerp(a.direction, b.direction),
        tilt: lerp(a.tilt, b.tilt),
        size: lerp(a.size, b.size),
        flow: lerp(a.flow, b.flow),
        ...(directions ? direction(i, t) : {}),
        ...(control?.dabState ? { dabState: control.dabState } : {}),
        ...(control?.cornerData ? { cornerData: control.cornerData } : {}),
      }
    },
  }
}

/** The public point list keeps its established subdivisions and object shape. */
export function sampleVectorStroke(stroke: VectorStroke, directions = false): PathSample[] {
  return samplePath(stroke, directions, 1)
}

/** Short image splines need at least four intervals to localize native markers.
 * Longer segments retain their finer distance integration; forcing every segment
 * to four intervals breaks otherwise matching marker positions. One interval is
 * retained only for internal comparisons with the previous approximation. */
export function sampleImageVectorStroke(
  stroke: VectorStroke,
  minimumSplineIntervals: 1 | 4 = 4,
): PathSample[] {
  return samplePath(stroke, true, minimumSplineIntervals)
}

function samplePath(
  stroke: VectorStroke,
  directions: boolean,
  minimumSplineIntervals: number,
): PathSample[] {
  const pts = stroke.points,
    out: PathSample[] = []
  if (pts.length === 1) return [{ ...requiredAt(pts, 0) }]
  const path = createVectorPath(stroke)
  for (let i = 0; i < path.segments; i++) {
    const a = requiredAt(pts, i),
      b = pts[i + 1] ?? requiredAt(pts, 0)
    const length =
      Math.hypot(b.x - a.x, b.y - a.y) +
      a.handles.reduce(
        (sum, v, j) => (j % 2 ? sum : sum + Math.hypot(v - a.x, numberAt(a.handles, j + 1) - a.y)),
        0,
      )
    const minimum = (stroke.flags & 240) === 128 ? minimumSplineIntervals + 1 : 2
    const count = Math.max(minimum, Math.ceil(length * 2))
    check(out.length + count <= 1000000, 'LIMIT_VECTOR_SAMPLES')
    for (let j = i ? 1 : 0; j < count; j++) out.push(path.evaluate(i, j / (count - 1), directions))
  }
  return out
}
