import { clampedAt } from './indexed.js'
import { num, type ClipRow } from './records.js'
import { checkCancelled } from '../diagnostics.js'
import type { ClipPixels } from '../types.js'

/** Saved gray-expression previews retain the original gray plane in the cache. */
export function applyGrayPreview(pixels: ClipPixels, row: ClipRow, signal?: AbortSignal): void {
  if (!num(row, 'UsePreviewColorType') || row.PreviewColorTypeIndex !== 1) return
  const black = row.PreviewColorTypeBlackChecked === 1,
    white = row.PreviewColorTypeWhiteChecked === 1
  if (black === white) return
  const data = pixels.rgba,
    ink = white ? 255 : 0,
    colorToAlpha = !!num(row, 'PreviewColorTypeColorToAlpha')
  for (let i = 0; i < data.length; i += 4) {
    if (i % 65536 === 0) checkCancelled(signal)
    if (colorToAlpha) {
      const gray = Math.min(
        255,
        Math.floor(
          (298912 * clampedAt(data, i) +
            586611 * clampedAt(data, i + 1) +
            114478 * clampedAt(data, i + 2)) /
            1000000,
        ),
      )
      // Native 8-bit conversion truncates coverage; rounding changes faint ink.
      data[i + 3] = Math.floor((clampedAt(data, i + 3) * (white ? gray : 255 - gray)) / 255)
    }
    data[i] = data[i + 1] = data[i + 2] = ink
  }
}
