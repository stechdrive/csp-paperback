import { ClipError } from '../diagnostics.js'
// FilterLayerInfo framing: Aodaruma/clipfile-rs and wamsoft/clipparse (MIT).
// Equations and native channel layouts: docs/adjustments.md.
import { check, Reader } from './binary.js'
import { validateAdjustment } from '../render/adjustment.js'
import type { MaterialAdjustment, AdjustmentCurve, AdjustmentLevels } from '../material/types.js'

export function readAdjustment(bytes: Uint8Array): MaterialAdjustment {
  const r = new Reader(bytes),
    kind = r.u32(),
    length = r.u32()
  check(length === bytes.length - 8, 'INVALID_ADJUSTMENT_HEADER')
  let result: MaterialAdjustment
  if (kind === 6 && length === 0) result = { kind: 'invert' }
  else if (kind === 8 && length === 4) result = { kind: 'threshold', threshold: r.u32() }
  else if (kind === 7 && length === 4) result = { kind: 'posterize', levels: r.u32() }
  else if (kind === 1 && length === 8)
    result = { kind: 'brightness-contrast', brightness: r.number('i32'), contrast: r.number('i32') }
  else if (kind === 4 && length === 12)
    result = {
      kind: 'hue-saturation-lightness',
      hue: r.number('i32'),
      saturation: r.number('i32'),
      lightness: r.number('i32'),
    }
  else if (kind === 2 && length === 320) {
    const read = (): AdjustmentLevels => ({
      inputBlack: r.number('u16'),
      inputMid: r.number('u16'),
      inputWhite: r.number('u16'),
      outputBlack: r.number('u16'),
      outputWhite: r.number('u16'),
    })
    result = { kind: 'levels', channels: [read(), read(), read(), read()] }
  } else if (kind === 3 && length === 4160) {
    const read = (): AdjustmentCurve => {
      const count = r.number('u16')
      check(count >= 2 && count <= 32, 'INVALID_ADJUSTMENT_SETTINGS')
      const points = Array.from({ length: count }, (): [number, number] => [
        r.number('u16'),
        r.number('u16'),
      ])
      r.take((32 - count) * 4)
      return points
    }
    result = { kind: 'tone-curve', channels: [read(), read(), read(), read()] }
  } else throw new ClipError('UNSUPPORTED_ADJUSTMENT', { kind, length })
  validateAdjustment(result)
  return result
}
