import { numberAt } from './indexed.js'
// Extracted from csp-paperback (MIT). See docs/provenance.json.
import { rethrowFatal, type DiagnosticCode } from '../diagnostics.js'
// Text TLV and array layout: dobrokot/clip_to_psd and animeops/clip-tools (MIT).
import { check, Reader } from './binary.js'
import { num, str, type ClipRow } from './records.js'
import type { TextObject } from '../material/types.js'

export interface ClipTextObject extends TextObject {
  cacheId?: number
  cache?: { left: number; top: number }
}

function array(row: ClipRow, key: string): Uint8Array[] {
  const result: Uint8Array[] = []
  const first = row[key]
  if (first instanceof Uint8Array) result.push(first)
  else if (typeof first === 'string') result.push(new Uint8Array(new TextEncoder().encode(first)))
  const rest = row[`${key}Array`]
  if (rest instanceof Uint8Array) {
    const r = new Reader(rest, true)
    while (r.position < rest.length) {
      check(result.length < 1000, 'LIMIT_TEXT_OBJECTS')
      result.push(r.take(r.u32()))
    }
  }
  return result
}

export function readTextAttributes(bytes: Uint8Array): Map<number, Uint8Array> {
  const r = new Reader(bytes, true),
    fields = new Map<number, Uint8Array>()
  while (r.position < bytes.length) {
    const tag = r.u32(),
      size = r.u32()
    fields.set(tag, r.take(size))
    check(fields.size < 1000, 'LIMIT_TEXT_ATTRIBUTES')
  }
  return fields
}

export function readTextObjects(
  row: ClipRow,
  dpi: number,
  report: (message: DiagnosticCode) => void = () => {},
): ClipTextObject[] {
  const strings = array(row, 'TextLayerString'),
    attributes = array(row, 'TextLayerAttributes')
  return strings
    .map((string, index) => {
      check(str(string).length <= 100000, 'LIMIT_TEXT_LENGTH')
      try {
        return textObject(
          string,
          attributes[index] ? readTextAttributes(attributes[index]) : new Map(),
          row,
          dpi,
        )
      } catch (error) {
        rethrowFatal(error)
        report('APPROXIMATE_TEXT_ATTRIBUTES')
        return textObject(string, new Map(), row, dpi)
      }
    })
    .filter((o) => o.text.length > 0)
}

function textObject(
  string: Uint8Array,
  fields: Map<number, Uint8Array>,
  row: ClipRow,
  dpi: number,
): ClipTextObject {
  const reader = (tag: number) => (fields.has(tag) ? new Reader(fields.get(tag)!, true) : undefined)
  const box = reader(42),
    size = reader(32),
    color = reader(34),
    align = reader(12)
  const left = box?.number('i32') ?? 0,
    top = box?.number('i32') ?? 0
  const right = box?.number('i32') ?? left,
    bottom = box?.number('i32') ?? top
  const fontSize = Math.max(1, Math.min(4096, ((size ? size.u32() / 100 : 12) * (dpi || 72)) / 72))
  const object: ClipTextObject = {
    text: str(string),
    left: left + num(row, 'LayerOffsetX'),
    top: top + num(row, 'LayerOffsetY'),
    width: box ? Math.max(0, right - left + 1) : 0,
    height: box ? Math.max(0, bottom - top + 1) : 0,
    font: str(fields.get(31)) || 'sans-serif',
    size: fontSize,
    color: color ? [color.u32() >>> 24, color.u32() >>> 24, color.u32() >>> 24] : [0, 0, 0],
    align: 'left',
    runs: [],
  }
  const cacheId = reader(50)?.u32()
  if (cacheId) {
    object.cacheId = cacheId
    const quad = reader(64),
      offset = reader(72)
    if (box && quad && offset) {
      // The cache already contains static rotation/stretch. Its local origin is
      // tag 72; align the opposite corners of tag 64 with the text box centre.
      // Keep 1/100px integers until rounding, including for negative positions.
      const q = Array.from({ length: 8 }, () => quad.number('i32'))
      object.cache = {
        left:
          Math.ceil(((left + right) * 100 - numberAt(q, 0) - numberAt(q, 4)) / 200) -
          offset.number('i32') +
          num(row, 'LayerOffsetX'),
        top:
          Math.ceil(((top + bottom) * 100 - numberAt(q, 1) - numberAt(q, 5)) / 200) -
          offset.number('i32') +
          num(row, 'LayerOffsetY'),
      }
    } else if (box && !quad && !offset) object.cache = { left: object.left, top: object.top }
  }
  if (align && align.u32() > 0) {
    align.take(12)
    object.align = (['left', 'center', 'right'] as const)[align.number('u8')] ?? 'left'
  }
  const runs = reader(11)
  if (runs) {
    const count = runs.u32()
    check(count <= 10000, 'LIMIT_TEXT_RUNS')
    for (let i = 0; i < count; i++) {
      const start = runs.number('i32'),
        length = runs.u32(),
        recordSize = runs.u32()
      const end = runs.position + recordSize - 8
      runs.take(2)
      const rgb: [number, number, number] = [
        runs.number('u16') >>> 8,
        runs.number('u16') >>> 8,
        runs.number('u16') >>> 8,
      ]
      const scale = runs.number('f64')
      const font = new TextDecoder('utf-16le').decode(runs.take(runs.number('u16') * 2))
      check(end >= runs.position, 'INVALID_TEXT_RUN')
      runs.take(end - runs.position)
      object.runs.push({
        start,
        length,
        font: font || object.font,
        size: scale > 0 ? Math.min(4096, (fontSize * scale) / 100) : fontSize,
        color: rgb,
      })
    }
  }
  return object
}
