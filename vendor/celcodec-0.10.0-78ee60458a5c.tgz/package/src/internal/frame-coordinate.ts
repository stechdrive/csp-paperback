import { check } from './binary.js'

/** Retain native subframes; normalize only negligible arithmetic noise at integer boundaries. */
export function frameCoordinate(value: number): number {
  check(Number.isFinite(value) && Math.abs(value) <= 1_000_000, 'LIMIT_TIMELINE_RANGE')
  const rounded = Math.round(value)
  return Math.abs(value - rounded) < 1e-7 ? rounded : value
}
