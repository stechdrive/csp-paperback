import { requiredAt, clampedAt } from './indexed.js'
// Extracted from csp-paperback (MIT). See docs/provenance.json.
import { check, Reader } from './binary.js'
import { readAttribute, readRaster } from './raster.js'
import { decodeRasterPixels } from './raster-decode.js'
import { validateCanvasPixels } from './canvas-limits.js'
import {
  checkRegion,
  intersectRegion,
  localRegion,
  quadSourceRegion,
  emptyRegion,
  transformRegion,
} from './image-region.js'
import { RasterIndexCache, regionTiles } from './raster-index.js'
import { ByteCache } from './byte-cache.js'
import { previewPixels } from './preview-pixels.js'
import { applyGrayPreview } from './gray-preview.js'
import type { ImageRegion } from '../image-resources.js'
import {
  resolveImageLimits,
  resourceLimit,
  rgbaBuffer,
  checkImageAllocation,
  type ImageResourceLimits,
} from '../image-resources.js'
import { readTextObjects } from './text.js'
import { num, str, type ClipRow } from './records.js'
import type { ClipDiagnostic } from '../diagnostics.js'
import type { ClipLayer, ClipPixels } from '../material/types.js'
import type { MaterialEffects, MaterialQuad } from '../material/types.js'
import { readGradient } from './gradient.js'
import { hasLayerMask, hasUnallocatedVectorIndices, isPaper } from './layer-metadata.js'
import { readAdjustment } from './adjustment.js'
import {
  readVectorStrokes,
  renderVectorProgram,
  type BrushPattern,
  type VectorBrushes,
  type VectorStroke,
} from './vector.js'
import { layerRenderingDiagnostics } from '../material/diagnostics.js'
import { inspectBrushPattern } from './vector-audit.js'
import { activeBrushPattern } from './vector-settings.js'
import {
  ClipError,
  errorCode,
  rethrowFatal,
  type DiagnosticCode,
  diagnostic,
  checkCancelled,
} from '../diagnostics.js'
const isMediaKind = (kind: string | undefined) => kind === 'audio' || kind === 'video'

/** Decode only drawing effects; palette label colors are deliberately unrelated. */
export function readMaterialEffects(
  row: ClipRow,
  report?: (message: DiagnosticCode) => void,
): MaterialEffects | undefined {
  const effects: MaterialEffects = {}
  // Paper stores its fill color in the same columns, without a recoloring effect.
  if (num(row, 'DrawColorEnable') && !isPaper(row)) {
    const rgb = (prefix: string, fallback: number) =>
      ['Red', 'Green', 'Blue'].map((c) => num(row, prefix + c, fallback) >>> 24) as [
        number,
        number,
        number,
      ]
    const main = rgb('DrawColorMain', 0)
    // A committed white-only gray layer uses the main drawing color too.
    // A preview on an existing two-ink layer still uses that layer's subcolor.
    const whiteOnly =
      row.LayerColorTypeIndex === 1 &&
      row.LayerColorTypeBlackChecked === 0 &&
      row.LayerColorTypeWhiteChecked === 1
    effects.layerColor = { main, sub: whiteOnly ? [...main] : rgb('DrawColorSub', 0xffffffff) }
  }
  try {
    const bytes = row.LayerEffectInfo
    if (bytes instanceof Uint8Array && num(row, 'LayerEffectAttached')) {
      const tone = effectRecord(bytes, 'EffectTone')
      if (tone?.u32()) effects.tone = true
    }
    Object.assign(effects, readEdgeEffects(row))
  } catch (e) {
    if (!report) throw e
    report(errorCode(e))
  }
  return Object.keys(effects).length ? effects : undefined
}

function effectRecord(bytes: Uint8Array, name: string): Reader | undefined {
  const needle = [0, 0, 0, name.length, ...Array.from(name).flatMap((c) => [0, c.charCodeAt(0)])]
  const start = bytes.findIndex((_, i) => needle.every((b, j) => bytes[i + j] === b))
  return start < 0 ? undefined : new Reader(bytes.subarray(start + needle.length))
}

function readEdgeEffects(row: ClipRow): MaterialEffects | undefined {
  const bytes = row.LayerEffectInfo
  if (!(bytes instanceof Uint8Array) || !num(row, 'LayerEffectAttached')) return
  const r = effectRecord(bytes, 'EffectEdge')
  if (!r) return
  if (!r.u32()) return
  const radius = r.number('f64')
  check(radius >= 0 && radius <= 256, 'INVALID_EDGE_RADIUS')
  const color: [number, number, number] = [r.u32() >>> 24, r.u32() >>> 24, r.u32() >>> 24]
  const water = effectRecord(bytes, 'EffectWaterEdge')
  if (water) {
    const size = water.u32()
    check(
      size >= 40 && size - 4 <= water.bytes.length - water.position,
      'INVALID_WATERCOLOR_RECORD',
    )
    if (water.u32()) {
      const range = water.number('f64'),
        opacity = water.number('f64'),
        darkness = water.number('f64'),
        blur = water.number('f64')
      check(
        range >= 0 &&
          range <= 20 &&
          opacity >= 0 &&
          opacity <= 100 &&
          darkness >= 0 &&
          darkness <= 100 &&
          blur >= 0 &&
          blur <= 10,
        'INVALID_WATERCOLOR_SETTINGS',
      )
      const style = size >= 44 ? water.u32() : 0
      return { watercolor: { range, opacity, darkness, blur, ...(style ? { style } : {}) } }
    }
  }
  const edge: NonNullable<MaterialEffects['edge']> = { radius, color }
  // CSP 5.1.5 appends edge options after the sized EffectLine record.
  // A native checkbox-only A/B changes reflectOpacity here, not EffectApplyOpacity.
  const line = effectRecord(bytes, 'EffectLine')
  if (line) {
    const size = line.u32()
    check(size >= 4 && size <= line.bytes.length, 'INVALID_EDGE_RECORD')
    line.take(size - 4)
    if (line.bytes.length - line.position === 20) {
      line.take(4)
      const aa = line.u32()
      line.take(4)
      const opacity = line.u32()
      check(opacity <= 1 && aa <= 1, 'INVALID_EDGE_OPACITY')
      edge.reflectOpacity = !!opacity
      edge.antialias = !!aa
    }
  }
  return { edge }
}

/** ResizableImageInfo describes static artwork placement, not animation/camera transforms. */
export function readMaterialQuad(bytes: Uint8Array): MaterialQuad {
  const r = new Reader(bytes)
  check(r.u32() === 120, 'INVALID_PLACEMENT')
  r.take(116)
  const tl = [r.number('f64'), r.number('f64')],
    tr = [r.number('f64'), r.number('f64')]
  const bl = [r.number('f64'), r.number('f64')],
    br = [r.number('f64'), r.number('f64')]
  return [...tl, ...tr, ...br, ...bl] as MaterialQuad
}

export interface MaterialTables {
  mipmaps: Map<number, ClipRow>
  mipInfos: Map<number, ClipRow>
  offscreens: Map<number, ClipRow>
  thumbnails: ClipRow[]
  external: Map<string, Uint8Array>
  vectors?: Map<number, ClipRow>
  brushes?: Map<number, ClipRow>
  brushGraphs?: Map<number, ClipRow>
  brushPatterns?: Map<number, ClipRow>
  brushImages?: Map<number, ClipRow>
}

export function materialOffscreen(
  t: MaterialTables,
  row: ClipRow,
  field: string,
): ClipRow | undefined {
  const mip = t.mipmaps.get(num(row, field)),
    info = mip && t.mipInfos.get(num(mip, 'BaseMipmapInfo'))
  return info && num(info, 'ThisScale', 100) === 100
    ? t.offscreens.get(num(info, 'Offscreen'))
    : undefined
}

/** A declared cache with missing painted tiles is evidence of missing content. */
function hasOnlyEmptyVectorCaches(t: MaterialTables, row: ClipRow): boolean {
  return ['LayerRenderMipmap', 'TimeLineOriginalMipmap', 'ResizableOriginalMipmap'].every(
    (field) => {
      if (!num(row, field)) return true
      const off = materialOffscreen(t, row, field)
      if (!(off?.Attribute instanceof Uint8Array)) return false
      const attr = readAttribute(off.Attribute)
      // A 104-byte tile contains just the native begin/end headers and no pixel payload.
      return !attr.hasColor && attr.sizes.every((size) => size === 104)
    },
  )
}

/** Each layer can fall back independently; one failed image cannot cancel the document. */
export interface MaterialDecoderOptions {
  /** Preview-only power-of-two reduction, 1/256..1. Raster/paper/folder sources only;
   * returned pixels use reduced document coordinates. Source selection is preserved. */
  rasterScale?: number
  /** Requested original-material document coordinates, before playback transforms.
   * Placement/effects remain metadata; use a document/frame renderer for final appearance. */
  region?: ImageRegion
  /** Independent request for a separately animated mask; defaults to region. */
  maskRegion?: ImageRegion
  imageLimits?: ImageResourceLimits
  maxVectorWork?: number
  /** Original refuses transformed caches; prefer-original permits a saved fallback. */
  source?: 'original' | 'prefer-original' | 'saved'
  /** When false, a saved folder exposes its mask/effects for child composition, not a baked preview. */
  folderComposite?: boolean
  budget?: 'cropped' | 'extent'
  maxDecodedBytes?: number
  vectorReservation?: boolean
  signal?: AbortSignal
  inflate?: import('../types.js').Inflate
}

/** Saved folder/movie composites already contain drawing effects. Masks remain separate. */
export async function decodeSavedComposite(
  t: MaterialTables,
  layer: ClipLayer,
  row: ClipRow,
  diagnostics: ClipDiagnostic[],
  options: MaterialDecoderOptions = {},
): Promise<number> {
  checkCancelled(options.signal)
  const imageLimits = resolveImageLimits(
    options.imageLimits ??
      (options.maxDecodedBytes === undefined ? undefined : { maxBytes: options.maxDecodedBytes }),
    { maxBytes: 384 * 1024 * 1024, maxPixels: 64 * 1024 * 1024 },
  )
  const limit = resourceLimit(options.maxDecodedBytes ?? imageLimits.maxBytes)
  let retained = 0
  const decode = async (field: string, mask: boolean) => {
    const off = materialOffscreen(t, row, field)
    check(off?.Attribute instanceof Uint8Array, mask ? 'MISSING_MASK' : 'MISSING_SAVED_PREVIEW')
    const attr = readAttribute(off.Attribute),
      body = t.external.get(str(off.BlockData)),
      x =
        num(row, 'LayerOffsetX') +
        num(row, mask ? 'LayerMaskOffscrOffsetX' : 'LayerRenderOffscrOffsetX') +
        (mask ? num(row, 'LayerMaskOffsetX') : 0),
      y =
        num(row, 'LayerOffsetY') +
        num(row, mask ? 'LayerMaskOffscrOffsetY' : 'LayerRenderOffscrOffsetY') +
        (mask ? num(row, 'LayerMaskOffsetY') : 0),
      requested = mask ? (options.maskRegion ?? options.region) : options.region,
      region =
        requested &&
        intersectRegion(localRegion(requested, x, y), {
          left: 0,
          top: 0,
          width: attr.width,
          height: attr.height,
        })
    check(body || attr.hasColor, mask ? 'MISSING_MASK' : 'MISSING_SAVED_PREVIEW')
    const pixels =
      requested && !region
        ? emptyRegion(mask, attr.color & 255)
        : await decodeRasterPixels(
            attr,
            body,
            mask,
            options.budget !== 'extent',
            {
              ...(options.signal ? { signal: options.signal } : {}),
              ...(options.inflate ? { inflate: options.inflate } : {}),
              ...(region ? { region } : {}),
            },
            {
              maxBytes: limit - retained,
              maxPixels: imageLimits.maxPixels,
            },
          )
    check(pixels, mask ? 'MISSING_MASK' : 'MISSING_SAVED_PREVIEW')
    retained += pixels.rgba.byteLength
    check(retained <= limit, 'LIMIT_MATERIAL_BYTES')
    pixels.left +=
      num(row, 'LayerOffsetX') +
      num(row, mask ? 'LayerMaskOffscrOffsetX' : 'LayerRenderOffscrOffsetX')
    pixels.top +=
      num(row, 'LayerOffsetY') +
      num(row, mask ? 'LayerMaskOffscrOffsetY' : 'LayerRenderOffscrOffsetY')
    if (mask) {
      pixels.left += num(row, 'LayerMaskOffsetX')
      pixels.top += num(row, 'LayerMaskOffsetY')
      pixels.disabled = !(num(row, 'LayerVisibility') & 2)
    }
    return pixels
  }
  layer.savedComposite = true
  layer.materialSource = 'render'
  delete layer.effects
  for (const mask of [false, true]) {
    if (mask && !hasLayerMask(row)) continue
    try {
      const pixels = await decode(mask ? 'LayerLayerMaskMipmap' : 'LayerRenderMipmap', mask)
      if (mask) layer.mask = pixels
      else layer.pixels = pixels
    } catch (error) {
      rethrowFatal(error)
      diagnostics.push({
        ...diagnostic(errorCode(error)),
        layerId: layer.id,
        part: mask ? 'mask' : 'material',
        outcome: mask ? 'missing-effect' : 'missing-content',
      })
    }
  }
  checkCancelled(options.signal)
  return retained
}
/** Metadata only: lifetime is bounded by the owning document, with no decoded bitmap cache. */
export function createMaterialIndex(t: MaterialTables, maxBytes = 16 * 1024 * 1024) {
  const referenced = new Set([...t.mipInfos.values()].map((r) => num(r, 'Offscreen')))
  for (const row of t.thumbnails) referenced.add(num(row, 'ThumbnailOffscreen'))
  const objects = new Map<number, ClipRow[]>()
  for (const off of t.offscreens.values())
    if (!referenced.has(num(off, 'MainId')) && t.external.has(str(off.BlockData))) {
      const id = num(off, 'LayerId'),
        list = objects.get(id) ?? []
      list.push(off)
      objects.set(id, list)
    }
  const preparations = new ByteCache(maxBytes)
  return { objects, rasters: new RasterIndexCache(preparations), preparations }
}
export function createMaterialDecoder(
  t: MaterialTables,
  width: number,
  height: number,
  dpi: number,
  diagnostics: ClipDiagnostic[],
  compatibility?: 'saved' | 'not-saved' | 'unknown',
  options: MaterialDecoderOptions = {},
  index: {
    objects: Map<number, ClipRow[]>
    rasters?: RasterIndexCache
    preparations?: ByteCache
  } = createMaterialIndex(t),
) {
  checkCancelled(options.signal)
  if (options.region) checkRegion(options.region)
  if (options.maskRegion) checkRegion(options.maskRegion)
  validateCanvasPixels(width, height)
  const imageLimits = resolveImageLimits(
    options.imageLimits ??
      (options.maxDecodedBytes === undefined ? undefined : { maxBytes: options.maxDecodedBytes }),
    {
      maxBytes: (options.budget === 'extent' ? 512 : 384) * 1024 * 1024,
      maxPixels: 64 * 1024 * 1024,
    },
  )
  const maxDecodedBytes = resourceLimit(options.maxDecodedBytes ?? imageLimits.maxBytes)
  const scale = options.rasterScale ?? 1
  check(
    scale >= 1 / 256 && scale <= 1 && Number.isInteger(Math.log2(scale)),
    'INVALID_FRAME_RENDER_OPTIONS',
  )
  const previewOffscreen = (row: ClipRow, field: string) => {
    let off = materialOffscreen(t, row, field),
      sampleScale = 1
    if (off && scale < 1) {
      const mip = t.mipmaps.get(num(row, field)),
        visited = new Set<number>()
      let next = mip && num(mip, 'BaseMipmapInfo')
      while (next) {
        check(!visited.has(next) && visited.size < 32, 'INVALID_MIPMAP_CYCLE')
        visited.add(next)
        const info = t.mipInfos.get(next)
        check(info, 'MISSING_MIPMAP')
        const candidateScale = num(info, 'ThisScale') / 100,
          candidate = t.offscreens.get(num(info, 'Offscreen'))
        if (candidate && candidateScale >= scale && candidateScale < sampleScale) {
          off = candidate
          sampleScale = candidateScale
        }
        next = num(info, 'NextIndex')
      }
    }
    return { off, sampleScale }
  }
  let decodedBytes = 0
  const vectorBrushes: VectorBrushes = {
    styles: t.brushes ?? new Map(),
    graphs: t.brushGraphs ?? new Map(),
    patterns: new Map(),
    textures: new Map(),
  }
  type PreparedBrushImage = BrushPattern & { requiresColor: boolean }
  const patternDiagnostics = new Map<
    number,
    Array<{ code: DiagnosticCode; data: ClipDiagnostic['data'] }>
  >()
  const brushImages = new Map<number, PreparedBrushImage | undefined>()
  async function loadBrushImage(id: number): Promise<PreparedBrushImage | undefined> {
    if (!id) return
    if (brushImages.has(id)) return brushImages.get(id)
    brushImages.set(id, undefined)
    const image = t.brushImages?.get(id)
    const cached = image && index.preparations?.get<PreparedBrushImage>(image)
    if (cached) {
      check(decodedBytes + cached.width * cached.height * 4 <= maxDecodedBytes, 'LIMIT_BRUSH_BYTES')
      check(
        cached.width * cached.height <=
          (options.imageLimits ? imageLimits.maxPixels : 4 * 1024 * 1024),
        'LIMIT_BRUSH_BYTES',
      )
      decodedBytes += cached.alpha.byteLength
      brushImages.set(id, cached)
      return cached
    }
    const off = image && materialOffscreen(t, image, 'Mipmap')
    if (!(off?.Attribute instanceof Uint8Array)) return
    const a = readAttribute(off.Attribute)
    check(
      a.width * a.height <= (options.imageLimits ? imageLimits.maxPixels : 4 * 1024 * 1024) &&
        decodedBytes + a.width * a.height * 4 <= maxDecodedBytes,
      'LIMIT_BRUSH_BYTES',
    )
    const pixels = await readRaster(a, t.external.get(str(off.BlockData)), false, false, {
      ...rasterOptions,
      imageLimits,
    })
    if (!pixels) return
    const alpha = new Uint8Array(a.width * a.height)
    let requiresColor = a.channels === 4
    for (let i = 0; i < alpha.length; i++) {
      const opacity = clampedAt(pixels.rgba, i * 4 + 3)
      alpha[i] = opacity
      // Alpha-only tips have no color plane. In two-plane gray tips, visible
      // nonblack values need the secondary drawing color, which replay omits.
      if (a.channels !== 0 && opacity && clampedAt(pixels.rgba, i * 4)) requiresColor = true
    }
    decodedBytes += alpha.length
    const bitmap = { width: a.width, height: a.height, alpha, requiresColor }
    brushImages.set(id, bitmap)
    // Texture minification can retain one float plane in addition to alpha.
    if (image) index.preparations?.set(image, bitmap, alpha.byteLength * 5 + 128)
    return bitmap
  }
  async function loadPattern(id: number) {
    if (!id || patternDiagnostics.has(id)) return
    const pattern = t.brushPatterns?.get(id)
    const issues: Array<{ code: DiagnosticCode; data: ClipDiagnostic['data'] }> = []
    if (!pattern) {
      patternDiagnostics.set(id, issues)
      return
    }
    const inspected = inspectBrushPattern(pattern)
    for (const reason of inspected.unresolved) {
      const code: DiagnosticCode =
        reason === 'image-sequence'
          ? 'UNSUPPORTED_BRUSH_SEQUENCE'
          : reason === 'reverse-mode'
            ? 'UNSUPPORTED_BRUSH_REVERSE'
            : 'INVALID_BRUSH_PATTERN'
      issues.push({
        code,
        data: {
          patternId: id,
          reason,
          imageCount: inspected.images.length,
          declaredImages: inspected.declaredImages,
        },
      })
    }
    let missingReferences = 0,
      firstMissingImage = 0
    for (const imageId of inspected.images)
      if (!t.brushImages?.has(imageId)) {
        if (!missingReferences) firstMissingImage = imageId
        missingReferences++
      }
    if (missingReferences)
      issues.push({
        code: 'MISSING_BRUSH_TIP',
        data: { patternId: id, imageId: firstMissingImage, missingReferences },
      })
    const imageId = inspected.images[0]
    const image = imageId === undefined ? undefined : await loadBrushImage(imageId)
    if (imageId !== undefined && image?.requiresColor)
      issues.push({ code: 'UNSUPPORTED_BRUSH_COLOR', data: { patternId: id, imageId } })
    // Several pattern styles can share one bitmap but use different reverse modes.
    if (image) vectorBrushes.patterns.set(id, { ...image, reverse: num(pattern, 'Reverse2') })
    patternDiagnostics.set(id, issues)
  }
  const { objects } = index,
    rasters = index.rasters ?? new RasterIndexCache(),
    rasterOptions = {
      ...(options.signal ? { signal: options.signal } : {}),
      ...(options.inflate ? { inflate: options.inflate } : {}),
    }
  const hasContent = async (off: ClipRow | undefined): Promise<boolean> => {
    if (!(off?.Attribute instanceof Uint8Array)) return false
    const entry = rasters.get(off.Attribute, t.external.get(str(off.BlockData)), options.signal)
    if (entry.content !== undefined) return entry.content
    const a = entry.attribute
    for (let y = 0; y < a.height; y += 256)
      for (let x = 0; x < a.width; x += 256) {
        const region = {
            left: x,
            top: y,
            width: Math.min(256, a.width - x),
            height: Math.min(256, a.height - y),
          },
          tiles = regionTiles(entry, region)
        // Missing native blocks are implicit background, not 256px allocations.
        // A large empty image cache must not materialize its entire canvas just
        // to choose between saved pixels and the original image material.
        if (!tiles.length) {
          if (a.hasColor && a.color & 255) return (entry.content = true)
          continue
        }
        const tile = await decodeRasterPixels(
          a,
          entry.body,
          false,
          false,
          { ...rasterOptions, region },
          { maxBytes: 256 * 256 * 4 },
          tiles,
        )
        if (tile?.rgba.some((v, i) => i % 4 === 3 && v > 0)) return (entry.content = true)
      }
    return (entry.content = false)
  }
  async function pixels(
    off: ClipRow | undefined,
    mask = false,
    keepExtent = false,
    offsetX = 0,
    offsetY = 0,
    requested = options.region,
    sampleScale = 1,
    alphaColor?: 0 | 255,
  ): Promise<ClipPixels | undefined> {
    if (!(off?.Attribute instanceof Uint8Array)) return
    const body = t.external.get(str(off.BlockData)),
      entry = requested ? rasters.get(off.Attribute, body, options.signal) : undefined,
      a = entry?.attribute ?? readAttribute(off.Attribute),
      region =
        requested &&
        intersectRegion(
          localRegion(
            {
              left: requested.left * sampleScale,
              top: requested.top * sampleScale,
              width: requested.width * sampleScale,
              height: requested.height * sampleScale,
            },
            offsetX * sampleScale,
            offsetY * sampleScale,
          ),
          {
            left: 0,
            top: 0,
            width: a.width,
            height: a.height,
          },
        )
    if (!body && !a.hasColor) return
    if (requested && !region) {
      check(decodedBytes + 4 <= maxDecodedBytes, 'LIMIT_MATERIAL_BYTES')
      decodedBytes += 4
      return emptyRegion(mask, a.color & 255)
    }
    if (options.budget === 'extent' && !region)
      check(decodedBytes + a.width * a.height * 4 <= maxDecodedBytes, 'LIMIT_MATERIAL_BYTES')
    const decoded = await decodeRasterPixels(
      a,
      body,
      mask,
      !keepExtent,
      {
        ...rasterOptions,
        ...(region ? { region } : {}),
        ...(alphaColor !== undefined ? { alphaColor } : {}),
      },
      {
        maxBytes: maxDecodedBytes - decodedBytes,
        maxPixels: imageLimits.maxPixels,
      },
      entry && region ? regionTiles(entry, region) : undefined,
    )
    if (!decoded) return
    decodedBytes += decoded.rgba.length
    if (decodedBytes > maxDecodedBytes) throw new ClipError('LIMIT_MATERIAL_BYTES')
    return decoded
  }
  return async (layer: ClipLayer, row: ClipRow) => {
    checkCancelled(options.signal)
    check(
      scale === 1 || (['raster', 'paper', 'folder'].includes(layer.kind ?? '') && !layer.effects),
      'UNSUPPORTED_FRAME_MATERIAL',
      { reason: 'preview-scale' },
    )
    if (
      options.source === 'saved' &&
      ((layer.isFolder && options.folderComposite !== false) || layer.kind === 'video')
    ) {
      decodedBytes += await decodeSavedComposite(t, layer, row, diagnostics, {
        ...options,
        maxDecodedBytes: maxDecodedBytes - decodedBytes,
      })
      if (scale !== 1)
        for (const part of ['pixels', 'mask'] as const) {
          const pixels = layer[part]
          if (!pixels) continue
          layer[part] = previewPixels(
            pixels,
            1,
            scale,
            part === 'mask',
            maxDecodedBytes - decodedBytes,
            options.signal,
          )
          decodedBytes += layer[part].rgba.byteLength
        }
      return
    }
    if (isMediaKind(layer.kind)) return
    const failures: string[] = []
    const useOriginal =
      options.source !== 'saved' &&
      (!!num(row, 'TimeLineLayerKeyFrameEnabled') ||
        num(row, 'TimeLineOriginalMipmap') > 0 ||
        num(row, 'TimeLineOriginalMaskMipmap') > 0)
    const report = (
      code: DiagnosticCode,
      part: ClipDiagnostic['part'] = 'material',
      outcome: ClipDiagnostic['outcome'] = code === 'MISSING_VECTOR_STROKE' ||
      code === 'MISSING_VECTOR_REMAINDER'
        ? 'missing-content'
        : 'approximate',
      data?: ClipDiagnostic['data'],
    ) =>
      diagnostics.push({
        ...diagnostic(code, data),
        part,
        outcome,
        layerId: layer.id,
        ...(part === 'material' && layer.kind === 'vector' ? { materialKind: 'vector' } : {}),
      })
    const failed = (error: unknown) => {
      rethrowFatal(error)
      failures.push(errorCode(error))
    }
    try {
      const effects = readMaterialEffects(row, (message) =>
        report(message, 'effect', 'missing-effect'),
      )
      if (effects) layer.effects = effects
      else delete layer.effects
    } catch (e) {
      report(errorCode(e), 'effect', 'missing-effect')
    }
    check(scale === 1 || !layer.effects, 'UNSUPPORTED_FRAME_MATERIAL', { reason: 'preview-scale' })
    if (row.FilterLayerInfo instanceof Uint8Array) {
      try {
        layer.adjustment = readAdjustment(row.FilterLayerInfo)
        layer.materialSource = 'adjustment'
      } catch (e) {
        report(
          errorCode(e),
          'material',
          'missing-content',
          e instanceof ClipError ? e.diagnostic.data : undefined,
        )
      }
    } else if (!layer.isFolder && isPaper(row) && num(row, 'DrawColorEnable')) {
      // Paper's Offscreen InitColor can be black even when its actual fill is white.
      const nativeBounds = options.region
          ? intersectRegion(options.region, { left: 0, top: 0, width, height })
          : { left: 0, top: 0, width, height },
        bounds = nativeBounds && {
          left: Math.floor(nativeBounds.left * scale),
          top: Math.floor(nativeBounds.top * scale),
          width:
            Math.ceil((nativeBounds.left + nativeBounds.width) * scale) -
            Math.floor(nativeBounds.left * scale),
          height:
            Math.ceil((nativeBounds.top + nativeBounds.height) * scale) -
            Math.floor(nativeBounds.top * scale),
        },
        w = bounds?.width ?? 1,
        h = bounds?.height ?? 1
      if (decodedBytes + w * h * 4 > maxDecodedBytes) throw new ClipError('LIMIT_MATERIAL_BYTES')
      const rgba = rgbaBuffer(
        checkImageAllocation(w, h, {
          ...imageLimits,
          maxBytes: maxDecodedBytes - decodedBytes,
        }),
      )
      const color = [
        ...['Red', 'Green', 'Blue'].map((c) => num(row, `DrawColorMain${c}`) >>> 24),
        255,
      ]
      decodedBytes += rgba.length
      if (bounds)
        new Uint32Array(rgba.buffer, rgba.byteOffset, rgba.length / 4).fill(
          new Uint32Array(new Uint8ClampedArray(color).buffer)[0]!,
        )
      layer.pixels = { width: w, height: h, left: bounds?.left ?? 0, top: bounds?.top ?? 0, rgba }
      layer.materialSource = 'fill'
    } else if (!layer.isFolder) {
      // Original animation material takes precedence over a render of the current shooting frame.
      const candidates = [
        ['TimeLineOriginalMipmap', 'timeline-original'],
        ['LayerRenderMipmap', 'render'],
        ['ResizableOriginalMipmap', 'image-original'],
      ] as const
      const ordered =
        options.source === 'saved' ? [candidates[1], candidates[0], candidates[2]] : candidates
      for (const [field, source] of ordered) {
        // A missing original must never silently introduce a shooting transform.
        if (source === 'render' && useOriginal && options.source !== 'prefer-original') continue
        try {
          const { off, sampleScale } = previewOffscreen(row, field),
            offset =
              source === 'render'
                ? 'LayerRenderOffscrOffset'
                : source === 'timeline-original'
                  ? 'TimeLineRenderOriginalOffset'
                  : '',
            x = num(row, 'LayerOffsetX') + (offset ? num(row, offset + 'X') : 0),
            y = num(row, 'LayerOffsetY') + (offset ? num(row, offset + 'Y') : 0)
          let requested = options.region,
            placement: MaterialQuad | undefined,
            placementSource: ImageRegion | undefined
          if (source === 'image-original' && row.ResizableImageInfo instanceof Uint8Array) {
            try {
              placement = readMaterialQuad(row.ResizableImageInfo).map(
                (v, i) => v + num(row, i % 2 ? 'LayerOffsetY' : 'LayerOffsetX'),
              ) as MaterialQuad
            } catch {
              report('APPROXIMATE_PLACEMENT', 'placement')
            }
            if (placement && requested && off?.Attribute instanceof Uint8Array) {
              const a = readAttribute(off.Attribute)
              placementSource = { left: x, top: y, width: a.width, height: a.height }
              const local = quadSourceRegion(
                placement,
                a.width,
                a.height,
                transformRegion(requested),
              )
              requested = { ...local, left: local.left + x, top: local.top + y }
            }
          }
          const decoded = await pixels(
            off,
            false,
            source === 'image-original',
            x,
            y,
            requested,
            sampleScale,
            // A black-only gray cache stores coverage without a color plane.
            // Restore its ink before effects; raw rasters, masks and brush tips
            // retain their context-free interpretation.
            row.LayerColorTypeIndex === 1 &&
              row.LayerColorTypeBlackChecked === 1 &&
              row.LayerColorTypeWhiteChecked === 0
              ? 0
              : undefined,
          )
          if (!decoded) continue
          if (
            source === 'render' &&
            layer.kind === 'image-material' &&
            !(options.region
              ? await hasContent(off)
              : decoded.rgba.some((value, i) => i % 4 === 3 && value > 0))
          )
            continue
          decoded.left = decoded.left / sampleScale + x
          decoded.top = decoded.top / sampleScale + y
          if (placementSource) layer.placementSource = placementSource
          if (placement) layer.placement = placement
          layer.pixels =
            scale === 1
              ? decoded
              : previewPixels(
                  decoded,
                  sampleScale,
                  scale,
                  false,
                  maxDecodedBytes - decodedBytes,
                  options.signal,
                )
          if (scale !== 1) decodedBytes += layer.pixels.rgba.byteLength
          layer.materialSource = source
          break
        } catch (e) {
          failed(e)
        }
      }
      if (!layer.pixels && layer.kind === 'vector') {
        layer.vectorRendering = 'unavailable'
        try {
          const vector =
            t.vectors?.get(num(row, 'VectorNormalStrokeIndex')) ??
            [...(t.vectors?.values() ?? [])].find((v) => num(v, 'LayerId') === num(row, 'MainId'))
          const raw = vector && t.external.get(str(vector.VectorData))
          if (!raw)
            check(
              !vector &&
                t.vectors &&
                hasUnallocatedVectorIndices(row) &&
                failures.length === 0 &&
                hasOnlyEmptyVectorCaches(t, row),
              'MISSING_VECTOR_DATA',
            )
          if (!raw?.byteLength) {
            check(decodedBytes + 4 <= maxDecodedBytes, 'LIMIT_MATERIAL_BYTES')
            layer.pixels = { width: 1, height: 1, left: 0, top: 0, rgba: new Uint8ClampedArray(4) }
            delete layer.vectorRendering
          } else {
            // VectorSurface bounds actual allocated tiles, not a hypothetical
            // full-document float surface.
            if (options.vectorReservation)
              check(
                decodedBytes + width * height * 20 + 64 * 1024 * 1024 <= maxDecodedBytes,
                'LIMIT_MATERIAL_BYTES',
              )
            let strokes = index.preparations?.get<VectorStroke[]>(raw)
            if (!strokes) {
              strokes = readVectorStrokes(raw, options.signal)
              index.preparations?.set(
                raw,
                strokes,
                strokes.reduce((n, s) => n + 128 + s.points.length * 256, 0),
              )
            }
            const patterns = new Set(
              strokes.map((s) => activeBrushPattern(vectorBrushes.styles.get(s.brush) ?? {})),
            )
            for (const id of patterns) {
              try {
                await loadPattern(id)
                // Replay the issues for each layer, including cached patterns.
                for (const issue of patternDiagnostics.get(id) ?? [])
                  report(issue.code, 'material', 'approximate', issue.data)
              } catch (e) {
                rethrowFatal(e)
                report(errorCode(e))
              }
            }
            // Unlike PatternStyle, TexturePattern directly references BrushPatternImage.
            const textures = new Set(
              strokes.map((s) => {
                const style = vectorBrushes.styles.get(s.brush) ?? {}
                return num(style, 'TextureFlag') & 1 ? num(style, 'TexturePattern') : 0
              }),
            )
            for (const id of textures) {
              try {
                const image = await loadBrushImage(id)
                if (image) vectorBrushes.textures!.set(id, image)
              } catch (e) {
                rethrowFatal(e)
                report(errorCode(e))
              }
            }
            layer.pixels = renderVectorProgram([
              strokes,
              vectorBrushes,
              width,
              height,
              num(row, 'LayerOffsetX'),
              num(row, 'LayerOffsetY'),
              report,
              {
                ...options,
                imageLimits: { ...imageLimits, maxBytes: maxDecodedBytes - decodedBytes },
                ...(options.maxVectorWork === undefined ? {} : { maxWork: options.maxVectorWork }),
                maxPixels: options.imageLimits ? imageLimits.maxPixels : 16 * 1024 * 1024,
                maxSurfaceBytes: options.imageLimits
                  ? maxDecodedBytes - decodedBytes
                  : 256 * 1024 * 1024,
              },
              index.preparations,
            ])
            layer.vectorRendering = 'approximate'
          }
          decodedBytes += layer.pixels.rgba.length
          check(decodedBytes <= maxDecodedBytes, 'LIMIT_MATERIAL_BYTES')
          layer.materialSource = 'vector'
        } catch (e) {
          failed(e)
        }
      }
      if (!layer.pixels && (row.TextLayerString != null || row.TextLayerStringArray != null)) {
        try {
          const texts = readTextObjects(row, dpi, report),
            caches = objects.get(num(row, 'MainId')) ?? []
          const fragments: ClipPixels[] = [],
            unresolved = []
          const same = (a: Uint8Array, b: Uint8Array) =>
            a.length === b.length && a.every((v, i) => v === b[i])
          for (const text of texts) {
            const matching = caches.filter((off) => {
              if (!(off.Attribute instanceof Uint8Array)) return false
              if (text.cacheId) return !!text.cache && num(off, 'MainId') === text.cacheId
              try {
                const a = readAttribute(off.Attribute)
                return a.width === text.width && a.height >= text.height
              } catch {
                return false
              }
            })
            const off = matching[0]
            const unique =
              off &&
              matching.every(
                (other) =>
                  same(off.Attribute as Uint8Array, other.Attribute as Uint8Array) &&
                  same(t.external.get(str(off.BlockData))!, t.external.get(str(other.BlockData))!),
              )
            let image: ClipPixels | undefined
            try {
              image = unique
                ? await pixels(
                    off,
                    false,
                    false,
                    text.cache?.left ?? text.left,
                    text.cache?.top ?? text.top,
                  )
                : undefined
            } catch (error) {
              rethrowFatal(error) // Other cache failures fall back to text metadata.
            }
            if (image) {
              image.left += text.cache?.left ?? text.left
              image.top += text.cache?.top ?? text.top
              fragments.push(image)
            } else unresolved.push(text)
          }
          if (fragments.length === 1) layer.pixels = requiredAt(fragments, 0)
          else if (fragments.length) layer.fragments = fragments
          if (unresolved.length) layer.text = unresolved
          if (unresolved.length) layer.materialSource = 'text'
          else if (fragments.length) layer.materialSource = 'object-cache'
          else delete layer.materialSource
        } catch (e) {
          failed(e)
        }
      }
      if (
        !layer.pixels &&
        !layer.fragments?.length &&
        !layer.text?.length &&
        row.GradationFillInfo instanceof Uint8Array
      ) {
        try {
          if (!options.region && decodedBytes + width * height * 4 > maxDecodedBytes)
            throw new ClipError('LIMIT_MATERIAL_BYTES')
          layer.pixels = readGradient(
            row.GradationFillInfo,
            width,
            height,
            num(row, 'LayerOffsetX'),
            num(row, 'LayerOffsetY'),
            report,
            { ...imageLimits, maxBytes: maxDecodedBytes - decodedBytes },
            options.region,
          )
          decodedBytes += layer.pixels.rgba.length
          layer.materialSource = 'gradient'
        } catch (e) {
          failed(e)
        }
      }
      if (!layer.pixels && !layer.fragments?.length && !layer.text?.length) {
        if (layer.kind === '3d') {
          layer.unsupported3D = true
        }
        if (
          failures.length ||
          (layer.kind !== 'vector' &&
            layer.kind !== '3d' &&
            (useOriginal || !(num(row, 'LayerType') & 1)))
        ) {
          for (const failure of failures)
            report(failure as DiagnosticCode, 'material', 'missing-content')
          report('MISSING_MATERIAL', 'material', 'missing-content')
        }
      }
    }
    if (layer.pixels) applyGrayPreview(layer.pixels, row, options.signal)
    for (const fragment of layer.fragments ?? []) applyGrayPreview(fragment, row, options.signal)
    if (hasLayerMask(row)) {
      try {
        const original =
          num(row, 'TimeLineOriginalMaskMipmap') > 0 &&
          layer.materialSource !== 'render' &&
          (options.source !== 'saved' || layer.materialSource === 'timeline-original')
        check(
          original || !useOriginal || options.source === 'prefer-original',
          'MISSING_ORIGINAL_MASK',
        )
        const offset = original ? 'TimeLineMaskOriginalOffset' : 'LayerMaskOffscrOffset',
          mx = num(row, 'LayerOffsetX') + num(row, 'LayerMaskOffsetX') + num(row, offset + 'X'),
          my = num(row, 'LayerOffsetY') + num(row, 'LayerMaskOffsetY') + num(row, offset + 'Y')
        const { off, sampleScale } = previewOffscreen(
          row,
          original ? 'TimeLineOriginalMaskMipmap' : 'LayerLayerMaskMipmap',
        )
        const mask = await pixels(
          off,
          true,
          false,
          mx,
          my,
          options.maskRegion ?? options.region,
          sampleScale,
        )
        check(mask, 'MISSING_MASK')
        mask.left = mask.left / sampleScale + mx
        mask.top = mask.top / sampleScale + my
        mask.disabled = !(num(row, 'LayerVisibility') & 2)
        layer.mask =
          scale === 1
            ? mask
            : previewPixels(
                mask,
                sampleScale,
                scale,
                true,
                maxDecodedBytes - decodedBytes,
                options.signal,
              )
        if (scale !== 1) decodedBytes += layer.mask.rgba.byteLength
      } catch (e) {
        rethrowFatal(e)
        report(errorCode(e), 'mask', 'missing-effect')
      }
    }
    diagnostics.push(...layerRenderingDiagnostics(layer, compatibility))
  }
}
