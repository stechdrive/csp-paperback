import { num, type ClipRow } from './records.js'
import { decodeBrushDynamics } from './vector-dynamics.js'
import type { DiagnosticCode } from '../diagnostics.js'
import type { VectorPoint } from './vector.js'
import { check } from './binary.js'
import {
  brushInputOmission,
  activeBrushPattern,
  renderedBrushStyleFlags,
  textureApplication,
} from './vector-settings.js'

export interface BrushProgram {
  inputs: ReturnType<typeof compileBrushInputs>
  shape: 'round' | 'image'
  /** Absence is distinct from a native row containing zero flags. */
  savedFlags: number | undefined
  unknownFlags: number | undefined
  darken: boolean
  adjustDensityByGap: boolean
  minimumPixel: boolean
  thicknessAxis: 'horizontal' | 'vertical'
  interval: number
  automaticInterval: boolean
  textureApplication: 'disabled' | 'dab' | 'stroke'
}

/** Decode settings once; preset names and bitmap identity never select a rule. */
export function compileBrushProgram(style: ClipRow, graphs: Map<number, ClipRow>): BrushProgram {
  const flags = typeof style.StyleFlag === 'number' ? style.StyleFlag : undefined
  check(
    flags === undefined || (Number.isInteger(flags) && flags >= 0 && flags <= 0xffffffff),
    'INVALID_BRUSH_NUMBER',
  )
  const auto = num(style, 'AutoIntervalType', 2)
  check([0, 1, 2, 3].includes(auto), 'UNSUPPORTED_BRUSH_INTERVAL')
  return {
    inputs: compileBrushInputs(style, graphs),
    shape: activeBrushPattern(style) ? 'image' : 'round',
    savedFlags: flags,
    unknownFlags: flags === undefined ? undefined : (flags & ~renderedBrushStyleFlags) >>> 0,
    darken: !!((flags ?? 0) & 4096),
    adjustDensityByGap: !!((flags ?? 0) & 4),
    minimumPixel: !!((flags ?? 0) & 8),
    thicknessAxis: (flags ?? 0) & 64 ? 'vertical' : 'horizontal',
    automaticInterval: auto !== 0,
    interval:
      auto === 0
        ? Math.max(0, num(style, 'IntervalBase', 1))
        : auto === 1
          ? 0.12
          : auto === 2
            ? 0.08
            : 0.04,
    textureApplication: textureApplication(style),
  }
}

const clamp = (v: number) => Math.max(0, Math.min(1, v))

/** Compile input response curves independently of the tip bitmap or rasterizer. */
export function compileBrushInputs(style: ClipRow, graphs: Map<number, ClipRow>) {
  const size = decodeBrushDynamics(style.SizeEffector, graphs),
    flow = decodeBrushDynamics(style.FlowEffector, graphs),
    opacity = decodeBrushDynamics(style.OpacityEffector, graphs),
    thickness = decodeBrushDynamics(
      brushInputOmission(style, 'ThicknessEffector') ? undefined : style.ThicknessEffector,
      graphs,
    ),
    interval = decodeBrushDynamics(
      brushInputOmission(style, 'IntervalEffector') ? undefined : style.IntervalEffector,
      graphs,
    ),
    textureDensity = decodeBrushDynamics(
      brushInputOmission(style, 'TextureDensityEffector')
        ? undefined
        : style.TextureDensityEffector,
      graphs,
    )
  const diagnostics = new Set<DiagnosticCode>()
  for (const input of [size, flow, opacity, thickness, interval, textureDensity]) {
    if (input.inspection.missingGraphs.length) diagnostics.add('MISSING_BRUSH_GRAPH')
    if (input.inspection.unknownFlags || input.inspection.remainingBytes)
      diagnostics.add('UNSUPPORTED_BRUSH_INPUT')
  }
  return {
    diagnostics: [...diagnostics],
    randomFlowMinimum: flow.randomMinimum,
    approximateRandom:
      size.randomMinimum !== undefined ||
      opacity.randomMinimum !== undefined ||
      thickness.randomMinimum !== undefined ||
      interval.randomMinimum !== undefined ||
      textureDensity.randomMinimum !== undefined,
    evaluate(point: VectorPoint) {
      return {
        // Locked controls already contain their final size/density factor.
        size: point.size * (point.flags & 4096 ? 1 : size.value(point)),
        flow: point.flow * (point.flags & 8192 ? 1 : flow.value(point)) * num(style, 'FlowBase', 1),
        opacity: opacity.value(point),
        // Keep response factors dimensionless; minimum pixel footprints belong
        // to tip rasterization, after the final diameter is known.
        thickness: clamp(num(style, 'ThicknessBase', 1) * thickness.value(point)),
        interval: num(style, 'AutoIntervalType', 2) ? 1 : interval.value(point),
        textureDensity: textureDensity.value(point),
        randomFlow: point.flags & 8192 ? 0 : 1,
      }
    },
  }
}
