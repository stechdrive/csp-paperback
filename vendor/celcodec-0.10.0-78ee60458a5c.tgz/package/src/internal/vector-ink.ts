/** The opacity response is a ceiling; stroke opacity is applied after accumulation. */
export function accumulateInk(
  previous: number,
  alpha: number,
  opacity: number,
  mode: 'over' | 'maximum',
): number {
  return mode === 'over'
    ? previous + alpha * Math.max(0, opacity - previous)
    : Math.max(previous, alpha * opacity)
}
import type { BrushProgram } from './vector-brush.js'
import { brushSpacingDistance } from './vector-spacing.js'

export function inkMode(program: BrushProgram, legacyOver: boolean): 'over' | 'maximum' {
  return (program.savedFlags === undefined ? !legacyOver : program.darken) ? 'maximum' : 'over'
}

/** Clamp the spacing ratio before dividing by effective thickness. The result
 * may exceed one; clamp flow times this factor before applying raster coverage. */
export function gapDensity(
  program: BrushProgram,
  diameter: number,
  intervalResponse = 1,
  thickness = 1,
  antialias = true,
): number {
  if (!program.adjustDensityByGap || program.darken || diameter <= 0) return 1
  const image = program.shape === 'image'
  // Non-AA image rasterization failed the independent thin-tip evaluation.
  // Preserve that measured profile until coverage and ink can be separated.
  if (image && !antialias)
    return Math.min(1, (3 * Math.max(1, diameter * program.interval)) / diameter)
  // A zero-width non-AA tip has no coverage; keep the ink factor finite.
  if (image && thickness <= 0) return 1
  const gap = brushSpacingDistance(
    {
      mode: image ? (program.automaticInterval ? 'image-auto' : 'image-manual') : 'round',
      interval: program.interval,
    },
    diameter,
    image ? thickness : 1,
    intervalResponse,
  )
  return Math.min(1, (3 * gap) / diameter) / (image ? thickness : 1)
}
