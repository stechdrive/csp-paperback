import { readAttribute, type OffscreenAttribute } from './raster.js'
import { readRasterTiles, type RasterTile } from '../format/raster-tiles.js'
import type { ImageRegion } from '../image-resources.js'
import { ByteCache } from './byte-cache.js'

interface Entry {
  body: Uint8Array | undefined
  attribute: OffscreenAttribute
  tiles: Map<number, RasterTile>
  bytes: number
  content?: boolean
}
/** Bounded metadata cache, never decoded pixels. Views borrow the session input. */
export class RasterIndexCache {
  constructor(private entries = new ByteCache(16 * 1024 ** 2)) {}
  get(attribute: Uint8Array, body: Uint8Array | undefined, signal?: AbortSignal): Entry {
    let entry = this.entries.get<Entry>(attribute)
    if (entry && entry.body === body) {
      return entry
    }
    const a = readAttribute(attribute),
      tiles = new Map<number, RasterTile>()
    for (const t of readRasterTiles(a, body, signal)) tiles.set((t.y / 256) * a.cols + t.x / 256, t)
    entry = { body, attribute: a, tiles, bytes: 256 + tiles.size * 96 + a.sizes.length * 8 }
    this.entries.set(attribute, entry, entry.bytes)
    return entry
  }
  clear(): void {
    this.entries.clear()
  }
}
export function regionTiles(entry: Entry, r: ImageRegion): RasterTile[] {
  const result: RasterTile[] = []
  for (let y = Math.floor(r.top / 256); y < Math.ceil((r.top + r.height) / 256); y++)
    for (let x = Math.floor(r.left / 256); x < Math.ceil((r.left + r.width) / 256); x++) {
      const tile = entry.tiles.get(y * entry.attribute.cols + x)
      if (tile) result.push(tile)
    }
  return result
}
