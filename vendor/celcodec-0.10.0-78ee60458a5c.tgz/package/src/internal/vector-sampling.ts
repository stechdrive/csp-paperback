/** Explicit coverage grids. Image tips sample at the stored path coordinates;
 * the remaining fallback phases are approximations, not geometry corrections. */
export function vectorSamplingGrid(nativeRound: boolean, image: boolean, aa: number) {
  const imageAA = image && [1, 2, 3].includes(aa)
  const scale = nativeRound ? 1 : imageAA ? 2 : aa ? 4 : 1
  return {
    scale,
    samplePhase: imageAA ? 0 : 0.5,
    pathPhaseX: nativeRound || image ? 0 : scale > 1 ? 0.001 : -0.499,
    pathPhaseY: nativeRound || image ? 0 : scale > 1 ? 0.001 : 0.501,
  }
}

/** Explicit inverse paper transform; layer offset is removed by the caller. */
export function paperCoordinates(
  x: number,
  y: number,
  offsetX: number,
  offsetY: number,
  cos: number,
  sin: number,
  scale: number,
  width: number,
  height: number,
  pixelAligned: boolean,
): [number, number] {
  const dx = (pixelAligned ? Math.floor(x) : x) - offsetX,
    dy = (pixelAligned ? Math.floor(y) : y) - offsetY
  const wrap = (v: number, size: number) => ((v % size) + size) % size
  const periodX = width * scale,
    periodY = height * scale
  return [
    pixelAligned
      ? (wrap(dx * cos + dy * sin, periodX) * width) / periodX
      : (dx * cos + dy * sin) / scale - 0.5,
    pixelAligned
      ? (wrap(-dx * sin + dy * cos, periodY) * height) / periodY
      : (-dx * sin + dy * cos) / scale - 0.5,
  ]
}
