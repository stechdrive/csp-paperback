/** Read a required element in a validated dense array or pixel buffer.
 * Unlike a non-null assertion, this also rejects a broken indexing invariant at runtime.
 * Optional lookups must use normal indexing and handle the missing value explicitly.
 */
export function requiredAt<T>(values: ArrayLike<T>, index: number): T {
  const value = values[index]
  if (value === undefined) {
    throw new RangeError(`Missing element at ${index} in a buffer of length ${values.length}`)
  }
  return value
}

// Keep hot numeric reads separate: one generic array-like accessor becomes megamorphic
// when object arrays, buffers and several typed-array layouts share its inline cache.
function missing(index: number, length: number): never {
  throw new RangeError(`Missing element at ${index} in a buffer of length ${length}`)
}
export function u8At(values: Uint8Array, index: number): number {
  return values[index] ?? missing(index, values.length)
}
export function clampedAt(values: Uint8ClampedArray, index: number): number {
  return values[index] ?? missing(index, values.length)
}
export function floatAt(values: Float32Array | Uint8Array, index: number): number {
  return values[index] ?? missing(index, values.length)
}
export function intAt(values: Int32Array, index: number): number {
  return values[index] ?? missing(index, values.length)
}
export function numberAt(values: readonly number[], index: number): number {
  return values[index] ?? missing(index, values.length)
}

/** Runtime validation without Array.isArray's narrowing of typed readonly arrays to any[]. */
export function isArrayValue(value: unknown): boolean {
  return Array.isArray(value)
}
