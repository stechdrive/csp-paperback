import { requiredAt } from './indexed.js'
// Shared from vector-dynamics.ts (csp-paperback extraction, MIT,
// Copyright (c) 2025 stechdrive); quadratic model measured against native captures.
const clamp = (v: number) => Math.max(0, Math.min(1, v))
/** Validated monotone-x controls; used by native pen and tone-curve decoders. */
export function compileCurve(
  points: readonly (readonly [number, number])[],
): (v: number) => number {
  const count = points.length
  // CSP 5.1.5 captures use quadratic Bezier segments through the midpoints
  // between interior controls, not a polyline through those controls.
  // Decode the segments once; invert their monotone x coordinate per sample.
  // See docs/vector-brushes.md and docs/adjustments.md for independent captures.
  const first = requiredAt(points, 0),
    last = requiredAt(points, count - 1)
  if (count === 1) return () => first[1]
  if (count === 2)
    return (x) =>
      x <= first[0]
        ? first[1]
        : x >= last[0]
          ? last[1]
          : first[1] + ((last[1] - first[1]) * (x - first[0])) / (last[0] - first[0])
  const segments: Array<{
    start: readonly [number, number]
    control: readonly [number, number]
    end: readonly [number, number]
  }> = []
  let start = first
  for (let i = 1; i < count - 1; i++) {
    const control = requiredAt(points, i),
      next = requiredAt(points, i + 1),
      end: readonly [number, number] =
        i === count - 2 ? next : [(control[0] + next[0]) / 2, (control[1] + next[1]) / 2]
    segments.push({ start, control, end })
    start = end
  }
  return (x) => {
    if (x <= first[0]) return first[1]
    if (x >= last[0]) return last[1]
    let lo = 0,
      hi = segments.length - 1
    while (lo < hi) {
      const mid = (lo + hi) >>> 1
      if (x > requiredAt(segments, mid).end[0]) lo = mid + 1
      else hi = mid
    }
    const { start: a, control: b, end: c } = requiredAt(segments, lo),
      dx = x - a[0],
      d0 = b[0] - a[0],
      d1 = c[0] - b[0]
    // Rationalized quadratic root avoids cancellation when the x spacing is
    // almost linear. Coincident controls are finite and require no iteration.
    const denominator = d0 + Math.sqrt(Math.max(0, d0 * d0 + (d1 - d0) * dx)),
      t = denominator > 0 ? clamp(dx / denominator) : 0,
      u = 1 - t
    return clamp(u * u * a[1] + 2 * u * t * b[1] + t * t * c[1])
  }
}
