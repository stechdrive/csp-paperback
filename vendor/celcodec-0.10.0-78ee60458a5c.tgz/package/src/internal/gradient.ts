import { requiredAt, numberAt } from './indexed.js'
// Extracted from csp-paperback (MIT). See docs/provenance.json.
import { type DiagnosticCode } from '../diagnostics.js'
// GradationFillInfo layout: dobrokot/clip_to_psd (MIT).
import { check, Reader } from './binary.js'
import type { ClipPixels } from './types.js'
import { intersectRegion, emptyRegion, checkRegion } from './image-region.js'
import type { ImageRegion } from '../image-resources.js'
import {
  resolveImageLimits,
  checkImageAllocation,
  rgbaBuffer,
  type ImageResourceLimits,
} from '../image-resources.js'

type Stop = { position: number; rgba: number[] }

/** Identify a fill without allocating or decoding a canvas-sized image. */
export function readGradientKind(bytes: Uint8Array): 'fill' | 'gradient' | undefined {
  try {
    const r = new Reader(bytes)
    r.take(8)
    let geometry = false,
      colors = false,
      flat = false
    while (r.position < bytes.length) {
      const name = r.wideName()
      if (name === 'GradationSetting') {
        r.take(68)
        geometry = true
      } else {
        const part = new Reader(r.take(r.u32()))
        if (name === 'GradationData') colors = part.bytes.length >= 16
        if (name === 'GradationSettingAdd0001') {
          flat = !!part.u32()
          if (flat) part.take(12)
        }
      }
    }
    return flat ? 'fill' : geometry && colors ? 'gradient' : undefined
  } catch {
    // A malformed display hint must not prevent the rest of the document loading.
    // The rendering decoder reports any unusable material when it is requested.
    return undefined
  }
}

function gradientParts(bytes: Uint8Array) {
  const r = new Reader(bytes)
  r.take(8)
  let geometry:
      [number, number, number, number, number, number, number, number, number, number] | undefined,
    flat: [number, number, number] | undefined,
    colorData: Uint8Array | undefined
  while (r.position < bytes.length) {
    const name = r.wideName()
    if (name === 'GradationSetting') {
      geometry = [
        r.u32(),
        r.u32(),
        r.u32(),
        r.number('f64'),
        r.number('f64'),
        r.number('f64'),
        r.number('f64'),
        r.number('f64'),
        r.number('f64'),
        r.number('f64'),
      ]
    } else {
      const part = new Reader(r.take(r.u32()))
      if (name === 'GradationData') {
        colorData = part.bytes
      } else if (name === 'GradationSettingAdd0001' && part.u32()) {
        flat = [part.u32(), part.u32(), part.u32()]
      }
    }
  }
  return { geometry, flat, colorData }
}

/** Native unsigned RGB words for an active solid fill; no bitmap allocation or inactive stop decoding. */
export function readSolidFillColor(bytes: Uint8Array): [number, number, number] | undefined {
  return gradientParts(bytes).flat
}

/** Generate the known gradient forms when no saved layer image is available. */
export function readGradient(
  bytes: Uint8Array,
  width: number,
  height: number,
  offsetX: number,
  offsetY: number,
  report: (message: DiagnosticCode) => void,
  imageLimits?: ImageResourceLimits,
  region?: ImageRegion,
): ClipPixels {
  const { geometry, flat: words, colorData } = gradientParts(bytes),
    flat = words ? [...words.map((v) => v >>> 24), 255] : undefined
  let stops: Stop[] | undefined,
    approximate = false
  // Flat fills can retain an unused gradient in a different format. Only their
  // flat color contributes to the image; do not decode the inactive stop list.
  if (!flat && colorData) {
    const part = new Reader(colorData)
    part.take(8)
    const count = part.u32()
    part.u32()
    check(count > 0 && count <= 1024, 'LIMIT_GRADIENT_STOPS')
    stops = Array.from({ length: count }, () => {
      const rgba = Array.from({ length: 4 }, () => part.u32() >>> 24)
      const currentColor = part.u32(),
        position = part.u32() / 32768,
        curves = part.u32()
      check(curves <= 1024, 'LIMIT_GRADIENT_CURVES')
      part.take(curves * 16)
      approximate ||= curves > 0 || currentColor !== 0
      return { position, rgba }
    }).sort((a, b) => a.position - b.position)
  }
  check(flat || (stops?.length && geometry), 'MISSING_GRADIENT')
  if (region) checkRegion(region)
  const bounds = region
    ? intersectRegion(region, { left: 0, top: 0, width, height })
    : { left: 0, top: 0, width, height }
  if (!bounds) return emptyRegion()
  width = bounds.width
  height = bounds.height
  offsetX -= bounds.left
  offsetY -= bounds.top
  const rgba = rgbaBuffer(checkImageAllocation(width, height, resolveImageLimits(imageLimits)))
  if (flat) {
    for (let i = 0; i < rgba.length; i += 4) rgba.set(flat, i)
  } else {
    const [repeat, shape, , , secondDiameter, , sx, sy, ex, ey] = geometry!
    check(repeat <= 3 && shape <= 2, 'UNSUPPORTED_GRADIENT')
    const dx = ex - sx,
      dy = ey - sy,
      radius = Math.hypot(dx, dy)
    check(radius > 0 && (shape !== 2 || secondDiameter > 0), 'INVALID_GRADIENT_SIZE')
    const colors = stops!
    for (let y = 0; y < height; y++)
      for (let x = 0; x < width; x++) {
        const px = x + 0.5 - offsetX - sx,
          py = y + 0.5 - offsetY - sy
        const along = (px * dx + py * dy) / (radius * radius)
        const across = (py * dx - px * dy) / (radius * (shape === 2 ? secondDiameter / 2 : radius))
        let t = shape === 0 ? along : Math.hypot(along, across)
        if (repeat === 3 && (t < 0 || t > 1)) continue
        if (repeat === 1) t = ((t % 1) + 1) % 1
        else if (repeat === 2) {
          t = ((t % 2) + 2) % 2
          if (t > 1) t = 2 - t
        } else t = Math.max(0, Math.min(1, t))
        const last = colors.findIndex((s) => s.position >= t)
        const b = requiredAt(colors, last < 0 ? colors.length - 1 : last),
          a = requiredAt(colors, Math.max(0, last - 1))
        const amount =
          last <= 0 || b.position === a.position
            ? 1
            : Math.max(0, Math.min(1, (t - a.position) / (b.position - a.position)))
        const at = (y * width + x) * 4
        for (let c = 0; c < 4; c++)
          rgba[at + c] = numberAt(a.rgba, c) * (1 - amount) + numberAt(b.rgba, c) * amount
      }
  }
  if (approximate) report('APPROXIMATE_GRADIENT')
  return { width, height, left: bounds.left, top: bounds.top, rgba }
}
