import { requiredAt, floatAt } from './indexed.js'
// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
// Curve sampling and brush stamping adapted from animeops/clip-tools (MIT).
// 88/92-byte stroke layouts cross-checked with Aodaruma/clipfile-rs (MIT).
// This is an approximate material renderer, not CSP's brush engine.
import { check } from './binary.js'
import { decodeVectorStrokes } from './vector-native.js'
import { num, type ClipRow } from './records.js'
import { VectorSurface } from './vector-surface.js'
import type { ClipPixels } from './types.js'
import { createBrushTextureProgram, type ProgramBrushTexture } from './vector-texture.js'
import { StrokeRandomState } from './vector-state.js'
import { vectorSamplingGrid } from './vector-sampling.js'
import { compileBrushProgram } from './vector-brush.js'
import { activeBrushPattern, knownBrushRotation } from './vector-settings.js'
import { accumulateInk, gapDensity, inkMode } from './vector-ink.js'
import type { VectorTrace } from './vector-trace.js'
import {
  prepareImageTip,
  imageTipFootprint,
  imageTipThickness,
  imageTipRotation,
} from './vector-tip.js'
import { compileImageTipCoverage } from './vector-tip-coverage.js'
import {
  sampleVectorStroke as samplePath,
  sampleImageVectorStroke,
  createVectorPath,
  CLOSED_VECTOR_STROKE,
  type PathSample,
} from './vector-path.js'
import { spaceStamps, type Stamp } from './vector-stamps.js'
import { checkCancelled, errorCode, type DiagnosticCode } from '../diagnostics.js'
import { intersectRegion, checkRegion, emptyRegion } from './image-region.js'
import type { ImageRegion } from '../image-resources.js'
import type { ByteCache } from './byte-cache.js'
import {
  allocateImage,
  resolveImageLimits,
  resourceLimit,
  type ImageResourceLimits,
} from '../image-resources.js'

export interface VectorPoint {
  x: number
  y: number
  flags: number
  pressure: number
  /** Saved pen tilt at point offset 40 (1 for an upright pen). Historical API name. */
  velocity: number
  /** Saved drawing speed input at point offset 44. Historical API name. */
  smooth: number
  direction: number
  /** Separate input at point offset 52. Its physical axis is unconfirmed. */
  tilt: number
  size: number
  flow: number
  handles: number[]
  /** Three saved floats at a control with flag 0x2. The last two form a unit
   * pair in observed corners. Their effect on the outline is unresolved. */
  cornerData?: readonly [value: number, x: number, y: number]
  /** Native dab continuation at this control. Omit for newly supplied geometry.
   * Interpreted for hard round pens and image tips. */
  dabState?: {
    remainingDistance: number
    randomState: number
    count: number
  }
}
export interface VectorStroke {
  flags: number
  brush: number
  diameter: number
  opacity: number
  randomSeed: number
  color: number[]
  points: VectorPoint[]
}
export interface BrushPattern {
  width: number
  height: number
  alpha: Uint8Array
  reverse?: number
}
export interface VectorBrushes {
  styles: Map<number, ClipRow>
  graphs: Map<number, ClipRow>
  patterns: Map<number, BrushPattern>
  textures?: Map<number, BrushPattern>
}
const clamp = (v: number) => Math.max(0, Math.min(1, v))

/** Read the rendering model; lossless inspection remains an internal, bounded path. */
export function readVectorStrokes(bytes: Uint8Array, signal?: AbortSignal): VectorStroke[] {
  return decodeVectorStrokes(bytes, signal)
}

/** Keep the public sampling entry independent of the internal pipeline layout. */
export function sampleVectorStroke(stroke: VectorStroke): VectorPoint[] {
  return samplePath(stroke)
}

/** Worker-safe software renderer. Per-stroke bounds avoid full-canvas supersampling. */
export function renderVectors(
  strokes: VectorStroke[],
  brushes: VectorBrushes,
  width: number,
  height: number,
  offsetX = 0,
  offsetY = 0,
  report: (code: DiagnosticCode) => void = () => {},
  options: {
    signal?: AbortSignal
    maxSurfaceBytes?: number
    maxPixels?: number
    maxWork?: number
    imageLimits?: ImageResourceLimits
    region?: ImageRegion
  } = {},
): ClipPixels {
  return renderVectorProgram([strokes, brushes, width, height, offsetX, offsetY, report, options])
}

/** Internal observation entry; the public renderer never allocates trace events. */
export function renderVectorProgram(
  args: [...Parameters<typeof renderVectors>, preparations?: ByteCache | undefined],
  trace?: VectorTrace,
  evaluation?: {
    exactDirection?: boolean
    exactPosition?: boolean
    minimumSplineIntervals?: 1 | 4
  },
): ClipPixels {
  const [
    strokes,
    brushes,
    width,
    height,
    offsetX = 0,
    offsetY = 0,
    report = () => {},
    options = {},
    preparations,
  ] = args
  checkCancelled(options.signal)
  check(
    Number.isSafeInteger(width) && Number.isSafeInteger(height) && width > 0 && height > 0,
    'LIMIT_VECTOR_CANVAS',
  )
  check(
    Number.isFinite(offsetX) &&
      Number.isFinite(offsetY) &&
      Math.abs(offsetX) <= 1000000 &&
      Math.abs(offsetY) <= 1000000,
    'INVALID_VECTOR_OFFSET',
  )
  const limits = resolveImageLimits(options.imageLimits, {
    maxPixels: 16 * 1024 * 1024,
    maxBytes: 512 * 1024 * 1024,
  })
  const maxPixels = resourceLimit(options.maxPixels ?? limits.maxPixels),
    maxWork = resourceLimit(options.maxWork ?? 250000000)
  if (options.region) checkRegion(options.region)
  const viewport = options.region
    ? intersectRegion(options.region, { left: 0, top: 0, width, height })
    : { left: 0, top: 0, width, height }
  if (!viewport) return emptyRegion()
  const output = new VectorSurface(
    viewport.width,
    viewport.height,
    options.maxSurfaceBytes ?? (options.imageLimits ? limits.maxBytes : 256 * 1024 * 1024),
    { ...limits, maxPixels },
  )
  let work = 0,
    sampleCount = 0
  const issues = new Set<DiagnosticCode>()
  const textures = new Map<number, ProgramBrushTexture | undefined>()
  const programs = new Map<number, ReturnType<typeof compileBrushProgram>>()
  const tips = new Map<BrushPattern, ReturnType<typeof prepareImageTip>>()
  try {
    for (const [strokeIndex, st] of strokes.entries()) {
      checkCancelled(options.signal)
      try {
        const b = brushes.styles.get(st.brush) ?? {}
        check(
          [
            'AntiAlias',
            'Hardness',
            'ThicknessBase',
            'FlowBase',
            'IntervalBase',
            'RotationBase',
          ].every((k) => Number.isFinite(num(b, k))),
          'INVALID_BRUSH_NUMBER',
        )
        if (!brushes.styles.has(st.brush)) issues.add('MISSING_BRUSH_SETTINGS')
        const patternId = activeBrushPattern(b)
        const pattern = patternId ? brushes.patterns.get(patternId) : undefined
        if (patternId && !pattern) issues.add('MISSING_BRUSH_TIP')
        const imageAA = !!pattern && [1, 2, 3].includes(num(b, 'AntiAlias', 1))
        let tip = pattern && tips.get(pattern)
        if (pattern && !tip) {
          tip = prepareImageTip(pattern, (code) => issues.add(code))
          tips.set(pattern, tip)
        }
        if (!textures.has(st.brush))
          textures.set(
            st.brush,
            createBrushTextureProgram(
              b,
              brushes.textures?.get(num(b, 'TexturePattern')),
              (message) => issues.add(message),
              imageAA,
              options.imageLimits,
            ),
          )
        const texture = textures.get(st.brush)
        const outlineTexture = !!texture && num(b, 'TextureComposite') === 4
        if (
          num(b, 'SprayFlag') ||
          num(b, 'UseWaterColor') ||
          num(b, 'WaterEdgeFlag') ||
          ![0, 27, 31].includes(num(b, 'CompositeMode'))
        )
          issues.add('UNSUPPORTED_BRUSH_COMPOSITE')
        const thickness = Math.max(0.01, Math.min(1, num(b, 'ThicknessBase', 1))),
          aa = num(b, 'AntiAlias', 1),
          composite = num(b, 'CompositeMode')
        // Native round-tip captures cover AA=weak/medium/strong and both ordinary
        // pen composites, including subpixel sizes. Retain the earlier weak-AA
        // ellipse/texture path; do not extend the new evidence to other effects.
        const basicRound =
          !pattern &&
          num(b, 'Hardness', 1) === 1 &&
          [1, 2, 3].includes(aa) &&
          [0, 31].includes(composite) &&
          thickness === 1 &&
          !patternId &&
          !num(b, 'SprayFlag') &&
          !num(b, 'TexturePattern') &&
          !num(b, 'UseWaterColor') &&
          !num(b, 'WaterEdgeFlag')
        const nativeRound =
          basicRound ||
          (!pattern &&
            aa === 1 &&
            num(b, 'Hardness', 1) === 1 &&
            composite === 0 &&
            st.diameter >= 4)
        // Independent image-tip captures use the same 2x grid for AA=1/2/3.
        // This is a sampling approximation, not a translation of the saved path.
        // Experimental preparation must never reuse or replace default geometry.
        const preparationCache =
          evaluation?.minimumSplineIntervals === undefined ? preparations : undefined
        let samples = preparationCache?.get<PathSample[]>(st)
        if (!samples) {
          samples = pattern
            ? sampleImageVectorStroke(st, evaluation?.minimumSplineIntervals)
            : samplePath(st, true)
          preparationCache?.set(st, samples, (samples.length + st.points.length) * 256 + 128)
        }
        const sampling = vectorSamplingGrid(nativeRound, !!pattern, aa)
        const ss = sampling.scale
        sampleCount += samples.length
        check(sampleCount <= 1000000, 'LIMIT_VECTOR_SAMPLES')
        let program = programs.get(st.brush)
        if (!program) {
          program = compileBrushProgram(b, brushes.graphs)
          programs.set(st.brush, program)
          for (const code of program.inputs.diagnostics) issues.add(code)
        }
        const inputs = program.inputs
        const rotationMode = num(b, 'RotationEffector', 3)
        const knownRotation = knownBrushRotation(rotationMode, !!pattern)
        const followPath = !!pattern && knownRotation && !!(rotationMode & 64)
        const texturePerDab = !!texture && program.textureApplication === 'dab'
        const opacityCeiling = basicRound || !!pattern
        const accumulation = inkMode(
          program,
          !!(nativeRound || pattern || composite === 0 || num(b, 'Hardness', 1) < 0.9),
        )
        if (inputs.approximateRandom) issues.add('APPROXIMATE_BRUSH_RANDOM')
        let stamps: Stamp[] = samples.map((p) => {
          const factors = inputs.evaluate(p)
          const nominalDiameter = st.diameter * factors.size
          const diameter =
            program.minimumPixel && nominalDiameter > 0
              ? Math.max(1, nominalDiameter)
              : nominalDiameter
          trace?.record({
            stage: 'input',
            stroke: strokeIndex,
            x: p.x,
            y: p.y,
            size: factors.size,
            flow: factors.flow,
            opacity: factors.opacity,
            thickness: factors.thickness,
          })
          const pointThickness = pattern
            ? imageTipThickness(nominalDiameter, factors.thickness, !!aa)
            : thickness
          return {
            ...p,
            x: p.x + offsetX - sampling.pathPhaseX,
            y: p.y + offsetY - sampling.pathPhaseY,
            diameter: diameter * (!pattern && ss > 1 ? Math.cbrt(pointThickness) : 1),
            spacingDiameter: nominalDiameter,
            thickness: pointThickness,
            randomFlow: factors.randomFlow,
            interval: factors.interval,
            textureDensity: factors.textureDensity,
            // Input opacity bounds the accumulated ink; density controls
            // each dab. Multiplying opacity into density darkens overlapping dabs.
            alpha: clamp(factors.flow * (opacityCeiling ? 1 : factors.opacity)),
            opacity: opacityCeiling ? factors.opacity : 1,
          }
        })
        // Distance integration and final curve evaluation are separate. Placing
        // dabs on integration chords cuts corners; evaluate the saved spline at
        // the recovered parameter without changing the integration subdivisions.
        // Keep non-spline geometry and the comparison-direction trace unchanged.
        const splinePosition =
          !!pattern && (st.flags & 240) === 128 && evaluation?.exactPosition !== false
        const exactDirection = followPath && evaluation?.exactDirection !== false
        const path = splinePosition || exactDirection ? createVectorPath(st) : undefined
        stamps = spaceStamps(
          stamps,
          {
            mode: pattern ? (program.automaticInterval ? 'image-auto' : 'image-manual') : 'round',
            interval: program.interval,
            antialias: !!aa,
          },
          basicRound || !!pattern,
          trace
            ? (p, state, placed, predictedRemaining) =>
                trace.record({
                  stage: 'resume',
                  stroke: strokeIndex,
                  x: p.x,
                  y: p.y,
                  remaining: state.remainingDistance,
                  seed: state.randomState,
                  count: state.count,
                  placed,
                  predictedRemaining,
                })
            : undefined,
          followPath,
          path
            ? (segment, parameter) => {
                const direction = exactDirection ? path.direction(segment, parameter) : {}
                if (!splinePosition) return direction
                const p = path.evaluate(segment, parameter)
                return {
                  ...direction,
                  x: p.x + offsetX - sampling.pathPhaseX,
                  y: p.y + offsetY - sampling.pathPhaseY,
                }
              }
            : undefined,
          !!(st.flags & CLOSED_VECTOR_STROKE),
        )
        sampleCount += Math.max(0, stamps.length - samples.length)
        check(sampleCount <= 1000000, 'LIMIT_VECTOR_SAMPLES')
        let x0 = width,
          y0 = height,
          x1 = 0,
          y1 = 0
        for (const p of stamps) {
          const radius = p.diameter * 0.72 + 1
          x0 = Math.min(x0, Math.floor(p.x - radius))
          y0 = Math.min(y0, Math.floor(p.y - radius))
          x1 = Math.max(x1, Math.ceil(p.x + radius))
          y1 = Math.max(y1, Math.ceil(p.y + radius))
        }
        x0 = Math.max(viewport.left, x0)
        y0 = Math.max(viewport.top, y0)
        x1 = Math.min(viewport.left + viewport.width, x1)
        y1 = Math.min(viewport.top + viewport.height, y1)
        if (x1 <= x0 || y1 <= y0) continue
        const w = (x1 - x0) * ss,
          h = (y1 - y0) * ss
        check(Number.isSafeInteger(w * h) && w * h <= maxPixels, 'LIMIT_VECTOR_STROKE', {
          limit: maxPixels,
        })
        work += w * h
        check(work <= maxWork, 'LIMIT_VECTOR_WORK', { limit: maxWork })
        output.reserveScratch(w * h * 4)
        const alpha = allocateImage(w * h * 4, () => new Float32Array(w * h))
        const random = new StrokeRandomState(st.randomSeed)
        // Raster coverage and curve stepping remain approximate even when the
        // decoded direction and random-stream order are known.
        if (!knownRotation || rotationMode & 64) issues.add('APPROXIMATE_BRUSH_ROTATION')
        for (let i = 0; i < stamps.length; i++) {
          if (i % 1024 === 0) checkCancelled(options.signal)
          const p = requiredAt(stamps, i),
            previous = requiredAt(stamps, Math.max(0, i - 1))
          random.resume(
            p.seed,
            !!p.skippedInitialDab,
            !!(rotationMode & 128),
            inputs.randomFlowMinimum !== undefined,
          )
          // Native fixtures consume angle before density, including invisible dabs.
          const randomAngle =
            rotationMode & 128
              ? (random.next() - (pattern ? 0.5 : 0)) * 2 * Math.PI * num(b, 'RotationRandom', 1)
              : 0
          if (inputs.randomFlowMinimum !== undefined)
            p.alpha *= 1 - p.randomFlow * (1 - inputs.randomFlowMinimum) * (1 - random.next())
          p.alpha = clamp(
            p.alpha * gapDensity(program, p.spacingDiameter, p.interval, p.thickness, !!aa),
          )
          const radius = ((pattern ? Math.max(2, p.diameter) : p.diameter) * ss) / 2,
            cx = (p.x - x0) * ss,
            cy = (p.y - y0) * ss
          const footprint =
            tip &&
            imageTipFootprint(
              tip,
              p.diameter,
              p.thickness,
              program.thicknessAxis === 'vertical',
              !!aa,
            )
          const roundRadius = basicRound ? Math.max(1, radius) : radius,
            roundDensity = basicRound ? Math.min(1, radius) : 1,
            roundEdge = basicRound ? Math.min(roundRadius, aa + 0.5) : 1.5
          const tangent =
            followPath && p.tangentX !== undefined && p.tangentY !== undefined
              ? Math.atan2(p.tangentY, p.tangentX)
              : i
                ? Math.atan2(p.y - previous.y, p.x - previous.x)
                : stamps.length > 1
                  ? Math.atan2(requiredAt(stamps, 1).y - p.y, requiredAt(stamps, 1).x - p.x)
                  : 0
          const rotation =
            randomAngle +
            (num(b, 'RotationBase') * Math.PI) / 180 +
            (knownRotation ? (rotationMode & 64 ? tangent : 0) : tangent + Math.PI / 2)
          trace?.record({
            stage: 'stamp',
            stroke: strokeIndex,
            x: p.x,
            y: p.y,
            diameter: p.diameter,
            angle: rotation,
            alpha: p.alpha,
            seed: random.seed,
            randomState: random.state,
            draws: random.draws,
          })
          // Invisible dabs still consume randomness and remain observable.
          if (p.diameter <= 0 || p.alpha <= 0) continue
          const reach = radius * 1.42 + 1
          // Native image dabs combine output-pixel coverage, not independent
          // subpixel ink buffers. Outline paper also needs this ordering.
          const dabStep = pattern || (outlineTexture && texturePerDab) ? ss : 1
          const left = Math.max(0, Math.floor((cx - reach) / dabStep) * dabStep),
            right = Math.min(w, Math.ceil((cx + reach) / dabStep) * dabStep)
          const top = Math.max(0, Math.floor((cy - reach) / dabStep) * dabStep),
            bottom = Math.min(h, Math.ceil((cy + reach) / dabStep) * dabStep)
          // A dab outside either axis visits no samples in this tile.
          if (left >= right || top >= bottom) continue
          work += (right - left) * (bottom - top)
          check(work <= maxWork, 'LIMIT_VECTOR_WORK', { limit: maxWork })
          const { cos, sin } = pattern
            ? imageTipRotation(rotation)
            : { cos: Math.cos(rotation), sin: Math.sin(rotation) }
          const imageCoverage =
            tip &&
            footprint &&
            compileImageTipCoverage(tip, footprint, cx, cy, cos, sin, ss, sampling.samplePhase)
          for (let y = top; y < bottom; y += dabStep)
            for (let x = left; x < right; x += dabStep) {
              let coverage = imageCoverage ? imageCoverage(x, y) : 0
              if (!imageCoverage) {
                for (let v = 0; v < dabStep; v++)
                  for (let u = 0; u < dabStep; u++) {
                    const phase = sampling.samplePhase
                    const dx = x + u + phase - cx,
                      dy = y + v + phase - cy,
                      lx = dx * cos + dy * sin,
                      ly = -dx * sin + dy * cos
                    let sampled: number
                    {
                      const dist = nativeRound
                          ? Math.hypot(lx / p.thickness, ly)
                          : Math.hypot(lx, ly / (ss === 1 ? p.thickness : 1)),
                        hardness = clamp(num(b, 'Hardness', 1))
                      // The inward AA ramp grows by one pixel per AA level. Below
                      // radius 1 the footprint stays fixed and density scales with
                      // radius, instead of shrinking width/opacity by fitted factors.
                      sampled = nativeRound
                        ? roundDensity * clamp(((roundRadius - dist) * p.thickness) / roundEdge)
                        : ss === 1
                          ? +(dist <= radius)
                          : hardness >= 1
                            ? clamp(radius + 0.5 - dist)
                            : clamp((radius - dist) / Math.max(0.001, radius * (1 - hardness)))
                    }
                    coverage += sampled
                  }
                coverage /= dabStep * dabStep
              }
              const a = clamp(
                coverage *
                  p.alpha *
                  (texturePerDab
                    ? texture.sample(
                        x0 + (x + 0.5) / ss - offsetX,
                        y0 + (y + 0.5) / ss - offsetY,
                        coverage * p.alpha,
                        p.textureDensity,
                      )
                    : 1),
              )
              for (let v = 0; v < dabStep; v++)
                for (let u = 0; u < dabStep; u++) {
                  const at = (y + v) * w + x + u
                  alpha[at] = accumulateInk(floatAt(alpha, at), a, p.opacity, accumulation)
                  if (trace?.observes(x0 + (x + u) / ss, y0 + (y + v) / ss))
                    trace.record({
                      stage: 'coverage',
                      stroke: strokeIndex,
                      x: x0 + (x + u) / ss,
                      y: y0 + (y + v) / ss,
                      coverage,
                      alpha: a,
                      accumulated: floatAt(alpha, at),
                    })
                }
            }
        }
        for (let y = 0; y < h; y += ss)
          for (let x = 0; x < w; x += ss) {
            let a = 0
            for (let v = 0; v < ss; v++)
              for (let u = 0; u < ss; u++) {
                const coverage = alpha[(y + v) * w + x + u]
                if (coverage)
                  a += clamp(
                    coverage *
                      (texture && !texturePerDab && !outlineTexture
                        ? texture.sample(
                            x0 + (x + u + 0.5) / ss - offsetX,
                            y0 + (y + v + 0.5) / ss - offsetY,
                            coverage,
                          )
                        : 1),
                  )
              }
            // Stroke opacity limits the completed stroke, not every overlapping tip.
            a /= ss * ss
            if (outlineTexture && texture && !texturePerDab)
              a = clamp(a * texture.sample(x0 + x / ss - offsetX, y0 + y / ss - offsetY, a))
            a *= st.opacity
            if (!a) continue
            output.blend(
              x0 + x / ss - viewport.left,
              y0 + y / ss - viewport.top,
              a,
              st.color,
              num(b, 'CompositeMode') === 27,
            )
          }
      } catch (e) {
        const code = errorCode(e)
        if (code === 'CANCELLED' || code === 'LIMIT_VECTOR_SURFACE') throw e
        issues.add(code)
        issues.add('MISSING_VECTOR_STROKE')
        if (work > 250000000 || sampleCount > 1000000) {
          issues.add('MISSING_VECTOR_REMAINDER')
          break
        }
      }
    }
    issues.forEach((code) => report(code))
    const result = output.finish()
    return { ...result, left: result.left + viewport.left, top: result.top + viewport.top }
  } finally {
    output.dispose()
  }
}
