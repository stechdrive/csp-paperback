import { numberAt } from './indexed.js'
// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
// Offscreen format and tile permutation: wamsoft/clipparse (MIT).
import { check, Reader } from './binary.js'
import type { ClipPixels } from './types.js'
import type { Inflate } from '../types.js'
import { decodeRasterPixels } from './raster-decode.js'
import { resolveImageLimits, type ImageResourceLimits } from '../image-resources.js'

export interface OffscreenAttribute {
  width: number
  height: number
  cols: number
  rows: number
  channels: number
  bitDepth: number
  planeBytes: number
  hasColor: boolean
  color: number
  rgb?: number[]
  sizes: number[]
}

export function readAttribute(bytes: Uint8Array, brushPattern = false): OffscreenAttribute {
  // Retain the public compatibility flag; gray planes also occur on ordinary layers.
  void brushPattern
  const r = new Reader(bytes)
  r.take(16)
  check(r.wideName() === 'Parameter', 'INVALID_RASTER_PARAMETER')
  const p = Array.from({ length: 20 }, () => r.u32())
  check(r.wideName() === 'InitColor', 'INVALID_RASTER_INIT_COLOR')
  r.u32()
  const hasColor = r.u32() !== 0,
    color = r.u32(),
    extra = r.u32()
  r.u32()
  check(extra <= 4, 'UNSUPPORTED_INITIAL_COLOR')
  const colorValues = Array.from({ length: extra }, () => r.u32())
  check(r.wideName() === 'BlockSize', 'INVALID_RASTER_BLOCK_SIZE')
  r.u32()
  const count = r.u32()
  r.u32()
  check(count <= 65536 && count === numberAt(p, 2) * numberAt(p, 3), 'INVALID_TILE_COUNT')
  const sizes = Array.from({ length: count }, () => r.u32())
  check(r.position === bytes.length, 'INVALID_ATTRIBUTE_END')
  check(
    numberAt(p, 0) > 0 &&
      numberAt(p, 1) > 0 &&
      numberAt(p, 0) <= numberAt(p, 2) * 256 &&
      numberAt(p, 1) <= numberAt(p, 3) * 256,
    'INVALID_IMAGE_DIMENSIONS',
  )
  check(
    ([1, 33].includes(numberAt(p, 4)) &&
      [0, 1, 2, 4].includes(numberAt(p, 6)) &&
      [1, 5].includes(numberAt(p, 7))) ||
      // Native gray layers and gray brush tips share 8-bit alpha/gray planes.
      (p[4] === 17 && p[6] === 1 && p[7] === 2 && p[8] === 65536),
    'UNSUPPORTED_COLOR_FORMAT',
  )
  check(p[14] === 256 && p[15] === 256, 'UNSUPPORTED_TILE_DIMENSIONS')
  const rgb =
    p[6] === 4 && extra === 4
      ? [
          numberAt(colorValues, 2) >>> 24,
          numberAt(colorValues, 1) >>> 24,
          numberAt(colorValues, 0) >>> 24,
        ]
      : undefined
  return {
    width: numberAt(p, 0),
    height: numberAt(p, 1),
    cols: numberAt(p, 2),
    rows: numberAt(p, 3),
    channels: numberAt(p, 6),
    bitDepth: numberAt(p, 7),
    planeBytes: numberAt(p, 8),
    hasColor,
    color,
    ...(rgb ? { rgb } : {}),
    sizes,
  }
}

export async function readRaster(
  a: OffscreenAttribute,
  body: Uint8Array | undefined,
  mask: boolean,
  crop = false,
  options: { signal?: AbortSignal; inflate?: Inflate; imageLimits?: ImageResourceLimits } = {},
): Promise<ClipPixels | undefined> {
  return decodeRasterPixels(a, body, mask, crop, options, resolveImageLimits(options.imageLimits))
}
