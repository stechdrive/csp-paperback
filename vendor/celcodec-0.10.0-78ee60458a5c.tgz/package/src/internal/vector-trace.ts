/** Internal research only. No bitmap/row references or unbounded payloads are retained. */
export type VectorTraceEvent =
  | {
      stage: 'input'
      stroke: number
      x: number
      y: number
      size: number
      flow: number
      opacity: number
      thickness: number
    }
  | {
      stage: 'resume'
      stroke: number
      x: number
      y: number
      remaining: number
      seed: number
      count: number
      placed?: number
      /** Distance computed before the saved state overrides it. */
      predictedRemaining?: number
    }
  | {
      stage: 'stamp'
      stroke: number
      x: number
      y: number
      diameter: number
      angle: number
      alpha: number
      seed: number
      randomState: number
      draws: number
    }
  | {
      stage: 'coverage'
      stroke: number
      x: number
      y: number
      coverage: number
      alpha: number
      accumulated: number
    }

export class VectorTrace {
  readonly events: VectorTraceEvent[] = []
  readonly limit: number
  truncated = false

  constructor(
    limit = 4096,
    readonly pixel?: { x: number; y: number },
  ) {
    this.limit = Number.isFinite(limit) ? Math.max(0, Math.min(16384, Math.floor(limit))) : 0
  }

  record(event: VectorTraceEvent): void {
    if (this.events.length < this.limit) this.events.push(event)
    else this.truncated = true
  }

  observes(x: number, y: number): boolean {
    return !!this.pixel && Math.floor(x) === this.pixel.x && Math.floor(y) === this.pixel.y
  }
}
