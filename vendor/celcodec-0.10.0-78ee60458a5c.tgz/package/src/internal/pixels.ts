// Extracted from csp-paperback (MIT, Copyright (c) 2025 stechdrive).
// Compared with xsheet-remap; see docs/provenance.json and THIRD_PARTY_NOTICES.md.
import type { ClipPixels } from './types.js'

/** Retain only meaningful pixels; most saved offscreens span the whole animation paper. */
export function cropPixels(pixels: ClipPixels, mask = false): ClipPixels {
  const { width, height, rgba } = pixels
  const background = pixels.defaultColor ?? 0,
    channel = mask ? 0 : 3,
    empty = mask ? background : 0,
    stride = width * 4,
    rowHasContent = (y: number) => {
      const end = (y + 1) * stride
      for (let at = y * stride + channel; at < end; at += 4) if (rgba[at] !== empty) return true
      return false
    }
  // Scan the margins rather than every interior pixel. An opaque full-size
  // image resolves after four probes; sparse and empty images retain exact bounds.
  let y0 = 0,
    y1 = height - 1,
    x0 = 0,
    x1 = width - 1
  while (y0 < height && !rowHasContent(y0)) y0++
  if (y0 === height)
    return {
      ...pixels,
      width: 1,
      height: 1,
      rgba: new Uint8ClampedArray(mask ? [background, background, background, 255] : [0, 0, 0, 0]),
    }
  while (y1 > y0 && !rowHasContent(y1)) y1--
  const columnHasContent = (x: number) => {
    for (let y = y0; y <= y1; y++) if (rgba[y * stride + x * 4 + channel] !== empty) return true
    return false
  }
  while (x0 < width && !columnHasContent(x0)) x0++
  while (x1 > x0 && !columnHasContent(x1)) x1--
  if (x0 === 0 && y0 === 0 && x1 === width - 1 && y1 === height - 1) return pixels
  const croppedWidth = x1 - x0 + 1,
    croppedHeight = y1 - y0 + 1,
    cropped = new Uint8ClampedArray(croppedWidth * croppedHeight * 4)
  for (let y = 0; y < croppedHeight; y++) {
    const at = ((y + y0) * width + x0) * 4
    cropped.set(rgba.subarray(at, at + croppedWidth * 4), y * croppedWidth * 4)
  }
  return {
    ...pixels,
    width: croppedWidth,
    height: croppedHeight,
    left: pixels.left + x0,
    top: pixels.top + y0,
    rgba: cropped,
  }
}
