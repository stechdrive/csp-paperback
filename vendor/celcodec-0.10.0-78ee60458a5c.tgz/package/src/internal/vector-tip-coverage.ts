import { sampleImageTip, type prepareImageTip, type imageTipFootprint } from './vector-tip.js'
import { u8At } from './indexed.js'

type Tip = ReturnType<typeof prepareImageTip>
type Footprint = ReturnType<typeof imageTipFootprint>

/** The non-AA positive, unrotated image path uses a quantized scan from a pixel-aligned
 * origin. Quantize the initial coordinate separately from the increment; doing
 * so only after multiplication loses the native subpixel transition thresholds.
 * The output rectangle clips pixels, while source bounds clip individual samples.
 * AA, rotated and reflected stamps retain their independently measured path.
 * See docs/vector-brush-cell-study.md for the rejected AA generalization. */
function compileAxisCoverage(
  tip: Tip,
  footprint: Footprint,
  centerX: number,
  centerY: number,
  phase: number,
): (x: number, y: number) => number {
  const precision = 32768,
    { pattern } = tip,
    width = footprint.width,
    height = footprint.height,
    left = centerX - width / 2,
    top = centerY - height / 2,
    x0 = Math.floor(left),
    y0 = Math.floor(top),
    x1 = Math.ceil(left + width),
    y1 = Math.ceil(top + height),
    stepX = Math.floor((pattern.width / width) * precision),
    stepY = Math.floor((pattern.height / height) * precision),
    startX = Math.trunc((((x0 + phase - left) * pattern.width) / width) * precision),
    startY = Math.trunc((((y0 + phase - top) * pattern.height) / height) * precision)
  return (x, y) => {
    if (x < x0 || x >= x1 || y < y0 || y >= y1) return 0
    const sx = Math.floor((startX + (x - x0) * stepX) / precision),
      sy = Math.floor((startY + (y - y0) * stepY) / precision)
    return sx >= 0 && sx < pattern.width && sy >= 0 && sy < pattern.height
      ? (u8At(pattern.alpha, sy * pattern.width + sx) / 255) * footprint.density
      : 0
  }
}

/** Compile one dab's sampling independently of placement and ink composition.
 * At a rotated AA footprint's extreme vertex, repeat the first subrow; at an
 * inner vertex, limit subsequent subrows to that vertex. This geometrical scan
 * approximation improves native edge agreement without filtering the image or
 * changing stroke coordinates. Residuals remain observable, including local
 * regressions; see docs/vector-brush-adoption.md for the measured tradeoffs. */
export function compileImageTipCoverage(
  tip: Tip,
  footprint: Footprint,
  centerX: number,
  centerY: number,
  cos: number,
  sin: number,
  scale: number,
  phase: number,
): (x: number, y: number) => number {
  if (
    !footprint.antialias &&
    scale === 1 &&
    cos === 1 &&
    sin === 0 &&
    tip.flipX === 1 &&
    tip.flipY === 1
  )
    return compileAxisCoverage(tip, footprint, centerX, centerY, phase)
  const extentY = (Math.abs(sin) * footprint.width * scale) / 2,
    extentX = (Math.abs(cos) * footprint.height * scale) / 2,
    vertices = [
      centerY - extentY - extentX,
      centerY - extentY + extentX,
      centerY + extentY - extentX,
      centerY + extentY + extentX,
    ].sort((a, b) => a - b),
    bottom = vertices[3]!
  return (x, y) => {
    let coverage = 0
    const boundary =
      footprint.antialias && cos !== 0 && sin !== 0
        ? vertices.find((value) => value > y && value <= y + scale - 1)
        : undefined
    const extremeRow =
      footprint.antialias &&
      cos !== 0 &&
      sin !== 0 &&
      ((y < bottom && y + scale - 1 >= bottom) ||
        (y < vertices[0]! && y + scale - 1 >= vertices[0]!))
    for (let v = 0; v < scale; v++)
      for (let u = 0; u < scale; u++) {
        const dx = x + u + phase - centerX,
          dy =
            y +
            (extremeRow ? 0 : boundary !== undefined ? Math.min(v, boundary - y) : v) +
            phase -
            centerY
        coverage += sampleImageTip(
          tip,
          footprint,
          (dx * cos + dy * sin) / scale,
          (-dx * sin + dy * cos) / scale,
        )
      }
    return coverage / (scale * scale)
  }
}
