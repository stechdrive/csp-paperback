import type { ClipPixels } from '../types.js'
import { checkCancelled } from '../diagnostics.js'
import { checkImageAllocation, rgbaBuffer } from '../image-resources.js'

/** Box filter in a fixed document grid, with premultiplied color and scalar masks. */
export function previewPixels(
  p: ClipPixels,
  sourceScale: number,
  scale: number,
  mask: boolean,
  maxBytes: number,
  signal?: AbortSignal,
): ClipPixels {
  const left = Math.floor(p.left * scale),
    top = Math.floor(p.top * scale),
    right = Math.ceil((p.left + p.width / sourceScale) * scale),
    bottom = Math.ceil((p.top + p.height / sourceScale) * scale),
    width = Math.max(1, right - left),
    height = Math.max(1, bottom - top),
    rgba = rgbaBuffer(
      checkImageAllocation(width, height, { maxBytes, maxPixels: Math.floor(maxBytes / 4) }),
    ),
    ratio = sourceScale / scale
  for (let y = 0; y < height; y++) {
    checkCancelled(signal)
    const y0 = ((top + y) / scale - p.top) * sourceScale,
      y1 = y0 + ratio
    for (let x = 0; x < width; x++) {
      const x0 = ((left + x) / scale - p.left) * sourceScale,
        x1 = x0 + ratio
      let alpha = 0,
        red = 0,
        green = 0,
        blue = 0
      for (let sy = Math.floor(y0); sy < Math.ceil(y1); sy++)
        for (let sx = Math.floor(x0); sx < Math.ceil(x1); sx++) {
          const w =
              (Math.min(sx + 1, x1) - Math.max(sx, x0)) * (Math.min(sy + 1, y1) - Math.max(sy, y0)),
            inside = sx >= 0 && sy >= 0 && sx < p.width && sy < p.height,
            i = (sy * p.width + sx) * 4,
            a = inside ? p.rgba[i + 3]! : mask ? 255 : 0,
            r = inside ? p.rgba[i]! : mask ? (p.defaultColor ?? 0) : 0,
            g = inside ? p.rgba[i + 1]! : r,
            b = inside ? p.rgba[i + 2]! : r
          alpha += a * w
          red += r * a * w
          green += g * a * w
          blue += b * a * w
        }
      const i = (y * width + x) * 4
      rgba[i] = alpha ? Math.round(red / alpha) : 0
      rgba[i + 1] = alpha ? Math.round(green / alpha) : 0
      rgba[i + 2] = alpha ? Math.round(blue / alpha) : 0
      rgba[i + 3] = Math.round(alpha / (ratio * ratio))
    }
  }
  return { ...p, left, top, width, height, rgba }
}
