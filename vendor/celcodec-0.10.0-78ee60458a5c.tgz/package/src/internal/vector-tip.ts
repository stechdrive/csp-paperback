// Image-tip sampling adapted from animeops/clip-tools (MIT); see THIRD_PARTY_NOTICES.md.
import { u8At } from './indexed.js'
import type { BrushPattern } from './vector.js'
import type { DiagnosticCode } from '../diagnostics.js'

/** Tip pixels are data: no brush names, material IDs or preset-specific formulas. */
export function prepareImageTip(pattern: BrushPattern, report: (code: DiagnosticCode) => void) {
  const reverse = pattern.reverse ?? 0
  if (
    !Number.isInteger(reverse) ||
    reverse < 0 ||
    reverse > 255 ||
    (reverse & 15) > 1 ||
    reverse >>> 4 > 1
  )
    report('UNSUPPORTED_BRUSH_REVERSE')
  const valid = Number.isInteger(reverse) && reverse >= 0 && reverse <= 255
  return {
    pattern,
    // The bitmap rectangle defines scale. Transparent margins do not enlarge
    // the tip; native padded-image controls reject painted-area normalization.
    aspectX: pattern.width / Math.max(pattern.width, pattern.height),
    aspectY: pattern.height / Math.max(pattern.width, pattern.height),
    flipX: valid && (reverse & 15) === 1 ? -1 : 1,
    flipY: valid && reverse >>> 4 === 1 ? -1 : 1,
  }
}

type ImageTip = ReturnType<typeof prepareImageTip>

/** Native image stamps quantize the combined base/direction/random angle to
 * integer degrees. Keep this at sampling, after RNG and tangent evaluation. */
export function imageTipRotation(rotation: number) {
  // Repair radians-to-degrees roundoff at a half degree (e.g. 33.5).
  const angle = Math.floor((rotation * 180) / Math.PI + 0.5 + 1e-10) / (180 / Math.PI)
  const cos = Math.cos(angle),
    sin = Math.sin(angle)
  return {
    cos: Math.abs(cos) < 1e-12 ? 0 : cos,
    sin: Math.abs(sin) < 1e-12 ? 0 : sin,
  }
}

/** The native AA minimum also participates in spacing and density. Keeping it
 * only in the raster footprint over-stamps thin tips and misnormalizes flow. */
export function imageTipThickness(diameter: number, thickness: number, antialias: boolean): number {
  return antialias ? Math.max(thickness, diameter > 0 ? Math.min(1, 2 / diameter) : 1) : thickness
}

/** Native weak-AA captures keep a two-pixel footprint, then attenuate tiny tips. */
export function imageTipFootprint(
  tip: ImageTip,
  diameter: number,
  thickness: number,
  vertical = false,
  antialias = true,
) {
  const minimum = antialias ? 2 : 0
  return {
    antialias,
    width: Math.max(minimum, diameter * (vertical ? 1 : thickness)) * tip.aspectX,
    height: Math.max(minimum, diameter * (vertical ? thickness : 1)) * tip.aspectY,
    density: antialias ? Math.min(1, diameter / 2) : 1,
  }
}

export function sampleImageTip(
  tip: ImageTip,
  footprint: ReturnType<typeof imageTipFootprint>,
  x: number,
  y: number,
): number {
  const { pattern } = tip,
    tolerance = footprint.antialias ? 1e-9 : 0,
    // Stabilize exact source-cell boundaries instead of shifting the path in
    // world coordinates. Transparent padding and the half-open bounds remain.
    u = Math.floor(((x * tip.flipX) / footprint.width + 0.5) * pattern.width + tolerance),
    v = Math.floor(((y * tip.flipY) / footprint.height + 0.5) * pattern.height + tolerance)
  return u >= 0 && u < pattern.width && v >= 0 && v < pattern.height
    ? (u8At(pattern.alpha, v * pattern.width + u) / 255) * footprint.density
    : 0
}
