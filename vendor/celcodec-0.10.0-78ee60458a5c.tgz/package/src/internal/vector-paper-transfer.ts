import { check } from './binary.js'
import { num, type ClipRow } from './records.js'

/** Native paper levels operate on sampled grain, after spatial interpolation.
 * Compile once per brush without modifying the shared embedded material. */
export function compilePaperTransfer(style: ClipRow): ((grain: number) => number) | undefined {
  const brightness = num(style, 'TextureBrightness'),
    contrast = num(style, 'TextureContrast'),
    inverted = !!(num(style, 'TextureFlag') & 256)
  check(
    [brightness, contrast].every((v) => Number.isFinite(v) && v >= -1 && v <= 1),
    'INVALID_TEXTURE_PARAMETERS',
  )
  if (!brightness && !contrast && !inverted) return
  return (value) => {
    // Quantize AFTER spatial interpolation. The epsilon only repairs floating
    // point error at exact byte values; it is not a paper-coordinate adjustment.
    value = Math.floor(value * 255 + 1e-9) / 255
    const centered = value - 0.5
    const shifted = centered - brightness / 2
    // Native contrast=100 has a singular transfer: an exact threshold returns
    // white even with inversion enabled (confirmed with black/white end points).
    if (contrast === 1 && shifted === 0) return 1
    const adjusted =
      contrast <= 0
        ? centered * (1 + contrast) + 0.5 - brightness / 2
        : contrast < 1
          ? shifted / (1 - contrast) + 0.5
          : shifted < 0
            ? 0
            : 1
    const grain = Math.max(0, Math.min(1, adjusted))
    return inverted ? 1 - grain : grain
  }
}
