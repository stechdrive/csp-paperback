import { check } from '../native/binary.js'
import { blob, type ClipContainer, type Row } from '../native/container.js'
import { mipmapChain, writeMipmap } from '../native/layers.js'
import { optionalRows, normalizedUuid } from '../native/layer-metadata.js'
import { readLayerKind } from '../internal/layer-metadata.js'
import { readAttribute } from '../internal/raster.js'
import type { Pixels } from '../native/raster.js'
import { checkImageAllocation, resolveImageLimits } from '../image-resources.js'

/** Replace original RGBA material; keep identity, layer coordinates, masks and every track. */
export function replaceRasterPixels(
  clip: ClipContainer,
  row: Row,
  pixels: Pixels,
  left: number,
  top: number,
  width: number,
  height: number,
  ancestors: readonly Row[],
): Row {
  const code = 'UNSUPPORTED_RASTER_EDIT'
  check(
    pixels &&
      pixels.data instanceof Uint8Array &&
      pixels.channels === 4 &&
      Number.isSafeInteger(pixels.width) &&
      Number.isSafeInteger(pixels.height) &&
      pixels.width > 0 &&
      pixels.height > 0 &&
      pixels.data.length === pixels.width * pixels.height * 4,
    'INVALID_PIXEL_LENGTH',
  )
  checkImageAllocation(pixels.width, pixels.height, resolveImageLimits(clip.imageLimits))
  check(
    [left, top].every((v) => Number.isSafeInteger(v) && Math.abs(v) <= 1000000),
    'INVALID_EDIT',
  )
  check(
    readLayerKind(
      row,
      optionalRows(clip, 'VectorObjectList').some((v) => v.LayerId === row.MainId),
    ) === 'raster' && !optionalRows(clip, 'LayerObject').some((v) => v.LayerId === row.MainId),
    code,
    { reason: 'material-kind' },
  )
  const original = Number(row.TimeLineOriginalMipmap) > 0
  const linked = [row.LinkLayerItemUUID, row.BankItemUuid].some((v) => {
    const id = normalizedUuid(v)
    return id !== '' && !/^0+$/.test(id)
  })
  check(!linked, code, { reason: 'linked-material' })
  check(
    original ||
      ![row, ...ancestors].some(
        (r) => r.TimeLineLayerKeyFrameEnabled || (r.LayerType === 512 && r.Camera2DApplyTransform),
      ),
    code,
    { reason: 'missing-original' },
  )
  check(
    [0, 1, 2, 3].includes(Number(row.LayerType)) &&
      (row.DrawToRenderOffscreenType ?? 0) === (original ? 70 : 0) &&
      (row.DrawToRenderMipmapType ?? 0) === (original ? 50 : 0) &&
      (row.SetRenderThumbnailInfoType ?? 0) === (original ? 50 : 0),
    code,
    { reason: 'render-strategy' },
  )
  const template = {
    ...row,
    LayerRenderMipmap: (original ? row.TimeLineOriginalMipmap : row.LayerRenderMipmap) ?? null,
  }
  const attr = readAttribute(blob(mipmapChain(clip, template.LayerRenderMipmap)[0]!.off.Attribute))
  check(attr.channels === 4 && attr.bitDepth === 5, code, { reason: 'rgba-required' })
  check([row.LayerOffsetX, row.LayerOffsetY].every(Number.isFinite), code, {
    reason: 'layer-offset',
  })
  const mipmap = writeMipmap(clip, row, pixels, clip, template)
  if (!original)
    return {
      LayerRenderMipmap: mipmap,
      LayerRenderOffscrOffsetX: left - Number(row.LayerOffsetX),
      LayerRenderOffscrOffsetY: top - Number(row.LayerOffsetY),
    }
  return {
    TimeLineOriginalMipmap: mipmap,
    TimeLineRenderOriginalLeft: 0,
    TimeLineRenderOriginalTop: 0,
    TimeLineRenderOriginalRight: pixels.width,
    TimeLineRenderOriginalBottom: pixels.height,
    TimeLineRenderOriginalOffsetX: left - Number(row.LayerOffsetX),
    TimeLineRenderOriginalOffsetY: top - Number(row.LayerOffsetY),
    LayerRenderMipmap: writeMipmap(clip, row, { width, height }, clip, row),
  }
}
