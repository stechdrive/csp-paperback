import { check } from '../internal/binary.js'
import type { DiagnosticCode } from '../diagnostics.js'
import type { BincNode } from '../native/binc.js'
import type { KeyframeClip } from '../native/keyframes.js'

const keyNames = new Set([
  'Frame',
  'Value',
  'Interp',
  'Tag',
  'LeftSlope',
  'RightSlope',
  'BreakKey',
  'ReviseConstant',
])

/** Only verified scalar arrays can be resized/reordered; unknown key metadata is never dropped. */
export function curveFields(curve: BincNode, code: DiagnosticCode = 'UNSUPPORTED_KEYFRAME_EDIT') {
  const fields = new Map(curve.children.map((n) => [n.name, n]))
  const frames = fields.get('Frame'),
    values = fields.get('Value')
  check(frames && values && fields.size === curve.children.length, code)
  check(['Single[]', 'Double[]'].includes(frames.kind), code)
  check(
    curve.children.every(
      (n) =>
        keyNames.has(n.name) &&
        /^(Single|Double|Byte|Int32|UInt32|String)\[\]$/.test(n.kind) &&
        n.values.length === frames.values.length &&
        n.children.length === 0,
    ),
    code,
  )
  return fields
}

/** Inverse of readKeyframeTrack's native motion/time mapping. Frame is relative to playback start. */
export function frameTick(c: KeyframeClip, frame: number, fps: number): number {
  return (
    (c.motion.start / c.motion.rate +
      (((frame - c.startFrame) / fps) * ((c.motion.end - c.motion.start) / c.motion.rate)) /
        ((c.time.end - c.time.start) / c.time.rate)) *
    c.curveRate
  )
}

export function frameOrigin(value: unknown): void {
  check(
    value === undefined || value === 'playback-start' || value === 'timeline-zero',
    'INVALID_TIMELINE_CLIP',
  )
}

export function frameNumber(value: number): void {
  check(Number.isFinite(value) && Math.abs(value) <= 1000000, 'INVALID_TIMELINE_CLIP')
}

export function replaceCelCurve(
  curve: BincNode,
  keys: readonly { tick: number; value: string | null }[],
): void {
  const fields = curveFields(curve, 'UNSUPPORTED_CEL_EDIT')
  check(fields.has('Tag') && fields.has('Interp'), 'UNSUPPORTED_CEL_EDIT')
  for (const [name, field] of fields)
    field.values = keys.map((key, i) =>
      name === 'Frame'
        ? key.tick
        : name === 'Value'
          ? i
          : name === 'Tag'
            ? (key.value ?? '')
            : name === 'Interp'
              ? 'Constant'
              : name === 'ReviseConstant'
                ? 1
                : 0,
    )
}

/** CSP omits both Tag fields on a constant blank cel channel. Preserve every other field. */
export function celCurveFields(curve: BincNode, param: BincNode) {
  const fields = curveFields(curve, 'UNSUPPORTED_CEL_EDIT')
  if (!fields.has('Tag')) {
    check(
      !param.attrs.Tag && fields.get('Value')!.values.every((v) => v === 0),
      'UNSUPPORTED_CEL_EDIT',
    )
    const tags: BincNode = {
      name: 'Tag',
      kind: 'String[]',
      attrs: {},
      children: [],
      values: fields.get('Frame')!.values.map(() => ''),
    }
    curve.children.push(tags)
    fields.set('Tag', tags)
  }
  return fields
}
