import { check } from '../internal/binary.js'
import type { ClipContainer, Row } from '../native/container.js'
import { ensureTrackLabelStorage } from '../native/track-labels.js'
import type { EditOperation } from '../edit/operations.js'

type LabelOperation = Extract<EditOperation, { type: 'setTrackLabel' | 'removeTrackLabel' }>
/** One bounded label index per edit transaction. Unselected rows and unknown fields remain intact. */
export function createLabelEditor(clip: ClipContainer) {
  let rows: Map<number, Row> | undefined
  const ordered = new Map<number, Row[]>()
  const patch = (table: string, row: Row, changes: Row) => {
    clip.update(table, row.MainId, changes)
    Object.assign(row, changes)
  }
  return (track: Row, timeline: Row, operation: LabelOperation) => {
    if (!rows) {
      ensureTrackLabelStorage(clip)
      rows = new Map(clip.rows('TimeLineLabel').map((row) => [Number(row.MainId), row]))
    }
    Object.assign(track, clip.row('Track', track.MainId))
    let list = ordered.get(Number(track.MainId))
    if (!list) {
      list = []
      const seen = new Set<number>()
      let next = Number(track.TrackLabelFirstIndex)
      while (next) {
        const row = rows.get(next)
        check(
          row &&
            !seen.has(next) &&
            row.TrackId === track.MainId &&
            row.ItemId === track.ItemId &&
            row.BankId === track.BankId,
          'INVALID_REFERENCE_CHAIN',
        )
        seen.add(next)
        list.push(row)
        next = Number(row.LabelNextIndex)
      }
      ordered.set(Number(track.MainId), list)
    }
    if (operation.type === 'removeTrackLabel') {
      const at = list.findIndex((row) => row.MainId === operation.labelId)
      check(at >= 0, 'MISSING_ROW')
      list.splice(at, 1)
    } else {
      check(
        Number.isFinite(operation.frame) &&
          (operation.kind === 'inbetween' || operation.kind === 'reverse'),
        'INVALID_TRACK_LABELS',
      )
      const frame = operation.frame + Number(timeline.StartFrame)
      check(frame >= 0 && frame < Number(timeline.EndFrame), 'INVALID_TRACK_LABELS')
      const target =
        operation.labelId === undefined
          ? list.find((row) => row.LabelFrame === frame)
          : list.find((row) => row.MainId === operation.labelId)
      check(operation.labelId === undefined || target, 'MISSING_ROW')
      check(
        !target || ([1, 2].includes(Number(target.LabelType)) && !target.LabelName),
        'UNSUPPORTED_LABEL_COLLISION',
      )
      check(
        !list.some((row) => row !== target && row.LabelFrame === frame),
        'UNSUPPORTED_LABEL_COLLISION',
      )
      const changes = { LabelFrame: frame, LabelType: operation.kind === 'inbetween' ? 1 : 2 }
      if (target) patch('TimeLineLabel', target, changes)
      else {
        const row = clip.insert(
          'TimeLineLabel',
          {},
          {
            ...changes,
            BankId: track.BankId,
            ItemId: track.ItemId,
            TrackId: track.MainId,
            LabelNextIndex: 0,
            LabelName: '',
            LabelLength: null,
          },
        )
        rows.set(Number(row.MainId), row)
        list.push(row)
      }
    }
    list.sort((a, b) => Number(a.LabelFrame) - Number(b.LabelFrame))
    list.forEach((row, i) =>
      patch('TimeLineLabel', row, { LabelNextIndex: list[i + 1]?.MainId ?? 0 }),
    )
    patch('Track', track, { TrackLabelFirstIndex: list[0]?.MainId ?? 0 })
  }
}
