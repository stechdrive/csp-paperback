import { requiredAt } from '../internal/indexed.js'
import { Reader, check } from '../internal/binary.js'
import { BincDocument, bincWriteLimits, type BincNode } from '../native/binc.js'
import { inflateBounded } from '../native/compression.js'
import { concatParts, named, u32, view } from '../native/binary.js'
import { animationMixer, packedMixer } from '../native/animation.js'
import { readAnimation } from '../native/read-animation.js'
import { editTrackMixers, child, setScalar } from './mixer-edit.js'
import {
  frameTick,
  frameOrigin as validateOrigin,
  replaceCelCurve,
  curveFields,
  celCurveFields,
  frameNumber,
} from './curve-edit.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { ExportTrackFrame } from '../native/model.js'

function mixer(bytes: Uint8Array, size: number): BincDocument {
  check(
    bytes.length >= 5 && view(bytes).getUint32(0, true) === bytes.length - 4,
    'INVALID_PACKED_BINC_SIZE',
  )
  check(
    Number.isSafeInteger(size) && size >= 16 && size <= bincWriteLimits.bytes,
    'LIMIT_BINC_BYTES',
  )
  const raw = inflateBounded(bytes.subarray(4), size)
  check(raw.length === size, 'INVALID_BINC_SIZE')
  return new BincDocument(raw, bincWriteLimits)
}

export function hasSingleCelClip(bytes: Uint8Array, size: number): boolean {
  const general = child(mixer(bytes, size).root, 'General')
  return general.children.length === 1 && general.children[0]!.name === 'ActionNodeClip'
}

/** Patch only the named entry; keep unknown entries and known entry tails byte-identical. */
export function patchValueMap(bytes: Uint8Array, rename: (name: string) => string): Uint8Array {
  const r = new Reader(bytes),
    header = r.u32(),
    count = r.u32(),
    parts: Uint8Array[] = [u32(header), u32(count)]
  check(header === 8 && count <= 100000, 'UNSUPPORTED_TRACK_VALUE_MAP')
  let matched = false
  for (let i = 0; i < count; i++) {
    const size = r.u32()
    check(size >= 4, 'UNSUPPORTED_TRACK_VALUE_MAP')
    const payload = r.take(size - 4),
      entry = new Reader(payload),
      name = entry.wideName()
    if (name !== 'ImageCelName') {
      parts.push(u32(size), payload)
      continue
    }
    check(!matched, 'UNSUPPORTED_TRACK_VALUE_MAP')
    matched = true
    const value = entry.wideName(),
      tail = payload.subarray(entry.position)
    const patched = concatParts([named(name), named(rename(value)), tail])
    parts.push(u32(patched.length + 4), patched)
  }
  check(matched && r.position === bytes.length, 'UNSUPPORTED_TRACK_VALUE_MAP')
  return concatParts(parts)
}

/** Unknown siblings, attributes and timing stay in the active mixers, never in abandoned blobs. */
export function renameCelReferences(
  clip: ClipContainer,
  track: Row,
  names: ReadonlyMap<string, string | null>,
): void {
  const rename = (name: string) => (names.has(name) ? (names.get(name) ?? '') : name)
  const changes: Row = {}
  for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
    const body = clip.body(track[field])
    if (!body) continue
    const doc = mixer(body, Number(track[`${field}Size`]))
    let changed = false
    doc.walk((node, parent) => {
      if (
        node.name === 'Param' &&
        node.attrs.Name === 'ImageCelName' &&
        typeof node.attrs.Tag === 'string'
      ) {
        const next = rename(node.attrs.Tag)
        changed ||= next !== node.attrs.Tag
        node.attrs.Tag = next
      }
      if (
        node.name === 'Tag' &&
        parent?.name === 'FCurve' &&
        parent.attrs.Type === 'ImageCelName'
      ) {
        node.values = node.values.map((value) => {
          check(typeof value === 'string', 'INVALID_CEL_KEYS')
          const next = rename(value)
          changed ||= next !== value
          return next
        })
      }
    })
    if (changed) {
      const raw = doc.encode()
      changes[field] = clip.addExternal(packedMixer(raw))
      changes[`${field}Size`] = raw.length
    }
  }
  check(track.TrackValueMap instanceof Uint8Array, 'UNSUPPORTED_TRACK_VALUE_MAP')
  changes.TrackValueMap = patchValueMap(track.TrackValueMap, rename)
  clip.update('Track', track.MainId, changes)
}

/** Includes defaults and hidden keys: a move must not silently rebind an off-range cel. */
export function referencedCelNames(clip: ClipContainer, track: Row): ReadonlySet<string> {
  check(track.TrackKind === 2000, 'UNSUPPORTED_CEL_EDIT')
  const names = new Set<string>()
  const add = (value: string) => {
    if (value) names.add(value)
    return value
  }
  check(track.TrackValueMap instanceof Uint8Array, 'UNSUPPORTED_TRACK_VALUE_MAP')
  patchValueMap(track.TrackValueMap, add)
  let found = false
  for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
    const bytes = clip.body(track[field])
    if (!bytes) {
      check(!track[field], 'MISSING_BINARY_COLUMN')
      continue
    }
    found = true
    mixer(bytes, Number(track[`${field}Size`])).walk((node, parent) => {
      if (node.name === 'Param' && node.attrs.Name === 'ImageCelName') {
        if (node.attrs.Tag !== undefined) add(node.attrs.Tag)
      }
      if (node.name === 'Tag' && parent?.name === 'FCurve' && parent.attrs.Type === 'ImageCelName')
        for (const value of node.values) {
          check(typeof value === 'string', 'UNSUPPORTED_CEL_EDIT')
          add(value)
        }
    })
  }
  check(found, 'MISSING_CEL_DATA')
  return names
}

/** Copy just the verified new clip, never replace an existing mixer root. */
export function newCelClip(
  seed: ClipContainer,
  secondary: boolean,
  start: number,
  end: number,
  fps: number,
): BincNode {
  frameNumber(start)
  frameNumber(end)
  check(end > start, 'INVALID_TIMELINE_CLIP')
  const template = seed.rows('Track').find((t) => t.TrackKind === 2000)
  check(template, 'MISSING_ANIMATION_TEMPLATE')
  const field = secondary ? 'TrackActionMixer2' : 'TrackActionMixer'
  const body = seed.body(template[field])
  check(body, 'MISSING_ANIMATION_TEMPLATE')
  const doc = new BincDocument(
    animationMixer(body, [{ frame: start, value: null }], end, fps),
    bincWriteLimits,
  )
  const general = child(doc.root, 'General')
  check(general.children.length === 1, 'MISSING_ANIMATION_TEMPLATE')
  return general.children[0]!
}

export function insertCelClip(
  clip: ClipContainer,
  track: Row,
  timeline: Row,
  start: number,
  end: number,
  template: (secondary: boolean) => BincNode,
  signal?: AbortSignal,
): number {
  frameNumber(start)
  frameNumber(end)
  check(end > start, 'INVALID_TIMELINE_CLIP')
  let index = 0
  editTrackMixers(
    clip,
    track,
    timeline,
    (general, clips, secondary) => {
      check(
        clips.every((c) => end <= c.startFrame || start >= c.endFrame),
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'clip-overlap' },
      )
      index = clips.findIndex((c) => c.startFrame > start)
      if (index < 0) index = clips.length
      general.children.splice(index, 0, template(secondary))
    },
    signal,
  )
  return index
}

export function removeTrackClip(
  clip: ClipContainer,
  track: Row,
  timeline: Row,
  index: number,
  signal?: AbortSignal,
): boolean {
  check(Number.isSafeInteger(index) && index >= 0, 'INVALID_TIMELINE_CLIP')
  return editTrackMixers(
    clip,
    track,
    timeline,
    (general, clips) => {
      check(clips[index], 'INVALID_TIMELINE_CLIP')
      general.children.splice(index, 1)
    },
    signal,
  )
}

/** Edit one cel channel without rebuilding neighboring properties or clips. */
export function setCelKeys(
  clip: ClipContainer,
  track: Row,
  keys: readonly ExportTrackFrame[],
  fps: number,
  start: number,
  end: number,
  clipIndex?: number,
  frameOrigin?: 'playback-start' | 'timeline-zero',
  signal?: AbortSignal,
  template?: (secondary: boolean) => BincNode,
): boolean {
  validateOrigin(frameOrigin)
  check(
    clipIndex === undefined || (Number.isSafeInteger(clipIndex) && clipIndex >= 0),
    'INVALID_TIMELINE_CLIP',
  )
  check(
    keys.length <= 100000 &&
      keys.every(
        (key, i) =>
          Number.isFinite(key.frame) &&
          Math.abs(key.frame) <= 1000000 &&
          (key.value === null || typeof key.value === 'string') &&
          (!i || key.frame > requiredAt(keys, i - 1).frame),
      ),
    'INVALID_CEL_KEYS',
  )
  const relative = keys.map((key) => ({
    ...key,
    frame: key.frame - (frameOrigin === 'timeline-zero' ? start : 0),
  }))
  const time = { FrameRate: fps, StartFrame: start, EndFrame: end }
  let inserted = false
  const changed = editTrackMixers(
    clip,
    track,
    time,
    (general, values, secondary) => {
      if (!values.length && clipIndex === undefined) {
        if (!keys.length) return
        check(template, 'MISSING_ANIMATION_TEMPLATE')
        general.children.push(template(secondary))
        inserted = true
        return
      }
      check(clipIndex !== undefined || values.length === 1, 'UNSUPPORTED_CEL_EDIT', {
        reason: 'clip-index-required',
      })
      const index = clipIndex ?? 0,
        c = values[index],
        node = general.children[index]
      check(c && node, 'INVALID_TIMELINE_CLIP')
      const anim = child(node, 'AnimInfo'),
        curves = anim.children.filter(
          (n) => n.name === 'FCurve' && n.attrs.Type === 'ImageCelName',
        ),
        params = anim.children.filter((n) => n.name === 'Param' && n.attrs.Name === 'ImageCelName')
      check(
        curves.length === 1 && params.length === 1 && !curves[0]!.attrs.Axis,
        'UNSUPPORTED_CEL_EDIT',
      )
      const curve = curves[0]!,
        param = params[0]!
      celCurveFields(curve, param)
      const curveKeys = relative.map((key) => ({
        tick: frameTick(c, key.frame, fps),
        value: key.value,
      }))
      if (clipIndex !== undefined) {
        const fields = curveFields(curve, 'UNSUPPORTED_CEL_EDIT'),
          ticks = fields.get('Frame')!.values,
          tags = fields.get('Tag')?.values
        if (
          (curveKeys.length > 0 || !param.attrs.Tag) &&
          ticks.length === curveKeys.length &&
          ticks.every(
            (tick, i) => tick === curveKeys[i]!.tick && tags?.[i] === (curveKeys[i]!.value ?? ''),
          )
        )
          return
      }
      if (clipIndex === undefined && relative.length) {
        // The legacy whole-track operation fits the sole clip to the supplied keys.
        // Adjust both envelopes at the original speed: other property keys keep their timeline positions.
        const first = relative[0]!.frame,
          last = Math.max(end - start, relative.at(-1)!.frame + 1),
          tc = child(node, 'TimeClip'),
          mc = child(node, 'MotionClip'),
          newStart = ((first + start) * c.time.rate) / fps,
          newEnd = ((last + start) * c.time.rate) / fps,
          scale = (c.motion.end - c.motion.start) / (c.time.end - c.time.start)
        frameNumber(first + start)
        frameNumber(last + start)
        setScalar(tc, 'Start', newStart)
        setScalar(tc, 'End', newEnd)
        setScalar(mc, 'Start', c.motion.start + (newStart - c.time.start) * scale)
        setScalar(mc, 'End', c.motion.start + (newEnd - c.time.start) * scale)
      }
      replaceCelCurve(curve, curveKeys)
      param.attrs.Tag = relative[0]?.value ?? ''
      param.values = [0]
    },
    signal,
  )
  if (inserted) {
    setCelKeys(clip, track, keys, fps, start, end, 0, frameOrigin, signal)
    return true
  }
  if (changed && (clipIndex === undefined || clipIndex === 0)) {
    check(track.TrackValueMap instanceof Uint8Array, 'UNSUPPORTED_TRACK_VALUE_MAP')
    clip.update('Track', track.MainId, {
      TrackValueMap: patchValueMap(track.TrackValueMap, () => relative[0]?.value ?? ''),
    })
  }
  for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
    const row = clip.row('Track', track.MainId),
      body = clip.body(row[field])
    if (body) readAnimation(body, Number(row[`${field}Size`]), fps, start, end)
  }
  return changed
}
