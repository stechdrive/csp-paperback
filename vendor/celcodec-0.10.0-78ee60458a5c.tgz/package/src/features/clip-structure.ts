import { check } from '../internal/binary.js'
import { compareFrame } from '../internal/frame-boundary.js'
import type { BincNode } from '../native/binc.js'
import type { KeyframeClip } from '../native/keyframes.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { EditOperation } from '../edit/operations.js'
import { child, close, editTrackMixers, setScalar } from './mixer-edit.js'
import {
  celCurveFields,
  frameNumber,
  frameOrigin,
  frameTick,
  replaceCelCurve,
} from './curve-edit.js'

export function clipBounds(
  node: BincNode,
  c: KeyframeClip,
  start: number,
  end: number,
  fps: number,
): void {
  check(end > start && [start, end].every(Number.isFinite), 'INVALID_TIMELINE_CLIP')
  const time = child(node, 'TimeClip'),
    motion = child(node, 'MotionClip'),
    nativeStart =
      start === c.startFrame
        ? c.time.start
        : c.time.start + ((start - c.startFrame) * c.time.rate) / fps,
    nativeEnd =
      end === c.endFrame ? c.time.end : c.time.start + ((end - c.startFrame) * c.time.rate) / fps,
    scale = (c.motion.end - c.motion.start) / (c.time.end - c.time.start)
  setScalar(time, 'Start', nativeStart)
  setScalar(time, 'End', nativeEnd)
  setScalar(
    motion,
    'Start',
    start === c.startFrame ? c.motion.start : c.motion.start + (nativeStart - c.time.start) * scale,
  )
  setScalar(
    motion,
    'End',
    end === c.endFrame ? c.motion.end : c.motion.start + (nativeEnd - c.time.start) * scale,
  )
}

export function moveClip(node: BincNode, c: KeyframeClip, delta: number, fps: number): void {
  const time = child(node, 'TimeClip'),
    shift = (delta * c.time.rate) / fps
  setScalar(time, 'Start', c.time.start + shift)
  setScalar(time, 'End', c.time.end + shift)
}

function celKeys(node: BincNode, start: number, end: number) {
  const anim = child(node, 'AnimInfo'),
    curve = anim.children.find((n) => n.name === 'FCurve' && n.attrs.Type === 'ImageCelName')
  if (!curve) return undefined
  const param = anim.children.find((n) => n.name === 'Param' && n.attrs.Name === 'ImageCelName')
  check(param, 'UNSUPPORTED_CEL_EDIT')
  const f = celCurveFields(curve, param),
    frames = f.get('Frame')!.values as number[],
    tags = f.get('Tag')!.values
  check(
    tags && param && f.get('Interp')?.values.every((v) => v === 'Constant'),
    'UNSUPPORTED_CEL_EDIT',
  )
  // Compare the cut in the curve's own storage precision. This avoids carrying
  // the preceding cel or creating duplicate float32 keys at a split boundary.
  const stored = (tick: number) => (f.get('Frame')!.kind === 'Single[]' ? Math.fround(tick) : tick),
    at = frames.findLastIndex((v) => compareFrame(v, stored(start)) <= 0),
    first = at < 0 ? (param.attrs.Tag ?? '') : tags[at]
  check(typeof first === 'string', 'UNSUPPORTED_CEL_EDIT')
  const keys = [{ tick: start, value: first }]
  frames.forEach((tick, i) => {
    if (compareFrame(tick, stored(start)) > 0 && compareFrame(tick, stored(end)) < 0)
      keys.push({ tick, value: String(tags[i]) })
  })
  return { curve, param, keys }
}

/** Native split keeps numeric curves intact and partitions cel assignment with a carried boundary key. */
export function cropCel(node: BincNode, start: number, end: number): void {
  const cel = celKeys(node, start, end)
  if (!cel) return
  replaceCelCurve(cel.curve, cel.keys)
  cel.param.attrs.Tag = cel.keys[0]!.value
  cel.param.values = [0]
}

export function clipPiece(
  node: BincNode,
  c: KeyframeClip,
  start: number,
  end: number,
  fps: number,
): BincNode {
  const piece = structuredClone(node)
  clipBounds(piece, c, start, end, fps)
  cropCel(piece, frameTick(c, start, fps), frameTick(c, end, fps))
  return piece
}

type StructureEdit = Extract<
  EditOperation,
  { type: 'splitTrackClip' | 'joinTrackClips' | 'extendTrackClip' }
>
export function editClipStructure(
  clip: ClipContainer,
  track: Row,
  time: Row,
  operation: StructureEdit,
  signal?: AbortSignal,
): boolean {
  check(
    Number.isSafeInteger(operation.clipIndex) && operation.clipIndex >= 0,
    'INVALID_TIMELINE_CLIP',
  )
  const fps = Number(time.FrameRate),
    origin = Number(time.StartFrame)
  if (operation.type !== 'joinTrackClips') frameOrigin(operation.frameOrigin)
  return editTrackMixers(
    clip,
    track,
    time,
    (general, clips) => {
      const index = operation.clipIndex,
        c = clips[index],
        node = general.children[index]
      check(c && node, 'INVALID_TIMELINE_CLIP')
      if (operation.type === 'extendTrackClip') {
        frameNumber(operation.startFrame)
        frameNumber(operation.endFrame)
        const offset = operation.frameOrigin === 'timeline-zero' ? origin : 0,
          start = operation.startFrame - offset,
          end = operation.endFrame - offset
        check(start <= c.startFrame && end >= c.endFrame, 'INVALID_TIMELINE_CLIP')
        if (close(start, c.startFrame) && close(end, c.endFrame)) return
        check(![4000, 4001].includes(Number(track.TrackKind)), 'UNSUPPORTED_TIMELINE_EDIT', {
          reason: 'media-extension',
        })
        frameNumber(start + origin)
        frameNumber(end + origin)
        clipBounds(node, c, start, end, fps)
      } else if (operation.type === 'splitTrackClip') {
        frameNumber(operation.frame)
        const frame = operation.frame - (operation.frameOrigin === 'timeline-zero' ? origin : 0)
        check(frame > c.startFrame && frame < c.endFrame, 'INVALID_TIMELINE_CLIP')
        general.children.splice(
          index,
          1,
          clipPiece(node, c, c.startFrame, frame, fps),
          clipPiece(node, c, frame, c.endFrame, fps),
        )
      } else {
        const next = operation.nextClipIndex,
          other = clips[next],
          right = general.children[next]
        check(
          Number.isSafeInteger(next) && next >= 0 && next !== index && other && right,
          'INVALID_TIMELINE_CLIP',
        )
        check(close(c.endFrame, other.startFrame), 'UNSUPPORTED_TIMELINE_EDIT', {
          reason: 'join-not-touching',
        })
        const celOnly =
          Number(track.TrackKind) === 2000 &&
          [node, right].every((n) =>
            child(n, 'AnimInfo').children.every(
              (v) => v.name === 'Param' || (v.name === 'FCurve' && v.attrs.Type === 'ImageCelName'),
            ),
          )
        check(
          celOnly ||
            (close(c.curveRate, other.curveRate) &&
              close(frameTick(c, other.startFrame, fps), frameTick(other, other.startFrame, fps)) &&
              close(frameTick(c, other.endFrame, fps), frameTick(other, other.endFrame, fps))),
          'UNSUPPORTED_TIMELINE_EDIT',
          { reason: 'join-source-timing' },
        )
        const normalized = (n: BincNode) => {
          const copy = structuredClone(n)
          for (const name of ['TimeClip', 'MotionClip']) {
            setScalar(child(copy, name), 'Start', 0)
            setScalar(child(copy, name), 'End', 1)
          }
          const anim = child(copy, 'AnimInfo')
          anim.children = anim.children.filter(
            (v) => v.attrs.Type !== 'ImageCelName' && v.attrs.Name !== 'ImageCelName',
          )
          return JSON.stringify(copy)
        }
        check(normalized(node) === normalized(right), 'UNSUPPORTED_TIMELINE_EDIT', {
          reason: 'join-different-channels',
        })
        const leftCel = celKeys(
            node,
            frameTick(c, c.startFrame, fps),
            frameTick(c, c.endFrame, fps),
          ),
          rightCel = celKeys(
            right,
            frameTick(other, other.startFrame, fps),
            frameTick(other, other.endFrame, fps),
          )
        check(Boolean(leftCel) === Boolean(rightCel), 'UNSUPPORTED_CEL_EDIT')
        if (leftCel && rightCel) {
          const rebase = (tick: number) => {
            const first = frameTick(other, other.startFrame, fps),
              perFrame = frameTick(other, other.startFrame + 1, fps) - first
            return frameTick(c, other.startFrame + (tick - first) / perFrame, fps)
          }
          const keys = [
            ...leftCel.keys,
            ...rightCel.keys.map((key) => ({ ...key, tick: rebase(key.tick) })),
          ].filter((key, i, all) => i === 0 || key.value !== all[i - 1]!.value)
          replaceCelCurve(leftCel.curve, keys)
          leftCel.param.attrs.Tag = keys[0]!.value
          leftCel.param.values = [0]
        }
        clipBounds(node, c, c.startFrame, other.endFrame, fps)
        general.children.splice(next, 1)
      }
    },
    signal,
  )
}
