import { requiredAt } from '../internal/indexed.js'
import { BincDocument, bincWriteLimits, type BincNode } from '../native/binc.js'
import { check, view } from '../native/binary.js'
import { inflateBounded } from '../native/compression.js'

/** Preserve opaque root/general metadata; replacing a clip with unknown internals is unsupported. */
export function preserveAudioEnvelope(
  packed: Uint8Array,
  size: number,
  replacement: Uint8Array,
): Uint8Array {
  check(
    packed.length >= 5 && view(packed).getUint32(0, true) === packed.length - 4,
    'INVALID_PACKED_BINC_SIZE',
  )
  check(Number.isInteger(size) && size >= 16 && size <= bincWriteLimits.bytes, 'LIMIT_BINC_BYTES')
  const raw = inflateBounded(packed.subarray(4), size)
  check(raw.length === size, 'INVALID_BINC_SIZE')
  const original = new BincDocument(raw, bincWriteLimits),
    next = new BincDocument(replacement, bincWriteLimits)
  const general = original.root.children.filter((n) => n.name === 'General'),
    nextGeneral = next.root.children.find((n) => n.name === 'General')!
  check(general.length === 1, 'UNSUPPORTED_AUDIO_EDIT')
  const allowed: Record<string, readonly string[]> = {
    ActionNodeClip: ['TimeClip', 'MotionClip', 'MotionBlend', 'TimeInfo', 'AnimInfo'],
    TimeClip: ['Start', 'End', 'Rate'],
    MotionClip: ['Start', 'End', 'Rate'],
    MotionBlend: ['ShiftBlend', 'NextBlend', 'BlendEnable'],
    TimeInfo: ['Rate'],
    AnimInfo: ['Param', 'FCurve'],
    FCurve: ['Frame', 'Value', 'LeftSlope', 'RightSlope', 'Interp', 'ReviseConstant', 'Tag'],
  }
  function verify(node: BincNode) {
    const attrs =
      node.name === 'ActionNodeClip'
        ? ['Name']
        : node.name === 'FCurve'
          ? ['Type']
          : node.name === 'Param'
            ? ['Name', 'Tag']
            : []
    check(
      Object.keys(node.attrs).every((key) => attrs.includes(key)),
      'UNSUPPORTED_AUDIO_EDIT',
    )
    if (node.name === 'FCurve')
      check(
        typeof node.attrs.Type === 'string' &&
          ['AudioPlayer', 'PlayTime'].includes(node.attrs.Type),
        'UNSUPPORTED_AUDIO_EDIT',
      )
    if (node.name === 'Param')
      check(
        typeof node.attrs.Name === 'string' &&
          ['AudioPlayer', 'AudioVolume', 'PlayTime'].includes(node.attrs.Name),
        'UNSUPPORTED_AUDIO_EDIT',
      )
    check(
      node.children.every((child) => (allowed[node.name] ?? []).includes(child.name)),
      'UNSUPPORTED_AUDIO_EDIT',
    )
    for (const child of node.children) verify(child)
  }
  for (const node of requiredAt(general, 0).children.filter((n) => n.name === 'ActionNodeClip'))
    verify(node)
  // Names/placement/player/volume are the explicitly replaced feature; envelope metadata is retained.
  requiredAt(general, 0).children = [
    ...requiredAt(general, 0).children.filter((n) => n.name !== 'ActionNodeClip'),
    ...nextGeneral.children,
  ]
  return original.encode()
}
