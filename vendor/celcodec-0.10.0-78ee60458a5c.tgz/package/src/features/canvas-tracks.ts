import { Reader, check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { BincDocument, bincWriteLimits } from '../native/binc.js'
import { packedMixer } from '../native/animation.js'
import { inflateBounded } from '../native/compression.js'
import { view } from '../native/binary.js'
import { normalizedUuid, optionalRows } from '../native/layer-metadata.js'
import type { ClipContainer, Row } from '../native/container.js'

const code = 'UNSUPPORTED_CANVAS_EDIT'
const camera = (row: Row) => !!(Number(row.LayerType) & 512) && !!(Number(row.LayerFolder) & 1)
const coordinate = (name: string | undefined) =>
  name === 'ImagePosition' ||
  name === 'MaskPosition' ||
  name === 'MaskCenter' ||
  name === 'ImageCenter'

/** Translate coordinate channels, leaving timing, tangents, blending and unknown siblings intact. */
export function translateCanvasTracks(
  clip: ClipContainer,
  rows: readonly Row[],
  dx: number,
  dy: number,
  cameraRounding: { x: number; y: number },
  signal?: AbortSignal,
) {
  if (!dx && !dy && !cameraRounding.x && !cameraRounding.y) return
  const layers = new Map(rows.map((r) => [normalizedUuid(r.LayerUuid), r]))
  for (const track of optionalRows(clip, 'Track')) {
    checkCancelled(signal)
    const row = layers.get(normalizedUuid(track.LayerUuidWithTrack))
    if (!row) continue
    const isCamera = camera(row),
      changes: Row = {}
    const delta = (name: string | undefined) =>
      isCamera && name === 'ImageCenter' ? [cameraRounding.x, cameraRounding.y] : [dx, dy]
    for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
      const body = clip.body(track[field])
      if (!body) {
        check(!track[field], 'MISSING_BINARY_COLUMN', { field })
        continue
      }
      const size = Number(track[field + 'Size'])
      check(
        Number.isSafeInteger(size) && size >= 16 && size <= bincWriteLimits.bytes,
        'LIMIT_BINC_BYTES',
      )
      check(
        body.length >= 4 && view(body).getUint32(0, true) === body.length - 4,
        'INVALID_PACKED_BINC_SIZE',
      )
      const raw = inflateBounded(body.subarray(4), size)
      check(raw.length === size, 'INVALID_BINC_SIZE')
      const doc = new BincDocument(raw, bincWriteLimits, signal)
      let changed = false
      doc.walk((node, parent) => {
        if (node.name === 'Param' && coordinate(node.attrs.Name)) {
          check(['Float2', 'Double2'].includes(node.kind) && node.values.length === 2, code, {
            reason: 'coordinate-parameter',
          })
          node.values = node.values.map((v, i) => {
            check(typeof v === 'number', code, { reason: 'coordinate-value' })
            return v + delta(node.attrs.Name)[i]!
          })
          changed = true
        }
        if (node.name === 'Value' && parent?.name === 'FCurve' && coordinate(parent.attrs.Type)) {
          check(
            ['Single[]', 'Double[]'].includes(node.kind) && ['X', 'Y'].includes(parent.attrs.Axis!),
            code,
            { reason: 'coordinate-curve' },
          )
          node.values = node.values.map((v) => {
            check(typeof v === 'number', code, { reason: 'coordinate-value' })
            return v + delta(parent.attrs.Type)[parent.attrs.Axis === 'X' ? 0 : 1]!
          })
          changed = true
        }
      })
      if (changed) {
        const encoded = doc.encode()
        changes[field] = clip.addExternal(packedMixer(encoded))
        changes[field + 'Size'] = encoded.length
      }
    }
    if (track.TrackValueMap instanceof Uint8Array) {
      const bytes = track.TrackValueMap.slice(),
        r = new Reader(bytes),
        v = view(bytes)
      check(r.u32() === 8, 'UNSUPPORTED_TRACK_VALUE_MAP')
      const count = r.u32()
      check(count <= 100000, 'LIMIT_DOCUMENT_ITEMS')
      let changed = false
      for (let i = 0; i < count; i++) {
        const size = r.u32(),
          start = r.position
        check(size >= 4, 'UNSUPPORTED_TRACK_VALUE_MAP')
        const entry = new Reader(r.take(size - 4)),
          name = entry.wideName()
        if (!coordinate(name)) continue
        // Native vector entries: optional tag, type 3, two big-endian doubles.
        entry.wideName()
        check(entry.u32() === 3, 'UNSUPPORTED_TRACK_VALUE_MAP')
        const at = start + entry.position,
          x = entry.number('f64'),
          y = entry.number('f64')
        v.setFloat64(at, x + delta(name)[0]!)
        v.setFloat64(at + 8, y + delta(name)[1]!)
        changed = true
      }
      check(r.position === bytes.length, 'UNSUPPORTED_TRACK_VALUE_MAP')
      if (changed) changes.TrackValueMap = bytes
    }
    if (Object.keys(changes).length) clip.update('Track', track.MainId, changes)
  }
}

/** The camera frame moves by the exact anchor shift. Its pivot absorbs raster half-pixel rounding. */
export function translateCamera(
  row: Row,
  dx: number,
  dy: number,
  rounding: { x: number; y: number },
): Row {
  const frameX = dx - rounding.x,
    frameY = dy - rounding.y
  const changes: Row = {}
  for (const [axis, delta] of [
    ['X', frameX],
    ['Y', frameY],
  ] as const) {
    const field = 'Camera2DOriginalFrameCenter' + axis
    check(typeof row[field] === 'number' && Number.isFinite(row[field]), code, { field })
    changes[field] = row[field] + delta
  }
  const source = row.Camera2DResizableImageInfo
  check(
    source instanceof Uint8Array && source.length >= 184 && view(source).getUint32(0) === 120,
    code,
    { reason: 'camera-placement' },
  )
  const bytes = source.slice(),
    v = view(bytes)
  for (const offset of [64, 72, 120, 128, 136, 144, 152, 160, 168, 176]) {
    const value = v.getFloat64(offset)
    check(Number.isFinite(value), code, { reason: 'camera-placement' })
    v.setFloat64(offset, value + ([64, 120, 136, 152, 168].includes(offset) ? frameX : frameY))
  }
  for (const [offset, delta] of [
    [80, rounding.x],
    [88, rounding.y],
  ] as const) {
    const value = v.getFloat64(offset)
    check(Number.isFinite(value), code, { reason: 'camera-pivot' })
    v.setFloat64(offset, value + delta)
  }
  changes.Camera2DResizableImageInfo = bytes
  return changes
}
