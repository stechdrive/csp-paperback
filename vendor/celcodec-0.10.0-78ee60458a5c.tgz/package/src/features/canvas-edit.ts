import { check } from '../internal/binary.js'
import { validateCanvasPixels } from '../internal/canvas-limits.js'
import { animationPaper, canvasUnitScale, frameAnchors } from '../document/paper.js'
import { hasLayerMask, isPaper, readLayerKind } from '../internal/layer-metadata.js'
import { optionalRows, normalizedUuid } from '../native/layer-metadata.js'
import { writeMipmap } from '../native/layers.js'
import { translateCamera, translateCanvasTracks } from './canvas-tracks.js'
import { alignCanvasMask } from './canvas-masks.js'
import { resizeScene3D } from './canvas-3d.js'
import { checkCancelled } from '../diagnostics.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { EditOperation } from '../edit/operations.js'

interface Context {
  clip: ClipContainer
  canvas: Row
  width: number
  height: number
  layers: Iterable<Row>
  signal: AbortSignal | undefined
  maxCanvasPixels: number | undefined
  patch: (table: string, row: Row, changes: Row) => void
  invalidate: (id: number) => void
}
const code = 'UNSUPPORTED_CANVAS_EDIT'
function shape(value: object, keys: readonly string[]) {
  check(
    value &&
      Object.keys(value).every((k) => keys.includes(k)) &&
      keys.every((k) => Object.hasOwn(value, k)),
    'INVALID_CANVAS_FRAME',
  )
}
function finite(v: number) {
  check(Number.isFinite(v) && Math.abs(v) <= 1000000, 'INVALID_CANVAS_FRAME')
}
function size(w: number, h: number) {
  finite(w)
  finite(h)
  check(w > 0 && h > 0, 'INVALID_CANVAS_FRAME')
}

/** Changes canvas coordinates without resampling or cropping original material payloads. */
export function editCanvas(
  context: Context,
  operation: Extract<EditOperation, { type: 'resizeCanvas' | 'setAnimationPaper' }>,
) {
  const { clip, canvas, width, height, patch, invalidate } = context,
    dpi = Number(canvas.CanvasResolution)
  const paper = animationPaper(canvas, width, height, dpi)
  let nextWidth = width,
    nextHeight = height,
    dx = 0,
    dy = 0,
    cameraRounding = { x: 0, y: 0 }
  const changes: Row = {}
  if (operation.type === 'resizeCanvas') {
    const anchor = frameAnchors.indexOf(operation.anchor)
    check(
      anchor >= 0 &&
        Number.isSafeInteger(operation.width) &&
        Number.isSafeInteger(operation.height) &&
        operation.width >= width &&
        operation.height >= height,
      'INVALID_CANVAS_FRAME',
    )
    nextWidth = operation.width
    nextHeight = operation.height
    dx = Math.ceil(((nextWidth - width) * (anchor % 3)) / 2)
    dy = Math.ceil(((nextHeight - height) * Math.floor(anchor / 3)) / 2)
    cameraRounding = {
      x: dx - ((nextWidth - width) * (anchor % 3)) / 2,
      y: dy - ((nextHeight - height) * Math.floor(anchor / 3)) / 2,
    }
    if (nextWidth === width && nextHeight === height) return { width, height }
    // Comic/manuscript frames have different geometry. Preserve them only when understood.
    if (paper.enabled) {
      check(paper.settings && !paper.diagnostics.length, code, {
        reason: 'animation-frame-geometry',
      })
      const scale = canvasUnitScale(paper.stored.unit, dpi)
      changes.CropFrameCropOffsetX =
        paper.stored.drawingOffsetX! + (dx - cameraRounding.x - (nextWidth - width) / 2) / scale
      changes.CropFrameCropOffsetY =
        paper.stored.drawingOffsetY! + (dy - cameraRounding.y - (nextHeight - height) / 2) / scale
    } else {
      check(!canvas.CropFrameOptionFlag, code, { reason: 'non-animation-frame' })
    }
  } else {
    const s = operation.settings
    shape(s, ['unit', 'basis', 'drawing', 'margins', 'direction'])
    check(
      (s.drawing === null || typeof s.drawing === 'object') &&
        (s.direction === null || typeof s.direction === 'object'),
      'INVALID_CANVAS_FRAME',
    )
    shape(s.basis, ['width', 'height'])
    check(s.unit === 'px' || s.unit === 'mm', 'UNSUPPORTED_CANVAS_UNIT')
    check(
      operation.contentAnchor === 'canvas' || operation.contentAnchor === 'basis',
      'INVALID_EDIT',
    )
    size(s.basis.width, s.basis.height)
    const scale = canvasUnitScale(s.unit === 'px' ? 0 : 2, dpi)
    const insets = (v: typeof s.margins) => {
      shape(v, ['left', 'top', 'right', 'bottom'])
      for (const n of Object.values(v)) {
        finite(n)
        check(n >= 0, 'INVALID_CANVAS_FRAME')
      }
    }
    insets(s.margins)
    if (s.direction) {
      insets(s.direction)
      check(
        s.direction.left + s.direction.right < s.basis.width &&
          s.direction.top + s.direction.bottom < s.basis.height,
        'INVALID_CANVAS_FRAME',
      )
    }
    let anchor = 4,
      ox = 0,
      oy = 0
    const dw = s.drawing?.width ?? s.basis.width,
      dh = s.drawing?.height ?? s.basis.height
    if (s.drawing) {
      shape(s.drawing, ['width', 'height', 'anchor', 'offsetX', 'offsetY'])
      size(dw, dh)
      check(dw >= s.basis.width && dh >= s.basis.height, 'INVALID_CANVAS_FRAME')
      anchor = frameAnchors.indexOf(s.drawing.anchor)
      check(anchor >= 0, 'INVALID_CANVAS_FRAME')
      finite(s.drawing.offsetX)
      finite(s.drawing.offsetY)
      ox = (dw - s.basis.width) * ((anchor % 3) / 2 - 0.5) + s.drawing.offsetX
      oy = (dh - s.basis.height) * (Math.floor(anchor / 3) / 2 - 0.5) + s.drawing.offsetY
    }
    nextWidth = Math.round((dw + s.margins.left + s.margins.right) * scale)
    nextHeight = Math.round((dh + s.margins.top + s.margins.bottom) * scale)
    // Preserve the entered dimensions and margins. CSP rounds only the raster extent.
    const cx = (s.margins.left - s.margins.right) / 2,
      cy = (s.margins.top - s.margins.bottom) / 2
    if (operation.contentAnchor === 'basis') {
      check(paper.pixels && !paper.diagnostics.length, code, { reason: 'existing-basis-required' })
      const exactX =
          nextWidth / 2 + (cx + ox - s.basis.width / 2) * scale - paper.pixels.basis.left,
        exactY = nextHeight / 2 + (cy + oy - s.basis.height / 2) * scale - paper.pixels.basis.top
      // Native paper changes round the signed displacement, with ties away from zero.
      dx = Math.sign(exactX) * Math.round(Math.abs(exactX)) || 0
      dy = Math.sign(exactY) * Math.round(Math.abs(exactY)) || 0
      cameraRounding = { x: dx - exactX, y: dy - exactY }
    }
    check(
      Number.isInteger(canvas.CropFrameOptionFlag) &&
        (paper.enabled || Number(canvas.CropFrameOptionFlag) === 0),
      code,
      { reason: 'non-animation-frame' },
    )
    Object.assign(changes, {
      CanvasUnit: s.unit === 'px' ? 0 : 2,
      CanvasWidth: dw + s.margins.left + s.margins.right,
      CanvasHeight: dh + s.margins.top + s.margins.bottom,
      CropFrameUnitKind: s.unit === 'px' ? 0 : 2,
      CropFrameOptionFlag:
        (Number(canvas.CropFrameOptionFlag) & ~(8192 | 4096)) |
        65536 |
        2 |
        (s.drawing ? 8192 : 0) |
        (s.direction ? 4096 : 0),
      CropFrameWidth: dw,
      CropFrameHeight: dh,
      CropFrameInnerWidth: s.basis.width,
      CropFrameInnerHeight: s.basis.height,
      CropFrameCropOffsetX: cx,
      CropFrameCropOffsetY: cy,
      CropFrameInnerOffsetX: ox,
      CropFrameInnerOffsetY: oy,
      CropFrameInnerOffsetBasePosition: anchor,
      CropFrameDesignationType: 0,
      CropFrameSafeMarginLeft: s.direction?.left ?? Number(canvas.CropFrameSafeMarginLeft),
      CropFrameSafeMarginTop: s.direction?.top ?? Number(canvas.CropFrameSafeMarginTop),
      CropFrameSafeMarginRight: s.direction?.right ?? Number(canvas.CropFrameSafeMarginRight),
      CropFrameSafeMarginBottom: s.direction?.bottom ?? Number(canvas.CropFrameSafeMarginBottom),
    })
  }
  validateCanvasPixels(nextWidth, nextHeight, context.maxCanvasPixels)
  check([dx, dy, cameraRounding.x, cameraRounding.y].every(Number.isFinite), 'INVALID_CANVAS_FRAME')
  if (
    nextWidth !== width ||
    nextHeight !== height ||
    dx ||
    dy ||
    cameraRounding.x ||
    cameraRounding.y
  ) {
    const rows = [...context.layers],
      vectors = new Set(optionalRows(clip, 'VectorObjectList').map((r) => r.LayerId)),
      cameras3D = new Map<number, Row[]>()
    if (rows.some((row) => row.Manager3DOd))
      for (const camera of optionalRows(clip, 'CameraInfo')) {
        const id = Number(camera.LayerId),
          entries = cameras3D.get(id) ?? []
        entries.push(camera)
        cameras3D.set(id, entries)
      }
    // Check every participant before mutation, including hidden artwork and linked references.
    for (const row of rows) {
      const kind = readLayerKind(row, vectors.has(row.MainId))
      check(kind !== 'other' || row.LayerType === 800, code, {
        reason: 'unknown-layer-placement',
        affectedLayerId: normalizedUuid(row.LayerUuid),
      })
      check([row.LayerOffsetX, row.LayerOffsetY].every(Number.isFinite), code, {
        reason: 'layer-offset',
      })
      if (kind === 'raster')
        check(
          [0, 70].includes(Number(row.DrawToRenderOffscreenType ?? 0)) &&
            [0, 50].includes(Number(row.DrawToRenderMipmapType ?? 0)) &&
            [0, 50].includes(Number(row.SetRenderThumbnailInfoType ?? 0)) &&
            (!row.TimeLineLayerKeyFrameEnabled || !!row.TimeLineOriginalMipmap),
          code,
          { reason: 'render-strategy' },
        )
      if (hasLayerMask(row))
        check([row.LayerMaskOffsetX, row.LayerMaskOffsetY].every(Number.isFinite), code, {
          reason: 'mask-offset',
        })
    }
    translateCanvasTracks(clip, rows, dx, dy, cameraRounding, context.signal)
    for (const row of rows) {
      checkCancelled(context.signal)
      const folder = !!(Number(row.LayerFolder) & 1),
        camera = folder && !!(Number(row.LayerType) & 512),
        kind = readLayerKind(row, vectors.has(row.MainId)),
        changes: Row = {}
      if (folder) {
        if (hasLayerMask(row)) {
          changes.LayerMaskOffsetX = Number(row.LayerMaskOffsetX) + dx
          changes.LayerMaskOffsetY = Number(row.LayerMaskOffsetY) + dy
        }
      } else {
        changes.LayerOffsetX = Number(row.LayerOffsetX) + dx
        changes.LayerOffsetY = Number(row.LayerOffsetY) + dy
      }
      const projection = resizeScene3D(
        clip,
        row,
        cameras3D.get(Number(row.MainId)) ?? [],
        nextWidth,
        nextHeight,
        dx,
        dy,
        context.signal,
      )
      if (projection) Object.assign(changes, projection)
      if (camera) {
        Object.assign(changes, translateCamera(row, dx, dy, cameraRounding))
        for (const [field, value] of Object.entries({
          TimeLineRenderOriginalLeft: 0,
          TimeLineRenderOriginalTop: 0,
          TimeLineRenderOriginalRight: nextWidth,
          TimeLineRenderOriginalBottom: nextHeight,
        }))
          if (row[field] != null) changes[field] = value
      } else if (folder) {
        for (const [field, delta] of [
          ['TimeLineRenderOriginalLeft', dx],
          ['TimeLineRenderOriginalTop', dy],
          ['TimeLineRenderOriginalRight', dx],
          ['TimeLineRenderOriginalBottom', dy],
        ] as const)
          if (typeof row[field] === 'number') changes[field] = row[field] + delta
      }
      if (
        row.LayerRenderMipmap &&
        (folder ||
          projection ||
          isPaper(row) ||
          row.LayerType === 800 ||
          row.TimeLineOriginalMipmap ||
          ['vector', 'text', 'image-material', 'adjustment', 'gradient', 'fill'].includes(kind))
      ) {
        changes.LayerRenderMipmap = writeMipmap(
          clip,
          row,
          { width: nextWidth, height: nextHeight },
          clip,
          row,
        )
        changes.LayerRenderOffscrOffsetX = -Number(changes.LayerOffsetX ?? row.LayerOffsetX)
        changes.LayerRenderOffscrOffsetY = -Number(changes.LayerOffsetY ?? row.LayerOffsetY)
      }
      if (row.TimeLineOriginalMaskMipmap && row.LayerLayerMaskMipmap) {
        changes.LayerLayerMaskMipmap = writeMipmap(
          clip,
          row,
          { width: nextWidth, height: nextHeight },
          clip,
          row,
          true,
        )
        changes.LayerMaskOffscrOffsetX =
          -Number(changes.LayerOffsetX ?? row.LayerOffsetX) -
          Number(changes.LayerMaskOffsetX ?? row.LayerMaskOffsetX ?? 0)
        changes.LayerMaskOffscrOffsetY =
          -Number(changes.LayerOffsetY ?? row.LayerOffsetY) -
          Number(changes.LayerMaskOffsetY ?? row.LayerMaskOffsetY ?? 0)
      }
      Object.assign(changes, alignCanvasMask(clip, row, changes))
      patch('Layer', row, changes)
      invalidate(Number(row.MainId))
    }
    const canvasScale = canvasUnitScale(
      typeof canvas.CanvasUnit === 'number' ? canvas.CanvasUnit : undefined,
      dpi,
    )
    if (operation.type === 'resizeCanvas') {
      changes.CanvasWidth = nextWidth / canvasScale
      changes.CanvasHeight = nextHeight / canvasScale
    }
    for (const thumb of clip.rows('LayerThumbnail'))
      patch('LayerThumbnail', thumb, {
        ThumbnailCanvasWidth: nextWidth,
        ThumbnailCanvasHeight: nextHeight,
      })
  }
  const changed = Object.fromEntries(Object.entries(changes).filter(([k, v]) => v !== canvas[k]))
  if (Object.keys(changed).length) patch('Canvas', canvas, changed)
  return { width: nextWidth, height: nextHeight }
}
