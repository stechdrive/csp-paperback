import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import type { ClipContainer, Row } from '../native/container.js'
import { normalizedUuid, optionalRows } from '../native/layer-metadata.js'
import type { EditOperation } from '../edit/operations.js'

/** Follow only the selected native chain. Orphaned rows are preserved, never promoted into it. */
export function rowChain(rows: readonly Row[], first: number, nextField: string): Row[] {
  const map = new Map(rows.map((r) => [Number(r.MainId), r])),
    seen = new Set<number>(),
    result: Row[] = []
  let next = first
  while (next) {
    const row = map.get(next)
    check(row && !seen.has(next), 'INVALID_REFERENCE_CHAIN')
    seen.add(next)
    result.push(row)
    next = Number(row[nextField] ?? 0)
  }
  return result
}

export function labelChain(clip: ClipContainer, time: Row, track?: Row): Row[] {
  return rowChain(
    optionalRows(clip, 'TimeLineLabel').filter(
      (r) =>
        r.BankId === time.BankId &&
        r.ItemId === time.MainId &&
        Number(r.TrackId ?? 0) === Number(track?.MainId ?? 0),
    ),
    Number(track ? (track.TrackLabelFirstIndex ?? 0) : (time.LabelFirstIndex ?? 0)),
    'LabelNextIndex',
  )
}

type StructureEdit = Extract<
  EditOperation,
  { type: 'duplicateTimeline' | 'removeTimeline' | 'moveTimeline' }
>
export function editTimelineStructure(
  clip: ClipContainer,
  time: Row,
  operation: StructureEdit,
  signal?: AbortSignal,
): void {
  const all = clip.rows('TimeLine'),
    bank = clip.rows('AnimationCutBank').find((r) => r.MainId === time.BankId)
  check(bank, 'INVALID_REFERENCE_CHAIN')
  // Scenario chains are independent references whose authoring rules have not been verified.
  check(!bank.FirstScenario && !time.NextScenario, 'UNSUPPORTED_TIMELINE_EDIT', {
    reason: 'scenario-references',
  })
  const list = rowChain(
      all.filter((r) => r.BankId === bank.MainId),
      Number(bank.FirstTimeLine),
      'NextTimeLine',
    ),
    at = list.findIndex((r) => r.MainId === time.MainId),
    current = list[Number(bank.CurrentIndex)]
  check(at >= 0 && current, 'INVALID_REFERENCE_CHAIN')
  if (operation.type === 'duplicateTimeline') {
    check(
      /^[0-9a-f]{32}$/.test(operation.id) &&
        !all.some((r) => normalizedUuid(r.TimeLineUuid) === operation.id),
      'INVALID_UUID',
    )
    check(typeof operation.name === 'string' && operation.name.length <= 65535, 'INVALID_EDIT')
    const index = operation.index ?? at + 1
    check(Number.isSafeInteger(index) && index >= 0 && index <= list.length, 'INVALID_EDIT')
    const bytes = (id: string) => Uint8Array.from(id.match(/../g)!, (v) => parseInt(v, 16)),
      copy = clip.insert('TimeLine', time, {
        TimeLineUuid: bytes(operation.id),
        TimeLineName: operation.name,
        NextTimeLine: 0,
        FirstTrack: 0,
        LabelFirstIndex: 0,
      })
    const cloneLabels = (sourceTrack?: Row, targetTrack?: Row) => {
      const labels = labelChain(clip, time, sourceTrack),
        copies: Row[] = []
      for (const label of labels) {
        checkCancelled(signal)
        copies.push(
          clip.insert('TimeLineLabel', label, {
            ItemId: copy.MainId,
            TrackId: targetTrack?.MainId ?? label.TrackId ?? 0,
            LabelNextIndex: 0,
          }),
        )
      }
      copies.forEach((r, i) =>
        clip.update('TimeLineLabel', r.MainId, { LabelNextIndex: copies[i + 1]?.MainId ?? 0 }),
      )
      if (copies.length)
        clip.update(targetTrack ? 'Track' : 'TimeLine', targetTrack?.MainId ?? copy.MainId, {
          [targetTrack ? 'TrackLabelFirstIndex' : 'LabelFirstIndex']: copies[0]!.MainId,
        })
    }
    cloneLabels()
    const sourceTracks = rowChain(
        clip.rows('Track').filter((r) => r.ItemId === time.MainId && r.BankId === time.BankId),
        Number(time.FirstTrack),
        'TrackNextIndex',
      ),
      copies: Row[] = []
    for (const source of sourceTracks) {
      checkCancelled(signal)
      // External payload references are immutable; subsequent edits allocate separate blobs.
      const track = clip.insert('Track', source, {
        ItemId: copy.MainId,
        TrackUuid: bytes(crypto.randomUUID().replaceAll('-', '')),
        TrackNextIndex: 0,
        TrackLabelFirstIndex: 0,
      })
      copies.push(track)
      cloneLabels(source, track)
    }
    copies.forEach((r, i) =>
      clip.update('Track', r.MainId, { TrackNextIndex: copies[i + 1]?.MainId ?? 0 }),
    )
    clip.update('TimeLine', copy.MainId, { FirstTrack: copies[0]?.MainId ?? 0 })
    list.splice(index, 0, copy)
  } else {
    const row = list.splice(at, 1)[0]!
    if (operation.type === 'moveTimeline') {
      check(
        Number.isSafeInteger(operation.index) &&
          operation.index >= 0 &&
          operation.index <= list.length,
        'INVALID_EDIT',
      )
      list.splice(operation.index, 0, row)
    }
    // Removal unlinks the timeline. Its rows and opaque payloads remain available for preservation.
  }
  list.forEach((r, i) =>
    clip.update('TimeLine', r.MainId, { NextTimeLine: list[i + 1]?.MainId ?? 0 }),
  )
  const selected = list.findIndex((r) => r.MainId === current.MainId)
  clip.update('AnimationCutBank', bank.MainId, {
    FirstTimeLine: list[0]?.MainId ?? 0,
    CurrentIndex: selected < 0 ? Math.min(at, Math.max(0, list.length - 1)) : selected,
    Enable: list.length ? bank.Enable : 0,
  })
}
