import { check } from '../internal/binary.js'
import type { BincNode } from '../native/binc.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { EditOperation } from '../edit/operations.js'
import { child, close, editTrackMixers } from './mixer-edit.js'
import { curveFields, frameOrigin, frameTick } from './curve-edit.js'

type KeyEdit = Extract<
  EditOperation,
  { type: 'setPropertyKey' | 'movePropertyKey' | 'removePropertyKey' }
>
const interpolation = {
  constant: 'Constant',
  linear: 'Linear',
  smooth: 'Default',
  hermite: 'Hermite',
}
const properties = [
  'ImagePosition',
  'ImageCenter',
  'ImageScale',
  'ImageAspectScale',
  'ImageRotation',
  'Opacity',
]
const finiteFrame = (v: number) =>
  check(Number.isFinite(v) && Math.abs(v) <= 1000000, 'INVALID_KEYFRAME_KEYS')

export function editPropertyKey(
  clip: ClipContainer,
  track: Row,
  time: Row,
  operation: KeyEdit,
  signal?: AbortSignal,
): boolean {
  frameOrigin(operation.frameOrigin)
  finiteFrame(operation.frame)
  check(
    Number.isSafeInteger(operation.clipIndex) &&
      operation.clipIndex >= 0 &&
      properties.includes(operation.property),
    'UNSUPPORTED_KEYFRAME_EDIT',
  )
  const vector = ['ImagePosition', 'ImageCenter', 'ImageAspectScale'].includes(operation.property)
  check(
    vector ? operation.axis === 'X' || operation.axis === 'Y' : operation.axis === undefined,
    'INVALID_KEYFRAME_KEYS',
  )
  const fps = Number(time.FrameRate),
    origin = Number(time.StartFrame),
    offset = operation.frameOrigin === 'timeline-zero' ? origin : 0,
    frame = operation.frame - offset
  if (operation.type === 'setPropertyKey') {
    check(
      Number.isFinite(operation.value) && Math.abs(operation.value) <= 1e9,
      'INVALID_KEYFRAME_KEYS',
    )
    if (operation.property === 'Opacity')
      check(operation.value >= 0 && operation.value <= 100, 'INVALID_KEYFRAME_KEYS')
    check(
      operation.interpolation === undefined ||
        Object.hasOwn(interpolation, operation.interpolation),
      'INVALID_KEYFRAME_KEYS',
    )
    check(
      operation.handleMode === undefined || ['coupled', 'split'].includes(operation.handleMode),
      'INVALID_KEYFRAME_KEYS',
    )
    for (const v of [operation.leftSlope, operation.rightSlope])
      check(v === undefined || (Number.isFinite(v) && Math.abs(v) <= 1e9), 'INVALID_KEYFRAME_KEYS')
  }
  return editTrackMixers(
    clip,
    track,
    time,
    (general, values, secondary) => {
      const c = values[operation.clipIndex],
        node = general.children[operation.clipIndex]
      check(c && node, 'INVALID_TIMELINE_CLIP')
      const anim = child(node, 'AnimInfo'),
        param = anim.children.find((n) => n.name === 'Param' && n.attrs.Name === operation.property)
      check(
        param &&
          (vector
            ? ['Float2', 'Double2'].includes(param.kind) && param.values.length === 2
            : ['Single', 'Double'].includes(param.kind) && param.values.length === 1),
        'UNSUPPORTED_KEYFRAME_EDIT',
        { reason: 'missing-or-unknown-parameter' },
      )
      let curve = anim.children.find(
        (n) =>
          n.name === 'FCurve' &&
          n.attrs.Type === operation.property &&
          n.attrs.Axis === operation.axis,
      )
      if (!curve) {
        check(operation.type === 'setPropertyKey', 'INVALID_KEYFRAME_KEYS')
        curve = {
          name: 'FCurve',
          kind: 'null',
          values: [],
          attrs: { Type: operation.property, ...(operation.axis ? { Axis: operation.axis } : {}) },
          children: [],
        }
        for (const name of [
          'Frame',
          'Value',
          'LeftSlope',
          'RightSlope',
          'Interp',
          'ReviseConstant',
        ])
          curve.children.push({
            name,
            kind:
              name === 'Interp'
                ? 'String[]'
                : name === 'ReviseConstant'
                  ? 'Byte[]'
                  : secondary
                    ? 'Double[]'
                    : 'Single[]',
            values: [],
            attrs: {},
            children: [],
          })
        anim.children.push(curve)
      }
      const fields = curveFields(curve),
        ticks = fields.get('Frame')!.values as number[],
        tick = frameTick(c, frame, fps),
        matches = ticks.map((v, i) => ({ v, i })).filter(({ v }) => close(v, tick))
      check(matches.length <= 1, 'INVALID_KEYFRAME_KEYS')
      const at = matches[0]?.i ?? -1,
        entries = ticks.map((_, i) =>
          Object.fromEntries([...fields].map(([name, field]) => [name, field.values[i]!])),
        )
      if (operation.type === 'removePropertyKey') {
        check(at >= 0, 'INVALID_KEYFRAME_KEYS')
        entries.splice(at, 1)
        if (!entries.length) {
          // Removing the last key leaves the existing stored parameter as the static value.
          anim.children = anim.children.filter((n) => n !== curve)
          return
        }
      } else if (operation.type === 'movePropertyKey') {
        finiteFrame(operation.toFrame)
        check(at >= 0, 'INVALID_KEYFRAME_KEYS')
        const destination = frameTick(c, operation.toFrame - offset, fps)
        check(!ticks.some((v, i) => i !== at && close(v, destination)), 'INVALID_KEYFRAME_KEYS')
        entries[at]!.Frame = destination
      } else {
        const ensure = (name: string, kind: string, value: string | number) => {
          if (fields.has(name)) return
          const field: BincNode = {
            name,
            kind,
            values: ticks.map(() => value),
            attrs: {},
            children: [],
          }
          fields.set(name, field)
          curve.children.push(field)
          for (const entry of entries) entry[name] = value
        }
        ensure('Interp', 'String[]', 'Linear')
        ensure('LeftSlope', secondary ? 'Double[]' : 'Single[]', 0)
        ensure('RightSlope', secondary ? 'Double[]' : 'Single[]', 0)
        ensure('ReviseConstant', 'Byte[]', 1)
        if (operation.handleMode !== undefined) ensure('BreakKey', 'Byte[]', 0)
        const entry =
          at >= 0
            ? entries[at]!
            : Object.fromEntries(
                [...fields].map(([name]) => [
                  name,
                  name === 'Interp'
                    ? 'Linear'
                    : name === 'Tag'
                      ? ''
                      : name === 'ReviseConstant'
                        ? 1
                        : 0,
                ]),
              )
        const perFrame = frameTick(c, frame + 1, fps) - tick
        entry.Frame = tick
        entry.Value = operation.value
        if (operation.interpolation !== undefined)
          entry.Interp = interpolation[operation.interpolation]
        if (operation.leftSlope !== undefined) entry.LeftSlope = operation.leftSlope / perFrame
        if (operation.rightSlope !== undefined) entry.RightSlope = operation.rightSlope / perFrame
        if (operation.handleMode !== undefined)
          entry.BreakKey = operation.handleMode === 'split' ? 1 : 0
        check(
          entry.BreakKey === undefined || entry.BreakKey === 0 || entry.BreakKey === 1,
          'UNSUPPORTED_KEYFRAME_EDIT',
        )
        if (
          !entry.BreakKey &&
          (operation.leftSlope !== undefined ||
            operation.rightSlope !== undefined ||
            operation.handleMode === 'coupled')
        ) {
          if (operation.leftSlope !== undefined && operation.rightSlope === undefined)
            entry.RightSlope = entry.LeftSlope!
          if (operation.rightSlope !== undefined && operation.leftSlope === undefined)
            entry.LeftSlope = entry.RightSlope!
          check(close(Number(entry.LeftSlope), Number(entry.RightSlope)), 'INVALID_KEYFRAME_KEYS')
        }
        if (at < 0) entries.push(entry)
      }
      entries.sort((a, b) => Number(a.Frame) - Number(b.Frame))
      check(entries.length <= 100000, 'LIMIT_DOCUMENT_ITEMS')
      for (const [name, field] of fields) field.values = entries.map((entry) => entry[name]!)
    },
    signal,
  )
}
