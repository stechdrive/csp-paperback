import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { view } from '../native/binary.js'
import type { ClipContainer, Row } from '../native/container.js'

const code = 'UNSUPPORTED_CANVAS_EDIT'
const finite = (row: Row, field: string): number => {
  const value = row[field]
  check(typeof value === 'number' && Number.isFinite(value), code, {
    reason: '3d-projection-value',
    field,
  })
  return value
}

/** Update the native projection envelope; never decode or rewrite model/scene payloads. */
export function resizeScene3D(
  clip: ClipContainer,
  layer: Row,
  cameras: readonly Row[],
  width: number,
  height: number,
  dx: number,
  dy: number,
  signal?: AbortSignal,
): Row | undefined {
  if (!layer.Manager3DOd) {
    // Old-format CSP materials can still use Manager3DOd. Manager3D alone is a
    // separate, unverified storage layout; translating only its cache is unsafe.
    check(!layer.Manager3D, code, {
      reason: '3d-projection-layout',
      affectedLayerId: Number(layer.MainId),
    })
    return undefined
  }
  const manager = clip.row('Manager3DOd', layer.Manager3DOd)
  check(manager.LayerId === layer.MainId, code, {
    reason: '3d-projection-reference',
    affectedLayerId: Number(layer.MainId),
  })
  // PAINT can leave older CameraInfo rows after replacing an object's camera.
  // Resolve the live object chain instead of interpreting those retained rows.
  const camerasById = new Map(cameras.map((camera) => [camera.MainId, camera])),
    activeCameras: Row[] = [],
    seen = new Set<number>()
  let next = Number(layer.FirstLayerObject ?? 0)
  while (true) {
    checkCancelled(signal)
    check(Number.isSafeInteger(next) && next >= 0 && !seen.has(next), code, {
      reason: '3d-projection-reference',
      affectedLayerId: Number(layer.MainId),
    })
    if (next === 0) break
    seen.add(next)
    const object = clip.row('LayerObject', next)
    check(object.LayerId === layer.MainId, code, {
      reason: '3d-projection-reference',
      affectedLayerId: Number(layer.MainId),
    })
    if (object.Camera) {
      const camera = camerasById.get(object.Camera)
      check(camera && camera.LayerObjectId === object.MainId, code, {
        reason: '3d-projection-reference',
        affectedLayerId: Number(layer.MainId),
      })
      activeCameras.push(camera)
    }
    next = Number(object.ObjectNext ?? 0)
  }
  check(activeCameras.length > 0, code, {
    reason: '3d-projection-reference',
    affectedLayerId: Number(layer.MainId),
  })
  let shift: readonly [number, number] | undefined
  for (const camera of activeCameras) {
    checkCancelled(signal)
    const oldWidth = finite(camera, 'ViewportWidth'),
      oldHeight = finite(camera, 'ViewportHeight'),
      left = finite(camera, 'FrustumLeft'),
      right = finite(camera, 'FrustumRight'),
      top = finite(camera, 'FrustumTop'),
      bottom = finite(camera, 'FrustumBottom')
    check(oldWidth > 0 && oldHeight > 0 && right > left && top > bottom, code, {
      reason: '3d-projection-range',
    })
    const sx = width / oldWidth,
      sy = height / oldHeight,
      nextLeft = left * sx,
      nextRight = right * sx,
      nextTop = top * sy,
      nextBottom = bottom * sy,
      // CSP quantizes the projected old origin, including floating-point boundary effects.
      // Rounding the dimension delta instead loses a pixel in native center-expansion captures.
      x = Math.floor(((left - nextLeft) / (nextRight - nextLeft)) * width),
      y = Math.floor(((nextTop - top) / (nextTop - nextBottom)) * height),
      axisX = finite(camera, 'LayerOpticalAxisPtX') * sx,
      axisY = finite(camera, 'LayerOpticalAxisPtY') * sy
    check([nextLeft, nextRight, nextTop, nextBottom, axisX, axisY].every(Number.isFinite), code, {
      reason: '3d-projection-range',
    })
    check(
      [x, y].every(Number.isSafeInteger) && (!shift || (shift[0] === x && shift[1] === y)),
      code,
      {
        reason: '3d-projection-placement',
      },
    )
    shift = [x, y]
    clip.update('CameraInfo', camera.MainId, {
      FrustumLeft: nextLeft,
      FrustumRight: nextRight,
      FrustumTop: nextTop,
      FrustumBottom: nextBottom,
      ViewportWidth: width,
      ViewportHeight: height,
      LayerOpticalAxisPtX: axisX,
      LayerOpticalAxisPtY: axisY,
    })
  }
  const [x, y] = shift!,
    changes: Row = {
      CanvasRectRight: finite(manager, 'CanvasRectLeft') + width,
      CanvasRectBottom: finite(manager, 'CanvasRectTop') + height,
    }
  const preset = manager.MultiViewPresetCameraFrustum
  if (preset != null) {
    check(
      preset instanceof Uint8Array && preset.length === 52 && view(preset).getUint32(0) === 6,
      code,
      { reason: '3d-preset-frustum' },
    )
    const bytes = preset.slice(),
      data = view(bytes),
      top = data.getFloat64(36),
      bottom = data.getFloat64(44)
    check(Number.isFinite(top) && Number.isFinite(bottom) && top > bottom, code, {
      reason: '3d-preset-frustum',
    })
    const left = bottom * (width / height),
      right = top * (width / height)
    check([left, right].every(Number.isFinite), code, { reason: '3d-preset-frustum' })
    data.setFloat64(20, left)
    data.setFloat64(28, right)
    changes.MultiViewPresetCameraFrustum = bytes
  }
  clip.update('Manager3DOd', manager.MainId, changes)
  translatePerspective(clip, layer, x, y, signal)
  return {
    LayerOffsetX: finite(layer, 'LayerOffsetX') + dx - x,
    LayerOffsetY: finite(layer, 'LayerOffsetY') + dy - y,
    LayerMaskOffsetX: finite(layer, 'LayerMaskOffsetX') + x,
    LayerMaskOffsetY: finite(layer, 'LayerMaskOffsetY') + y,
  }
}

/** The 3D ruler uses layer coordinates, so compensate for the projection-origin shift. */
function translatePerspective(
  clip: ClipContainer,
  layer: Row,
  dx: number,
  dy: number,
  signal?: AbortSignal,
) {
  if (!layer.SpecialRulerManager || (!dx && !dy)) return
  const manager = clip.row('SpecialRulerManager', layer.SpecialRulerManager)
  check(manager.LayerId === layer.MainId, code, { reason: '3d-ruler-reference' })
  const walk = (table: string, first: Row[string] | undefined, visit: (row: Row) => void) => {
    let next = Number(first ?? 0)
    const seen = new Set<number>()
    while (next) {
      checkCancelled(signal)
      check(Number.isSafeInteger(next) && next > 0 && !seen.has(next), code, {
        reason: '3d-ruler-reference',
      })
      seen.add(next)
      const row = clip.row(table, next)
      check(row.LayerId === layer.MainId, code, { reason: '3d-ruler-reference' })
      visit(row)
      next = Number(row.NextIndex ?? 0)
    }
  }
  const coordinates = (row: Row, prefixes: readonly string[]) => {
    const changes: Row = {}
    for (const prefix of prefixes)
      for (const [suffix, delta] of [
        ['X', dx],
        ['Y', dy],
      ] as const) {
        const field = prefix + suffix
        if (row[field] != null) changes[field] = finite(row, field) + delta
      }
    return changes
  }
  const movedPoints = new Set<number>()
  walk('RulerPerspective', manager.FirstPerspective, (row) => {
    clip.update(
      'RulerPerspective',
      row.MainId,
      coordinates(row, ['EyeLevelHandle', 'MoveHandle', 'GridOrigin', 'LensCenter']),
    )
    walk('RulerVanishPoint', row.FirstVanishIndex, (point) => {
      if (movedPoints.has(Number(point.MainId))) return
      movedPoints.add(Number(point.MainId))
      const changes = coordinates(point, ['VanishPoint']),
        guide = point.Guide
      if (guide != null) {
        check(
          guide instanceof Uint8Array &&
            point.GuideDataSize === 16 &&
            Number.isSafeInteger(point.GuideNumber) &&
            Number(point.GuideNumber) >= 0 &&
            guide.length === Number(point.GuideNumber) * 16,
          code,
          { reason: '3d-ruler-guide' },
        )
        const bytes = guide.slice(),
          data = view(bytes)
        for (let offset = 0; offset < bytes.length; offset += 8) {
          const v = data.getFloat64(offset)
          check(Number.isFinite(v), code, { reason: '3d-ruler-guide' })
          data.setFloat64(offset, v + (offset % 16 ? dy : dx))
        }
        changes.Guide = bytes
      }
      clip.update('RulerVanishPoint', point.MainId, changes)
    })
  })
}
