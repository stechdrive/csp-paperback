import { check, externalId, utf8 } from '../native/binary.js'
import { blob, type ClipContainer, type Row } from '../native/container.js'
import { mipmapChain } from '../native/layers.js'
import { normalizedUuid, optionalRows } from '../native/layer-metadata.js'
import { hasLayerMask, readLayerKind } from '../internal/layer-metadata.js'
import { readAttribute } from '../internal/raster.js'

interface AnimationStateContext {
  readonly clip: ClipContainer
  readonly byId: ReadonlyMap<number, Row>
  readonly children: ReadonlyMap<number, readonly number[]>
  readonly tracks: readonly Row[]
  readonly ancestors: (row: Row) => readonly Row[]
  readonly patch: (table: string, row: Row, changes: Row) => void
  readonly invalidate: (id: number) => void
}

const code = 'UNSUPPORTED_ANIMATION_STATE_EDIT'
// Clear only observed cache columns; future columns with a similar prefix stay opaque.
const originalCacheFields = [
  'TimeLineOriginalMipmap',
  'TimeLineRenderOriginalLeft',
  'TimeLineRenderOriginalTop',
  'TimeLineRenderOriginalRight',
  'TimeLineRenderOriginalBottom',
  'TimeLineRenderOriginalOffsetX',
  'TimeLineRenderOriginalOffsetY',
  'TimeLineRenderExtentLeft',
  'TimeLineRenderExtentTop',
  'TimeLineRenderExtentRight',
  'TimeLineRenderExtentBottom',
] as const
const camera = (row: Row) => row.LayerType === 512 && row.LayerFolder === 1
function active(row: Row): boolean {
  const field = camera(row) ? 'Camera2DApplyTransform' : 'TimeLineLayerKeyFrameEnabled',
    value = row[field]
  check(value === 0 || value === 1 || (!camera(row) && value == null), code, { field })
  return value === 1
}
function opacity(value: Row[string] | undefined): number {
  check(typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 256, code, {
    reason: 'original-opacity',
  })
  return value
}

/** Clone mutable cache records, retaining immutable external pixel payloads by reference. */
function refreshedMipmap(clip: ClipContainer, id: Row[string] | undefined): number {
  const original = clip.row('Mipmap', id)
  let next: Row[string] = 0
  for (const { info, off } of mipmapChain(clip, id).reverse()) {
    const copy = clip.insert('Offscreen', off, { BlockData: utf8.encode(externalId()) })
    next = clip.insert('MipmapInfo', info, { Offscreen: copy.MainId, NextIndex: next }).MainId!
  }
  return Number(clip.insert('Mipmap', original, { BaseMipmapInfo: next }).MainId)
}

/** Saved state transitions require material/cache bookkeeping as well as a flag.
 * Limited to existing raster/folder tracks. Mask material activation/deactivation
 * and opaque kinds are refused; an independently animated child mask can stay active.
 */
export function setAnimationState(
  context: AnimationStateContext,
  target: Row,
  kind: 'camera' | 'keyframes',
  enabled: boolean,
): void {
  const { clip, byId, children, tracks, ancestors, patch, invalidate } = context,
    field = kind === 'camera' ? 'Camera2DApplyTransform' : 'TimeLineLayerKeyFrameEnabled'
  check((kind === 'camera') === camera(target), code, { reason: 'target-kind' })
  check(target[field] === 0 || target[field] === 1, code, { field })
  if (target[field] === Number(enabled)) return
  check(
    tracks.some(
      (t) =>
        normalizedUuid(t.LayerUuidWithTrack) === normalizedUuid(target.LayerUuid) &&
        [1000, 2000, 2005].includes(Number(t.TrackKind)),
    ),
    code,
    { reason: 'existing-track-required' },
  )
  const vectorLayers = new Set(optionalRows(clip, 'VectorObjectList').map((row) => row.LayerId)),
    objectLayers = new Set(optionalRows(clip, 'LayerObject').map((row) => row.LayerId)),
    linked = (value: Row[string] | undefined) => {
      const id = normalizedUuid(value)
      return id !== '' && !/^0+$/.test(id)
    },
    ancestorActive = ancestors(target).map(active).some(Boolean),
    pending = [{ row: target, before: ancestorActive, after: ancestorActive }]
  while (pending.length) {
    const item = pending.pop()!,
      row = item.row,
      folder = Number(row.LayerFolder) & 1,
      layerKind = readLayerKind(row, vectorLayers.has(row.MainId)),
      ownActive = active(row),
      before = item.before || ownActive,
      after = item.after || (row === target ? enabled : ownActive),
      mask = hasLayerMask(row)
    check(
      (!mask || before === after) &&
        !objectLayers.has(row.MainId) &&
        !linked(row.LinkLayerItemUUID) &&
        !linked(row.BankItemUuid) &&
        (folder ? ['folder', 'camera'].includes(layerKind) : layerKind === 'raster') &&
        (folder ? row.LayerType === 0 || camera(row) : row.LayerType === 0 || row.LayerType === 1),
      code,
      { reason: 'material-kind', affectedLayerId: normalizedUuid(row.LayerUuid) },
    )
    const changes: Row = {}
    if (before !== after) {
      if (!folder)
        check(
          row.DrawToRenderOffscreenType === (before ? 70 : 0) &&
            row.DrawToRenderMipmapType === (before ? 50 : 0) &&
            row.SetRenderThumbnailInfoType === (before ? 50 : 0),
          code,
          { reason: 'render-strategy' },
        )
      if (after) {
        const base = mipmapChain(clip, row.LayerRenderMipmap)[0]!,
          size = readAttribute(blob(base.off.Attribute))
        check(!row.TimeLineOriginalMipmap, code, { reason: 'unexpected-original' })
        Object.assign(changes, {
          TimeLineRenderOriginalLeft: 0,
          TimeLineRenderOriginalTop: 0,
          TimeLineRenderOriginalRight: size.width,
          TimeLineRenderOriginalBottom: size.height,
        })
        if (!folder) {
          check(clip.body(base.off.BlockData), code, { reason: 'missing-original-pixels' })
          check(
            Number.isFinite(row.LayerRenderOffscrOffsetX) &&
              Number.isFinite(row.LayerRenderOffscrOffsetY),
            code,
            { reason: 'original-offset' },
          )
          Object.assign(changes, {
            TimeLineOriginalMipmap: row.LayerRenderMipmap,
            TimeLineRenderOriginalOffsetX: row.LayerRenderOffscrOffsetX,
            TimeLineRenderOriginalOffsetY: row.LayerRenderOffscrOffsetY,
            LayerType: 0,
            DrawToRenderOffscreenType: 70,
            DrawToRenderMipmapType: 50,
            SetRenderThumbnailInfoType: 50,
          })
        }
      } else {
        if (!folder) {
          const base = mipmapChain(clip, row.TimeLineOriginalMipmap)[0]!
          check(clip.body(base.off.BlockData), code, { reason: 'missing-original-pixels' })
          check(
            Number.isFinite(row.TimeLineRenderOriginalOffsetX) &&
              Number.isFinite(row.TimeLineRenderOriginalOffsetY),
            code,
            { reason: 'original-offset' },
          )
          Object.assign(changes, {
            LayerRenderMipmap: row.TimeLineOriginalMipmap,
            LayerRenderOffscrOffsetX: row.TimeLineRenderOriginalOffsetX,
            LayerRenderOffscrOffsetY: row.TimeLineRenderOriginalOffsetY,
            LayerType: 1,
            DrawToRenderOffscreenType: 0,
            DrawToRenderMipmapType: 0,
            SetRenderThumbnailInfoType: 0,
          })
        }
        for (const key of originalCacheFields) if (Object.hasOwn(row, key)) changes[key] = null
      }
    }
    if (row === target) {
      changes[field] = Number(enabled)
      if (enabled) changes.TimeLineOriginalLayerOpacity = opacity(row.LayerOpacity)
      else {
        changes.LayerOpacity = opacity(row.TimeLineOriginalLayerOpacity)
        changes.TimeLineOriginalLayerOpacity = null
      }
    }
    if (!folder && after) {
      check(Number(changes.TimeLineOriginalMipmap ?? row.TimeLineOriginalMipmap) > 0, code, {
        reason: 'missing-original-pixels',
      })
      changes.LayerRenderMipmap = refreshedMipmap(clip, row.LayerRenderMipmap)
    }
    if (mask && after) {
      check(Number(row.TimeLineOriginalMaskMipmap) > 0, code, { reason: 'missing-original-mask' })
      check(clip.body(mipmapChain(clip, row.TimeLineOriginalMaskMipmap)[0]!.off.BlockData), code, {
        reason: 'missing-original-mask',
      })
      changes.LayerLayerMaskMipmap = refreshedMipmap(clip, row.LayerLayerMaskMipmap)
    }
    patch('Layer', row, changes)
    invalidate(Number(row.MainId))
    for (const id of children.get(Number(row.MainId)) ?? [])
      pending.push({ row: byId.get(id)!, before, after })
  }
}
