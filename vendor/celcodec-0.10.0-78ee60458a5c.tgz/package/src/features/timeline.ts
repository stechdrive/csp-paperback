import { check } from '../internal/binary.js'
import type { BincNode } from '../native/binc.js'
import type { KeyframeClip } from '../native/keyframes.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { EditOperation } from '../edit/operations.js'
import { child, setScalar, close, editTrackMixers } from './mixer-edit.js'

export function timelineRange(fps: number, start: number, end: number): void {
  check(
    Number.isFinite(fps) &&
      fps >= 1 &&
      fps <= 120 &&
      Number.isFinite(start) &&
      start >= 0 &&
      Number.isFinite(end) &&
      end > start &&
      end - start <= 1000000,
    'INVALID_TIMELINE_RANGE',
  )
}
type ClipEdit = Extract<EditOperation, { type: 'moveTrackClip' | 'trimTrackClip' }>
function patchClips(
  clip: ClipContainer,
  track: Row,
  timeline: Row,
  update: (node: BincNode, value: KeyframeClip, index: number) => void,
  signal?: AbortSignal,
): boolean {
  return editTrackMixers(
    clip,
    track,
    timeline,
    (general, values) => {
      general.children.forEach((node, i) => update(node, values[i]!, i))
    },
    signal,
  )
}

export function editTrackClip(
  clip: ClipContainer,
  track: Row,
  time: Row,
  operation: ClipEdit,
  signal?: AbortSignal,
): boolean {
  check(
    Number.isSafeInteger(operation.clipIndex) && operation.clipIndex >= 0,
    'INVALID_TIMELINE_CLIP',
  )
  check(
    Number.isFinite(operation.startFrame) && Math.abs(operation.startFrame) <= 1000000,
    'INVALID_TIMELINE_CLIP',
  )
  if (operation.type === 'trimTrackClip')
    check(Number.isFinite(operation.endFrame), 'INVALID_TIMELINE_CLIP')
  check(
    operation.frameOrigin === undefined ||
      operation.frameOrigin === 'playback-start' ||
      operation.frameOrigin === 'timeline-zero',
    'INVALID_TIMELINE_CLIP',
  )
  const fps = Number(time.FrameRate),
    origin = Number(time.StartFrame),
    coordinateOffset = operation.frameOrigin === 'timeline-zero' ? origin : 0
  timelineRange(fps, origin, Number(time.EndFrame))
  let found = false
  const changed = patchClips(
    clip,
    track,
    time,
    (node, c, index) => {
      if (index !== operation.clipIndex) return
      found = true
      const start = operation.startFrame - coordinateOffset
      const end =
        operation.type === 'moveTrackClip'
          ? start + (c.endFrame - c.startFrame)
          : operation.endFrame - coordinateOffset
      // Preserve the native duration directly; converting both bounds through seconds can drift.
      const ticksPerFrame = c.time.rate / fps,
        nativeStart = (start + origin) * ticksPerFrame,
        nativeEnd =
          operation.type === 'moveTrackClip'
            ? nativeStart + (c.time.end - c.time.start)
            : (end + origin) * ticksPerFrame
      if (nativeStart === c.time.start && nativeEnd === c.time.end) return
      check(
        Number.isFinite(end) &&
          end > start &&
          Math.abs(start + origin) <= 1000000 &&
          Math.abs(end + origin) <= 1000000,
        'INVALID_TIMELINE_CLIP',
      )
      if (operation.type === 'trimTrackClip') {
        check(
          (start >= c.startFrame || close(start, c.startFrame)) &&
            (end <= c.endFrame || close(end, c.endFrame)),
          'UNSUPPORTED_TIMELINE_EDIT',
          { reason: 'clip-extension' },
        )
        const motion = child(node, 'MotionClip'),
          scale = (c.motion.end - c.motion.start) / (c.time.end - c.time.start)
        setScalar(motion, 'Start', c.motion.start + (nativeStart - c.time.start) * scale)
        setScalar(motion, 'End', c.motion.start + (nativeEnd - c.time.start) * scale)
      }
      const target = child(node, 'TimeClip')
      setScalar(target, 'Start', nativeStart)
      setScalar(target, 'End', nativeEnd)
    },
    signal,
  )
  check(found, 'INVALID_TIMELINE_CLIP')
  return changed
}

/** Native FPS conversion: drawing clip envelopes scale; audio/movie clips keep real-time timing. */
export function preserveTrackFrames(
  clip: ClipContainer,
  track: Row,
  timeline: Row,
  fps: number,
  signal?: AbortSignal,
): void {
  patchClips(
    clip,
    track,
    timeline,
    (node, c) => {
      const target = child(node, 'TimeClip'),
        scale = Number(timeline.FrameRate) / fps
      setScalar(target, 'Start', c.time.start * scale)
      setScalar(target, 'End', c.time.end * scale)
    },
    signal,
  )
}

/** CSP stores fractional frame coordinates as doubles; FPS conversion does not quantize them. */
export function scaleFrame(value: number, ratio: number): number {
  const result = value * ratio
  check(Number.isFinite(value) && Number.isFinite(result), 'INVALID_TIMELINE_RANGE')
  check(Math.abs(result) <= 1000000, 'LIMIT_TIMELINE_RANGE')
  return result
}
