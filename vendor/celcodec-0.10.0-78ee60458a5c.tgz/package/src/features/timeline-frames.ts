import { check } from '../internal/binary.js'
import { compareFrame } from '../internal/frame-boundary.js'
import { checkCancelled } from '../diagnostics.js'
import type { ClipContainer, Row } from '../native/container.js'
import type { EditOperation } from '../edit/operations.js'
import { child, editTrackMixers, setScalar } from './mixer-edit.js'
import { curveFields, frameNumber, frameOrigin, frameTick } from './curve-edit.js'
import { clipBounds, clipPiece, moveClip } from './clip-structure.js'
import { labelChain } from './timeline-structure.js'
import { timelineRange } from './timeline.js'

type FrameEdit = Extract<EditOperation, { type: 'insertTimelineFrames' | 'removeTimelineFrames' }>
export function editTimelineFrames(
  clip: ClipContainer,
  time: Row,
  tracks: readonly Row[],
  operation: FrameEdit,
  signal?: AbortSignal,
): number[] {
  frameNumber(operation.frame)
  frameOrigin(operation.frameOrigin)
  check(
    Number.isSafeInteger(operation.count) && operation.count > 0 && operation.count <= 1000000,
    'INVALID_TIMELINE_CLIP',
  )
  check(
    ['shift', 'preserve'].includes(operation.trackLabels) &&
      ['shift', 'preserve'].includes(operation.timelineLabels) &&
      ['resize', 'preserve'].includes(operation.playbackRange) &&
      ['shift-keys', 'split'].includes(operation.crossingClips),
    'INVALID_EDIT',
  )
  check(operation.trackIds === 'all' || Array.isArray(operation.trackIds), 'INVALID_EDIT')
  const ids =
    operation.trackIds === 'all' ? tracks.map((t) => Number(t.MainId)) : operation.trackIds
  check(
    new Set(ids).size === ids.length &&
      ids.every((id) => Number.isSafeInteger(id) && tracks.some((t) => t.MainId === id)),
    'MISSING_TRACK',
  )
  const fps = Number(time.FrameRate),
    origin = Number(time.StartFrame),
    begin = operation.frame - (operation.frameOrigin === 'timeline-zero' ? origin : 0),
    count = operation.count,
    remove = operation.type === 'removeTimelineFrames',
    end = begin + count,
    delta = remove ? -count : count
  frameNumber(begin + origin)
  frameNumber(end + origin)
  const compare = (a: number, b: number) => compareFrame(a, b, origin)
  const mapped = (v: number) =>
    compare(v, begin) < 0 ? v : remove ? Math.max(begin, v - count) : v + count
  const changed: number[] = []
  for (const track of tracks.filter((t) => ids.includes(Number(t.MainId)))) {
    checkCancelled(signal)
    if (
      editTrackMixers(
        clip,
        track,
        time,
        (general, values) => {
          general.children = general.children.flatMap((node, index) => {
            const c = values[index]!
            if (compare(c.endFrame, begin) <= 0) return [node]
            if (compare(c.startFrame, remove ? end : begin) >= 0) {
              frameNumber(c.startFrame + delta + origin)
              frameNumber(c.endFrame + delta + origin)
              moveClip(node, c, delta, fps)
              return [node]
            }
            if (remove && compare(c.startFrame, begin) >= 0 && compare(c.endFrame, end) <= 0)
              return []
            if (operation.crossingClips === 'split') {
              const pieces = []
              if (compare(c.startFrame, begin) < 0)
                pieces.push(clipPiece(node, c, c.startFrame, begin, fps))
              const rightStart = remove ? end : begin
              if (compare(c.endFrame, rightStart) > 0) {
                frameNumber(rightStart + delta + origin)
                frameNumber(c.endFrame + delta + origin)
                const right = clipPiece(node, c, rightStart, c.endFrame, fps),
                  tc = child(right, 'TimeClip')
                for (const name of ['Start', 'End'])
                  setScalar(
                    tc,
                    name,
                    Number(child(tc, name).values[0]) + (delta * c.time.rate) / fps,
                  )
                pieces.push(right)
              }
              return pieces
            }
            check(![4000, 4001].includes(Number(track.TrackKind)), 'UNSUPPORTED_TIMELINE_EDIT', {
              reason: 'media-requires-split',
            })
            // CSP trims a crossing clip's tail without changing its hidden numeric keys.
            if (remove && compare(c.endFrame, end) <= 0)
              return [clipPiece(node, c, c.startFrame, begin, fps)]
            const newStart = compare(c.startFrame, begin) < 0 ? c.startFrame : begin,
              newEnd = mapped(c.endFrame),
              anim = child(node, 'AnimInfo')
            frameNumber(newStart + origin)
            frameNumber(newEnd + origin)
            const nextTick = (oldFrame: number) => frameTick(c, mapped(oldFrame), fps)
            for (const curve of anim.children) {
              if (curve.name !== 'FCurve') continue
              const fields = curveFields(curve),
                keys = c.curves.find(
                  (v) => v.property === curve.attrs.Type && v.axis === curve.attrs.Axis,
                )!.keys,
                // Removed keys collapse to the cut boundary. Retain the last key and all its metadata.
                keep = keys
                  .map((key, i) => ({ key, i, tick: nextTick(key.frame) }))
                  .filter(
                    (entry, i, all) =>
                      i === all.length - 1 || Math.abs(entry.tick - all[i + 1]!.tick) > 1e-7,
                  )
              for (const [name, field] of fields)
                field.values = keep.map(({ tick, i }) =>
                  name === 'Frame' ? tick : field.values[i]!,
                )
            }
            clipBounds(node, c, newStart, newEnd, fps)
            return [node]
          })
        },
        signal,
      )
    )
      changed.push(Number(track.MainId))
  }
  const labels = (track?: Row) => {
    const list = labelChain(clip, time, track),
      kept: Row[] = []
    for (const row of list) {
      const frame = Number(row.LabelFrame) - origin
      check(Number.isFinite(frame), 'INVALID_TRACK_LABELS')
      // Range-label semantics are not inferred from their opaque type/length fields.
      check(
        !row.LabelLength || compare(frame + Number(row.LabelLength), begin) <= 0,
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'range-label' },
      )
      if (remove && compare(frame, begin) >= 0 && compare(frame, end) < 0) continue
      const next = mapped(frame) + origin
      frameNumber(next)
      clip.update('TimeLineLabel', row.MainId, { LabelFrame: next })
      kept.push(row)
    }
    kept.forEach((r, i) =>
      clip.update('TimeLineLabel', r.MainId, { LabelNextIndex: kept[i + 1]?.MainId ?? 0 }),
    )
    if (list.length)
      clip.update(track ? 'Track' : 'TimeLine', track?.MainId ?? time.MainId, {
        [track ? 'TrackLabelFirstIndex' : 'LabelFirstIndex']: kept[0]?.MainId ?? 0,
      })
  }
  if (operation.timelineLabels === 'shift') labels()
  if (operation.trackLabels === 'shift')
    for (const t of tracks.filter((t) => ids.includes(Number(t.MainId)))) labels(t)
  if (operation.playbackRange === 'resize') {
    // Insertion at the first playback frame expands that window instead of moving its start.
    const start = !remove && begin === 0 ? origin : mapped(0) + origin,
      end = mapped(Number(time.EndFrame) - origin) + origin
    timelineRange(fps, start, end)
    clip.update('TimeLine', time.MainId, {
      StartFrame: start,
      EndFrame: end,
      CurrentFrame: Math.max(start, Math.min(end - 1, Number(time.CurrentFrame))),
      SmallestStartFrame: Math.min(Number(time.SmallestStartFrame), start),
      BiggestEndFrame: Math.max(Number(time.BiggestEndFrame), end),
    })
  }
  return changed
}
