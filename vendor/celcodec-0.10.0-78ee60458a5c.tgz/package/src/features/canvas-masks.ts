import { check } from '../internal/binary.js'
import { readAttribute } from '../internal/raster.js'
import { blob, type ClipContainer, type Row } from '../native/container.js'
import { mipmapChain, writeMipmap } from '../native/layers.js'
import { decodeRaster, placePixels } from '../native/raster.js'

/** CSP saves static masks on the canvas tile grid, independently of layer/mask linking. */
export function alignCanvasMask(clip: ClipContainer, row: Row, placement: Row): Row {
  if (!row.LayerLayerMaskMipmap || row.TimeLineOriginalMaskMipmap) return {}
  const off = mipmapChain(clip, row.LayerLayerMaskMipmap)[0]!.off,
    attribute = blob(off.Attribute),
    size = readAttribute(attribute),
    layerX = Number(placement.LayerOffsetX ?? row.LayerOffsetX),
    layerY = Number(placement.LayerOffsetY ?? row.LayerOffsetY),
    maskX = Number(placement.LayerMaskOffsetX ?? row.LayerMaskOffsetX),
    maskY = Number(placement.LayerMaskOffsetY ?? row.LayerMaskOffsetY),
    x = layerX + maskX + Number(row.LayerMaskOffscrOffsetX),
    y = layerY + maskY + Number(row.LayerMaskOffscrOffsetY)
  check([x, y].every(Number.isSafeInteger), 'UNSUPPORTED_CANVAS_EDIT', {
    reason: 'mask-placement',
  })
  const left = Math.floor(x / 256) * 256,
    top = Math.floor(y / 256) * 256,
    width = Math.ceil((x + size.width - left) / 256) * 256,
    height = Math.ceil((y + size.height - top) / 256) * 256
  if (x === left && y === top && width === size.width && height === size.height) return {}
  // Retain the entire mask, even outside the canvas, and its infinite default value.
  // Only pad its occupied tile rectangle; do not allocate a full-canvas bitmap.
  const pixels = placePixels(
    decodeRaster(attribute, clip.body(off.BlockData), clip.imageLimits),
    width,
    height,
    x - left,
    y - top,
    clip.imageLimits,
  )
  return {
    LayerLayerMaskMipmap: writeMipmap(clip, row, pixels, clip, row, true),
    LayerMaskOffscrOffsetX: left - layerX - maskX,
    LayerMaskOffscrOffsetY: top - layerY - maskY,
  }
}
