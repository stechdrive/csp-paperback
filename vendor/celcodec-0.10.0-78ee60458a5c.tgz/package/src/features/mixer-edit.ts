import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { view } from '../native/binary.js'
import { BincDocument, bincWriteLimits, type BincNode } from '../native/binc.js'
import { inflateBounded } from '../native/compression.js'
import { packedMixer } from '../native/animation.js'
import { readKeyframeTrack, type KeyframeClip } from '../native/keyframes.js'
import type { ClipContainer, Row } from '../native/container.js'

export const close = (a: number, b: number) =>
  Math.abs(a - b) <= 1e-8 * Math.max(1, Math.abs(a), Math.abs(b))
export function child(node: BincNode, name: string): BincNode {
  const found = node.children.filter((n) => n.name === name)
  check(found.length === 1, 'INVALID_KEYFRAME_STRUCTURE', { field: name })
  return found[0]!
}
export function setScalar(node: BincNode, name: string, value: number): void {
  const target = child(node, name)
  check(
    target.kind === 'Double' && target.values.length === 1 && Number.isFinite(value),
    'UNSUPPORTED_TIMELINE_EDIT',
    { field: name },
  )
  target.values = [value]
}

/** Edits only verified timing envelopes. Curve payloads, tags and opaque siblings are retained. */
export function editTrackMixers(
  clip: ClipContainer,
  track: Row,
  timeline: Row,
  update: (general: BincNode, values: readonly KeyframeClip[], secondary: boolean) => void,
  signal?: AbortSignal,
): boolean {
  const kind = Number(track.TrackKind),
    static3D = [3000, 3102, 3103, 3104, 3106].includes(kind)
  check(
    [1000, 2000, 2001, 2003, 2005, 4000, 4001].includes(kind) || static3D,
    'UNSUPPORTED_TIMELINE_EDIT',
    { trackId: Number(track.MainId) },
  )
  let reference: readonly KeyframeClip[] | undefined
  const changes: Row = {}
  for (const field of ['TrackActionMixer', 'TrackActionMixer2']) {
    checkCancelled(signal)
    const body = clip.body(track[field])
    if (!body) {
      check(!track[field], 'MISSING_BINARY_COLUMN', { field })
      continue
    }
    const size = Number(track[`${field}Size`])
    check(
      Number.isSafeInteger(size) && size >= 16 && size <= bincWriteLimits.bytes,
      'LIMIT_BINC_BYTES',
    )
    const parsed = readKeyframeTrack(body, size, {
      fps: Number(timeline.FrameRate),
      startFrame: Number(timeline.StartFrame),
      signal,
    })
    check(
      !parsed.diagnostics.some((d) =>
        ['UNSUPPORTED_KEYFRAME_VERSION', 'UNSUPPORTED_KEYFRAME_OVERLAP'].includes(d.code),
      ),
      'UNSUPPORTED_TIMELINE_EDIT',
      { reason: 'version-or-overlap' },
    )
    check(
      parsed.clips.every((c) => !c.blend?.enabled),
      'UNSUPPORTED_TIMELINE_EDIT',
      { reason: 'motion-blend' },
    )
    if (reference) {
      check(
        reference.length === parsed.clips.length &&
          reference.every((c, i) => {
            const other = parsed.clips[i]!
            return (
              ['time', 'motion'].every((k) => {
                const a = c[k as 'time' | 'motion'],
                  b = other[k as 'time' | 'motion']
                return (
                  close(a.start / a.rate, b.start / b.rate) && close(a.end / a.rate, b.end / b.rate)
                )
              }) && close(c.curveRate, other.curveRate)
            )
          }),
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'mixer-timing-mismatch' },
      )
    } else reference = parsed.clips
    check(view(body).getUint32(0, true) === body.length - 4, 'INVALID_PACKED_BINC_SIZE')
    const doc = new BincDocument(
      inflateBounded(body.subarray(4), size, signal),
      bincWriteLimits,
      signal,
    )
    const general = child(doc.root, 'General')
    // PAINT creates these tracks for static 3D, including old-format materials
    // (3102) and 3D under a keyed 2D camera folder.
    // Only the empty layer envelope participates in time edits. Scene/model data
    // and the empty camera/light/object tracks remain byte-identical.
    if (static3D)
      check(
        kind === 3000
          ? general.children.every((n) => child(n, 'AnimInfo').children.length === 0)
          : general.children.length === 0,
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'animated-3d-track', trackId: Number(track.MainId) },
      )
    check(
      general.children.every((n) => n.name === 'ActionNodeClip'),
      'UNSUPPORTED_TIMELINE_EDIT',
      { reason: 'unknown-clip-envelope' },
    )
    for (const node of general.children) {
      check(
        node.children.every((n) =>
          ['TimeClip', 'MotionClip', 'MotionBlend', 'TimeInfo', 'AnimInfo'].includes(n.name),
        ),
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'unknown-clip-envelope' },
      )
      for (const name of ['TimeClip', 'MotionClip'])
        check(
          child(node, name).children.every((n) => ['Start', 'End', 'Rate'].includes(n.name)),
          'UNSUPPORTED_TIMELINE_EDIT',
          { reason: 'unknown-clip-envelope' },
        )
      check(
        child(node, 'TimeInfo').children.every((n) => n.name === 'Rate'),
        'UNSUPPORTED_TIMELINE_EDIT',
        { reason: 'unknown-clip-envelope' },
      )
    }
    const before = JSON.stringify(doc.root)
    update(general, parsed.clips, doc.secondary)
    if (JSON.stringify(doc.root) === before) continue
    const raw = doc.encode(),
      packed = packedMixer(raw)
    const verified = readKeyframeTrack(packed, raw.length, {
      fps: Number(timeline.FrameRate),
      startFrame: Number(timeline.StartFrame),
      signal,
    })
    check(
      !verified.diagnostics.some((d) => d.code === 'UNSUPPORTED_KEYFRAME_OVERLAP'),
      'UNSUPPORTED_TIMELINE_EDIT',
      { reason: 'clip-overlap' },
    )
    changes[field] = clip.addExternal(packed)
    changes[`${field}Size`] = raw.length
  }
  check(reference, 'MISSING_BINARY_COLUMN')
  clip.update('Track', track.MainId, changes)
  Object.assign(track, changes)
  return Object.keys(changes).length > 0
}
