/** Unpremultiplied RGBA8, cropped bounds in the source offscreen coordinate system. */
export interface ClipPixels {
  width: number
  height: number
  left: number
  top: number
  rgba: Uint8ClampedArray
  /** Mask value outside the stored crop; not the image alpha. */
  defaultColor?: number
  disabled?: boolean
}

/** Must enforce limit while inflating; caller verifies the final byte count too. */
export type Inflate = (
  bytes: Uint8Array,
  limit: number,
  signal?: AbortSignal,
) => Promise<Uint8Array>
