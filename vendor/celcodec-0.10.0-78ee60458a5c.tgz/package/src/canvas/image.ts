import { numberAt, clampedAt } from '../internal/indexed.js'
import { check } from '../internal/binary.js'
import type { ClipLayer, ClipPixels } from '../material/types.js'
import type { MaterialQuad, TextObject } from '../material/types.js'

import { type CanvasSurface, type CanvasContext, type CanvasFactory, context } from './types.js'
import { checkCancelled } from '../diagnostics.js'
import { inverseQuad, intersectRegion, quadSourceRegion } from '../internal/image-region.js'
import type { ImageRegion } from '../image-resources.js'
import {
  resolveImageLimits,
  checkImageAllocation,
  type ImageResourceLimits,
} from '../image-resources.js'

/** Each instance owns its canvas factory and allocation scope. No global DOM is accessed. */
export function createCanvasRenderer<C extends CanvasSurface>(
  factory: CanvasFactory<C>,
  options: {
    maxBytes?: number
    signal?: AbortSignal
    release?: (canvas: C) => void
    imageLimits?: ImageResourceLimits
  } = {},
) {
  let allocated = 0
  const owned = new Map<C, number>()
  const limits = resolveImageLimits(
    options.imageLimits ??
      (options.maxBytes === undefined ? undefined : { maxBytes: options.maxBytes }),
  )
  const maxBytes = options.maxBytes ?? limits.maxBytes
  check(Number.isSafeInteger(maxBytes) && maxBytes >= 0, 'INVALID_LIMIT')
  const createCanvas = (width: number, height: number): C => {
    checkCancelled(options.signal)
    check(
      Number.isSafeInteger(width) && Number.isSafeInteger(height) && width > 0 && height > 0,
      'INVALID_IMAGE_DIMENSIONS',
    )
    checkImageAllocation(
      width,
      height,
      { ...limits, maxBytes: maxBytes - allocated },
      'LIMIT_CANVAS_BYTES',
    )
    const canvas = factory(width, height)
    try {
      check(
        canvas.width === width && canvas.height === height && !!canvas.getContext('2d'),
        'UNAVAILABLE_CANVAS',
      )
    } catch (error) {
      if (options.release) options.release(canvas)
      else {
        canvas.width = 1
        canvas.height = 1
      }
      throw error
    }
    owned.set(canvas, width * height * 4)
    allocated += width * height * 4
    return canvas
  }
  function pixelCanvas(pixels: ClipPixels): C {
    const canvas = createCanvas(pixels.width, pixels.height),
      ctx = context(canvas)
    const data = ctx.createImageData(pixels.width, pixels.height)
    data.data.set(pixels.rgba)
    ctx.putImageData(data, 0, 0)
    return canvas
  }

  function placeMaterial(
    pixels: ClipPixels,
    quad: MaterialQuad,
    region?: ImageRegion,
    source: ImageRegion = pixels,
  ): { canvas: C; left: number; top: number } {
    const xs = quad.filter((_, i) => i % 2 === 0),
      ys = quad.filter((_, i) => i % 2 !== 0)
    const qleft = Math.floor(Math.min(...xs)),
      qtop = Math.floor(Math.min(...ys)),
      extent = {
        left: qleft,
        top: qtop,
        width: Math.ceil(Math.max(...xs)) - qleft,
        height: Math.ceil(Math.max(...ys)) - qtop,
      },
      bounds = region ? intersectRegion(extent, region) : extent
    if (!bounds) return { canvas: createCanvas(1, 1), left: region!.left, top: region!.top }
    const { left, top, width, height } = bounds,
      cropX = pixels.left - source.left,
      cropY = pixels.top - source.top
    checkImageAllocation(
      width,
      height,
      { ...limits, maxBytes: maxBytes - allocated },
      'LIMIT_CANVAS_BYTES',
    )
    const canvas = createCanvas(width, height),
      ctx = context(canvas)
    if (
      Math.abs(quad[0] + quad[4] - quad[2] - quad[6]) < 1e-7 &&
      Math.abs(quad[1] + quad[5] - quad[3] - quad[7]) < 1e-7
    ) {
      const size = 128,
        pad = 2,
        tile = createCanvas(size + 2 * pad, size + 2 * pad)
      try {
        for (let ty = Math.floor(top / size) * size; ty < top + height; ty += size)
          for (let tx = Math.floor(left / size) * size; tx < left + width; tx += size) {
            checkCancelled(options.signal)
            tile.width = size + 2 * pad
            const tc = context(tile),
              bounds = quadSourceRegion(quad, source.width, source.height, {
                left: tx - pad,
                top: ty - pad,
                width: size + 2 * pad,
                height: size + 2 * pad,
              }),
              input = createCanvas(bounds.width, bounds.height),
              sc = context(input),
              upload = sc.createImageData(bounds.width, bounds.height),
              overlap = intersectRegion(bounds, {
                left: cropX,
                top: cropY,
                width: pixels.width,
                height: pixels.height,
              })
            if (overlap)
              for (let y = 0; y < overlap.height; y++) {
                const at = ((overlap.top - cropY + y) * pixels.width + overlap.left - cropX) * 4
                upload.data.set(
                  pixels.rgba.subarray(at, at + overlap.width * 4),
                  ((overlap.top - bounds.top + y) * bounds.width + overlap.left - bounds.left) * 4,
                )
              }
            sc.putImageData(upload, 0, 0)
            tc.setTransform(
              (quad[2] - quad[0]) / source.width,
              (quad[3] - quad[1]) / source.width,
              (quad[6] - quad[0]) / source.height,
              (quad[7] - quad[1]) / source.height,
              quad[0] - tx + pad,
              quad[1] - ty + pad,
            )
            try {
              tc.drawImage(input, bounds.left, bounds.top)
            } finally {
              release(input)
            }
            const lx = Math.max(tx, left),
              ly = Math.max(ty, top),
              w = Math.min(tx + size, left + width) - lx,
              h = Math.min(ty + size, top + height) - ly
            ctx.putImageData(
              tc.getImageData(lx - tx + pad, ly - ty + pad, w, h),
              lx - left,
              ly - top,
            )
          }
      } finally {
        release(tile)
      }
    } else {
      const m = inverseQuad(quad),
        data = ctx.createImageData(width, height),
        src = pixels.rgba
      for (let y = 0; y < height; y++)
        for (let x = 0; x < width; x++) {
          const dx = x + left + 0.5,
            dy = y + top + 0.5,
            d = numberAt(m, 6) * dx + numberAt(m, 7) * dy + 1
          const u = (numberAt(m, 0) * dx + numberAt(m, 1) * dy + numberAt(m, 2)) / d,
            v = (numberAt(m, 3) * dx + numberAt(m, 4) * dy + numberAt(m, 5)) / d
          if (u < 0 || v < 0 || u >= 1 || v >= 1) continue
          const sx = u * source.width - 0.5,
            sy = v * source.height - 0.5,
            ix = Math.floor(sx),
            iy = Math.floor(sy)
          const fx = sx - ix,
            fy = sy - iy,
            at = (y * width + x) * 4,
            sum: [number, number, number, number] = [0, 0, 0, 0]
          for (let j = 0; j < 2; j++)
            for (let i = 0; i < 2; i++) {
              const px = Math.max(0, Math.min(source.width - 1, ix + i)) - cropX,
                py = Math.max(0, Math.min(source.height - 1, iy + j)) - cropY
              check(
                px >= 0 && py >= 0 && px < pixels.width && py < pixels.height,
                'INVALID_PLACEMENT',
              )
              const pos = (py * pixels.width + px) * 4,
                weight = (i ? fx : 1 - fx) * (j ? fy : 1 - fy),
                alpha = clampedAt(src, pos + 3) / 255
              for (let c = 0; c < 3; c++)
                sum[c] = numberAt(sum, c) + clampedAt(src, pos + c) * alpha * weight
              sum[3] += alpha * weight
            }
          for (let c = 0; c < 3; c++)
            data.data[at + c] = numberAt(sum, 3) > 0 ? numberAt(sum, c) / numberAt(sum, 3) : 0
          data.data[at + 3] = numberAt(sum, 3) * 255
        }
      ctx.putImageData(data, 0, 0)
    }
    return { canvas, left, top }
  }

  /** Basic browser text rendering. Cached CSP pixels always take precedence. */
  function drawTextObject(ctx: CanvasContext, text: TextObject): void {
    ctx.save()
    ctx.textBaseline = 'top'
    let offset = 0,
      y = text.top
    let line: { char: string; font: string; size: number; color: number[]; width: number }[] = []
    let lineWidth = 0,
      lineHeight = text.size * 1.2
    let afterCarriageReturn = false
    const flush = () => {
      let x =
        text.left +
        (text.align === 'center'
          ? (text.width - lineWidth) / 2
          : text.align === 'right'
            ? text.width - lineWidth
            : 0)
      for (const glyph of line) {
        ctx.font = `${glyph.size}px ${JSON.stringify(glyph.font)}, sans-serif`
        ctx.fillStyle = `rgb(${glyph.color.join(',')})`
        ctx.fillText(glyph.char, x, y)
        x += glyph.width
      }
      y += lineHeight
      line = []
      lineWidth = 0
      lineHeight = text.size * 1.2
    }
    for (const char of text.text) {
      const style = text.runs.find((r) => offset >= r.start && offset < r.start + r.length) ?? text
      offset += char.length
      // Run offsets use the original UTF-16 string, including both characters of CRLF.
      if (char === '\r') {
        flush()
        afterCarriageReturn = true
        continue
      }
      if (char === '\n') {
        if (!afterCarriageReturn) flush()
        afterCarriageReturn = false
        continue
      }
      afterCarriageReturn = false
      ctx.font = `${style.size}px ${JSON.stringify(style.font)}, sans-serif`
      const width = ctx.measureText(char).width
      if (text.width > 0 && line.length && lineWidth + width > text.width) flush()
      line.push({ char, font: style.font, size: style.size, color: style.color, width })
      lineWidth += width
      lineHeight = Math.max(lineHeight, style.size * 1.2)
    }
    flush()
    ctx.restore()
  }

  function renderClipMaterial(
    layer: ClipLayer,
    width: number,
    height: number,
    region?: ImageRegion,
  ): { canvas: C; left: number; top: number } | undefined {
    const bounds = region ?? { left: 0, top: 0, width, height }
    if (layer.adjustment) {
      const canvas = createCanvas(bounds.width, bounds.height),
        ctx = context(canvas)
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, 0, bounds.width, bounds.height)
      return { canvas, left: bounds.left, top: bounds.top }
    }
    if (layer.pixels && !layer.text?.length && !layer.fragments?.length) {
      return layer.placement
        ? placeMaterial(layer.pixels, layer.placement, region, layer.placementSource)
        : { canvas: pixelCanvas(layer.pixels), left: layer.pixels.left, top: layer.pixels.top }
    }
    if (!layer.pixels && !layer.fragments?.length && !layer.text?.length) return
    const canvas = createCanvas(bounds.width, bounds.height),
      ctx = context(canvas)
    ctx.setTransform(1, 0, 0, 1, -bounds.left, -bounds.top)
    for (const pixels of [...(layer.pixels ? [layer.pixels] : []), ...(layer.fragments ?? [])])
      ctx.drawImage(pixelCanvas(pixels), pixels.left, pixels.top)
    for (const text of layer.text ?? []) drawTextObject(ctx, text)
    return { canvas, left: bounds.left, top: bounds.top }
  }

  const release = (canvas: C): void => {
    const bytes = owned.get(canvas)
    if (bytes !== undefined) {
      owned.delete(canvas)
      allocated -= bytes
      if (options.release) options.release(canvas)
      else {
        canvas.width = 1
        canvas.height = 1
      }
    }
  }
  const detach = (canvas: C): C => {
    const bytes = owned.get(canvas)
    if (bytes !== undefined) {
      owned.delete(canvas)
      allocated -= bytes
    }
    return canvas
  }
  const dispose = (): void => {
    for (const canvas of owned.keys()) release(canvas)
  }
  return {
    pixelCanvas,
    placeMaterial,
    drawTextObject,
    renderClipMaterial,
    release,
    detach,
    dispose,
    get allocatedBytes() {
      return allocated
    },
  }
}
