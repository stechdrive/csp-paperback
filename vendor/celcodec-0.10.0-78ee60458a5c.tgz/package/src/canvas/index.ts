export { createCanvasRenderer } from './image.js'
export type { CanvasSurface, CanvasFactory, CanvasContext, PixelImage } from './types.js'
export { applyLayerColor } from './layer-color.js'
import { applyLayerColor } from './layer-color.js'
import { applyEdge as edge } from './edge-effect.js'
import { applyWatercolor as watercolor } from './watercolor-effect.js'
import { check } from '../internal/binary.js'
import { checkCancelled, diagnostic, type ClipDiagnostic } from '../diagnostics.js'
import type { EdgeEffect, WatercolorEffect, MaterialEffects } from '../material/types.js'
export type {
  MaterialEffects,
  MaterialAdjustment,
  EdgeEffect,
  WatercolorEffect,
} from '../material/types.js'
export interface PixelEffectOptions {
  signal?: AbortSignal
  maxWorkingBytes?: number
}
function validate(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  working: number,
  options: PixelEffectOptions,
) {
  checkCancelled(options.signal)
  check(
    Number.isInteger(width) &&
      Number.isInteger(height) &&
      width > 0 &&
      height > 0 &&
      data.length === width * height * 4,
    'INVALID_PIXEL_LENGTH',
  )
  const limit = options.maxWorkingBytes ?? 512 * 1024 * 1024
  check(Number.isSafeInteger(limit) && limit >= 0, 'INVALID_LIMIT')
  check(working <= limit, 'LIMIT_MATERIAL_BYTES')
}
export function applyEdge(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  effect: EdgeEffect,
  options: PixelEffectOptions = {},
) {
  validate(data, width, height, width * height * 5 + width * 4, options)
  check(
    Number.isFinite(effect.radius) &&
      effect.radius >= 0 &&
      effect.radius <= 256 &&
      effect.color.length === 3 &&
      effect.color.every((c) => Number.isFinite(c) && c >= 0 && c <= 255),
    'INVALID_EDGE_RADIUS',
  )
  edge(data, width, height, effect)
}
export function applyWatercolor(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  effect: WatercolorEffect,
  options: PixelEffectOptions = {},
): ClipDiagnostic[] {
  validate(data, width, height, data.length + 320 * 320 * 40, options)
  check(
    [effect.range, effect.opacity, effect.darkness, effect.blur].every(Number.isFinite) &&
      effect.range >= 0 &&
      effect.range <= 20 &&
      effect.opacity >= 0 &&
      effect.opacity <= 100 &&
      effect.darkness >= 0 &&
      effect.darkness <= 100 &&
      effect.blur >= 0 &&
      effect.blur <= 10,
    'INVALID_WATERCOLOR_SETTINGS',
  )
  if (effect.style) return [diagnostic('UNSUPPORTED_WATERCOLOR_STYLE')]
  watercolor(data, width, height, effect)
  return [diagnostic('APPROXIMATE_WATERCOLOR')]
}
export { applyAdjustment } from '../render/adjustment.js'

export function applyMaterialEffects(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  effects: MaterialEffects | undefined,
  options: PixelEffectOptions = {},
): ClipDiagnostic[] {
  validate(data, width, height, 0, options)
  const diagnostics: ClipDiagnostic[] = []
  if (effects?.layerColor) applyLayerColor(data, effects.layerColor)
  if (effects?.watercolor)
    diagnostics.push(...applyWatercolor(data, width, height, effects.watercolor, options))
  if (effects?.edge) applyEdge(data, width, height, effects.edge, options)
  if (effects?.tone) diagnostics.push(diagnostic('UNSUPPORTED_TONE'))
  return diagnostics
}
