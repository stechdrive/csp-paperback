import { clampedAt, numberAt } from '../internal/indexed.js'
// Extracted from csp-paperback (MIT); see docs/provenance.json.
import type { MaterialEffects } from '../material/types.js'
export function applyLayerColor(
  data: Uint8ClampedArray,
  color: NonNullable<MaterialEffects['layerColor']>,
): void {
  for (let i = 0; i < data.length; i += 4) {
    if (!data[i + 3]) continue
    // Coefficients recovered from native gray/R/G/B ramps and mixed-color pixels.
    const gray = Math.min(
      255,
      Math.floor(
        (298912 * clampedAt(data, i) +
          586611 * clampedAt(data, i + 1) +
          114478 * clampedAt(data, i + 2)) /
          1000000,
      ),
    )
    for (let c = 0; c < 3; c++)
      data[i + c] = Math.round(
        (numberAt(color.main, c) * (255 - gray) + numberAt(color.sub, c) * gray) / 255,
      )
  }
}
