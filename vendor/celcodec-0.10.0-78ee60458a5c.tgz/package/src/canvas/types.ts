/** Structural environment boundary; HTMLCanvasElement, OffscreenCanvas and native canvases fit. */
export interface CanvasSurface {
  width: number
  height: number
  getContext(type: '2d'): unknown
}
export type CanvasFactory<C extends CanvasSurface = CanvasSurface> = (
  width: number,
  height: number,
) => C
export interface PixelImage {
  width: number
  height: number
  data: Uint8ClampedArray
}
export interface CanvasContext {
  createImageData(width: number, height: number): PixelImage
  putImageData(image: PixelImage, x: number, y: number): void
  getImageData(x: number, y: number, width: number, height: number): PixelImage
  drawImage(source: CanvasSurface, x: number, y: number): void
  setTransform(a: number, b: number, c: number, d: number, e: number, f: number): void
  resetTransform(): void
  save(): void
  restore(): void
  fillRect(x: number, y: number, width: number, height: number): void
  measureText(text: string): { width: number }
  fillText(text: string, x: number, y: number): void
  fillStyle: string
  font: string
  textBaseline: string
}
export function context(canvas: CanvasSurface): CanvasContext {
  return canvas.getContext('2d') as CanvasContext
}
