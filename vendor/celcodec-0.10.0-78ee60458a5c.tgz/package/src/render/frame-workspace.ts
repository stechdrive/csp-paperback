import { check } from '../internal/binary.js'
import {
  context,
  type CanvasFactory,
  type CanvasSurface,
  type PixelImage,
} from '../canvas/types.js'

/** At most one upload and two surfaces, borrowed only within a single frame. */
export function createTransformWorkspace(
  factory: CanvasFactory,
  reserve: (bytes: number) => void,
  release: (bytes: number) => void,
) {
  let source: CanvasSurface | undefined,
    target: CanvasSurface | undefined,
    upload: PixelImage | undefined,
    sourceBytes = 0,
    targetBytes = 0
  const dropSource = () => {
    if (source) {
      source.width = 1
      source.height = 1
    }
    source = undefined
    upload = undefined
    release(sourceBytes)
    sourceBytes = 0
  }
  const dropTarget = () => {
    if (target) {
      target.width = 1
      target.height = 1
    }
    target = undefined
    release(targetBytes)
    targetBytes = 0
  }
  const clear = () => {
    dropSource()
    dropTarget()
  }
  const validate = (surface: CanvasSurface, w: number, h: number) =>
    check(
      surface.width === w && surface.height === h && surface.getContext('2d'),
      'UNAVAILABLE_CANVAS',
    )
  return {
    clear,
    prepare(sw: number, sh: number, tw: number, th: number, available: number) {
      // Count both surfaces, the source upload and the independently owned readback.
      check(
        sw * sh * 8 + tw * th * 8 <= available + sourceBytes + targetBytes,
        'LIMIT_FRAME_RENDER_BYTES',
      )
      if (source?.width !== sw || source.height !== sh) dropSource()
      if (target?.width !== tw || target.height !== th) dropTarget()
      if (target) {
        const tc = context(target) as ReturnType<typeof context> & {
          clearRect?: (x: number, y: number, w: number, h: number) => void
        }
        // Existing structural Canvas adapters need not implement clearRect.
        if (typeof tc.clearRect === 'function') {
          tc.setTransform(1, 0, 0, 1, 0, 0)
          tc.clearRect(0, 0, tw, th)
        } else dropTarget()
      }
      try {
        if (!source) {
          reserve(sw * sh * 8)
          sourceBytes = sw * sh * 8
          source = factory(sw, sh)
          validate(source, sw, sh)
          upload = context(source).createImageData(sw, sh)
        }
        if (!target) {
          reserve(tw * th * 4)
          targetBytes = tw * th * 4
          target = factory(tw, th)
          validate(target, tw, th)
        }
        return { source, target, upload: upload! }
      } catch (error) {
        clear()
        throw error
      }
    },
  }
}

export type TransformWorkspace = ReturnType<typeof createTransformWorkspace>
