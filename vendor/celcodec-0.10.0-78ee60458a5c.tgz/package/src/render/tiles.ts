import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { imageByteLength, type ImageRegion } from '../image-resources.js'
import { compositeLayers } from './composite.js'
import type { CompositeLayer, CompositeOptions, CompositeResult } from './types.js'

export interface CompositeTileOptions extends CompositeOptions {
  tileWidth?: number
  tileHeight?: number
}
/** A provider returns document-space pixels/masks covering the requested region.
 * Preserve the layer tree, clipping, mask defaults and adjustment nodes. Effects
 * needing neighbor pixels must be evaluated with their halo before returning. */
export type CompositeTileSource =
  | readonly CompositeLayer[]
  | ((
      region: Readonly<ImageRegion>,
    ) => readonly CompositeLayer[] | Promise<readonly CompositeLayer[]>)

/** Pull-based output, without a full output bitmap or Canvas. Defaults to 256px
 * tiles. Set tileWidth=width for PNG row strips. Budgets apply per tile; retained
 * inputs/results belong to the caller. Providers are called only as consumed. */
export async function* compositeLayerTiles(
  layers: CompositeTileSource,
  width: number,
  height: number,
  options: CompositeTileOptions = {},
): AsyncGenerator<CompositeResult> {
  imageByteLength(width, height)
  const tw = options.tileWidth ?? 256,
    th = options.tileHeight ?? 256,
    left = options.left ?? 0,
    top = options.top ?? 0
  check(
    [tw, th].every((v) => Number.isSafeInteger(v) && v > 0),
    'INVALID_IMAGE_DIMENSIONS',
  )
  check([left, top, left + width, top + height].every(Number.isSafeInteger), 'INVALID_PLACEMENT')
  // Snapshot policy, but borrow pixel inputs as in compositeLayers().
  options = {
    ...options,
    ...(options.imageLimits ? { imageLimits: { ...options.imageLimits } } : {}),
  }
  for (let y = 0; y < height; y += th)
    for (let x = 0; x < width; x += tw) {
      checkCancelled(options.signal)
      const region = Object.freeze({
          left: left + x,
          top: top + y,
          width: Math.min(tw, width - x),
          height: Math.min(th, height - y),
        }),
        nodes = typeof layers === 'function' ? await layers(region) : layers
      checkCancelled(options.signal)
      yield compositeLayers(nodes, region.width, region.height, {
        ...options,
        left: region.left,
        top: region.top,
      })
    }
}
