import { check } from '../internal/binary.js'
import { checkCancelled, diagnostic } from '../diagnostics.js'
import type { ClipPixels } from '../types.js'
import type { CompositeLayer, CompositeOptions, CompositeResult } from './types.js'
import { blendInto, isClipBlendMode } from './blend.js'
import { compileAdjustment, type AdjustPixel } from './adjustment.js'
import { maskAt } from './pixel-mask.js'
import { resolveImageLimits, rgbaBuffer } from '../image-resources.js'

const TILE = 128
function validatePixels(p: ClipPixels): void {
  check(
    Number.isSafeInteger(p.width) &&
      p.width > 0 &&
      Number.isSafeInteger(p.height) &&
      p.height > 0 &&
      p.rgba instanceof Uint8ClampedArray &&
      p.rgba.length === p.width * p.height * 4,
    'INVALID_PIXEL_LENGTH',
  )
  check(
    Number.isSafeInteger(p.left) &&
      Number.isSafeInteger(p.top) &&
      Number.isSafeInteger(p.left + p.width) &&
      Number.isSafeInteger(p.top + p.height),
    'INVALID_PLACEMENT',
  )
  check(
    p.defaultColor === undefined ||
      (Number.isInteger(p.defaultColor) && p.defaultColor >= 0 && p.defaultColor <= 255),
    'INVALID_COMPOSITE_LAYER',
  )
  check(p.disabled === undefined || typeof p.disabled === 'boolean', 'INVALID_COMPOSITE_LAYER')
}
/** Composite a top-to-bottom layer tree into an owned straight RGBA8 rectangle.
 * Inputs are not modified. No Canvas, document cache, color-profile conversion,
 * cel selection or application output policy is implicit in this operation. */
export function compositeLayers(
  layers: readonly CompositeLayer[],
  width: number,
  height: number,
  options: CompositeOptions = {},
): CompositeResult {
  checkCancelled(options.signal)
  const background = options.background
  check(
    background === undefined ||
      (Array.isArray(background) &&
        background.length === 4 &&
        background.every((v) => Number.isInteger(v) && v >= 0 && v <= 255)),
    'INVALID_COMPOSITE_LAYER',
  )
  const left = options.left ?? 0,
    top = options.top ?? 0,
    maxBytes = options.maxWorkingBytes ?? options.imageLimits?.maxBytes ?? 512 * 1024 * 1024,
    maxLayers = options.maxLayers ?? 100_000,
    maxDepth = options.maxDepth ?? 64
  check(
    [maxBytes, maxLayers, maxDepth].every((v) => Number.isSafeInteger(v) && v >= 0),
    'INVALID_LIMIT',
  )
  check(
    [width, height].every((v) => Number.isSafeInteger(v) && v > 0),
    'INVALID_IMAGE_DIMENSIONS',
  )
  check([left, top, left + width, top + height].every(Number.isSafeInteger), 'INVALID_PLACEMENT')
  let allocated = width * height * 4,
    count = 0
  check(Number.isSafeInteger(allocated) && allocated <= maxBytes, 'LIMIT_COMPOSITE_BYTES')
  if (options.imageLimits)
    check(width * height <= resolveImageLimits(options.imageLimits).maxPixels, 'LIMIT_IMAGE_PIXELS')
  const ancestors = new Set<CompositeLayer>()
  const adjustments = new Map<CompositeLayer, AdjustPixel>()
  function validate(nodes: readonly CompositeLayer[], depth: number): void {
    check(Array.isArray(nodes) && depth <= maxDepth, 'INVALID_COMPOSITE_LAYER')
    for (let i = nodes.length - 1; i >= 0; i--) {
      checkCancelled(options.signal)
      check(++count <= maxLayers, 'LIMIT_COMPOSITE_LAYERS')
      const node = nodes[i]!
      check(!!node && !ancestors.has(node), 'INVALID_COMPOSITE_LAYER')
      check(
        node.visible === undefined || typeof node.visible === 'boolean',
        'INVALID_COMPOSITE_LAYER',
      )
      check(
        node.clipping === undefined || typeof node.clipping === 'boolean',
        'INVALID_COMPOSITE_LAYER',
      )
      const opacity = node.opacity ?? 1,
        mode = node.blendMode ?? 0
      check(Number.isFinite(opacity) && opacity >= 0 && opacity <= 1, 'INVALID_COMPOSITE_LAYER')
      check(isClipBlendMode(mode), 'UNSUPPORTED_COMPOSITE_MODE', { mode })
      check(mode !== 30 || node.kind === 'group', 'UNSUPPORTED_COMPOSITE_STRUCTURE')
      if (node.mask) validatePixels(node.mask)
      if (node.kind === 'pixels') validatePixels(node.pixels)
      else if (node.kind === 'group') {
        ancestors.add(node)
        validate(node.children, depth + 1)
        ancestors.delete(node)
      } else if (node.kind === 'adjustment') {
        // Conservatively reserve the maximum RGB lookup table per node.
        allocated += 768
        check(allocated <= maxBytes, 'LIMIT_COMPOSITE_BYTES')
        adjustments.set(node, compileAdjustment(node.adjustment))
      } else check(false, 'UNSUPPORTED_COMPOSITE_STRUCTURE')
    }
  }
  validate(layers, 0)
  const rgba = rgbaBuffer(width * height * 4),
    tileBytes = Math.min(TILE, width) * Math.min(TILE, height) * 4,
    pool: Uint8ClampedArray[] = []
  const take = () => {
    let buffer = pool.pop()
    if (!buffer) {
      check(allocated + tileBytes <= maxBytes, 'LIMIT_COMPOSITE_BYTES')
      buffer = rgbaBuffer(tileBytes)
      allocated += tileBytes
    } else buffer.fill(0)
    return buffer
  }
  const release = (buffer: Uint8ClampedArray) => {
    pool.push(buffer)
  }
  for (let ty = 0; ty < height; ty += TILE)
    for (let tx = 0; tx < width; tx += TILE) {
      checkCancelled(options.signal)
      const tw = Math.min(TILE, width - tx),
        th = Math.min(TILE, height - ty),
        n = tw * th * 4,
        ox = left + tx,
        oy = top + ty
      function mix(
        dest: Uint8ClampedArray,
        rendered: Uint8ClampedArray,
        node: CompositeLayer,
      ): void {
        for (let i = 0; i < n; i += 4) {
          const opacity =
              (node.opacity ?? 1) *
              maskAt(node.mask, ox + ((i / 4) % tw), oy + Math.floor(i / 4 / tw)),
            a = dest[i + 3]! * (1 - opacity),
            b = rendered[i + 3]! * opacity,
            alpha = a + b
          for (let c = 0; c < 3; c++)
            dest[i + c] = alpha ? Math.round((dest[i + c]! * a + rendered[i + c]! * b) / alpha) : 0
          dest[i + 3] = Math.round(alpha)
        }
      }
      function blend(
        dest: Uint8ClampedArray,
        source: Uint8ClampedArray,
        node: CompositeLayer,
      ): void {
        const mode = node.blendMode === 30 ? 0 : (node.blendMode ?? 0),
          opacity = node.opacity ?? 1
        if (!node.mask || node.mask.disabled) {
          for (let i = 0; i < n; i += 4) blendInto(dest, i, source, i, mode, opacity)
          return
        }
        for (let i = 0; i < n; i += 4)
          blendInto(
            dest,
            i,
            source,
            i,
            // A pass-through folder participating in a clipping chain is isolated.
            mode,
            opacity * maskAt(node.mask, ox + ((i / 4) % tw), oy + Math.floor(i / 4 / tw)),
          )
      }
      function source(node: CompositeLayer): Uint8ClampedArray {
        const buffer = take()
        if (node.kind === 'group') stack(node.children, buffer)
        else if (node.kind === 'pixels') {
          const p = node.pixels,
            x0 = Math.max(ox, p.left),
            x1 = Math.min(ox + tw, p.left + p.width),
            y0 = Math.max(oy, p.top),
            y1 = Math.min(oy + th, p.top + p.height)
          if (x1 > x0)
            for (let y = y0; y < y1; y++) {
              const start = ((y - p.top) * p.width + x0 - p.left) * 4
              buffer.set(
                p.rgba.subarray(start, start + (x1 - x0) * 4),
                ((y - oy) * tw + x0 - ox) * 4,
              )
            }
        }
        return buffer
      }
      function draw(node: CompositeLayer, dest: Uint8ClampedArray, clipped = false): void {
        checkCancelled(options.signal)
        if (node.visible === false || node.opacity === 0) return
        if (node.kind === 'pixels') {
          // Blend the intersecting source rows directly. Sparse cels need neither
          // a cleared/copied source tile nor a scan of the surrounding canvas.
          const p = node.pixels,
            x0 = Math.max(ox, p.left),
            x1 = Math.min(ox + tw, p.left + p.width),
            y0 = Math.max(oy, p.top),
            y1 = Math.min(oy + th, p.top + p.height),
            mode = node.blendMode ?? 0,
            opacity = node.opacity ?? 1,
            mask = node.mask?.disabled ? undefined : node.mask
          for (let y = y0; y < y1; y++) {
            let si = ((y - p.top) * p.width + x0 - p.left) * 4,
              di = ((y - oy) * tw + x0 - ox) * 4
            for (let x = x0; x < x1; x++, si += 4, di += 4)
              blendInto(dest, di, p.rgba, si, mode, mask ? opacity * maskAt(mask, x, y) : opacity)
          }
        } else if (node.kind === 'adjustment') {
          const corrected = take(),
            apply = adjustments.get(node)!
          corrected.set(dest)
          for (let i = 0; i < n; i += 4) {
            apply(corrected, i)
            const alpha = dest[i + 3]!
            corrected[i + 3] = dest[i + 3] = 255
            blendInto(
              dest,
              i,
              corrected,
              i,
              node.blendMode ?? 0,
              (node.opacity ?? 1) *
                maskAt(node.mask, ox + ((i / 4) % tw), oy + Math.floor(i / 4 / tw)),
            )
            dest[i + 3] = alpha
          }
          release(corrected)
        } else if (node.kind === 'group' && node.blendMode === 30 && !clipped) {
          const rendered = take()
          rendered.set(dest)
          stack(node.children, rendered)
          mix(dest, rendered, node)
          release(rendered)
        } else {
          const pixels = source(node)
          blend(dest, pixels, node)
          release(pixels)
        }
      }
      function stack(nodes: readonly CompositeLayer[], dest: Uint8ClampedArray): void {
        for (let i = nodes.length - 1; i >= 0; i--) {
          const base = nodes[i]!
          let last = i
          while (last > 0 && nodes[last - 1]!.clipping) last--
          // CSP retains the stored clipping flags but ignores the entire chain
          // when there is no sibling base, or that base is backdrop-dependent.
          // Do not promote an ignored clipped sibling to become a new base.
          const hasBase = !base.clipping && base.kind !== 'adjustment' && base.blendMode !== 30
          if (last === i || !hasBase) {
            for (let j = i; j >= last; j--) draw(nodes[j]!, dest)
          } else if (base.visible !== false && base.opacity !== 0) {
            checkCancelled(options.signal)
            // Clip colors are composited against an opaque base, then the base's
            // original alpha, mask, opacity and blend mode apply to the chain once.
            const pixels = source(base),
              original = take()
            original.set(pixels)
            for (let j = 3; j < n; j += 4) pixels[j] = 255
            for (let j = i - 1; j >= last; j--) draw(nodes[j]!, pixels, true)
            for (let j = 3; j < n; j += 4) pixels[j] = original[j]!
            blend(dest, pixels, base)
            release(original)
            release(pixels)
          }
          i = last
        }
      }
      const tile = take()
      if (background && background[3]) for (let i = 0; i < n; i += 4) tile.set(background, i)
      stack(layers, tile)
      for (let y = 0; y < th; y++)
        rgba.set(tile.subarray(y * tw * 4, (y + 1) * tw * 4), ((ty + y) * width + tx) * 4)
      release(tile)
    }
  return {
    pixels: { width, height, left, top, rgba },
    diagnostics: [
      ...(count ? [diagnostic('APPROXIMATE_COMPOSITING')] : []),
      ...(adjustments.size ? [diagnostic('APPROXIMATE_ADJUSTMENT')] : []),
    ],
  }
}
