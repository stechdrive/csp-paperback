import type {
  DocumentSession,
  LayerView,
  PlaybackFrame,
  PlaybackLayer,
  PlaybackFrameOptions,
  PlaybackTransform,
} from '../document/index.js'
import type { PlaybackPolicy } from '../document/playback-policy.js'
import { checkPlaybackPolicy } from '../document/playback-policy.js'
import type { ClipDiagnostic } from '../diagnostics.js'
import { checkCancelled, diagnostic } from '../diagnostics.js'
import { check } from '../internal/binary.js'
import {
  createSceneRenderer,
  blocking,
  type FrameRendererOptions,
  type FrameRenderOptions,
  type RenderView,
} from './frame.js'
import { renderRegions, type RenderTileOptions } from './regions.js'
import type { ClipPixels } from '../types.js'
import { isClipBlendMode } from './blend.js'

/** One placement in a drawing tree. IDs identify placements, not source UUIDs.
 * Siblings are top-to-bottom. Omitted children use the source folder's children;
 * an explicit empty array renders an empty folder while retaining its effects/mask. */
export interface RenderNode {
  readonly id: string
  /** Omit only for a synthetic group, which must supply children. */
  readonly layerId?: string
  readonly children?: readonly RenderNode[]
  readonly visible?: boolean
  readonly opacity?: number
  readonly blendMode?: number
  readonly clipping?: boolean
  readonly maskEnabled?: boolean
  /** Per-placement policies; override this node only, never descendants. */
  readonly camera?: PlaybackPolicy
  readonly layerKeyframes?: PlaybackPolicy
}
export interface RenderComposition {
  readonly layers: readonly RenderNode[]
  /** RGBA8 backdrop, before blend modes/adjustments; independent of native paper. */
  readonly background?: readonly [number, number, number, number]
}
export interface CompositionRendererOptions extends FrameRendererOptions {
  /** Default error. Omit incomplete source materials only, returning status partial.
   * Masks, transforms, effect/composition errors and resource failures remain strict. */
  missingMaterials?: 'error' | 'omit'
  /** Default original: no camera/keyframes or implicit timeline cel filtering. */
  source?: 'original' | 'saved'
  /** Enables time evaluation; source must be original. */
  timelineId?: string
  maxNodes?: number
  maxDepth?: number
}
export interface CompositionRenderOptions extends FrameRenderOptions {
  /** Required with timelineId; relative to playback start. Negative/fractional values are preserved. */
  frame?: number
}
export interface CompositionTileOptions extends CompositionRenderOptions, RenderTileOptions {}
export type CompositionRenderResult = {
  readonly diagnostics: readonly ClipDiagnostic[]
  /** Evaluated placements, not a claim of per-pixel causal attribution. */
  readonly nodes: readonly Readonly<{
    id: string
    layerId: string | undefined
    visible: boolean | undefined
  }>[]
} & (
  | { readonly status: 'rendered' | 'partial'; readonly pixels: ClipPixels }
  | { readonly status: 'unavailable'; readonly pixels: undefined }
)
export interface CompositionRenderer {
  /** Validate and snapshot one reusable tree. A new prepare replaces the previous handle.
   * Release the handle when no longer needed; renderer.dispose also invalidates it. */
  prepare(composition: RenderComposition): PreparedComposition
  render(
    composition: RenderComposition,
    options?: CompositionRenderOptions,
  ): Promise<CompositionRenderResult>
  renderTiles(
    composition: RenderComposition,
    options?: CompositionTileOptions,
  ): AsyncGenerator<CompositionRenderResult, void>
  clearCache(): void
  resources: ReturnType<typeof createSceneRenderer>['resources']
  dispose(): void
}
export interface PreparedComposition {
  render(options?: CompositionRenderOptions): Promise<CompositionRenderResult>
  renderTiles(options?: CompositionTileOptions): AsyncGenerator<CompositionRenderResult, void>
  dispose(): void
}
interface Binding {
  view: RenderView
  node: RenderNode
}
interface Compiled {
  roots: readonly RenderView[]
  bindings: readonly Binding[]
  background: RenderComposition['background']
}
const identity: PlaybackTransform = [1, 0, 0, 1, 0, 0]
const both = (a: boolean | undefined, b: boolean | undefined) =>
  a === false || b === false ? false : a === undefined || b === undefined ? undefined : true
function multiply(
  a: PlaybackTransform | undefined,
  b: PlaybackTransform | undefined,
): PlaybackTransform | undefined {
  if (!a || !b) return undefined
  const out: PlaybackTransform = [
    a[0] * b[0] + a[2] * b[1],
    a[1] * b[0] + a[3] * b[1],
    a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3],
    a[0] * b[4] + a[2] * b[5] + a[4],
    a[1] * b[4] + a[3] * b[5] + a[5],
  ]
  return out.every(Number.isFinite) ? out : undefined
}

/** A reusable CLIP-source renderer. It never edits the document or caches final compositions. */
export function createCompositionRenderer(
  session: DocumentSession,
  options: CompositionRendererOptions,
): CompositionRenderer {
  check(options && typeof options.canvas === 'function', 'INVALID_FRAME_RENDER_OPTIONS')
  const source = options.source ?? 'original',
    maxNodes = options.maxNodes ?? 100_000,
    maxDepth = options.maxDepth ?? 64
  check(source === 'original' || source === 'saved', 'INVALID_FRAME_RENDER_OPTIONS')
  check(
    options.missingMaterials === undefined ||
      options.missingMaterials === 'error' ||
      options.missingMaterials === 'omit',
    'INVALID_FRAME_RENDER_OPTIONS',
  )
  check(
    [maxNodes, maxDepth].every((n) => Number.isSafeInteger(n) && n >= 0) && maxDepth <= 256,
    'INVALID_LIMIT',
  )
  check(options.timelineId === undefined || source === 'original', 'INVALID_FRAME_RENDER_OPTIONS')
  const originals = new Map<string, LayerView>()
  const collect = (views: readonly LayerView[]) => {
    for (const view of views) {
      originals.set(view.id, view)
      collect(view.children)
    }
  }
  collect(session.document.layers)
  const playback =
    options.timelineId === undefined ? undefined : session.createPlayback(options.timelineId)
  let current: Compiled = { roots: [], bindings: [], background: undefined },
    busy = false,
    closed = false
  const compile = (composition: RenderComposition): Compiled => {
    check(
      composition &&
        typeof composition === 'object' &&
        !Array.isArray(composition) &&
        Object.keys(composition).every((k) => ['layers', 'background'].includes(k)),
      'INVALID_RENDER_COMPOSITION',
    )
    const background = composition.background
    check(
      background === undefined ||
        (Array.isArray(background) &&
          background.length === 4 &&
          background.every((v) => Number.isInteger(v) && v >= 0 && v <= 255)),
      'INVALID_RENDER_COMPOSITION',
    )
    const bindings: Binding[] = [],
      ids = new Set<string>(),
      ancestors = new Set<RenderNode>()
    const visit = (
      nodes: readonly RenderNode[],
      parentId: string | null,
      depth: number,
    ): RenderView[] => {
      check(
        Array.isArray(nodes) && (!nodes.length || depth <= maxDepth),
        'INVALID_RENDER_COMPOSITION',
      )
      return nodes.map((input) => {
        checkCancelled(options.signal)
        check(bindings.length < maxNodes, 'LIMIT_COMPOSITE_LAYERS')
        check(
          input && typeof input === 'object' && !Array.isArray(input) && !ancestors.has(input),
          'INVALID_RENDER_COMPOSITION',
        )
        check(
          Object.keys(input).every((k) =>
            [
              'id',
              'layerId',
              'children',
              'visible',
              'opacity',
              'blendMode',
              'clipping',
              'maskEnabled',
              'camera',
              'layerKeyframes',
            ].includes(k),
          ),
          'INVALID_RENDER_COMPOSITION',
        )
        check(
          typeof input.id === 'string' &&
            input.id.length > 0 &&
            input.id.length <= 4096 &&
            !ids.has(input.id),
          'INVALID_RENDER_COMPOSITION',
        )
        ids.add(input.id)
        check(
          input.layerId === undefined || typeof input.layerId === 'string',
          'INVALID_RENDER_COMPOSITION',
        )
        const node = { ...input },
          original = node.layerId === undefined ? undefined : originals.get(node.layerId)
        check(node.layerId === undefined || original, 'MISSING_ROW', {
          layerId: node.layerId ?? '',
        })
        check(original || node.children !== undefined, 'INVALID_RENDER_COMPOSITION')
        check(
          node.children === undefined || !original || original.folder,
          'INVALID_RENDER_COMPOSITION',
        )
        for (const flag of [node.visible, node.clipping, node.maskEnabled])
          check(flag === undefined || typeof flag === 'boolean', 'INVALID_RENDER_COMPOSITION')
        check(
          node.opacity === undefined ||
            (Number.isFinite(node.opacity) && node.opacity >= 0 && node.opacity <= 1),
          'INVALID_RENDER_COMPOSITION',
        )
        check(
          node.blendMode === undefined || isClipBlendMode(node.blendMode),
          'UNSUPPORTED_COMPOSITE_MODE',
        )
        check(node.camera === undefined || original?.kind === 'camera', 'INVALID_PLAYBACK_OPTIONS')
        check(
          node.layerKeyframes === undefined ||
            (original && original.kind !== 'camera' && original.kind !== 'audio'),
          'INVALID_PLAYBACK_OPTIONS',
        )
        if (node.camera !== undefined) checkPlaybackPolicy(node.camera)
        if (node.layerKeyframes !== undefined) checkPlaybackPolicy(node.layerKeyframes)
        const view: RenderView = {
          id: node.id,
          sourceId: original?.id ?? null,
          nativeId: original?.nativeId ?? 0,
          parentId,
          name: original?.name ?? node.id,
          role: original?.role ?? 'artwork',
          reference: original?.reference,
          kind: original?.kind ?? 'folder',
          animation: original?.animation ?? false,
          folder: original?.folder ?? true,
          children: [],
          visible: node.visible ?? original?.visible ?? (original ? undefined : true),
          opacity: node.opacity ?? original?.opacity ?? (original ? undefined : 1),
          blendMode: node.blendMode ?? original?.blendMode ?? (original ? undefined : 0),
          clipping: node.clipping,
          locked: original?.locked,
          expanded: original?.expanded,
          labelColor: original?.labelColor,
          mask:
            node.maskEnabled === undefined
              ? original?.mask
              : node.maskEnabled
                ? 'enabled'
                : 'disabled',
          stored: original?.stored ?? {
            type: undefined,
            visibility: undefined,
            opacity: undefined,
            folder: undefined,
          },
        }
        const binding = { view, node }
        bindings.push(binding)
        ancestors.add(input)
        const children = visit(
          node.children ??
            original?.children.map((child) => ({
              id: `${node.id}/${child.id}`,
              layerId: child.id,
            })) ??
            [],
          node.id,
          depth + 1,
        )
        ancestors.delete(input)
        binding.view = { ...view, children }
        return binding.view
      })
    }
    const roots = visit(composition.layers, null, 0)
    return {
      roots,
      bindings,
      background: background && [background[0], background[1], background[2], background[3]],
    }
  }
  const evaluate = (frame: number, policy: PlaybackFrameOptions = {}): PlaybackFrame => {
    // At most sixteen policy combinations per frame; source-local samples can be
    // shared by many placements without inheriting their original parents.
    const variants = new Map<string, Map<string, PlaybackLayer>>()
    let base = playback?.evaluate(frame, policy)
    if (base)
      variants.set(
        JSON.stringify([undefined, undefined]),
        new Map(base.layers.map((l) => [l.layerId, l])),
      )
    const sample = (node: RenderNode) => {
      if (!playback || node.layerId === undefined) return undefined
      const key = JSON.stringify([node.camera, node.layerKeyframes])
      let byId = variants.get(key)
      if (!byId) {
        const layers = policy.layers?.map((entry) => ({
          layerId: entry.layerId,
          ...(node.camera === undefined && entry.camera !== undefined
            ? { camera: entry.camera }
            : {}),
          ...(node.layerKeyframes === undefined && entry.layerKeyframes !== undefined
            ? { layerKeyframes: entry.layerKeyframes }
            : {}),
        }))
        const evaluated = playback.evaluate(frame, {
          camera: node.camera ?? policy.camera ?? 'document',
          layerKeyframes: node.layerKeyframes ?? policy.layerKeyframes ?? 'document',
          ...(layers ? { layers } : {}),
        })
        base ??= evaluated
        byId = new Map(evaluated.layers.map((l) => [l.layerId, l]))
        variants.set(key, byId)
      }
      return byId.get(node.layerId)
    }
    const states = new Map<string, PlaybackLayer>()
    for (const { view, node } of current.bindings) {
      const evaluated = sample(node),
        parent = view.parentId ? states.get(view.parentId) : undefined,
        props = node.layerId === undefined ? undefined : session.readLayerProperties(node.layerId),
        local = evaluated?.localTransform ?? (evaluated ? undefined : identity),
        maskLocal = evaluated ? evaluated.localState.maskTransform : identity,
        transform = multiply(parent ? parent.transform : identity, local),
        maskTransform = multiply(parent ? parent.transform : identity, maskLocal),
        issues = [...(evaluated?.localState.diagnostics ?? [])]
      let visible = both(
        view.visible,
        evaluated?.localState.exposure ?? (evaluated ? undefined : true),
      )
      const sampledCel = evaluated?.localState.cel
      const selected =
        sampledCel?.name == null
          ? undefined
          : view.children.findLast((c) => c.role === 'artwork' && c.name === sampledCel.name)
      const cel =
        sampledCel === undefined
          ? undefined
          : { name: sampledCel.name, layerId: sampledCel.name === null ? null : selected?.id }
      if (cel?.layerId === undefined && cel) {
        // Resolve names against effective children, not against source parentage.
        if (!issues.some((d) => d.code === 'UNRESOLVED_PLAYBACK_CEL'))
          issues.push(diagnostic('UNRESOLVED_PLAYBACK_CEL'))
      } else if (cel) {
        for (let i = issues.length - 1; i >= 0; i--)
          if (issues[i]!.code === 'UNRESOLVED_PLAYBACK_CEL') issues.splice(i, 1)
      }
      if (parent) {
        visible = both(visible, parent.visible)
        if (parent.cel)
          visible = both(
            visible,
            parent.cel.layerId === undefined ? undefined : parent.cel.layerId === view.id,
          )
      }
      if (!transform && local)
        issues.push(diagnostic('UNSUPPORTED_PLAYBACK_TRANSFORM', { reason: 'overflow' }))
      const opacity =
        node.opacity ??
        (evaluated
          ? evaluated.opacity
          : source === 'original' && props?.keyframesEnabled
            ? (props.originalOpacity ?? view.opacity)
            : view.opacity)
      states.set(view.id, {
        layerId: view.id,
        parentId: view.parentId,
        visible,
        opacity,
        transform,
        localTransform: local,
        maskTransform,
        localState: {
          exposure: evaluated?.localState.exposure ?? true,
          cel,
          maskTransform: maskLocal,
          diagnostics: issues,
        },
        keyframesEnabled: props?.keyframesEnabled ?? false,
        keyframeState: evaluated?.keyframeState ?? {
          policy: 'ignore',
          stored: props?.keyframesEnabled,
          applied: false,
          source: 'override',
        },
        cameraState: evaluated?.cameraState,
        cameraApplied: !!(parent?.cameraApplied || evaluated?.cameraState?.applied),
        cel,
        channels: evaluated?.channels ?? [],
        diagnostics: issues,
      })
    }
    return {
      timelineId: playback?.timelineId ?? '',
      frame,
      inPlaybackRange: base?.inPlaybackRange ?? false,
      camera: policy.camera ?? 'ignore',
      layerKeyframes: policy.layerKeyframes ?? 'ignore',
      layers: [...states.values()],
      diagnostics: [...states.values()].flatMap((s) => s.diagnostics),
    }
  }
  let engine: ReturnType<typeof createSceneRenderer>
  try {
    engine = createSceneRenderer(
      session,
      options,
      { evaluate, dispose: () => playback?.dispose() },
      {
        source,
        resolveRoots: () => current.roots,
        background: () => current.background,
        omitMissingMaterials: options.missingMaterials === 'omit',
      },
    )
  } catch (error) {
    playback?.dispose()
    throw error
  }
  const render = async (
    compiled: Compiled,
    input: CompositionRenderOptions,
  ): Promise<CompositionRenderResult> => {
    check(!closed, 'CLOSED_FRAME_RENDERER')
    check(!busy, 'BUSY_FRAME_RENDERER')
    const { frame, ...policy } = input
    check(
      playback
        ? typeof frame === 'number' && Number.isFinite(frame)
        : frame === undefined &&
            input.camera === undefined &&
            input.layerKeyframes === undefined &&
            input.layers === undefined &&
            compiled.bindings.every(
              (b) => b.node.camera === undefined && b.node.layerKeyframes === undefined,
            ),
      'INVALID_PLAYBACK_OPTIONS',
    )
    busy = true
    current = compiled
    try {
      const result = await engine.render(frame ?? 0, policy),
        sources = new Map(compiled.bindings.map((b) => [b.view.id, b.node.layerId]))
      const diagnostics = result.diagnostics.map((d) => {
        if (d.layerId === undefined || !sources.has(d.layerId)) return d
        const { layerId: nodeId, ...rest } = d,
          sourceId = sources.get(nodeId)
        return {
          ...rest,
          ...(sourceId === undefined ? {} : { layerId: sourceId }),
          data: { ...d.data, renderNodeId: nodeId },
        }
      })
      const nodes = result.frame.layers.map((l) => ({
        id: l.layerId,
        layerId: sources.get(l.layerId),
        visible: l.visible,
      }))
      return result.status === 'rendered'
        ? {
            status: diagnostics.some(blocking) ? 'partial' : 'rendered',
            pixels: result.pixels,
            diagnostics,
            nodes,
          }
        : { status: 'unavailable', pixels: undefined, diagnostics, nodes }
    } finally {
      busy = false
      current = { roots: [], bindings: [], background: undefined }
    }
  }
  const prepared = new Set<{ compiled: Compiled | undefined }>()
  const tiles = (compiled: Compiled, input: CompositionTileOptions = {}) => {
    const { tileWidth, tileHeight, ...policy } = input
    const snapshot = {
      ...policy,
      ...(policy.layers ? { layers: policy.layers.map((l) => ({ ...l })) } : {}),
    }
    return renderRegions(
      {
        left: 0,
        top: 0,
        width: Math.ceil(session.document.canvas.width * (input.scale ?? 1)),
        height: Math.ceil(session.document.canvas.height * (input.scale ?? 1)),
      },
      {
        ...snapshot,
        ...(tileWidth === undefined ? {} : { tileWidth }),
        ...(tileHeight === undefined ? {} : { tileHeight }),
      },
      (region) => render(compiled, { ...snapshot, region }),
    )
  }
  return Object.freeze({
    prepare(composition: RenderComposition): PreparedComposition {
      check(!closed, 'CLOSED_FRAME_RENDERER')
      const compiled = compile(composition)
      // A renderer keeps at most one registered tree. Existing tile streams own their snapshot.
      for (const handle of prepared) handle.compiled = undefined
      prepared.clear()
      const handle = { compiled: compiled as Compiled | undefined }
      prepared.add(handle)
      const active = () => {
        check(!closed && handle.compiled, 'CLOSED_FRAME_RENDERER')
        return handle.compiled
      }
      return Object.freeze({
        render: (input: CompositionRenderOptions = {}) => render(active(), { ...input }),
        renderTiles: (input: CompositionTileOptions = {}) => tiles(active(), input),
        dispose() {
          handle.compiled = undefined
          prepared.delete(handle)
        },
      })
    },
    render: async (composition: RenderComposition, input: CompositionRenderOptions = {}) => {
      check(!closed, 'CLOSED_FRAME_RENDERER')
      check(!busy, 'BUSY_FRAME_RENDERER')
      return render(compile(composition), { ...input })
    },
    renderTiles(composition: RenderComposition, input: CompositionTileOptions = {}) {
      check(!closed, 'CLOSED_FRAME_RENDERER')
      check(!busy, 'BUSY_FRAME_RENDERER')
      const compiled = compile(composition),
        { tileWidth, tileHeight, ...policy } = input
      const snapshot = {
        ...policy,
        ...(policy.layers ? { layers: policy.layers.map((l) => ({ ...l })) } : {}),
      }
      return renderRegions(
        {
          left: 0,
          top: 0,
          width: Math.ceil(session.document.canvas.width * (input.scale ?? 1)),
          height: Math.ceil(session.document.canvas.height * (input.scale ?? 1)),
        },
        {
          ...snapshot,
          ...(tileWidth === undefined ? {} : { tileWidth }),
          ...(tileHeight === undefined ? {} : { tileHeight }),
        },
        (region) => render(compiled, { ...snapshot, region }),
      )
    },
    clearCache: () => engine.clearCache(),
    resources: () => engine.resources(),
    dispose() {
      closed = true
      for (const handle of prepared) handle.compiled = undefined
      prepared.clear()
      engine.dispose()
      originals.clear()
    },
  })
}
