import { Zlib } from 'fflate'
import { check, concat, crc32, u32, utf8 } from '../native/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { byteBuffer, imageByteLength, resourceLimit } from '../image-resources.js'

export interface PngStreamOptions {
  signal?: AbortSignal
  /** Staging/chunk budget, excluding caller rows and compressor internals. Default 1 MiB. */
  maxWorkingBytes?: number
}

function chunk(name: string, data: Uint8Array): Uint8Array {
  const body = concat(utf8.encode(name), data)
  return concat(u32(data.length), body, u32(crc32(body)))
}

/** Stream straight RGBA8, top-to-bottom complete rows (one or more per input block),
 * to PNG chunks. No Canvas or whole-image allocation. Output chunks are owned.
 * Stop/abort the destination on errors: IEND is emitted only on successful completion.
 * Consuming incrementally preserves backpressure; collecting chunks defeats this. */
export async function* encodePngRows(
  width: number,
  height: number,
  rows: AsyncIterable<Uint8Array | Uint8ClampedArray> | Iterable<Uint8Array | Uint8ClampedArray>,
  options: PngStreamOptions = {},
): AsyncGenerator<Uint8Array> {
  imageByteLength(width, height)
  check(width <= 0x7fffffff && height <= 0x7fffffff, 'INVALID_IMAGE_DIMENSIONS')
  checkCancelled(options.signal)
  const budget = resourceLimit(options.maxWorkingBytes ?? 1024 * 1024)
  check(budget >= 4096, 'LIMIT_COMPOSITE_BYTES')
  const staging = byteBuffer(Math.min(65536, Math.floor(budget / 8))),
    rowBytes = width * 4
  let queued: Uint8Array[] = [],
    used = 0,
    count = 0
  const compressor = new Zlib({ level: 6, mem: 4 }, (data) => {
    if (data.length) queued.push(data)
  })
  yield new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10])
  checkCancelled(options.signal)
  yield chunk('IHDR', concat(u32(width), u32(height), new Uint8Array([8, 6, 0, 0, 0])))
  checkCancelled(options.signal)
  for await (const block of rows) {
    checkCancelled(options.signal)
    check(
      (block instanceof Uint8Array || block instanceof Uint8ClampedArray) &&
        block.length > 0 &&
        block.length % rowBytes === 0,
      'INVALID_PIXEL_LENGTH',
    )
    const n = block.length / rowBytes
    check(count + n <= height, 'INVALID_PIXEL_LENGTH')
    for (let row = 0; row < n; row++) {
      // Filter 0 preserves exact values; compression stays incremental across rows.
      staging[used++] = 0
      let at = row * rowBytes,
        end = at + rowBytes
      while (at < end || used === staging.length) {
        checkCancelled(options.signal)
        if (used === staging.length) {
          compressor.push(staging, false)
          for (const data of queued) {
            checkCancelled(options.signal)
            yield chunk('IDAT', data)
          }
          queued = []
          used = 0
        }
        const take = Math.min(end - at, staging.length - used)
        staging.set(block.subarray(at, at + take), used)
        used += take
        at += take
      }
    }
    count += n
    checkCancelled(options.signal)
  }
  checkCancelled(options.signal)
  check(count === height, 'INVALID_PIXEL_LENGTH')
  compressor.push(staging.subarray(0, used), true)
  for (const data of queued) {
    checkCancelled(options.signal)
    yield chunk('IDAT', data)
  }
  checkCancelled(options.signal)
  yield chunk('IEND', new Uint8Array())
}
