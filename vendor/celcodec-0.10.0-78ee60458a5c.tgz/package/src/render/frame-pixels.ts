import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import type { ClipPixels, ClipLayer, MaterialEffects } from '../material/types.js'
import type { PlaybackTransform } from '../document/playback.js'
import type { CanvasFactory } from '../canvas/types.js'
import { context } from '../canvas/types.js'
import { createCanvasRenderer } from '../canvas/image.js'
import { applyMaterialEffects } from '../canvas/index.js'
import { applyEdge } from '../canvas/edge-effect.js'
import { maskAt } from './pixel-mask.js'
import { createTransformWorkspace, type TransformWorkspace } from './frame-workspace.js'
import { inverseRegion, intersectRegion } from '../internal/image-region.js'
import {
  resolveImageLimits,
  checkImageAllocation,
  rgbaBuffer,
  type ImageResourceLimits,
  type ImageRegion,
} from '../image-resources.js'

export const emptyPixels = (): ClipPixels => ({
  width: 1,
  height: 1,
  left: 0,
  top: 0,
  rgba: new Uint8ClampedArray(4),
})
export const translation = (m: PlaybackTransform) =>
  m[0] === 1 &&
  m[1] === 0 &&
  m[2] === 0 &&
  m[3] === 1 &&
  Number.isSafeInteger(m[4]) &&
  Number.isSafeInteger(m[5])

/** All transient surfaces are released before returning caller-owned pixel arrays. */
export function materialPixels(
  layer: ClipLayer,
  width: number,
  height: number,
  factory: CanvasFactory,
  maxBytes: number,
  signal: AbortSignal,
  imageLimits?: ImageResourceLimits,
  region?: ImageRegion,
): ClipPixels | undefined {
  if (layer.pixels && !layer.placement && !layer.fragments?.length && !layer.text?.length)
    return layer.pixels
  const painter = createCanvasRenderer(factory, {
    maxBytes: Math.floor(maxBytes / 2),
    signal,
    ...(imageLimits ? { imageLimits } : {}),
  })
  try {
    const result = painter.renderClipMaterial(layer, width, height, region)
    if (!result) return
    const canvas = result.canvas
    check(
      painter.allocatedBytes + canvas.width * canvas.height * 4 <= maxBytes,
      'LIMIT_FRAME_RENDER_BYTES',
    )
    checkCancelled(signal)
    return {
      width: canvas.width,
      height: canvas.height,
      left: result.left,
      top: result.top,
      rgba: context(canvas).getImageData(0, 0, canvas.width, canvas.height).data,
    }
  } finally {
    painter.dispose()
  }
}

export function effectPixels(
  p: ClipPixels,
  effects: MaterialEffects | undefined,
  maxBytes: number,
  signal: AbortSignal,
  coverage?: { opacity: number; mask?: ClipPixels },
  imageLimits?: ImageResourceLimits,
) {
  if (!effects) return { pixels: p, diagnostics: [] }
  const pad = effects.edge ? Math.ceil(effects.edge.radius) + 1 : 0,
    width = p.width + 2 * pad,
    height = p.height + 2 * pad,
    bytes = width * height * 4
  checkImageAllocation(
    width,
    height,
    { ...resolveImageLimits(imageLimits), maxBytes },
    'LIMIT_FRAME_RENDER_BYTES',
  )
  const data = rgbaBuffer(bytes)
  for (let y = 0; y < p.height; y++)
    data.set(p.rgba.subarray(y * p.width * 4, (y + 1) * p.width * 4), ((y + pad) * width + pad) * 4)
  const { edge, ...otherEffects } = effects,
    diagnostics = applyMaterialEffects(data, width, height, coverage ? otherEffects : effects, {
      signal,
      // The output copy and the kernel scratch coexist. Neither aliases the input.
      maxWorkingBytes: maxBytes - bytes,
    })
  if (coverage && edge) {
    check(width * height * 5 + width * 4 <= maxBytes - bytes, 'LIMIT_FRAME_RENDER_BYTES')
    const amount = (i: number) =>
      coverage.opacity *
      maskAt(coverage.mask, p.left - pad + (i % width), p.top - pad + Math.floor(i / width))
    if (edge.radius > 0) applyEdge(data, width, height, edge, amount)
    else
      for (let i = 0; i < width * height; i++)
        data[i * 4 + 3] = Math.round(data[i * 4 + 3]! * amount(i))
  }
  return {
    pixels: { width, height, left: p.left - pad, top: p.top - pad, rgba: data },
    diagnostics,
  }
}

/** Transform scalar masks against their saved outside value, independently from image alpha. */
export function transformPixels(
  p: ClipPixels,
  matrix: PlaybackTransform,
  width: number,
  height: number,
  factory: CanvasFactory,
  maxBytes: number,
  signal: AbortSignal,
  mask = false,
  workspace?: TransformWorkspace,
  margin = 0,
  imageLimits?: ImageResourceLimits,
  region?: ImageRegion,
): ClipPixels {
  checkCancelled(signal)
  if (translation(matrix)) return { ...p, left: p.left + matrix[4], top: p.top + matrix[5] }
  const [a, b, c, d, e, f] = matrix,
    corners = [
      [p.left, p.top],
      [p.left + p.width, p.top],
      [p.left, p.top + p.height],
      [p.left + p.width, p.top + p.height],
    ],
    xs = corners.map(([x, y]) => a * x! + c * y! + e),
    ys = corners.map(([x, y]) => b * x! + d * y! + f),
    left = Math.max((region?.left ?? 0) - margin, Math.floor(Math.min(...xs)) - 1),
    top = Math.max((region?.top ?? 0) - margin, Math.floor(Math.min(...ys)) - 1),
    right = Math.min(
      (region?.left ?? 0) + (region?.width ?? width) + margin,
      Math.ceil(Math.max(...xs)) + 1,
    ),
    bottom = Math.min(
      (region?.top ?? 0) + (region?.height ?? height) + margin,
      Math.ceil(Math.max(...ys)) + 1,
    ),
    outside = p.defaultColor ?? 0
  check([...xs, ...ys].every(Number.isFinite), 'UNSUPPORTED_PLAYBACK_TRANSFORM', {
    reason: 'pixel-bounds-overflow',
  })
  if (right <= left || bottom <= top || a * d - b * c === 0) {
    const result = emptyPixels()
    if (mask) {
      result.rgba.fill(outside)
      result.defaultColor = outside
    }
    return result
  }
  const w = right - left,
    h = bottom - top
  const limits = resolveImageLimits(imageLimits)
  check(p.width * p.height <= limits.maxPixels && w * h <= limits.maxPixels, 'LIMIT_CANVAS_BYTES')
  const scratch =
    workspace ??
    createTransformWorkspace(
      factory,
      () => {},
      () => {},
    )
  try {
    if (region) {
      // Canvas edge coverage can depend on its clipping rectangle. A fixed global
      // grid gives full, regional and differently tiled renders identical phases.
      const size = 128,
        pad = 2,
        targetSize = size + 2 * pad,
        bytes = checkImageAllocation(w, h, { ...limits, maxBytes }, 'LIMIT_FRAME_RENDER_BYTES'),
        rgba = rgbaBuffer(bytes)
      check(targetSize * targetSize <= limits.maxPixels, 'LIMIT_CANVAS_BYTES')
      for (let ty = Math.floor(top / size) * size; ty < bottom; ty += size)
        for (let tx = Math.floor(left / size) * size; tx < right; tx += size) {
          checkCancelled(signal)
          const input = inverseRegion(
            { left: tx - pad, top: ty - pad, width: targetSize, height: targetSize },
            matrix,
          )
          // Integer rounding otherwise alternates the source dimensions by one
          // pixel, forcing Canvas reallocation on almost every output tile.
          const determinant = Math.abs(a * d - b * c)
          input.width = Math.ceil(((Math.abs(d) + Math.abs(c)) * targetSize) / determinant) + 5
          input.height = Math.ceil(((Math.abs(b) + Math.abs(a)) * targetSize) / determinant) + 5
          const overlap = intersectRegion(input, p)
          check(input.width * input.height <= limits.maxPixels, 'LIMIT_CANVAS_BYTES')
          const { source, target, upload } = scratch.prepare(
              input.width,
              input.height,
              targetSize,
              targetSize,
              maxBytes - bytes,
            ),
            sc = context(source),
            tc = context(target)
          upload.data.fill(mask ? outside : 0)
          if (overlap)
            for (let y = 0; y < overlap.height; y++) {
              const start = ((overlap.top - p.top + y) * p.width + overlap.left - p.left) * 4
              upload.data.set(
                p.rgba.subarray(start, start + overlap.width * 4),
                ((overlap.top - input.top + y) * input.width + overlap.left - input.left) * 4,
              )
            }
          if (mask)
            for (let i = 0; i < upload.data.length; i += 4) {
              upload.data[i + 1] = upload.data[i + 2] = upload.data[i]!
              upload.data[i + 3] = 255
            }
          sc.putImageData(upload, 0, 0)
          if (mask) {
            tc.fillStyle = `rgb(${outside},${outside},${outside})`
            tc.fillRect(0, 0, targetSize, targetSize)
          }
          tc.setTransform(a, b, c, d, e - tx + pad, f - ty + pad)
          tc.drawImage(source, input.left, input.top)
          const lx = Math.max(left, tx),
            ly = Math.max(top, ty),
            rw = Math.min(right, tx + size) - lx,
            rh = Math.min(bottom, ty + size) - ly,
            data = tc.getImageData(lx - tx + pad, ly - ty + pad, rw, rh).data
          for (let y = 0; y < rh; y++)
            rgba.set(
              data.subarray(y * rw * 4, (y + 1) * rw * 4),
              ((ly - top + y) * w + lx - left) * 4,
            )
        }
      return { width: w, height: h, left, top, rgba, ...(mask ? { defaultColor: outside } : {}) }
    }
    const { source, target, upload } = scratch.prepare(p.width, p.height, w, h, maxBytes),
      sc = context(source),
      tc = context(target)
    upload.data.set(p.rgba)
    if (mask)
      for (let i = 0; i < upload.data.length; i += 4) {
        upload.data[i + 1] = upload.data[i + 2] = upload.data[i]!
        upload.data[i + 3] = 255
      }
    sc.putImageData(upload, 0, 0)
    if (mask) {
      tc.fillStyle = `rgb(${outside},${outside},${outside})`
      tc.fillRect(0, 0, w, h)
    }
    tc.setTransform(a, b, c, d, e - left, f - top)
    tc.drawImage(source, p.left, p.top)
    checkCancelled(signal)
    return {
      width: w,
      height: h,
      left,
      top,
      rgba: tc.getImageData(0, 0, w, h).data,
      ...(mask ? { defaultColor: outside } : {}),
    }
  } finally {
    if (!workspace) scratch.clear()
  }
}
