import { check } from '../internal/binary.js'
import { checkRegion } from '../internal/image-region.js'
import { checkCancelled } from '../diagnostics.js'
import type { ImageRegion } from '../image-resources.js'

export interface RenderTileOptions {
  /** Default 256. Use the output width for sequential PNG row strips. */
  tileWidth?: number
  /** Default 256. Budgets apply to each tile and its effect/sampling halo. */
  tileHeight?: number
}

export function renderRegions<T extends { status: 'rendered' | 'partial' | 'unavailable' }>(
  canvas: ImageRegion,
  options: RenderTileOptions & { region?: ImageRegion; signal?: AbortSignal },
  render: (region: ImageRegion) => Promise<T>,
): AsyncGenerator<T, void> {
  const region = { ...(options.region ?? canvas) },
    width = options.tileWidth ?? 256,
    height = options.tileHeight ?? 256,
    signal = options.signal
  checkRegion(region)
  check(
    [width, height].every((n) => Number.isSafeInteger(n) && n > 0),
    'INVALID_IMAGE_DIMENSIONS',
  )
  return (async function* () {
    for (let y = 0; y < region.height; y += height)
      for (let x = 0; x < region.width; x += width) {
        checkCancelled(signal)
        const result = await render({
          left: region.left + x,
          top: region.top + y,
          width: Math.min(width, region.width - x),
          height: Math.min(height, region.height - y),
        })
        yield result
        if (result.status === 'unavailable') return
      }
  })()
}
