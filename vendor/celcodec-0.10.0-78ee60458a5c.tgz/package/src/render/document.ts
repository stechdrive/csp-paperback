import type {
  DocumentSession,
  LayerView,
  PlaybackFrame,
  PlaybackLayer,
  PlaybackTransform,
} from '../document/index.js'
import type { ClipPixels } from '../types.js'
import type { ClipDiagnostic } from '../diagnostics.js'
import type { ImageRegion } from '../image-resources.js'
import { check } from '../internal/binary.js'
import { createSceneRenderer, type FrameRenderer, type FrameRendererOptions } from './frame.js'
import type { RenderTileOptions } from './regions.js'

export interface DocumentRendererOptions extends FrameRendererOptions {
  /** Saved canvas materials (default), or original artwork with timeline transforms disabled.
   * Use createFrameRenderer to select a frame, cels, camera or keyframe policies. */
  source?: 'saved' | 'original'
  /** Isolate this layer/subtree in document coordinates. Its root blend/clipping becomes normal/unclipped. */
  layerId?: string
  /** Isolated root only. Descendants retain their saved visibility. Default document. */
  rootVisibility?: 'document' | 'show'
  /** Isolated root only. Descendants retain their saved opacity. Default document. */
  rootOpacity?: 'document' | 'ignore'
}
export interface DocumentRenderOptions {
  /** See FrameRenderOptions.scale. Preview regions/results use reduced coordinates. */
  scale?: number
  region?: ImageRegion
  signal?: AbortSignal
}
export interface DocumentTileOptions extends DocumentRenderOptions, RenderTileOptions {}
export type DocumentRenderResult = {
  readonly diagnostics: readonly ClipDiagnostic[]
} & (
  | { readonly status: 'rendered'; readonly pixels: ClipPixels }
  | { readonly status: 'unavailable'; readonly pixels: undefined }
)
export interface DocumentRenderer {
  render(options?: DocumentRenderOptions): Promise<DocumentRenderResult>
  renderTiles(options?: DocumentTileOptions): AsyncGenerator<DocumentRenderResult, void>
  clearCache(): void
  resources: FrameRenderer['resources']
  dispose(): void
}

/** Restores paper, placement, masks, effects and the compositing tree without a timeline.
 * Never owns/edits the session. Output is caller-owned RGBA8; all regions use document coordinates. */
export function createDocumentRenderer(
  session: DocumentSession,
  options: DocumentRendererOptions,
): DocumentRenderer {
  check(options && typeof options.canvas === 'function', 'INVALID_FRAME_RENDER_OPTIONS')
  const {
    source = 'saved',
    layerId,
    rootVisibility = 'document',
    rootOpacity = 'document',
  } = options
  check(source === 'saved' || source === 'original', 'INVALID_FRAME_RENDER_OPTIONS')
  check(
    ['document', 'show'].includes(rootVisibility) && ['document', 'ignore'].includes(rootOpacity),
    'INVALID_FRAME_RENDER_OPTIONS',
  )
  check(
    layerId !== undefined || (rootVisibility === 'document' && rootOpacity === 'document'),
    'INVALID_FRAME_RENDER_OPTIONS',
  )
  const flatten = (views: readonly LayerView[]): LayerView[] =>
      views.flatMap((v) => [v, ...flatten(v.children)]),
    all = flatten(session.document.layers),
    root = layerId === undefined ? undefined : all.find((v) => v.id === layerId)
  check(layerId === undefined || root, 'MISSING_ROW')
  const roots = root ? [root] : session.document.layers,
    views = root ? flatten([root]) : all,
    identity: PlaybackTransform = [1, 0, 0, 1, 0, 0]
  const evaluate = (): PlaybackFrame => {
    const states = new Map<string, PlaybackLayer>()
    for (const view of views) {
      const props = session.readLayerProperties(view.id),
        parent = view.parentId ? states.get(view.parentId) : undefined,
        visible = view === root && rootVisibility === 'show' ? true : view.visible,
        opacity =
          view === root && rootOpacity === 'ignore'
            ? 1
            : source === 'original' && props.keyframesEnabled
              ? (props.originalOpacity ?? view.opacity)
              : view.opacity
      states.set(view.id, {
        layerId: view.id,
        parentId: view.parentId,
        visible: parent?.visible === false ? false : visible,
        opacity,
        transform: identity,
        localTransform: identity,
        localState: { exposure: true, cel: undefined, maskTransform: identity, diagnostics: [] },
        maskTransform: identity,
        keyframesEnabled: props.keyframesEnabled ?? false,
        keyframeState: {
          policy: 'ignore',
          stored: props.keyframesEnabled,
          applied: false,
          source: 'override',
        },
        cameraState: undefined,
        cameraApplied: false,
        cel: undefined,
        channels: [],
        diagnostics: [],
      })
    }
    return {
      timelineId: '',
      frame: 0,
      inPlaybackRange: false,
      camera: 'ignore',
      layerKeyframes: 'ignore',
      layers: [...states.values()],
      diagnostics: [],
    }
  }
  const engine = createSceneRenderer(
      session,
      options,
      { evaluate, dispose() {} },
      { roots, source, ...(root ? { isolated: root.id } : {}) },
    ),
    result = ({
      status,
      pixels,
      diagnostics,
    }: Awaited<ReturnType<FrameRenderer['render']>>): DocumentRenderResult =>
      status === 'rendered'
        ? { status, pixels, diagnostics }
        : { status, pixels: undefined, diagnostics }
  return Object.freeze({
    async render(input: DocumentRenderOptions = {}) {
      return result(await engine.render(0, input))
    },
    async *renderTiles(input: DocumentTileOptions = {}) {
      for await (const tile of engine.renderTiles(0, input)) yield result(tile)
    },
    clearCache: () => engine.clearCache(),
    resources: () => engine.resources(),
    dispose: () => engine.dispose(),
  })
}
