import type { DocumentSession, LayerView } from '../document/index.js'
import type { PlaybackFrame, PlaybackFrameOptions, TimelinePlayback } from '../document/playback.js'
import type { CanvasFactory } from '../canvas/types.js'
import type { ClipPixels, ClipLayer, MaterialEffects } from '../material/types.js'
import type { Inflate } from '../types.js'
import {
  resolveImageLimits,
  type ImageResourceLimits,
  type ImageRegion,
} from '../image-resources.js'
import {
  checkRegion,
  expandRegion,
  inverseRegion,
  effectHalo,
  transformRegion,
} from '../internal/image-region.js'
import { renderRegions, type RenderTileOptions } from './regions.js'
import { check, inflate as inflateNative } from '../internal/binary.js'
import {
  checkCancelled,
  diagnostic,
  rethrowFatal,
  serializeClipError,
  type ClipDiagnostic,
  type DiagnosticCode,
} from '../diagnostics.js'
import { compositeLayers } from './composite.js'
import { isClipBlendMode } from './blend.js'
import { createTransformWorkspace } from './frame-workspace.js'
import type { CompositeLayer, CompositeAttributes } from './types.js'
import {
  emptyPixels,
  materialPixels,
  effectPixels,
  transformPixels,
  translation,
} from './frame-pixels.js'

export interface FrameRendererOptions {
  imageLimits?: ImageResourceLimits
  /** Independent Canvas surfaces; no DOM globals are accessed. Fonts must be ready before rendering text. */
  canvas: CanvasFactory
  /** Transient pixel planes and compositor work. Defaults to imageLimits.maxBytes, or 512 MiB. */
  maxWorkingBytes?: number
  /** Original material pixels retained between frames, separately from working memory. Default 64 MiB. */
  maxCacheBytes?: number
  /** Material and native-tile entries share this bound. Default 4096. */
  maxCacheEntries?: number
  signal?: AbortSignal
  inflate?: Inflate
}
export interface FrameRenderOptions extends PlaybackFrameOptions {
  /** Preview-only power-of-two scale, 1/256..1. Regions/results use reduced document
   * coordinates. Static raster/paper/folders without effects are supported; other
   * scenes return unavailable so callers can use full-resolution tiled rendering. */
  scale?: number
  signal?: AbortSignal
  /** Integer output rectangle in document coordinates. Default: the whole canvas. */
  region?: ImageRegion
}
export interface FrameTileOptions extends FrameRenderOptions, RenderTileOptions {}
export type FrameRenderResult = {
  readonly frame: PlaybackFrame
  readonly diagnostics: readonly ClipDiagnostic[]
} & (
  | {
      readonly status: 'rendered'
      /** Requested rectangle, caller-owned straight RGBA8 in document coordinates. */ readonly pixels: ClipPixels
    }
  | {
      readonly status: 'unavailable'
      /** A visible contribution could not be resolved. */ readonly pixels: undefined
    }
)
export interface FrameRenderer {
  render(frame: number, options?: FrameRenderOptions): Promise<FrameRenderResult>
  /** Pull-based, row-major tiles. An unavailable tile ends the stream with its diagnostics. */
  renderTiles(frame: number, options?: FrameTileOptions): AsyncGenerator<FrameRenderResult, void>
  clearCache(): void
  resources(): Readonly<{
    closed: boolean
    rendering: boolean
    cacheBytes: number
    cacheEntries: number
    decodes: number
    cacheHits: number
    tileCacheBytes: number
    tileCacheEntries: number
    tileCacheHits: number
    inflates: number
    cacheMetadataBytes: number
  }>
  dispose(): void
}
interface Material {
  layer: ClipLayer
  pixels: ClipPixels | undefined
  diagnostics: ClipDiagnostic[]
  bytes: number
  usedFrame: number
}
/** Evaluated drawing hierarchy. The document and decoded source metadata stay immutable. */
export interface RenderView extends LayerView {
  readonly sourceId?: string | null
  readonly clipping?: boolean
  readonly children: readonly RenderView[]
}
const knownChannels = new Set([
  'ImageCelName',
  'Opacity',
  ...['Image', 'Mask'].flatMap((p) =>
    ['Position', 'Center', 'Rotation', 'Scale', 'AspectScale'].map((s) => p + s),
  ),
])
export const blocking = (d: ClipDiagnostic) =>
  d.kind !== 'approximate' &&
  !(d.outcome === 'approximate' && (d.kind === 'missing' || d.kind === 'unsupported'))
const stamp = (d: ClipDiagnostic, id: string): ClipDiagnostic => ({
  ...d,
  ...(d.data ? { data: { ...d.data } } : {}),
  layerId: id,
})

/** Owns one compiled timeline and a bounded LRU of original materials, never the document session. */
export function createFrameRenderer(
  session: DocumentSession,
  timelineId: string,
  options: FrameRendererOptions,
): FrameRenderer {
  const playback = session.createPlayback(timelineId)
  try {
    return createSceneRenderer(session, options, playback)
  } catch (error) {
    playback.dispose()
    throw error
  }
}

/** Shared static/timeline engine. Only the scene evaluator decides visibility and transforms. */
export function createSceneRenderer(
  session: DocumentSession,
  options: FrameRendererOptions,
  playback: Pick<TimelinePlayback, 'evaluate' | 'dispose'>,
  scene: {
    roots?: readonly RenderView[]
    source?: 'saved' | 'original'
    isolated?: string
    resolveRoots?: () => readonly RenderView[]
    background?: () => readonly [number, number, number, number] | undefined
    omitMissingMaterials?: boolean
  } = {},
): FrameRenderer {
  check(options && typeof options.canvas === 'function', 'INVALID_FRAME_RENDER_OPTIONS')
  const factory = options.canvas,
    inflate = options.inflate,
    imageLimits = resolveImageLimits(
      options.imageLimits ??
        session.imageLimits ??
        (options.maxWorkingBytes === undefined ? undefined : { maxBytes: options.maxWorkingBytes }),
    ),
    maxWorkingBytes = options.maxWorkingBytes ?? imageLimits.maxBytes,
    maxCacheBytes = options.maxCacheBytes ?? 64 * 1024 * 1024,
    maxCacheEntries = options.maxCacheEntries ?? 4096
  check(
    [maxWorkingBytes, maxCacheBytes, maxCacheEntries].every(
      (v) => Number.isSafeInteger(v) && v >= 0,
    ),
    'INVALID_LIMIT',
  )
  const lifetime = new AbortController(),
    signal = options.signal ? AbortSignal.any([options.signal, lifetime.signal]) : lifetime.signal
  checkCancelled(signal)
  const cache = new Map<string, Material>(),
    tiles = new Map<string, { raw: Uint8Array; usedFrame: number; touched: number }>(),
    buffers = new WeakMap<ArrayBufferLike, number>(),
    ages = new Map<string, number>(),
    { width, height } = session.document.canvas
  let closed = false,
    rendering = false,
    cacheBytes = 0,
    decodes = 0,
    cacheHits = 0,
    frameSequence = 0,
    sequence = 0,
    bufferSequence = 0,
    tileCacheBytes = 0,
    tileCacheHits = 0,
    inflates = 0,
    cacheMetadataBytes = 0
  const metadataBytes = (key: string, value: Material) =>
    192 + key.length * 2 + JSON.stringify(value.diagnostics).length * 2
  const clearCache = () => {
    cache.clear()
    tiles.clear()
    ages.clear()
    cacheBytes = 0
    tileCacheBytes = 0
    cacheMetadataBytes = 0
  }
  const active = (s: AbortSignal) => {
    check(!closed, 'CLOSED_FRAME_RENDERER')
    check(!session.resources().closed, 'CLOSED_DOCUMENT')
    checkCancelled(s)
  }
  const room = (bytes: number, metadata: number) => {
    if (!maxCacheEntries || bytes > maxCacheBytes || metadata > 1024 * 1024) return false
    while (
      cache.size + tiles.size >= maxCacheEntries ||
      cacheBytes + tileCacheBytes + bytes > maxCacheBytes ||
      cacheMetadataBytes + metadata > 1024 * 1024
    ) {
      let oldest = Infinity,
        materialKey: string | undefined,
        tileKey: string | undefined
      for (const [key, value] of cache) {
        // Folder/empty metadata cannot evict useful pixel planes.
        if (value.usedFrame === frameSequence || (bytes <= 4 && value.bytes > 4)) continue
        if (ages.get(key)! < oldest) {
          oldest = ages.get(key)!
          materialKey = key
        }
      }
      for (const [key, value] of tiles) {
        if (bytes > 4 && value.usedFrame !== frameSequence && value.touched < oldest) {
          oldest = value.touched
          tileKey = key
          materialKey = undefined
        }
      }
      if (materialKey !== undefined) {
        const value = cache.get(materialKey)!
        cacheBytes -= value.bytes
        cacheMetadataBytes -= metadataBytes(materialKey, value)
        cache.delete(materialKey)
        ages.delete(materialKey)
      } else if (tileKey !== undefined) {
        tileCacheBytes -= tiles.get(tileKey)!.raw.byteLength
        cacheMetadataBytes -= 128 + tileKey.length * 2
        tiles.delete(tileKey)
      } else return false
    }
    return true
  }
  const remember = (id: string, value: Material) => {
    const metadata = metadataBytes(id, value)
    if (!room(value.bytes, metadata)) return
    cache.set(id, value)
    ages.set(id, ++sequence)
    cacheBytes += value.bytes
    cacheMetadataBytes += metadata
  }
  const cachedInflate: Inflate = async (data, expected, operationSignal) => {
    checkCancelled(operationSignal)
    let buffer = buffers.get(data.buffer)
    if (buffer === undefined) {
      buffer = ++bufferSequence
      buffers.set(data.buffer, buffer)
    }
    const key =
      data.byteLength <= 512
        ? `${expected}:` + Array.from(data, (v) => v.toString(16).padStart(2, '0')).join('')
        : `${buffer}:${data.byteOffset}:${data.byteLength}:${expected}`
    const hit = tiles.get(key)
    if (hit) {
      hit.usedFrame = frameSequence
      hit.touched = ++sequence
      tileCacheHits++
      return hit.raw
    }
    const raw = await (inflate ?? inflateNative)(data, expected, operationSignal)
    inflates++
    checkCancelled(operationSignal)
    check(raw.byteLength === expected, 'INVALID_INFLATED_SIZE')
    const metadata = 128 + key.length * 2
    if (room(raw.byteLength, metadata)) {
      // Custom inflaters may reuse their result buffer on the next call.
      const owned = inflate ? raw.slice() : raw
      tiles.set(key, { raw: owned, usedFrame: frameSequence, touched: ++sequence })
      tileCacheBytes += owned.byteLength
      cacheMetadataBytes += metadata
      return owned
    }
    return raw
  }
  const renderer: FrameRenderer = {
    async render(position: number, input: FrameRenderOptions = {}): Promise<FrameRenderResult> {
      active(signal)
      check(!rendering, 'BUSY_FRAME_RENDERER')
      check(
        input &&
          typeof input === 'object' &&
          !Array.isArray(input) &&
          Object.keys(input).every((k) =>
            ['camera', 'layerKeyframes', 'layers', 'signal', 'region', 'scale'].includes(k),
          ),
        'INVALID_FRAME_RENDER_OPTIONS',
      )
      const operationSignal = input.signal ? AbortSignal.any([signal, input.signal]) : signal
      active(operationSignal)
      const scale = input.scale ?? 1
      check(
        scale >= 1 / 256 && scale <= 1 && Number.isInteger(Math.log2(scale)),
        'INVALID_FRAME_RENDER_OPTIONS',
      )
      const scaledWidth = Math.ceil(width * scale),
        scaledHeight = Math.ceil(height * scale)
      const region = input.region && { ...input.region },
        viewport = region ?? { left: 0, top: 0, width: scaledWidth, height: scaledHeight }
      const roots = scene.resolveRoots?.() ?? scene.roots ?? session.document.layers
      const sourceId = (view: RenderView) => (view.sourceId === undefined ? view.id : view.sourceId)
      const properties = (view: RenderView) => {
        const id = sourceId(view)
        return id === null
          ? { clipping: view.clipping ?? false, effects: undefined, diagnostics: [] }
          : {
              ...session.readLayerProperties(id),
              ...(view.clipping === undefined ? {} : { clipping: view.clipping }),
            }
      }
      const omitted = new Set<string>()
      const unresolved = (d: ClipDiagnostic) =>
        blocking(d) && !(d.layerId !== undefined && omitted.has(d.layerId) && d.part === 'material')
      checkRegion(viewport)
      // New rendering API follows stored settings by default; existing evaluate defaults remain unchanged.
      const frame = playback.evaluate(position, {
          camera: input.camera === undefined ? 'document' : input.camera,
          layerKeyframes: input.layerKeyframes === undefined ? 'document' : input.layerKeyframes,
          ...(input.layers === undefined ? {} : { layers: input.layers }),
        }),
        states = new Map(frame.layers.map((l) => [l.layerId, l])),
        diagnostics: ClipDiagnostic[] = [],
        held = new Map<Uint8ClampedArray, number>(),
        transparent = emptyPixels()
      frameSequence++
      let workingBytes = 0
      const available = () => maxWorkingBytes - workingBytes
      const reserve = (bytes: number) => {
        check(bytes <= available(), 'LIMIT_FRAME_RENDER_BYTES')
        workingBytes += bytes
      }
      const scratch = createTransformWorkspace(factory, reserve, (bytes) => {
        workingBytes -= bytes
      })
      const hold = (p: ClipPixels | undefined) => {
        if (!p) return
        const references = held.get(p.rgba) ?? 0
        if (!references) {
          if (p.rgba.byteLength > available()) scratch.clear()
          reserve(p.rgba.byteLength)
        }
        held.set(p.rgba, references + 1)
      }
      const release = (rgba: Uint8ClampedArray) => {
        const references = held.get(rgba)!
        if (references === 1) {
          held.delete(rgba)
          workingBytes -= rgba.byteLength
        } else held.set(rgba, references - 1)
      }
      const scope = () => {
        const arrays = new Set<Uint8ClampedArray>()
        return {
          hold(p: ClipPixels | undefined) {
            if (p && !arrays.has(p.rgba)) {
              hold(p)
              arrays.add(p.rgba)
            }
          },
          dispose() {
            for (const rgba of arrays) release(rgba)
            arrays.clear()
          },
        }
      }
      const releaseTree = (nodes: readonly CompositeLayer[]) => {
        for (const node of nodes) {
          if (node.visible === false) continue
          if (node.mask) release(node.mask.rgba)
          if (node.kind === 'pixels') release(node.pixels.rgba)
          else if (node.kind === 'group') releaseTree(node.children)
        }
      }
      const issue = (code: DiagnosticCode, id: string, reason?: string) =>
        diagnostics.push({ ...diagnostic(code, reason ? { reason } : undefined), layerId: id })
      const finishEffects = (
        pixels: ClipPixels,
        effects: MaterialEffects,
        attrs: CompositeAttributes,
      ) => {
        scratch.clear()
        const applied = effectPixels(
          pixels,
          effects,
          available(),
          operationSignal,
          effects.edge
            ? { opacity: attrs.opacity ?? 1, ...(attrs.mask ? { mask: attrs.mask } : {}) }
            : undefined,
          imageLimits,
        )
        diagnostics.push(...applied.diagnostics.map((d) => stamp(d, attrs.id!)))
        if (effects.edge) {
          // These were applied independently to image and border, before their union.
          if (attrs.mask) release(attrs.mask.rgba)
          delete attrs.mask
          attrs.opacity = 1
        }
        return applied.pixels
      }
      const material = async (
        view: RenderView,
        request?: ImageRegion,
        maskRequest?: ImageRegion,
      ): Promise<Material> => {
        const id = sourceId(view)
        if (id === null)
          return {
            layer: { id: view.id, name: view.name, isFolder: true },
            pixels: undefined,
            diagnostics: [],
            bytes: 0,
            usedFrame: frameSequence,
          }
        const key = JSON.stringify([id, view.mask, request, maskRequest, scale]),
          hit = cache.get(key)
        if (hit) {
          cacheHits++
          hit.usedFrame = frameSequence
          cache.delete(key)
          cache.set(key, hit)
          ages.set(key, ++sequence)
          return hit
        }
        scratch.clear()
        const prepared = scope()
        try {
          const originalRegion = (r: ImageRegion) => ({
            left: r.left / scale,
            top: r.top / scale,
            width: r.width / scale,
            height: r.height / scale,
          })
          const decoded = await session.decodeLayer(id, {
            source: scene.source ?? 'original',
            folderComposite: false,
            ...(request ? { region: originalRegion(request) } : {}),
            ...(maskRequest ? { maskRegion: originalRegion(maskRequest) } : {}),
            ...(scale === 1 ? {} : { rasterScale: scale }),
            signal: operationSignal,
            maxDecodedBytes: available(),
            imageLimits,
            ...(region ? { inflate: cachedInflate } : inflate ? { inflate } : {}),
          })
          decodes++
          active(operationSignal)
          const layer = decoded.layer,
            ds = decoded.diagnostics
              .filter((d) => d.part !== 'mask' || view.mask === 'enabled')
              .map((d) => stamp(d, view.id))
          prepared.hold(layer.pixels)
          prepared.hold(layer.mask)
          for (const fragment of layer.fragments ?? []) prepared.hold(fragment)
          let pixels: ClipPixels | undefined
          if (!view.folder && !layer.adjustment && !ds.some(blocking)) {
            pixels = materialPixels(
              layer,
              width,
              height,
              factory,
              available(),
              operationSignal,
              imageLimits,
              request,
            )
            prepared.hold(pixels)
            if (pixels && layer.effects) {
              // Border coverage depends on this frame's mask and opacity. Cache
              // only the frame-independent material, never its final border.
              const { edge: _edge, ...originalEffects } = layer.effects
              if (Object.keys(originalEffects).length) {
                const applied = effectPixels(
                  pixels,
                  originalEffects,
                  available(),
                  operationSignal,
                  undefined,
                  imageLimits,
                )
                pixels = applied.pixels
                prepared.hold(pixels)
                ds.push(...applied.diagnostics.map((d) => stamp(d, view.id)))
              }
            }
          }
          // Retain prepared original material only, not temporary text/fragments/canvases.
          const retained: ClipLayer = {
              id: layer.id,
              name: layer.name,
              isFolder: layer.isFolder,
              ...(layer.mask ? { mask: layer.mask } : {}),
              ...(layer.effects ? { effects: layer.effects } : {}),
              ...(layer.adjustment ? { adjustment: layer.adjustment } : {}),
            },
            result = {
              layer: retained,
              pixels,
              diagnostics: ds,
              bytes: (pixels?.rgba.byteLength ?? 0) + (layer.mask?.rgba.byteLength ?? 0),
              usedFrame: frameSequence,
            }
          remember(key, result)
          return result
        } finally {
          prepared.dispose()
        }
      }
      const hidden = (v: RenderView): CompositeLayer => {
        const p = properties(v)
        // Hidden nodes still determine which clipping base the layers above them use.
        if (p.clipping === undefined || v.blendMode === undefined || !isClipBlendMode(v.blendMode))
          issue('UNRESOLVED_FRAME_LAYER', v.id, 'composition-attributes')
        // A hidden adjustment remains a backdrop-dependent clipping base.
        return v.folder || v.kind === 'adjustment'
          ? {
              kind: 'group',
              id: v.id,
              visible: false,
              children: [],
              blendMode: v.kind === 'adjustment' ? 30 : (v.blendMode ?? 0),
              clipping: p.clipping ?? false,
            }
          : {
              kind: 'pixels',
              id: v.id,
              visible: false,
              pixels: transparent,
              blendMode: v.blendMode ?? 0,
              clipping: p.clipping ?? false,
            }
      }
      const draw = async (views: readonly RenderView[], margin = 0): Promise<CompositeLayer[]> => {
        const result: CompositeLayer[] = []
        for (const view of views) {
          active(operationSignal)
          if (view.kind === 'audio' || view.role === 'light-table-reference') continue
          const state = states.get(view.id)!
          if (state.visible === false || state.opacity === 0) {
            result.push(hidden(view))
            continue
          }
          diagnostics.push(...state.diagnostics.map((d) => stamp(d, view.id)))
          if (state.visible === undefined || state.opacity === undefined || !state.transform) {
            issue('UNRESOLVED_FRAME_LAYER', view.id)
            result.push(hidden(view))
            continue
          }
          for (const c of state.channels)
            if (
              !knownChannels.has(c.property) ||
              (['Opacity', 'ImageCelName'].includes(c.property) && c.axis !== undefined)
            )
              issue('UNSUPPORTED_FRAME_CHANNEL', view.id, c.property)
          const props = properties(view)
          diagnostics.push(
            ...props.diagnostics
              .filter((d) => d.code !== 'UNRESOLVED_PLAYBACK_SETTING')
              .map((d) => stamp(d, view.id)),
          )
          if (
            props.clipping === undefined ||
            view.blendMode === undefined ||
            !isClipBlendMode(view.blendMode)
          ) {
            issue('UNRESOLVED_FRAME_LAYER', view.id, 'composition-attributes')
            result.push(hidden(view))
            continue
          }
          if (view.kind === 'video' && scene.source !== 'saved') {
            issue('UNSUPPORTED_FRAME_MATERIAL', view.id, 'video')
            result.push(hidden(view))
            continue
          }
          const transient = scope()
          try {
            const extent =
                margin +
                (props.effects?.edge ? Math.ceil(props.effects.edge.radius) + (region ? 2 : 1) : 0),
              outputRegion = region && expandRegion(region, extent),
              request =
                outputRegion &&
                expandRegion(
                  inverseRegion(
                    translation(state.transform) ? outputRegion : transformRegion(outputRegion),
                    state.transform,
                    translation(state.transform) ? 0 : 2,
                  ),
                  effectHalo(props.effects),
                ),
              maskRequest =
                outputRegion && state.maskTransform
                  ? inverseRegion(
                      translation(state.maskTransform)
                        ? outputRegion
                        : transformRegion(outputRegion),
                      state.maskTransform,
                      translation(state.maskTransform) ? 0 : 2,
                    )
                  : request,
              decoded = await material(view, request, maskRequest)
            diagnostics.push(...decoded.diagnostics.map((d) => stamp(d, view.id)))
            transient.hold(decoded.pixels)
            transient.hold(decoded.layer.mask)
            const failures = decoded.diagnostics.filter(blocking)
            if (
              scene.omitMissingMaterials &&
              !view.folder &&
              !decoded.layer.adjustment &&
              !decoded.pixels &&
              failures.length &&
              failures.every(
                (d) => d.part === 'material' && (d.kind === 'missing' || d.kind === 'unsupported'),
              )
            ) {
              omitted.add(view.id)
              result.push(hidden(view))
              continue
            }
            const effects = decoded.layer.effects,
              blendMode = scene.isolated === view.id ? 0 : view.blendMode,
              clipping = scene.isolated === view.id ? false : props.clipping
            // Border ordering is verified separately; watercolor and pass-through
            // effects still require different backdrop/extent semantics.
            if (
              (decoded.layer.adjustment && effects) ||
              (view.folder &&
                effects &&
                (effects.watercolor ||
                  blendMode === 30 ||
                  (!effects.edge && !translation(state.transform)))) ||
              (effects?.edge && !effects.edge.reflectOpacity && (blendMode !== 0 || clipping)) ||
              (effects?.watercolor && (view.mask === 'enabled' || !translation(state.transform)))
            )
              issue('UNSUPPORTED_FRAME_EFFECT_COMBINATION', view.id)
            const attrs: CompositeAttributes = {
              id: view.id,
              visible: true,
              opacity: state.opacity,
              blendMode,
              clipping,
            }
            if (view.mask === 'enabled') {
              if (!decoded.layer.mask || !state.maskTransform)
                issue('UNRESOLVED_FRAME_LAYER', view.id, 'mask')
              else {
                attrs.mask = transformPixels(
                  decoded.layer.mask,
                  state.maskTransform,
                  width,
                  height,
                  factory,
                  available(),
                  operationSignal,
                  true,
                  scratch,
                  extent,
                  imageLimits,
                  viewport,
                )
                hold(attrs.mask)
                if (!translation(state.maskTransform))
                  issue('APPROXIMATE_FRAME_TRANSFORM', view.id, 'mask')
              }
            }
            if (view.folder) {
              const children = await draw(view.children, extent)
              if (effects && !diagnostics.some(unresolved)) {
                scratch.clear()
                const flat = compositeLayers(
                  children,
                  viewport.width + 2 * extent,
                  viewport.height + 2 * extent,
                  {
                    imageLimits,
                    left: viewport.left - extent,
                    top: viewport.top - extent,
                    signal: operationSignal,
                    maxWorkingBytes: available(),
                  },
                )
                transient.hold(flat.pixels)
                releaseTree(children)
                children.length = 0
                diagnostics.push(...flat.diagnostics.map((d) => stamp(d, view.id)))
                const pixels = finishEffects(flat.pixels, effects, attrs)
                hold(pixels)
                result.push({ ...attrs, kind: 'pixels', pixels })
              } else result.push({ ...attrs, kind: 'group', children })
            } else if (decoded.layer.adjustment)
              result.push({ ...attrs, kind: 'adjustment', adjustment: decoded.layer.adjustment })
            else if (decoded.pixels) {
              let p = transformPixels(
                decoded.pixels,
                state.transform,
                width,
                height,
                factory,
                available(),
                operationSignal,
                false,
                scratch,
                extent,
                imageLimits,
                viewport,
              )
              if (effects?.edge) {
                transient.hold(p)
                p = finishEffects(p, { edge: effects.edge }, attrs)
              }
              hold(p)
              if (!translation(state.transform)) issue('APPROXIMATE_FRAME_TRANSFORM', view.id)
              result.push({ ...attrs, kind: 'pixels', pixels: p })
            } else {
              issue('UNSUPPORTED_FRAME_MATERIAL', view.id, view.kind ?? 'unknown')
              result.push(hidden(view))
            }
          } finally {
            transient.dispose()
          }
        }
        return result
      }
      rendering = true
      try {
        if (scale !== 1) {
          const visit = (views: readonly RenderView[]): void => {
            for (const view of views) {
              const state = states.get(view.id)!
              if (state.visible === false || state.opacity === 0) continue
              const id = sourceId(view),
                props = properties(view)
              check(
                (id === null ||
                  (['raster', 'paper', 'folder'].includes(view.kind ?? '') && !props.effects)) &&
                  state.transform?.every((v, i) => v === [1, 0, 0, 1, 0, 0][i]) &&
                  (!state.maskTransform ||
                    state.maskTransform.every((v, i) => v === [1, 0, 0, 1, 0, 0][i])),
                'UNSUPPORTED_FRAME_MATERIAL',
                { reason: 'preview-scale' },
              )
              visit(view.children)
            }
          }
          visit(roots)
        }
        const tree = await draw(roots)
        active(operationSignal)
        if (diagnostics.some(unresolved))
          return { status: 'unavailable', pixels: undefined, frame, diagnostics }
        scratch.clear()
        const background = scene.background?.()
        const output = compositeLayers(tree, viewport.width, viewport.height, {
          ...(background ? { background } : {}),
          left: viewport.left,
          top: viewport.top,
          imageLimits,
          signal: operationSignal,
          maxWorkingBytes: available(),
        })
        active(operationSignal)
        return {
          status: 'rendered',
          pixels: output.pixels,
          frame,
          diagnostics: [...diagnostics, ...output.diagnostics],
        }
      } catch (error) {
        rethrowFatal(error)
        const d = serializeClipError(error)
        if (d.kind === 'environment') throw error
        return { status: 'unavailable', pixels: undefined, frame, diagnostics: [...diagnostics, d] }
      } finally {
        rendering = false
        scratch.clear()
        held.clear()
      }
    },
    renderTiles(position: number, input: FrameTileOptions = {}) {
      const { tileWidth, tileHeight, ...rest } = input,
        policy = {
          ...rest,
          ...(rest.layers ? { layers: rest.layers.map((layer) => ({ ...layer })) } : {}),
        }
      return renderRegions(
        {
          left: 0,
          top: 0,
          width: Math.ceil(width * (input.scale ?? 1)),
          height: Math.ceil(height * (input.scale ?? 1)),
        },
        {
          ...policy,
          ...(tileWidth === undefined ? {} : { tileWidth }),
          ...(tileHeight === undefined ? {} : { tileHeight }),
        },
        (region) => renderer.render(position, { ...policy, region }),
      )
    },
    clearCache,
    resources: () =>
      Object.freeze({
        closed,
        rendering,
        cacheBytes: cacheBytes + tileCacheBytes,
        cacheEntries: cache.size + tiles.size,
        decodes,
        cacheHits,
        tileCacheBytes,
        tileCacheEntries: tiles.size,
        tileCacheHits,
        inflates,
        cacheMetadataBytes,
      }),
    dispose() {
      if (closed) return
      closed = true
      lifetime.abort()
      clearCache()
      playback.dispose()
    },
  }
  return Object.freeze(renderer)
}
