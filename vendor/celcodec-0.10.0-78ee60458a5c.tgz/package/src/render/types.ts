import type { ClipPixels } from '../types.js'
import type { MaterialAdjustment } from '../material/types.js'
import type { ClipDiagnostic } from '../diagnostics.js'

export interface CompositeAttributes {
  id?: string
  visible?: boolean
  /** Native normalized opacity, 0..1; never an output-workflow override. */
  opacity?: number
  /** Native LayerComposite ID. Unknown IDs fail explicitly. */
  blendMode?: number
  /** Clip to the nearest lower non-clipped sibling within this folder.
   * CSP ignores a chain without a base, or above a pass-through/adjustment base.
   * A pass-through folder clipped to a regular base renders as an isolated group. */
  clipping?: boolean
  /** Document-space grayscale mask: red channel, defaultColor outside the crop. */
  mask?: ClipPixels
}
export type CompositeLayer = CompositeAttributes &
  (
    | { kind: 'pixels'; pixels: ClipPixels }
    | { kind: 'group'; children: readonly CompositeLayer[] }
    | { kind: 'adjustment'; adjustment: MaterialAdjustment }
  )
export interface CompositeOptions {
  /** RGBA8 backdrop, painted before any layer blending. Default transparent. */
  background?: readonly [number, number, number, number]
  imageLimits?: import('../image-resources.js').ImageResourceLimits
  /** Origin of the requested output rectangle in document coordinates. Default 0. */
  left?: number
  top?: number
  signal?: AbortSignal
  /** Output and pooled scratch buffers combined; caller-owned input pixels excluded. Default 512 MiB. */
  maxWorkingBytes?: number
  /** Count includes hidden nodes. Default 100,000. */
  maxLayers?: number
  /** Default 64; cycles always fail. */
  maxDepth?: number
}
export interface CompositeResult {
  pixels: ClipPixels
  diagnostics: ClipDiagnostic[]
}
