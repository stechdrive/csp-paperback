import type { ClipPixels } from '../types.js'

/** Scalar masks use red, independently of alpha, and retain their outside value. */
export function maskAt(mask: ClipPixels | undefined, x: number, y: number): number {
  if (!mask || mask.disabled) return 1
  const mx = x - mask.left,
    my = y - mask.top
  return (
    (mx >= 0 && my >= 0 && mx < mask.width && my < mask.height
      ? mask.rgba[(my * mask.width + mx) * 4]!
      : (mask.defaultColor ?? 0)) / 255
  )
}
