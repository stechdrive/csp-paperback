import { check } from '../internal/binary.js'
import { compileCurve } from '../internal/curve.js'
import type { MaterialAdjustment, AdjustmentLevels } from '../material/types.js'

const byte = (v: number) => Math.max(0, Math.min(255, Math.round(v)))
const unit = (v: number) => Math.max(0, Math.min(1, v))
function range(v: number, min: number, max: number): boolean {
  return Number.isFinite(v) && v >= min && v <= max
}
/** Reject unsupported or malformed settings before changing any caller pixels. */
export function validateAdjustment(a: MaterialAdjustment): void {
  check(a && typeof a === 'object', 'INVALID_ADJUSTMENT_SETTINGS')
  let valid = false
  switch (a.kind) {
    case 'invert':
      valid = true
      break
    case 'threshold':
      valid = range(a.threshold, 0, 255)
      break
    case 'posterize':
      valid = Number.isInteger(a.levels) && range(a.levels, 2, 256)
      break
    case 'brightness-contrast':
      valid = range(a.brightness, -100, 100) && range(a.contrast, -100, 100)
      break
    case 'hue-saturation-lightness':
      valid =
        range(a.hue, -180, 180) && range(a.saturation, -100, 100) && range(a.lightness, -100, 100)
      break
    case 'tone-curve':
      valid =
        Array.isArray(a.channels) &&
        a.channels.length === 4 &&
        a.channels.every(
          (ps) =>
            Array.isArray(ps) &&
            ps.length >= 2 &&
            ps.length <= 32 &&
            ps.every(
              (p, i) =>
                Array.isArray(p) &&
                p.length === 2 &&
                p.every((v) => Number.isInteger(v) && range(v, 0, 65535)) &&
                (!i || p[0] >= ps[i - 1]![0]),
            ),
        )
      break
    case 'levels':
      valid =
        Array.isArray(a.channels) &&
        a.channels.length === 4 &&
        a.channels.every(
          (p) =>
            p &&
            [p.inputBlack, p.inputMid, p.inputWhite, p.outputBlack, p.outputWhite].every(
              (v) => Number.isInteger(v) && range(v, 0, 65535),
            ) &&
            p.inputBlack < p.inputMid &&
            p.inputMid < p.inputWhite,
        )
      break
    default:
      check(false, 'UNSUPPORTED_ADJUSTMENT')
  }
  check(valid, 'INVALID_ADJUSTMENT_SETTINGS')
}
function level(p: AdjustmentLevels): (v: number) => number {
  const span = p.inputWhite - p.inputBlack,
    exponent = Math.log(0.5) / Math.log((p.inputMid - p.inputBlack) / span)
  return (v) =>
    (p.outputBlack +
      (p.outputWhite - p.outputBlack) * unit((v * 65535 - p.inputBlack) / span) ** exponent) /
    65535
}
export type AdjustPixel = (data: Uint8ClampedArray, at: number) => void
/** At most 768 bytes of LUT storage per compiled adjustment. Alpha is unchanged. */
export function compileAdjustment(a: MaterialAdjustment): AdjustPixel {
  validateAdjustment(a)
  if (a.kind === 'threshold')
    return (data, i) => {
      const value =
        299 * data[i]! + 587 * data[i + 1]! + 114 * data[i + 2]! >= a.threshold * 1000 ? 255 : 0
      data[i] = data[i + 1] = data[i + 2] = value
    }
  if (a.kind === 'hue-saturation-lightness')
    return (data, i) => {
      const r = data[i]!,
        g = data[i + 1]!,
        b = data[i + 2]!,
        max = Math.max(r, g, b),
        min = Math.min(r, g, b),
        delta = max - min,
        lightness = a.lightness / 100,
        saturation = a.saturation / 100
      let value = max / 255,
        sat = max ? delta / max : 0,
        hue = delta
          ? max === r
            ? (g - b) / delta
            : max === g
              ? (b - r) / delta + 2
              : (r - g) / delta + 4
          : 0
      // CSP's lightness and saturation controls operate on HSV intermediates.
      // Lightness precedes saturation; positive saturation is limited by value.
      if (lightness >= 0) {
        value += (1 - value) * lightness
        sat *= 1 - lightness
      } else value *= 1 + lightness
      if (delta && saturation >= 0) {
        const minimum = value * (1 - sat),
          amount = minimum ? Math.min(saturation, (1 - value) / minimum) : saturation
        value += minimum * amount
        sat += (1 - sat) * amount
      } else if (delta) {
        value -= ((value * sat) / 2) * -saturation
        sat *= 1 + saturation
      }
      hue = (((hue + a.hue / 60) % 6) + 6) % 6
      const f = hue % 1,
        low = value * (1 - sat),
        down = value * (1 - sat * f),
        up = value * (1 - sat * (1 - f))
      let red: number, green: number, blue: number
      switch (Math.floor(hue)) {
        case 0:
          red = value
          green = up
          blue = low
          break
        case 1:
          red = down
          green = value
          blue = low
          break
        case 2:
          red = low
          green = value
          blue = up
          break
        case 3:
          red = low
          green = down
          blue = value
          break
        case 4:
          red = up
          green = low
          blue = value
          break
        default:
          red = value
          green = low
          blue = down
      }
      data[i] = byte(red * 255)
      data[i + 1] = byte(green * 255)
      data[i + 2] = byte(blue * 255)
    }
  const table = new Uint8Array(768)
  const channels =
    a.kind === 'tone-curve'
      ? a.channels.map((ps) => compileCurve(ps.map((p) => [p[0] / 65535, p[1] / 65535])))
      : a.kind === 'levels'
        ? a.channels.map(level)
        : undefined
  for (let ch = 0; ch < 3; ch++)
    for (let v = 0; v < 256; v++) {
      let result: number
      if (channels) result = channels[0]!(channels[ch + 1]!(v / 255)) * 255
      else if (a.kind === 'invert') result = 255 - v
      else if (a.kind === 'posterize')
        result =
          Math.floor(
            (Math.max(0, Math.ceil((v * a.levels) / 255) - 1) * 65535) / (a.levels - 1),
          ) >>> 8
      else if (a.kind === 'brightness-contrast') {
        const center = v - 127.5 + a.brightness
        result =
          a.contrast === 100
            ? center >= 0
              ? 255
              : 0
            : a.contrast >= 0
              ? center / (1 - a.contrast / 100) + 127.5
              : (v - 127.5) * (1 + a.contrast / 100) + 127.5 + a.brightness
      } else result = v
      table[ch * 256 + v] = byte(result)
    }
  return (data, i) => {
    for (let ch = 0; ch < 3; ch++) data[i + ch] = table[ch * 256 + data[i + ch]!]!
  }
}
/** In-place RGB correction with straight alpha preserved. Settings validate atomically.
 * Native 8-bit quantization is approximate; see docs/adjustments.md. */
export function applyAdjustment(data: Uint8ClampedArray, adjustment: MaterialAdjustment): void {
  check(data instanceof Uint8ClampedArray && data.length % 4 === 0, 'INVALID_PIXEL_LENGTH')
  const apply = compileAdjustment(adjustment)
  for (let i = 0; i < data.length; i += 4) apply(data, i)
}
