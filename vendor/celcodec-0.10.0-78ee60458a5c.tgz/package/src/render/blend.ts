// Color equations reference wamsoft/clipparse (MIT); native alpha and boundary
// behavior independently measured in CSP EX 5.1.5. See docs/compositing.md.
import { check } from '../internal/binary.js'

export const CLIP_BLEND_MODES = Object.freeze({
  normal: 0,
  darken: 1,
  multiply: 2,
  colorBurn: 3,
  linearBurn: 4,
  subtract: 5,
  darkerColor: 6,
  lighten: 7,
  screen: 8,
  colorDodge: 9,
  glowDodge: 10,
  add: 11,
  addGlow: 12,
  lighterColor: 13,
  overlay: 14,
  softLight: 15,
  hardLight: 16,
  vividLight: 17,
  linearLight: 18,
  pinLight: 19,
  hardMix: 20,
  difference: 21,
  exclusion: 22,
  hue: 23,
  saturation: 24,
  color: 25,
  luminosity: 26,
  passThrough: 30,
  divide: 36,
} as const)
export type ClipBlendMode = (typeof CLIP_BLEND_MODES)[keyof typeof CLIP_BLEND_MODES]
/** Straight (unpremultiplied) RGBA8. */
export type Rgba = readonly [number, number, number, number]
export function isClipBlendMode(value: number): value is ClipBlendMode {
  return Number.isInteger(value) && ((value >= 0 && value <= 26) || value === 30 || value === 36)
}
export const clamp = (v: number) => Math.max(0, Math.min(1, v))
const dodge = (b: number, s: number) => (b <= 0 ? 0 : s >= 1 ? 1 : Math.min(1, b / (1 - s)))
const burn = (b: number, s: number) => (b >= 1 ? 1 : s <= 0 ? 0 : 1 - Math.min(1, (1 - b) / s))
type Rgb = [number, number, number]
const lum = (v: Rgb) => v[0] * 0.3 + v[1] * 0.59 + v[2] * 0.11
const sat = (v: Rgb) => Math.max(...v) - Math.min(...v)
function setLum(v: Rgb, target: number): Rgb {
  const offset = target - lum(v)
  let [r, g, b] = v.map((c) => c + offset) as Rgb
  const n = Math.min(r, g, b),
    x = Math.max(r, g, b)
  if (n < 0) {
    const k = target / (target - n)
    r = target + (r - target) * k
    g = target + (g - target) * k
    b = target + (b - target) * k
  }
  if (x > 1) {
    const k = (1 - target) / (x - target)
    r = target + (r - target) * k
    g = target + (g - target) * k
    b = target + (b - target) * k
  }
  return [r, g, b]
}
function setSat(v: Rgb, target: number): Rgb {
  const n = Math.min(...v),
    x = Math.max(...v)
  return v.map((c) => (x > n ? ((c - n) * target) / (x - n) : 0)) as Rgb
}
function channel(b: number, s: number, mode: number): number {
  switch (mode) {
    case 0:
      return s
    case 1:
      return Math.min(b, s)
    case 2:
      return b * s
    case 3:
      return burn(b, s)
    case 4:
      return clamp(b + s - 1)
    case 5:
      return clamp(b - s)
    case 7:
      return Math.max(b, s)
    case 8:
      return 1 - (1 - b) * (1 - s)
    case 9:
    case 10:
      return dodge(b, s)
    case 11:
    case 12:
      return clamp(b + s)
    case 14:
      return b <= 0.5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s)
    case 15: {
      const d = b <= 0.25 ? ((16 * b - 12) * b + 4) * b : Math.sqrt(b)
      return s <= 0.5 ? b - (1 - 2 * s) * b * (1 - b) : b + (2 * s - 1) * (d - b)
    }
    case 16:
      return s <= 0.5 ? 2 * b * s : 1 - 2 * (1 - b) * (1 - s)
    case 17:
      return s <= 0 ? 0 : s >= 1 ? 1 : s <= 0.5 ? burn(b, 2 * s) : dodge(b, 2 * s - 1)
    case 18:
      return clamp(b + 2 * s - 1)
    case 19:
      return s <= 0.5 ? Math.min(b, 2 * s) : Math.max(b, 2 * s - 1)
    case 20: {
      // Native integer vivid-light threshold: complementary 8-bit pairs below
      // and above the source midpoint land on opposite sides of 127/128.
      if (b >= 1) return 1
      if (b <= 0) return 0
      const total = b * 255 + s * 255
      return total > 255 + 1e-10 || (Math.abs(total - 255) < 1e-10 && s < 0.5) ? 1 : 0
    }
    case 21:
      return Math.abs(b - s)
    case 22:
      return b + s - 2 * b * s
    case 36:
      return b <= 0 ? 0 : s <= 0 ? 1 : clamp(b / s)
    default:
      throw new Error('Validated blend mode required')
  }
}
/** Internal hot path; callers validate mode, offsets and buffers once. */
export function blendInto(
  dest: Uint8ClampedArray,
  di: number,
  source: Uint8ClampedArray,
  si: number,
  mode: number,
  opacity: number,
): void {
  const as = (source[si + 3]! / 255) * opacity,
    ab = dest[di + 3]! / 255
  if (as <= 0) return
  // These boundary cases preserve the exact RGBA8 result, including hidden RGB
  // when a positive source alpha rounds to zero. Other equations stay unchanged.
  if (ab === 0 || (mode === 0 && as === 1)) {
    dest[di] = source[si]!
    dest[di + 1] = source[si + 1]!
    dest[di + 2] = source[si + 2]!
    dest[di + 3] = Math.round(as * 255)
    return
  }
  const ao = as + ab * (1 - as),
    t = as / ao
  let rgb: Rgb | undefined
  if (mode === 6 || mode === 13 || (mode >= 23 && mode <= 26)) {
    const b: Rgb = [dest[di]! / 255, dest[di + 1]! / 255, dest[di + 2]! / 255]
    const s: Rgb = [source[si]! / 255, source[si + 1]! / 255, source[si + 2]! / 255]
    if (mode === 6 || mode === 13) {
      const lb = Math.round(lum(b) * 255),
        ls = Math.round(lum(s) * 255)
      rgb = (mode === 6 ? ls <= lb : ls >= lb) ? s : b
    } else if (mode === 23) rgb = setLum(setSat(s, sat(b)), lum(b))
    else if (mode === 24) rgb = setLum(setSat(b, sat(s)), lum(b))
    else if (mode === 25) rgb = setLum(s, lum(b))
    else rgb = setLum(b, lum(s))
  }
  for (let c = 0; c < 3; c++) {
    const b = dest[di + c]! / 255,
      s = source[si + c]! / 255
    const v = rgb?.[c] ?? channel(b, s * (mode === 10 ? as : mode === 12 ? t : 1), mode)
    const overlap =
      mode === 10 || mode === 12
        ? v
        : mode === 0 || mode === 2
          ? as * v + (1 - as) * b
          : t * v + (1 - t) * b
    dest[di + c] = Math.round(clamp(((1 - ab) * as * s + ab * overlap) / ao) * 255)
  }
  // CSP's five legacy light modes retain additive alpha even though their
  // straight RGB uses the source-over denominator. Do not substitute Canvas.
  const alpha =
    mode === 8 || mode === 9 || mode === 10 || mode === 15 || mode === 16
      ? Math.min(1, as + ab)
      : ao
  dest[di + 3] = Math.round(alpha * 255)
}

/** One native blend operation. Pass-through belongs to folders, not pixels.
 * Numerical agreement is bounded by native capture tests, not bit exact. */
export function compositePixel(backdrop: Rgba, source: Rgba, mode: number = 0, opacity = 1): Rgba {
  check(isClipBlendMode(mode) && mode !== 30, 'UNSUPPORTED_COMPOSITE_MODE', { mode })
  check(Number.isFinite(opacity) && opacity >= 0 && opacity <= 1, 'INVALID_COMPOSITE_LAYER')
  check(
    [backdrop, source].every(
      (v) => v.length === 4 && v.every((c) => Number.isInteger(c) && c >= 0 && c <= 255),
    ),
    'INVALID_PIXEL_LENGTH',
  )
  const out = new Uint8ClampedArray(backdrop)
  blendInto(out, 0, new Uint8ClampedArray(source), 0, mode, opacity)
  return [out[0]!, out[1]!, out[2]!, out[3]!]
}
