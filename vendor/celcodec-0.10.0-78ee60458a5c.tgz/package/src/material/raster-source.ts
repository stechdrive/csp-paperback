import { check } from '../internal/binary.js'
import { readAttribute } from '../internal/raster.js'
import { decodeRasterPixels } from '../internal/raster-decode.js'
import { readRasterTiles, type RasterTile } from '../format/raster-tiles.js'
import { checkCancelled, diagnostic } from '../diagnostics.js'
import {
  resourceLimit,
  resolveImageLimits,
  validateImageRegion,
  type ImageRegion,
} from '../image-resources.js'
import type { MaterialResult, RasterOptions } from './index.js'

export interface RasterSource {
  readonly width: number
  readonly height: number
  readRegion(
    region: ImageRegion,
    options?: { signal?: AbortSignal; crop?: boolean },
  ): Promise<MaterialResult>
  /** Row-major rectangles; consume/release each result before requesting the next. */
  tiles(options?: {
    region?: ImageRegion
    tileWidth?: number
    tileHeight?: number
    signal?: AbortSignal
  }): AsyncGenerator<MaterialResult>
  dispose(): void
}

/** Index native tile framing once. Inputs are borrowed read-only until dispose().
 * Only requested payloads are inflated; this is not whole-file payload validation.
 * Each result owns its RGBA buffer. Retained results count against the caller's budget. */
export function createRasterSource(
  attribute: Uint8Array,
  body?: Uint8Array,
  options: Omit<RasterOptions, 'region' | 'crop'> = {},
): RasterSource {
  checkCancelled(options.signal)
  check(
    attribute.byteLength + (body?.byteLength ?? 0) <=
      resourceLimit(options.maxInputBytes ?? 1024 ** 3),
    'LIMIT_INPUT_BYTES',
  )
  const a = readAttribute(attribute),
    limits = resolveImageLimits(options.imageLimits),
    maxPixels = resourceLimit(options.maxPixels ?? limits.maxPixels),
    lifetime = new AbortController(),
    signal = options.signal ? AbortSignal.any([lifetime.signal, options.signal]) : lifetime.signal,
    inflate = options.inflate,
    mask = options.mask ?? false,
    index = new Map<number, RasterTile>()
  for (const tile of readRasterTiles(a, body, signal))
    index.set((tile.y / 256) * a.cols + tile.x / 256, tile)
  let closed = false
  async function readRegion(
    region: ImageRegion,
    input: { signal?: AbortSignal; crop?: boolean } = {},
  ): Promise<MaterialResult> {
    check(!closed, 'CLOSED_RASTER_SOURCE')
    const operationSignal = input.signal ? AbortSignal.any([signal, input.signal]) : signal
    checkCancelled(operationSignal)
    region = { ...region }
    validateImageRegion(region, a.width, a.height)
    const selected: RasterTile[] = []
    for (
      let y = Math.floor(region.top / 256);
      y < Math.ceil((region.top + region.height) / 256);
      y++
    )
      for (
        let x = Math.floor(region.left / 256);
        x < Math.ceil((region.left + region.width) / 256);
        x++
      ) {
        const tile = index.get(y * a.cols + x)
        if (tile) selected.push(tile)
      }
    const pixels = await decodeRasterPixels(
      a,
      body,
      mask,
      input.crop ?? false,
      { region, signal: operationSignal, ...(inflate ? { inflate } : {}) },
      { ...limits, maxPixels },
      selected,
    )
    checkCancelled(operationSignal)
    return { pixels, diagnostics: pixels ? [] : [diagnostic('MISSING_RASTER_DATA')] }
  }
  return {
    width: a.width,
    height: a.height,
    readRegion,
    async *tiles(input = {}) {
      check(!closed, 'CLOSED_RASTER_SOURCE')
      const region = { ...(input.region ?? { left: 0, top: 0, width: a.width, height: a.height }) },
        tw = input.tileWidth ?? 256,
        th = input.tileHeight ?? 256
      validateImageRegion(region, a.width, a.height)
      check(
        [tw, th].every((v) => Number.isSafeInteger(v) && v > 0),
        'INVALID_IMAGE_DIMENSIONS',
      )
      for (let y = region.top; y < region.top + region.height; y += th)
        for (let x = region.left; x < region.left + region.width; x += tw)
          yield await readRegion(
            {
              left: x,
              top: y,
              width: Math.min(tw, region.left + region.width - x),
              height: Math.min(th, region.top + region.height - y),
            },
            input,
          )
    },
    dispose() {
      closed = true
      lifetime.abort()
      index.clear()
      a.sizes.length = 0
      body = undefined
    },
  }
}
