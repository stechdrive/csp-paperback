import { diagnostic, type ClipDiagnostic, type DiagnosticCode } from '../diagnostics.js'
import type { ClipLayer } from './types.js'
export function layerRenderingDiagnostics(
  layer: ClipLayer,
  _compatibility?: 'saved' | 'not-saved' | 'unknown',
): ClipDiagnostic[] {
  const result: ClipDiagnostic[] = []
  if (layer.kind === 'audio' || layer.kind === 'video') return result
  const add = (
    code: DiagnosticCode,
    part: NonNullable<ClipDiagnostic['part']>,
    outcome: NonNullable<ClipDiagnostic['outcome']>,
    materialKind?: string,
  ) =>
    result.push({
      ...diagnostic(code),
      layerId: layer.id,
      part,
      outcome,
      ...(materialKind ? { materialKind } : {}),
    })
  if (layer.unsupported3D) add('UNSUPPORTED_3D', 'material', 'missing-content', '3d')
  else if (layer.vectorRendering)
    add(
      layer.vectorRendering === 'unavailable' ? 'MISSING_VECTOR_DATA' : 'APPROXIMATE_VECTOR',
      'material',
      layer.vectorRendering === 'unavailable' ? 'missing-content' : 'approximate',
      'vector',
    )
  else if (layer.materialSource === 'text')
    add('APPROXIMATE_TEXT', 'material', 'approximate', 'text')
  if (layer.adjustment) add('APPROXIMATE_ADJUSTMENT', 'material', 'approximate', 'adjustment')
  if (layer.effects?.watercolor)
    add(
      layer.effects.watercolor.style ? 'UNSUPPORTED_WATERCOLOR_STYLE' : 'APPROXIMATE_WATERCOLOR',
      'effect',
      layer.effects.watercolor.style ? 'missing-effect' : 'approximate',
    )
  if (layer.effects?.tone) add('UNSUPPORTED_TONE', 'effect', 'missing-effect')
  return result
}
