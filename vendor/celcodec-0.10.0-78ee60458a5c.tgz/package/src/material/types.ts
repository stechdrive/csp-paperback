export interface EdgeEffect {
  radius: number
  color: [number, number, number]
  reflectOpacity?: boolean
  antialias?: boolean
}
export interface WatercolorEffect {
  range: number
  opacity: number
  darkness: number
  blur: number
  style?: number
}
export interface MaterialEffects {
  layerColor?: { main: [number, number, number]; sub: [number, number, number] }
  edge?: EdgeEffect
  watercolor?: WatercolorEffect
  /** Detected for guidance only; tone rasterization is intentionally unsupported. */
  tone?: boolean
}

/** Native 16-bit coordinates, 0..65535. RGB master followed by red, green, blue. */
export type AdjustmentCurve = readonly (readonly [number, number])[]
export interface AdjustmentLevels {
  inputBlack: number
  inputMid: number
  inputWhite: number
  outputBlack: number
  outputWhite: number
}
export type AdjustmentChannels<T> = readonly [T, T, T, T]
export type MaterialAdjustment =
  | { kind: 'invert' }
  | { kind: 'threshold'; threshold: number }
  | { kind: 'posterize'; levels: number }
  | { kind: 'brightness-contrast'; brightness: number; contrast: number }
  | { kind: 'hue-saturation-lightness'; hue: number; saturation: number; lightness: number }
  | { kind: 'tone-curve'; channels: AdjustmentChannels<AdjustmentCurve> }
  | { kind: 'levels'; channels: AdjustmentChannels<AdjustmentLevels> }

/** Corners in document space: top left, top right, bottom right, bottom left. */
export type MaterialQuad = [number, number, number, number, number, number, number, number]

export interface TextObject {
  text: string
  left: number
  top: number
  width: number
  height: number
  font: string
  size: number
  color: [number, number, number]
  align: 'left' | 'center' | 'right'
  runs: {
    start: number
    length: number
    font: string
    size: number
    color: [number, number, number]
  }[]
}

export type LayerContentKind =
  | 'raster'
  | 'folder'
  | 'camera'
  | 'text'
  | 'image-material'
  | 'vector'
  | '3d'
  | 'adjustment'
  | 'fill'
  | 'gradient'
  | 'paper'
  | 'audio'
  | 'video'
  | 'other'
export type { ClipPixels } from '../types.js'
import type { ClipPixels } from '../types.js'
/** Native material description. No PSD or UI state is required. */
export interface ClipLayer {
  id: string
  name: string
  isFolder: boolean
  kind?: LayerContentKind
  pixels?: ClipPixels
  /** Folder/movie snapshot at save time. Drawing effects are baked; mask is separate.
   * This is a preview, not reusable original artwork or a frame-addressable movie decoder. */
  savedComposite?: boolean
  fragments?: ClipPixels[]
  mask?: ClipPixels
  materialSource?:
    | 'render'
    | 'timeline-original'
    | 'image-original'
    | 'object-cache'
    | 'text'
    | 'fill'
    | 'gradient'
    | 'adjustment'
    | 'vector'
  vectorRendering?: 'approximate' | 'unavailable'
  unsupported3D?: boolean
  placement?: MaterialQuad
  /** Whole original extent when pixels are a regional crop used with placement. */
  placementSource?: import('../image-resources.js').ImageRegion
  text?: TextObject[]
  effects?: MaterialEffects
  adjustment?: MaterialAdjustment
}
