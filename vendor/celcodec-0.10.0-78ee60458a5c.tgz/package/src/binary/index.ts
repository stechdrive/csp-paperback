/** Bounded binary utilities for applications inspecting native records. */
export { Reader, check, inflate } from '../internal/binary.js'
export {
  crc32,
  adler32,
  concat,
  concatParts,
  named,
  u32,
  u64,
  uint64,
  utf8,
  text,
  view,
  externalId,
  layerUuid,
  identity,
} from '../native/binary.js'
export { inflateBounded } from '../native/compression.js'
export { num, str } from '../internal/records.js'
export type { ClipRow, ClipValue } from '../internal/records.js'
