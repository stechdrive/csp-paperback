import { numberAt } from '../internal/indexed.js'
// CLIP Offscreen framing shared by material and native decoders.
// Format research: wamsoft/clipparse (MIT); see THIRD_PARTY_NOTICES.md.
import { check, Reader } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import type { OffscreenAttribute } from '../internal/raster.js'

export interface RasterTile {
  x: number
  y: number
  expected: number
  compressed: Uint8Array
}

/** Validate framing before allocating pixels; compressed payloads borrow the input. */
export function readRasterTiles(
  a: OffscreenAttribute,
  body: Uint8Array | undefined,
  signal?: AbortSignal,
): RasterTile[] {
  checkCancelled(signal)
  if (!body) return []
  const source = new Reader(body),
    tiles: RasterTile[] = []
  for (let index = 0; index < a.sizes.length; index++) {
    checkCancelled(signal)
    const size = numberAt(a.sizes, index)
    check(size >= 104, 'INVALID_TILE_SIZE')
    const r = new Reader(source.take(size))
    check(r.u32() === size && r.wideName() === 'BlockDataBeginChunk', 'INVALID_TILE_HEADER')
    check(r.u32() === index, 'INVALID_TILE_INDEX')
    const length = r.u32(),
      width = r.u32(),
      height = r.u32(),
      hasData = r.u32()
    check(width === 256 && height === 256, 'INVALID_TILE_DIMENSIONS')
    if (hasData) {
      const section = r.u32(),
        compressed = new Reader(r.take(4), true).u32()
      check(section === compressed + 4, 'INVALID_COMPRESSED_SIZE')
      check(
        a.channels === 0 || a.channels === 4 || a.planeBytes >= (a.bitDepth === 1 ? 8192 : 65536),
        'INVALID_TILE_PLANES',
      )
      const expected = a.channels === 4 ? 327680 : a.channels === 0 ? 65536 : a.planeBytes * 2
      check(length === expected && expected <= 327680, 'UNSUPPORTED_TILE_FORMAT')
      tiles.push({
        x: (index % a.cols) * 256,
        y: Math.floor(index / a.cols) * 256,
        expected,
        compressed: r.take(compressed),
      })
    }
    check(r.wideName() === 'BlockDataEndChunk' && r.position === size, 'INVALID_TILE_END')
  }
  // Optional BlockStatus/BlockCheckSum trailers stay opaque; sizes bound tile reads.
  return tiles
}
