import type { ClipDiagnostic } from '../diagnostics.js'
import type { LayerContentKind } from '../material/types.js'
import type { AnimationPaperView } from './paper.js'

/** Binary handles are session-scoped; bytes are available only as caller-owned copies. */
export interface BinaryHandle {
  readonly kind: 'database' | 'chunk' | 'external'
  readonly id: string
  readonly byteLength: number
}
export interface LayerView {
  readonly id: string
  readonly nativeId: number
  readonly parentId: string | null
  readonly name: string
  /** Reference rows remain inspectable/preservable but never contribute artwork. */
  readonly role: 'artwork' | 'light-table-reference'
  readonly reference:
    | Readonly<{ kind: 'light-table'; sourceLayerId: string | undefined; storedFlag: number }>
    | undefined
  readonly kind: LayerContentKind | undefined
  readonly animation: boolean
  readonly folder: boolean
  readonly children: readonly LayerView[]
  readonly visible: boolean | undefined
  readonly opacity: number | undefined
  readonly blendMode: number | undefined
  readonly locked: boolean | undefined
  readonly expanded: boolean | undefined
  readonly labelColor: string | undefined
  readonly mask: 'enabled' | 'disabled' | undefined
  readonly stored: Readonly<{
    type: number | undefined
    visibility: number | undefined
    opacity: number | undefined
    folder: number | undefined
  }>
}
export interface LabelView {
  readonly id: number
  /** Absolute zero-based document frame, also for track labels. */
  readonly frame: number
  readonly type: number
  readonly name: string
  readonly length: number | null
}
export interface TrackView {
  readonly id: number
  readonly uuid: string
  readonly layerId: string
  readonly kind: number
  readonly labels: readonly LabelView[]
  readonly primary: BinaryHandle | undefined
  readonly secondary: BinaryHandle | undefined
}
export interface TimelineView {
  readonly id: string
  readonly nativeId: number
  readonly name: string
  readonly fps: number
  /** Absolute zero-based playback start. Native FPS conversion can produce fractional frames. */
  readonly startFrame: number
  /** Exclusive playback end; may be fractional and is independent of any clip's end. */
  readonly endFrame: number
  readonly durationFrames: number
  readonly durationSeconds: number
  /** Saved absolute playhead position. */
  readonly currentFrame: number
  readonly labels: readonly LabelView[]
  readonly tracks: readonly TrackView[]
}
export interface AnimationFrameView {
  /** Native inner/output frame. Values are never replaced with canvas dimensions when absent. */
  readonly stored: Readonly<{
    unit: number | undefined
    width: number | undefined
    height: number | undefined
    offsetX: number | undefined
    offsetY: number | undefined
    offsetBasePosition: number | undefined
    optionFlag: number | undefined
  }>
  /** Pixel values, including fractional values. Undefined for missing/unsupported unit or geometry. */
  readonly pixels:
    | Readonly<{
        width: number
        height: number
        offsetX: number
        offsetY: number
      }>
    | undefined
  /** Canvas-relative basis rectangle, including asymmetric drawing margins. */
  readonly bounds:
    Readonly<{ left: number; top: number; width: number; height: number }> | undefined
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface CanvasView {
  /** Actual raster dimensions in pixels, independent of the saved display unit. */
  readonly width: number
  readonly height: number
  readonly dpi: number
  readonly unit: number | undefined
  readonly animationFrame: AnimationFrameView
  readonly animationPaper: AnimationPaperView
}
export interface DocumentView {
  readonly canvas: CanvasView
  readonly layers: readonly LayerView[]
  readonly timelines: readonly TimelineView[]
  readonly defaultTimelineId: string | undefined
  readonly compatibility: 'saved' | 'not-saved' | 'unknown'
  readonly binaries: readonly BinaryHandle[]
}
export interface Capability {
  readonly allowed: boolean
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface EditImpact {
  readonly changedRows: readonly Readonly<{ table: string; id: number }>[]
  readonly addedExternalBlobs: number
  readonly invalidatedLayerIds: readonly string[]
  readonly preservation: 'original-bytes' | 'untouched-payloads-and-references'
}
export interface EditPlan extends Capability {
  readonly revision: number
  readonly operations: number
  readonly impact: EditImpact | undefined
}
export interface SaveResult {
  readonly bytes: Uint8Array
  readonly changed: boolean
  readonly impact: EditImpact
}
