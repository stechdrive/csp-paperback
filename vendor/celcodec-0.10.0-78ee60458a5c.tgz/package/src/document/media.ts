import { check } from '../internal/binary.js'
import { num, str, type ClipRow } from '../internal/records.js'
import { normalizedUuid } from '../native/layer-metadata.js'
import { readMediaItemKind } from '../internal/layer-metadata.js'
import type { BinaryHandle } from './types.js'

export interface MediaSourceView {
  readonly id: string
  readonly nativeId: number
  readonly kind: 'audio' | 'video'
  readonly name: string
  readonly extension: string
  readonly storage: 'embedded' | 'external' | 'unknown'
  /** Session-owned handle; use copyBinary for an owned copy. No media decoding is performed. */
  readonly data: BinaryHandle | undefined
  /** Opaque native path encoding. Never resolved or opened by the library. */
  readonly externalPath: Uint8Array | string | undefined
  readonly externalPathType: number | undefined
}
interface MediaStore {
  rows(table: string): ClipRow[]
}

/** Read only sources actually linked by this layer, including native movie LinkLayerItemUUID references. */
export function readMediaSources(
  store: MediaStore,
  layer: ClipRow,
  handle: (id: string) => BinaryHandle | undefined,
): MediaSourceView[] {
  const ids = new Set([normalizedUuid(layer.BankItemUuid), normalizedUuid(layer.LinkLayerItemUUID)])
  for (const object of store.rows('LayerObject'))
    if (object.LayerId === layer.MainId) ids.add(normalizedUuid(object.BankItemUuid))
  ids.delete('')
  const binaries = new Map(store.rows('CanvasItemBinary').map((row) => [num(row, 'MainId'), row]))
  const items = store
    .rows('CanvasItem')
    .filter((row) => ids.has(normalizedUuid(row.ItemUuid)) && readMediaItemKind(row))
  check(
    new Set(items.map((row) => normalizedUuid(row.ItemUuid))).size === items.length,
    'INVALID_MEDIA_REFERENCE',
  )
  return items.map((row) => {
    const binary = binaries.get(num(row, 'ItemBinaryMainIndex'))
    if (binary)
      check(binary.BankId === row.BankId && binary.ItemId === row.MainId, 'INVALID_MEDIA_REFERENCE')
    const embedded = row.ItemDataHoldMethod === 'InternalFilePath'
    const external = row.ItemDataHoldMethod === 'ExternalFilePath'
    const path = row.ItemExternalFilePath
    const data = binary ? handle(str(binary.ItemBinaryData)) : undefined
    check(!embedded || (binary && data), 'INVALID_MEDIA_REFERENCE')
    return {
      id: normalizedUuid(row.ItemUuid),
      nativeId: num(row, 'MainId'),
      kind: readMediaItemKind(row)!,
      name: str(row.ItemCaption),
      extension: str(row.ItemFileExtension),
      storage: embedded ? 'embedded' : external ? 'external' : 'unknown',
      data,
      externalPath:
        path instanceof Uint8Array
          ? new Uint8Array(path)
          : typeof path === 'string'
            ? path
            : undefined,
      externalPathType:
        typeof row.ItemExternalFilePathType === 'number' ? row.ItemExternalFilePathType : undefined,
    }
  })
}
