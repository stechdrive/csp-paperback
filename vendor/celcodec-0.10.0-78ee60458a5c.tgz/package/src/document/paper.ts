import { check } from '../internal/binary.js'
import type { ClipRow } from '../internal/records.js'
import {
  diagnostic,
  rethrowFatal,
  serializeClipError,
  type ClipDiagnostic,
} from '../diagnostics.js'

export type FrameAnchor =
  | 'top-left'
  | 'top'
  | 'top-right'
  | 'left'
  | 'center'
  | 'right'
  | 'bottom-left'
  | 'bottom'
  | 'bottom-right'
export interface FrameInsets {
  readonly left: number
  readonly top: number
  readonly right: number
  readonly bottom: number
}
export interface FrameRectangle {
  readonly left: number
  readonly top: number
  readonly width: number
  readonly height: number
}
export interface AnimationPaperSettings {
  readonly unit: 'px' | 'mm'
  /** Movie output rectangle (基準フレーム), not a timeline frame or 2D camera. */
  readonly basis: Readonly<{ width: number; height: number }>
  /** 作画フレーム. null disables it; the basis then owns the outer margins. */
  readonly drawing: Readonly<{
    width: number
    height: number
    anchor: FrameAnchor
    offsetX: number
    offsetY: number
  }> | null
  readonly margins: FrameInsets
  /** 演出フレーム: insets from the basis rectangle. null disables it. */
  readonly direction: FrameInsets | null
}
export interface AnimationPaperView {
  readonly enabled: boolean | undefined
  /** Values in the saved unit, with offsets relative to the chosen UI anchor. */
  readonly settings: AnimationPaperSettings | undefined
  readonly pixels:
    | Readonly<{
        basis: FrameRectangle
        drawing: FrameRectangle | null
        margins: FrameInsets
        direction: FrameRectangle | null
      }>
    | undefined
  readonly stored: Readonly<{
    unit: number | undefined
    optionFlag: number | undefined
    drawingWidth: number | undefined
    drawingHeight: number | undefined
    drawingOffsetX: number | undefined
    drawingOffsetY: number | undefined
    basisWidth: number | undefined
    basisHeight: number | undefined
    basisOffsetX: number | undefined
    basisOffsetY: number | undefined
    anchor: number | undefined
    directionLeft: number | undefined
    directionTop: number | undefined
    directionRight: number | undefined
    directionBottom: number | undefined
  }>
  readonly diagnostics: readonly ClipDiagnostic[]
}
export const frameAnchors: readonly FrameAnchor[] = [
  'top-left',
  'top',
  'top-right',
  'left',
  'center',
  'right',
  'bottom-left',
  'bottom',
  'bottom-right',
]
export function canvasUnitScale(unit: number | undefined, dpi: number): number {
  check(Number.isFinite(dpi) && dpi > 0, 'INVALID_CANVAS_FRAME')
  check(unit === 0 || unit === 2, 'UNSUPPORTED_CANVAS_UNIT', { unit: unit ?? -1 })
  return unit === 0 ? 1 : dpi / 25.4
}
export function animationPaper(
  row: ClipRow,
  width: number,
  height: number,
  dpi: number,
): AnimationPaperView {
  const n = (field: string) => (typeof row[field] === 'number' ? row[field] : undefined)
  const stored: AnimationPaperView['stored'] = {
    unit: n('CropFrameUnitKind'),
    optionFlag: n('CropFrameOptionFlag'),
    drawingWidth: n('CropFrameWidth'),
    drawingHeight: n('CropFrameHeight'),
    drawingOffsetX: n('CropFrameCropOffsetX'),
    drawingOffsetY: n('CropFrameCropOffsetY'),
    basisWidth: n('CropFrameInnerWidth'),
    basisHeight: n('CropFrameInnerHeight'),
    basisOffsetX: n('CropFrameInnerOffsetX'),
    basisOffsetY: n('CropFrameInnerOffsetY'),
    anchor: n('CropFrameInnerOffsetBasePosition'),
    directionLeft: n('CropFrameSafeMarginLeft'),
    directionTop: n('CropFrameSafeMarginTop'),
    directionRight: n('CropFrameSafeMarginRight'),
    directionBottom: n('CropFrameSafeMarginBottom'),
  }
  const enabled = stored.optionFlag === undefined ? undefined : !!(stored.optionFlag & 65536)
  const diagnostics: ClipDiagnostic[] = []
  let settings: AnimationPaperView['settings'], pixels: AnimationPaperView['pixels']
  if (enabled)
    try {
      check(
        Object.values(stored).every((v) => typeof v === 'number' && Number.isFinite(v)),
        'MISSING_COLUMN_VALUE',
        { field: 'CropFrame' },
      )
      const scale = canvasUnitScale(stored.unit, dpi),
        flag = stored.optionFlag!,
        anchor = stored.anchor!
      check(Number.isInteger(anchor) && anchor >= 0 && anchor < 9, 'UNSUPPORTED_CANVAS_FRAME', {
        field: 'CropFrameInnerOffsetBasePosition',
        value: anchor,
      })
      const dw = stored.drawingWidth!,
        dh = stored.drawingHeight!,
        bw = stored.basisWidth!,
        bh = stored.basisHeight!
      check(Math.min(dw, dh, bw, bh) > 0, 'INVALID_CANVAS_FRAME')
      const left = (width / scale - dw) / 2 + stored.drawingOffsetX!,
        top = (height / scale - dh) / 2 + stored.drawingOffsetY!
      const margins = {
        left,
        top,
        right: width / scale - dw - left,
        bottom: height / scale - dh - top,
      }
      const basis = {
        left: left + (dw - bw) / 2 + stored.basisOffsetX!,
        top: top + (dh - bh) / 2 + stored.basisOffsetY!,
        width: bw,
        height: bh,
      }
      const direction = {
        left: stored.directionLeft!,
        top: stored.directionTop!,
        right: stored.directionRight!,
        bottom: stored.directionBottom!,
      }
      // CSP retains the entered physical canvas extent even when its raster extent rounds.
      // Report UI margins from that saved extent; pixel rectangles use the actual pixel center.
      const canvasScale = canvasUnitScale(n('CanvasUnit') ?? 0, dpi),
        savedWidth = ((n('CanvasWidth') ?? width / canvasScale) * canvasScale) / scale,
        savedHeight = ((n('CanvasHeight') ?? height / canvasScale) * canvasScale) / scale,
        marginX = (savedWidth - dw) / 2,
        marginY = (savedHeight - dh) / 2,
        cleanInset = (v: number) => (Math.abs(v) < 1e-9 ? 0 : v)
      settings = {
        unit: stored.unit === 0 ? 'px' : 'mm',
        basis: { width: bw, height: bh },
        margins: {
          left: cleanInset(marginX + stored.drawingOffsetX!),
          right: cleanInset(marginX - stored.drawingOffsetX!),
          top: cleanInset(marginY + stored.drawingOffsetY!),
          bottom: cleanInset(marginY - stored.drawingOffsetY!),
        },
        drawing:
          flag & 8192
            ? {
                width: dw,
                height: dh,
                anchor: frameAnchors[anchor]!,
                offsetX: stored.basisOffsetX! - (dw - bw) * ((anchor % 3) / 2 - 0.5),
                offsetY: stored.basisOffsetY! - (dh - bh) * (Math.floor(anchor / 3) / 2 - 0.5),
              }
            : null,
        direction: flag & 4096 ? direction : null,
      }
      const rect = (r: FrameRectangle): FrameRectangle => ({
        left: r.left * scale,
        top: r.top * scale,
        width: r.width * scale,
        height: r.height * scale,
      })
      pixels = {
        basis: rect(basis),
        drawing: settings.drawing ? rect({ left, top, width: dw, height: dh }) : null,
        margins: {
          left: margins.left * scale,
          top: margins.top * scale,
          right: margins.right * scale,
          bottom: margins.bottom * scale,
        },
        direction: settings.direction
          ? rect({
              left: basis.left + direction.left,
              top: basis.top + direction.top,
              width: bw - direction.left - direction.right,
              height: bh - direction.top - direction.bottom,
            })
          : null,
      }
      check(
        [pixels.basis, pixels.drawing, pixels.margins, pixels.direction]
          .filter((v) => v !== null)
          .every((v) => Object.values(v).every(Number.isFinite)),
        'INVALID_CANVAS_FRAME',
      )
      if (
        Object.values(margins).some((v) => v < -1 / scale) ||
        (pixels.direction && Math.min(pixels.direction.width, pixels.direction.height) <= 0)
      )
        diagnostics.push(diagnostic('INVALID_CANVAS_FRAME'))
    } catch (error) {
      rethrowFatal(error)
      diagnostics.push(serializeClipError(error))
    }
  return { enabled, stored, settings, pixels, diagnostics }
}
