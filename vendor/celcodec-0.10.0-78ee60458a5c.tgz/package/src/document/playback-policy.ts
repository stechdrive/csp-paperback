import { check } from '../internal/binary.js'

/** A transient evaluation policy. It never changes the document's stored settings. */
export type PlaybackPolicy = 'document' | 'apply' | 'ignore'
export interface PlaybackLayerOverride {
  readonly layerId: string
  /** Camera folders only; independent of ordinary layer keyframes. */
  readonly camera?: PlaybackPolicy
  /** Ordinary layers/folders only; does not disable cel assignment or audio timing. */
  readonly layerKeyframes?: PlaybackPolicy
}
export interface PlaybackApplication {
  readonly policy: PlaybackPolicy
  /** Undefined when the stored setting is absent or has an unknown encoding. */
  readonly stored: boolean | undefined
  readonly applied: boolean | undefined
  readonly source: 'document' | 'override' | 'intrinsic'
}

export function checkPlaybackPolicy(value: unknown): asserts value is PlaybackPolicy {
  check(value === 'document' || value === 'apply' || value === 'ignore', 'INVALID_PLAYBACK_OPTIONS')
}

export function resolvePlaybackApplication(
  policy: PlaybackPolicy,
  stored: boolean | undefined,
  intrinsic = false,
  absentDefault?: boolean,
): PlaybackApplication {
  return {
    policy,
    stored,
    applied: intrinsic
      ? true
      : policy === 'document'
        ? (stored ?? absentDefault)
        : policy === 'apply',
    source: intrinsic ? 'intrinsic' : policy === 'document' ? 'document' : 'override',
  }
}
