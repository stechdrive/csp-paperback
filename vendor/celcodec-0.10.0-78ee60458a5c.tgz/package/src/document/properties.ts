import { check } from '../internal/binary.js'
import { hasLayerMask, isPaper } from '../internal/layer-metadata.js'
import { readSolidFillColor } from '../internal/gradient.js'
import { readMaterialEffects } from '../internal/material.js'
import type { ClipRow } from '../internal/records.js'
import type { MaterialEffects } from '../material/types.js'
import {
  diagnostic,
  rethrowFatal,
  serializeClipError,
  type ClipDiagnostic,
} from '../diagnostics.js'

export interface StoredOffset {
  readonly x: number | undefined
  readonly y: number | undefined
}
export interface LayerProperties {
  /** Stored clipping flag, independent of visibility and application selection. */
  readonly clipping: boolean | undefined
  readonly keyframesEnabled: boolean | undefined
  /** Saved 2D camera canvas display. Undefined for absent or unknown values. */
  readonly cameraDisplay: 'apply' | 'ignore' | undefined
  /** Original layer opacity, normalized from the 0..256 native column when present. */
  readonly originalOpacity: number | undefined
  readonly layerOffset: StoredOffset
  readonly mask:
    | Readonly<{
        enabled: boolean | undefined
        /** LayerSelect bit 0x100, independently observed by toggling CSP mask linkage. */
        linked: boolean | undefined
        /** Uninterpreted native flags; do not confuse this with mask visibility or linkage. */
        storedMasking: number | undefined
        offset: StoredOffset
        originalOffset: StoredOffset
        renderedOffset: StoredOffset
        originalMipmapId: number | undefined
        renderedMipmapId: number | undefined
      }>
    | undefined
  readonly flatColor:
    | Readonly<{
        source: 'paper' | 'fill'
        /** Eight-bit RGB used by the material decoder; not a color-profile conversion. */
        rgb: readonly [number, number, number]
        storedRGB: readonly [number, number, number]
      }>
    | undefined
  readonly effects: MaterialEffects | undefined
  readonly diagnostics: readonly ClipDiagnostic[]
}

/** Metadata projection with no decoded image, including native offsets instead of a guessed world transform. */
export function layerProperties(row: ClipRow): LayerProperties {
  const diagnostics: ClipDiagnostic[] = [],
    number = (name: string) => {
      const v = row[name]
      if (v === undefined || v === null) return undefined
      check(typeof v === 'number' && Number.isFinite(v), 'INVALID_LAYER_ATTRIBUTE', { field: name })
      return v
    },
    offset = (prefix: string): StoredOffset => ({
      x: number(prefix + 'X'),
      y: number(prefix + 'Y'),
    })
  let flatColor: LayerProperties['flatColor'], effects: MaterialEffects | undefined
  try {
    let storedRGB: [number, number, number] | undefined
    const paper = isPaper(row)
    if (paper) {
      const r = number('DrawColorMainRed'),
        g = number('DrawColorMainGreen'),
        b = number('DrawColorMainBlue')
      check(r !== undefined && g !== undefined && b !== undefined, 'MISSING_COLUMN_VALUE')
      storedRGB = [r, g, b]
    } else if (row.GradationFillInfo instanceof Uint8Array)
      storedRGB = readSolidFillColor(row.GradationFillInfo)
    if (storedRGB) {
      check(
        storedRGB.every((v) => Number.isInteger(v) && v >= 0 && v <= 0xffffffff),
        'UNSUPPORTED_COLOR_FORMAT',
      )
      flatColor = {
        source: paper ? 'paper' : 'fill',
        storedRGB,
        rgb: storedRGB.map((v) => v >>> 24) as [number, number, number],
      }
    }
  } catch (error) {
    rethrowFatal(error)
    diagnostics.push({ ...serializeClipError(error), part: 'material' })
  }
  effects = readMaterialEffects(row, (code) =>
    diagnostics.push({ ...diagnostic(code), part: 'effect' }),
  )
  const enabled = number('TimeLineLayerKeyFrameEnabled'),
    camera = number('Camera2DApplyTransform'),
    opacity = number('TimeLineOriginalLayerOpacity'),
    visibility = number('LayerVisibility'),
    selection = number('LayerSelect')
  for (const [field, value] of [
    ['TimeLineLayerKeyFrameEnabled', enabled],
    ['Camera2DApplyTransform', camera],
  ] as const)
    if (value !== undefined && value !== 0 && value !== 1)
      diagnostics.push(diagnostic('UNRESOLVED_PLAYBACK_SETTING', { field, value }))
  return {
    clipping: number('LayerClip') === undefined ? undefined : number('LayerClip') !== 0,
    keyframesEnabled: enabled === 0 ? false : enabled === 1 ? true : undefined,
    cameraDisplay: camera === 0 ? 'ignore' : camera === 1 ? 'apply' : undefined,
    originalOpacity: opacity === undefined ? undefined : opacity / 256,
    layerOffset: offset('LayerOffset'),
    mask: hasLayerMask(row)
      ? {
          enabled: visibility === undefined ? undefined : !!(visibility & 2),
          linked: selection === undefined ? undefined : !!(selection & 0x100),
          storedMasking: number('LayerMasking'),
          offset: offset('LayerMaskOffset'),
          originalOffset: offset('TimeLineMaskOriginalOffset'),
          renderedOffset: offset('LayerMaskOffscrOffset'),
          originalMipmapId: number('TimeLineOriginalMaskMipmap'),
          renderedMipmapId: number('LayerLayerMaskMipmap'),
        }
      : undefined,
    flatColor,
    effects,
    diagnostics,
  }
}
