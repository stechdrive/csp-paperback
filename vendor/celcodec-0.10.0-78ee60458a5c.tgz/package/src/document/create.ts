import { requiredAt } from '../internal/indexed.js'
import { blob, ClipContainer } from '../native/container.js'
import { mipmapChain } from '../native/layers.js'
import { readAttribute } from '../internal/raster.js'
import { readRasterTiles } from '../format/raster-tiles.js'
import { inflateBounded } from '../native/compression.js'
import { animationMixer } from '../native/animation.js'
import { normalizedUuid } from '../native/layer-metadata.js'
import { resizeCanvas } from '../native/canvas.js'
import { check } from '../internal/binary.js'
import { checkCancelled } from '../diagnostics.js'
import { validateClipCanvas, type ClipCanvasSettings } from '../native/model.js'
import type { SqlJsStatic } from '../native/sql.js'

/** Caller-owned empty animation template. No bundled bytes or fixed fingerprint. */
export function validateSeed(SQL: SqlJsStatic, seed: Uint8Array, signal?: AbortSignal) {
  checkCancelled(signal)
  check(seed instanceof Uint8Array && seed.length > 0, 'UNSUPPORTED_SEED')
  check(seed.length <= 512 * 1024 * 1024, 'LIMIT_INPUT_BYTES')
  const clip = new ClipContainer(SQL, seed, signal)
  try {
    const layers = clip.rows('Layer'),
      canvas = requiredAt(clip.rows('Canvas'), 0)
    const root = layers.find((l) => l.MainId === canvas.CanvasRootFolder && l.LayerType === 256)
    const paper = layers.find((l) => l.LayerType === 1584)
    const folder = layers.find((l) => l.LayerType === 0 && l.AnimationFolder === 1)
    const raster = layers.find((l) => l.LayerType === 1)
    check(layers.length === 4 && root && paper && folder && raster, 'UNSUPPORTED_SEED', {
      reason: 'empty-animation-template-required',
    })
    // Both native orders (paper first or last) are supported. No orphan artwork.
    const siblings = [paper, folder]
    const first = siblings.find((l) => l.MainId === root.LayerFirstChildIndex)
    const second = siblings.find((l) => l.MainId === first?.LayerNextIndex)
    check(
      first &&
        second &&
        first !== second &&
        !second.LayerNextIndex &&
        folder.LayerFirstChildIndex === raster.MainId &&
        !raster.LayerNextIndex &&
        !raster.LayerFirstChildIndex &&
        !paper.LayerFirstChildIndex,
      'UNSUPPORTED_SEED',
      { reason: 'template-layer-tree' },
    )
    for (const layer of layers) {
      check(
        !layer.LayerLayerMaskMipmap && !layer.TimeLineLayerKeyFrameEnabled && !layer.LayerClip,
        'UNSUPPORTED_SEED',
        { reason: 'template-layer-state' },
      )
    }
    for (const layer of [folder, raster]) {
      mipmapChain(clip, layer.LayerRenderMipmap)
      const thumbnail = clip.row('LayerThumbnail', layer.LayerRenderThumbnail)
      readAttribute(blob(clip.row('Offscreen', thumbnail.ThumbnailOffscreen).Attribute))
    }
    const off = requiredAt(mipmapChain(clip, raster.LayerRenderMipmap), 0).off
    const attribute = readAttribute(blob(off.Attribute))
    check(
      attribute.channels === 4 && (!attribute.hasColor || attribute.color === 0),
      'UNSUPPORTED_SEED',
      { reason: 'template-must-be-transparent' },
    )
    // Inspect alpha tile by tile; never allocate the canvas area to validate a template.
    for (const tile of readRasterTiles(attribute, clip.body(off.BlockData), signal)) {
      checkCancelled(signal)
      const pixels = inflateBounded(tile.compressed, tile.expected)
      check(
        pixels.length === tile.expected && pixels.subarray(0, 65536).every((v) => v === 0),
        'UNSUPPORTED_SEED',
        { reason: 'template-contains-drawing' },
      )
    }
    const timelines = clip.rows('TimeLine'),
      banks = clip.rows('AnimationCutBank'),
      tracks = clip.rows('Track')
    check(
      timelines.length === 1 &&
        banks.length === 1 &&
        tracks.length === 2 &&
        tracks.some((t) => t.TrackKind === 2000) &&
        tracks.some((t) => t.TrackKind === 2003),
      'UNSUPPORTED_SEED',
      { reason: 'template-animation-channels' },
    )
    for (const track of tracks) {
      const target = track.TrackKind === 2000 ? folder : paper
      check(
        normalizedUuid(track.LayerUuidWithTrack) === normalizedUuid(target.LayerUuid),
        'UNSUPPORTED_SEED',
        { reason: 'template-track-reference' },
      )
      for (const key of ['TrackActionMixer', 'TrackActionMixer2']) {
        const body = clip.body(track[key])
        check(body, 'UNSUPPORTED_SEED', { reason: 'template-missing-mixer' })
        animationMixer(body, [{ frame: 0, value: null }], 1, 24)
      }
    }
    checkCancelled(signal)
  } finally {
    clip.close()
  }
}

export async function createBytes(
  SQL: SqlJsStatic,
  seed: Uint8Array,
  canvas: ClipCanvasSettings,
  signal?: AbortSignal,
) {
  validateClipCanvas(canvas)
  validateSeed(SQL, seed, signal)
  const clip = new ClipContainer(SQL, seed, signal)
  try {
    const row = requiredAt(clip.rows('Canvas'), 0),
      layers = clip.rows('Layer'),
      root = layers.find((l) => l.MainId === row.CanvasRootFolder)!,
      paper = layers.find((l) => l.LayerType === 1584)!
    // Existing documents use patch operations; new documents start with a validated empty template.
    check(
      root && paper && typeof root.MainId === 'number' && typeof paper.MainId === 'number',
      'UNSUPPORTED_SEED',
    )
    clip.db.run('DELETE FROM Layer WHERE MainId NOT IN (?,?)', [root.MainId, paper.MainId])
    clip.update('Layer', root.MainId, { LayerFirstChildIndex: paper.MainId })
    clip.update('Layer', paper.MainId, { LayerNextIndex: 0 })
    clip.db.run('DELETE FROM Track')
    clip.db.run('DELETE FROM TimeLine')
    if (
      clip.db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='TimeLineLabel'")
        .length
    )
      clip.db.run('DELETE FROM TimeLineLabel')
    const bank = requiredAt(clip.rows('AnimationCutBank'), 0)
    clip.update('AnimationCutBank', bank.MainId, { FirstTimeLine: 0, CurrentIndex: 0 })
    clip.update('Canvas', row.MainId, { CanvasCurrentLayer: paper.MainId })
    resizeCanvas(clip, canvas, true)
    checkCancelled(signal)
    return clip.bytes()
  } finally {
    clip.close()
  }
}
