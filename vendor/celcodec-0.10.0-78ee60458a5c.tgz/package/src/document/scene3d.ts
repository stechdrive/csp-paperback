import { check } from '../internal/binary.js'
import { num, str, type ClipRow } from '../internal/records.js'
import { checkCancelled, diagnostic, rethrowFatal, type ClipDiagnostic } from '../diagnostics.js'
import type { BinaryHandle } from './types.js'

export type NativeMetadata = Readonly<
  Record<string, number | string | Uint8Array | null | undefined>
>
export interface Camera3DView {
  readonly nativeId: number
  readonly objectId: number
  /** Native scene coordinates, with no handedness or unit conversion. */
  readonly position: readonly [number, number, number]
  readonly target: readonly [number, number, number]
  readonly up: readonly [number, number, number]
  readonly twistRadians: number
  readonly frustum: Readonly<{
    left: number
    right: number
    top: number
    bottom: number
    near: number
    far: number
    orthographic: boolean
  }>
  readonly viewport: Readonly<{ x: number; y: number; width: number; height: number }>
  readonly opticalAxis: readonly [number, number]
  readonly stored: NativeMetadata
}
export interface Object3DView {
  readonly nativeId: number
  readonly uuid: string
  readonly name: string
  readonly visible: boolean | undefined
  readonly locked: boolean | undefined
  readonly camera: Camera3DView | undefined
  /** Object transforms/geometry may exist only inside the opaque scene. */
  readonly stored: NativeMetadata
}
export interface Layer3DView {
  readonly storage: 'scene-3d-od' | 'legacy-3d' | 'unknown'
  readonly managerId: number | undefined
  readonly scene: BinaryHandle | undefined
  readonly objects: readonly Object3DView[]
  readonly geometry: 'opaque'
  readonly diagnostics: readonly ClipDiagnostic[]
}
interface SceneStore {
  row(table: string, id: number): ClipRow
}
const copyRow = (row: ClipRow): NativeMetadata =>
  Object.fromEntries(
    Object.entries(row).map(([k, v]) => [k, v instanceof Uint8Array ? v.slice() : v]),
  )
function cameraView(row: ClipRow, objectId: number): Camera3DView {
  const value = (field: string) => {
      const v = row[field]
      check(typeof v === 'number' && Number.isFinite(v), 'INVALID_3D_CAMERA', { field })
      return v
    },
    vector = (prefix: string): [number, number, number] => [
      value(prefix + 'X'),
      value(prefix + 'Y'),
      value(prefix + 'Z'),
    ]
  const ortho = value('FrustumOrtho')
  check(ortho === 0 || ortho === 1, 'INVALID_3D_CAMERA', { field: 'FrustumOrtho' })
  const frustum = {
      left: value('FrustumLeft'),
      right: value('FrustumRight'),
      top: value('FrustumTop'),
      bottom: value('FrustumBottom'),
      near: value('FrustumNear'),
      far: value('FrustumFar'),
      orthographic: !!ortho,
    },
    viewport = {
      x: value('ViewportXmin'),
      y: value('ViewportYmin'),
      width: value('ViewportWidth'),
      height: value('ViewportHeight'),
    }
  check(
    frustum.right > frustum.left &&
      frustum.top > frustum.bottom &&
      frustum.far > frustum.near &&
      viewport.width > 0 &&
      viewport.height > 0,
    'INVALID_3D_CAMERA',
  )
  return {
    nativeId: value('MainId'),
    objectId,
    position: vector('CameraPosition'),
    target: vector('CameraTarget'),
    up: vector('CameraUp'),
    twistRadians: value('CameraTwist'),
    frustum,
    viewport,
    opticalAxis: [value('LayerOpticalAxisPtX'), value('LayerOpticalAxisPtY')],
    stored: copyRow(row),
  }
}

/** Read known metadata only. The scene wrapper and embedded models are not parsed or rewritten. */
export function readScene3D(
  store: SceneStore,
  layer: ClipRow,
  external: (id: string) => BinaryHandle | undefined,
  signal?: AbortSignal,
): Layer3DView {
  checkCancelled(signal)
  const diagnostics: ClipDiagnostic[] = [],
    layerId = num(layer, 'MainId'),
    modern = num(layer, 'Manager3DOd'),
    legacy = num(layer, 'Manager3D')
  const lookup = (table: string, id: number, objectId?: number) => {
    checkCancelled(signal)
    check(Number.isSafeInteger(id) && id > 0, 'INVALID_3D_REFERENCE', { table, id })
    const row = store.row(table, id)
    check(
      row.LayerId === layerId && (objectId === undefined || row.LayerObjectId === objectId),
      'INVALID_3D_REFERENCE',
      { table, id },
    )
    return row
  }
  if (!modern)
    return {
      storage: legacy ? 'legacy-3d' : 'unknown',
      managerId: legacy || undefined,
      scene: undefined,
      objects: [],
      geometry: 'opaque',
      diagnostics: [diagnostic('UNSUPPORTED_3D_STORAGE')],
    }
  const manager = lookup('Manager3DOd', modern),
    sceneId = str(manager.SceneData),
    scene = external(sceneId)
  if (!scene) diagnostics.push(diagnostic('MISSING_3D_SCENE'))
  if (legacy) diagnostics.push(diagnostic('UNSUPPORTED_3D_STORAGE', { manager3D: legacy }))
  const objects: Object3DView[] = [],
    seen = new Set<number>()
  let next = num(layer, 'FirstLayerObject')
  while (next) {
    check(!seen.has(next), 'INVALID_3D_REFERENCE', { table: 'LayerObject', id: next })
    seen.add(next)
    const object = lookup('LayerObject', next),
      cameraId = num(object, 'Camera')
    let camera: Camera3DView | undefined
    if (cameraId) {
      const row = lookup('CameraInfo', cameraId, next)
      try {
        camera = cameraView(row, next)
      } catch (error) {
        rethrowFatal(error)
        diagnostics.push(diagnostic('INVALID_3D_CAMERA', { cameraId }, 'error'))
      }
    }
    objects.push({
      nativeId: next,
      uuid: str(object.ObjectUuid),
      name: str(object.ObjectName),
      visible:
        typeof object.ObjectVisibility === 'number' ? !!(object.ObjectVisibility & 1) : undefined,
      locked: typeof object.ObjectLock === 'number' ? !!object.ObjectLock : undefined,
      camera,
      stored: copyRow(object),
    })
    next = num(object, 'ObjectNext')
  }
  return {
    storage: 'scene-3d-od',
    managerId: modern,
    scene,
    objects,
    geometry: 'opaque',
    diagnostics,
  }
}
