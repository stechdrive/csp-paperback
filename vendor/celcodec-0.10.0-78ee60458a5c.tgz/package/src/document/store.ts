import { requiredAt } from '../internal/indexed.js'
import { normalizedUuid } from '../native/layer-metadata.js'
import { check } from '../internal/binary.js'
import { canvasPixelLimit, validateCanvasPixels } from '../internal/canvas-limits.js'
import { checkCancelled, ClipError, errorCode, type ClipDiagnostic } from '../diagnostics.js'
import { num, str, type ClipRow } from '../internal/records.js'
import { readAttribute } from '../internal/raster.js'
import {
  readLayerKind,
  readMediaItemKind,
  readPaletteColor,
  hasLayerMask,
} from '../internal/layer-metadata.js'
import {
  createMaterialDecoder,
  createMaterialIndex,
  materialOffscreen,
  type MaterialTables,
  type MaterialDecoderOptions,
} from '../internal/material.js'
import { readContainer } from '../native/container-read.js'
import type { SqlJsStatic } from '../native/sql.js'
import type { ClipLayer } from '../material/types.js'
import { createRasterSource } from '../material/raster-source.js'
import type { LayerRasterOptions, SessionOptions } from './session.js'
import { layerProperties, type LayerProperties } from './properties.js'

export interface NativeLayer extends ClipLayer {
  nativeId: number
  /** All saved columns, including visibility/mask bits, opacity and unknown attributes. */
  attributes: ClipRow
  children: NativeLayer[]
  paletteColor: string | undefined
  maskState?: 'enabled' | 'disabled'
}
export interface NativeTrack {
  attributes: ClipRow
  labels: ClipRow[]
  primary: Uint8Array | undefined
  secondary: Uint8Array | undefined
}
export interface NativeTimeline {
  attributes: ClipRow
  labels: ClipRow[]
  tracks: NativeTrack[]
}
export interface NativeDocument {
  width: number
  height: number
  dpi: number
  canvas: ClipRow
  layers: NativeLayer[]
  timelines: NativeTimeline[]
  defaultTimelineId: number | undefined
  compatibility: 'saved' | 'not-saved' | 'unknown'
}
const uuid = (value: ClipRow[string]) => {
  const id =
    value instanceof Uint8Array
      ? Array.from(value, (b) => b.toString(16).padStart(2, '0')).join('')
      : str(value).replaceAll('-', '').toLowerCase()
  check(/^[0-9a-f]{32}$/.test(id), 'INVALID_UUID')
  return id
}
function chain(rows: Map<number, ClipRow>, first: number, field: string): ClipRow[] {
  const result: ClipRow[] = [],
    seen = new Set<number>()
  let next = first
  while (next) {
    const row = rows.get(next)
    check(row && !seen.has(next), 'INVALID_REFERENCE_CHAIN')
    seen.add(next)
    result.push(row)
    next = num(row, field)
  }
  return result
}

/** Read-only SQLite inspection. Database lifetime ends before the returned session escapes. */
export function openNativeStore(SQL: SqlJsStatic, bytes: Uint8Array, options: SessionOptions = {}) {
  checkCancelled(options.signal)
  const maxCanvasPixels = canvasPixelLimit(options.maxCanvasPixels)
  const container = readContainer(bytes, options.limits, options.signal)
  const maxRows = options.maxRows ?? 50000,
    maxDepth = options.maxDepth ?? 128
  check(
    Number.isSafeInteger(maxRows) &&
      maxRows >= 1 &&
      maxRows <= 1000000 &&
      Number.isSafeInteger(maxDepth) &&
      maxDepth >= 1 &&
      maxDepth <= 128,
    'INVALID_LIMIT',
  )
  const db = new SQL.Database(container.database),
    cache = new Map<string, ClipRow[]>()
  const rows = (table: string): ClipRow[] => {
    checkCancelled(options.signal)
    const hit = cache.get(table)
    if (hit) return hit
    if (!db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name=?", [table]).length)
      return []
    check(/^[A-Za-z_][A-Za-z_0-9]*$/.test(table), 'INVALID_TABLE_NAME')
    const stmt = db.prepare(`SELECT * FROM "${table}"`),
      result: ClipRow[] = []
    try {
      while (stmt.step()) {
        checkCancelled(options.signal)
        check(result.length < maxRows, 'LIMIT_DATABASE_ROWS', { table, limit: maxRows })
        result.push(stmt.getAsObject())
      }
    } finally {
      stmt.free()
    }
    cache.set(table, result)
    return result
  }
  const indices = new Map<string, Map<number, ClipRow>>()
  const byId = (name: string) => {
    const hit = indices.get(name)
    if (hit) return hit
    const result = new Map<number, ClipRow>()
    for (const row of rows(name)) {
      const id = num(row, 'MainId')
      check(Number.isSafeInteger(id) && !result.has(id), 'DUPLICATE_ROW_ID', { table: name, id })
      result.set(id, row)
    }
    indices.set(name, result)
    return result
  }
  let tables: MaterialTables, document: NativeDocument
  const layerRows = new Map<string, ClipRow>(),
    layerKinds = new Map<string, ClipLayer['kind']>()
  try {
    db.run('PRAGMA trusted_schema=OFF')
    db.run('PRAGMA query_only=ON')
    const canvases = rows('Canvas')
    check(canvases.length === 1, 'UNSUPPORTED_MULTI_CANVAS')
    const canvas = requiredAt(canvases, 0)
    tables = {
      mipmaps: byId('Mipmap'),
      mipInfos: byId('MipmapInfo'),
      offscreens: byId('Offscreen'),
      thumbnails: rows('LayerThumbnail'),
      external: container.external,
      vectors: byId('VectorObjectList'),
      brushes: byId('BrushStyle'),
      brushGraphs: byId('BrushEffectorGraphData'),
      brushPatterns: byId('BrushPatternStyle'),
      brushImages: byId('BrushPatternImage'),
    }
    const layers = byId('Layer'),
      root = layers.get(num(canvas, 'CanvasRootFolder'))
    check(root, 'MISSING_ROOT_LAYER')
    if ([...layers.values()].some((row) => num(row, 'Manager3DOd'))) {
      byId('Manager3DOd')
      byId('CameraInfo')
    }
    const off = materialOffscreen(tables, root, 'LayerRenderMipmap')
    const a = off?.Attribute instanceof Uint8Array ? readAttribute(off.Attribute) : undefined
    const width = a?.width ?? num(canvas, 'CanvasWidth'),
      height = a?.height ?? num(canvas, 'CanvasHeight'),
      dpi = num(canvas, 'CanvasResolution', 72)
    validateCanvasPixels(width, height, maxCanvasPixels)
    check(a || !num(canvas, 'CanvasUnit'), 'UNSUPPORTED_CANVAS_UNIT')
    const seen = new Set<number>([num(root, 'MainId')]),
      items = new Map(
        rows('CanvasItem').map((row) => [str(row.ItemUuid).replaceAll('-', '').toLowerCase(), row]),
      )
    const media = new Map<number, 'audio' | 'video'>()
    for (const object of rows('LayerObject')) {
      const item = items.get(str(object.BankItemUuid).replaceAll('-', '').toLowerCase()),
        kind = num(object, 'IsAudio') ? 'audio' : item && readMediaItemKind(item)
      if (kind) media.set(num(object, 'LayerId'), kind)
    }
    const vectorLayers = new Set([...tables.vectors!.values()].map((row) => num(row, 'LayerId')))
    const tree = (first: number, depth: number): NativeLayer[] => {
      check(depth <= maxDepth, 'LIMIT_LAYER_DEPTH')
      return chain(layers, first, 'LayerNextIndex')
        .reverse()
        .map((row) => {
          checkCancelled(options.signal)
          const nativeId = num(row, 'MainId')
          check(!seen.has(nativeId), 'INVALID_LAYER_CYCLE')
          seen.add(nativeId)
          const id = uuid(row.LayerUuid)
          check(!layerRows.has(id), 'DUPLICATE_LAYER_UUID')
          layerRows.set(id, row)
          const isFolder = !!(num(row, 'LayerFolder') & 1)
          const linked =
            items.get(normalizedUuid(row.LinkLayerItemUUID)) ??
            items.get(normalizedUuid(row.BankItemUuid))
          const kind = readLayerKind(
            row,
            vectorLayers.has(nativeId),
            media.get(nativeId) ?? (linked && readMediaItemKind(linked)),
          )
          layerKinds.set(id, kind)
          return {
            id,
            nativeId,
            name: str(row.LayerName),
            isFolder,
            attributes: row,
            kind,
            children: isFolder ? tree(num(row, 'LayerFirstChildIndex'), depth + 1) : [],
            paletteColor: readPaletteColor(row),
            ...(hasLayerMask(row)
              ? {
                  maskState: num(row, 'LayerVisibility') & 2 ? 'enabled' : 'disabled',
                }
              : {}),
          }
        })
    }
    for (const name of ['CanvasItemBinary', 'LayerObject', 'CanvasItem']) byId(name)
    const tracks = byId('Track'),
      labels = byId('TimeLineLabel'),
      timeRows = byId('TimeLine'),
      banks = rows('AnimationCutBank'),
      project = rows('Project')[0]
    const timelines: NativeTimeline[] = []
    let defaultTimelineId: number | undefined
    for (const bank of banks) {
      const ordered = chain(timeRows, num(bank, 'FirstTimeLine'), 'NextTimeLine')
      if (
        num(bank, 'MainId') === num(project ?? {}, 'ProjectCutBank') ||
        defaultTimelineId === undefined
      )
        defaultTimelineId = ordered[num(bank, 'CurrentIndex')]
          ? num(requiredAt(ordered, num(bank, 'CurrentIndex')), 'MainId')
          : undefined
      for (const row of ordered) {
        check(num(row, 'BankId') === num(bank, 'MainId'), 'INVALID_REFERENCE_CHAIN')
        const timelineLabels = chain(labels, num(row, 'LabelFirstIndex'), 'LabelNextIndex')
        check(
          timelineLabels.every(
            (label) =>
              num(label, 'BankId') === num(bank, 'MainId') &&
              num(label, 'ItemId') === num(row, 'MainId') &&
              !num(label, 'TrackId'),
          ),
          'INVALID_REFERENCE_CHAIN',
        )
        timelines.push({
          attributes: row,
          labels: timelineLabels,
          tracks: chain(tracks, num(row, 'FirstTrack'), 'TrackNextIndex').map((track) => {
            check(
              num(track, 'BankId') === num(bank, 'MainId') &&
                num(track, 'ItemId') === num(row, 'MainId'),
              'INVALID_REFERENCE_CHAIN',
            )
            const trackLabels = chain(labels, num(track, 'TrackLabelFirstIndex'), 'LabelNextIndex')
            check(
              trackLabels.every(
                (label) =>
                  num(label, 'BankId') === num(bank, 'MainId') &&
                  num(label, 'ItemId') === num(row, 'MainId') &&
                  num(label, 'TrackId') === num(track, 'MainId'),
              ),
              'INVALID_REFERENCE_CHAIN',
            )
            return {
              attributes: track,
              labels: trackLabels,
              primary: container.external.get(str(track.TrackActionMixer)),
              secondary: container.external.get(str(track.TrackActionMixer2)),
            }
          }),
        })
      }
    }
    const compatibilityValue = canvas.CanvasRenderMipmapForceSaved
    document = {
      width,
      height,
      dpi,
      canvas,
      layers: tree(num(root, 'LayerFirstChildIndex'), 0),
      timelines,
      defaultTimelineId,
      compatibility:
        typeof compatibilityValue === 'number'
          ? compatibilityValue
            ? 'saved'
            : 'not-saved'
          : 'unknown',
    }
  } catch (error) {
    if (error instanceof ClipError || error instanceof TypeError) throw error
    if (error instanceof RangeError) errorCode(error)
    throw new ClipError('INVALID_DATABASE', undefined, { cause: error })
  } finally {
    db.close()
  }
  const materialIndex = createMaterialIndex(tables, options.maxMaterialCacheBytes)
  let disposed = false
  return {
    document,
    materialCache: materialIndex.preparations,
    readLayerProperties(id: string) {
      check(!disposed, 'CLOSED_DOCUMENT')
      const row = layerRows.get(id)
      check(row, 'MISSING_ROW')
      let properties = materialIndex.preparations.get<LayerProperties>(row)
      if (!properties) {
        properties = layerProperties(row)
        const freeze = (value: unknown): void => {
          if (value && typeof value === 'object') {
            Object.values(value).forEach(freeze)
            Object.freeze(value)
          }
        }
        freeze(properties)
        materialIndex.preparations.set(row, properties, 512 + JSON.stringify(properties).length * 2)
      }
      return properties
    },
    rows(table: string) {
      check(!disposed, 'CLOSED_DOCUMENT')
      return cache.get(table) ?? []
    },
    row(table: string, id: number) {
      check(!disposed, 'CLOSED_DOCUMENT')
      const row = indices.get(table)?.get(id) ?? cache.get(table)?.find((row) => row.MainId === id)
      check(row, 'MISSING_ROW')
      return row
    },
    body(id: ClipRow[string] | undefined) {
      check(!disposed, 'CLOSED_DOCUMENT')
      return container.external.get(str(id))
    },
    /** Borrowed opaque native data. Unknown fields are not interpreted or rounded. */
    container,
    openLayerRaster(id: string, input: LayerRasterOptions = {}) {
      check(!disposed, 'CLOSED_DOCUMENT')
      const row = layerRows.get(id)
      check(row, 'MISSING_ROW')
      const slot = input.slot ?? 'saved',
        fields = {
          saved: 'LayerRenderMipmap',
          'timeline-original': 'TimeLineOriginalMipmap',
          'image-original': 'ResizableOriginalMipmap',
          mask: 'LayerLayerMaskMipmap',
        } as const
      check(Object.hasOwn(fields, slot), 'INVALID_EDIT')
      const off = materialOffscreen(tables, row, fields[slot])
      check(off?.Attribute instanceof Uint8Array, 'MISSING_RASTER_DATA')
      return createRasterSource(off.Attribute, tables.external.get(str(off.BlockData)), {
        ...(options.imageLimits ? { imageLimits: options.imageLimits } : {}),
        ...input,
        mask: slot === 'mask',
      })
    },
    async decodeLayer(id: string, decoderOptions: MaterialDecoderOptions = {}) {
      check(!disposed, 'CLOSED_DOCUMENT')
      checkCancelled(options.signal)
      checkCancelled(decoderOptions.signal)
      const row = layerRows.get(id)
      check(row, 'MISSING_ROW')
      const diagnostics: ClipDiagnostic[] = [],
        kind = layerKinds.get(id)
      const layer: ClipLayer = {
        id,
        name: str(row.LayerName),
        isFolder: !!(num(row, 'LayerFolder') & 1),
        ...(kind ? { kind } : {}),
      }
      const decodeSignal = decoderOptions.signal ?? options.signal
      await createMaterialDecoder(
        tables,
        document.width,
        document.height,
        document.dpi,
        diagnostics,
        document.compatibility,
        {
          ...(options.imageLimits ? { imageLimits: options.imageLimits } : {}),
          ...decoderOptions,
          ...(decodeSignal ? { signal: decodeSignal } : {}),
        },
        materialIndex,
      )(layer, row)
      check(!disposed, 'CLOSED_DOCUMENT')
      checkCancelled(options.signal)
      checkCancelled(decoderOptions.signal)
      return { layer, diagnostics }
    },
    dispose() {
      if (disposed) return
      disposed = true
      cache.clear()
      indices.clear()
      materialIndex.objects.clear()
      materialIndex.rasters.clear()
      layerRows.clear()
      layerKinds.clear()
      container.external.clear()
      container.externalOffsets.clear()
      container.chunks.length = 0
      container.database = new Uint8Array()
      for (const timeline of document.timelines)
        for (const track of timeline.tracks) {
          track.primary = undefined
          track.secondary = undefined
        }
      for (const value of Object.values(tables)) if (value instanceof Map) value.clear()
      tables.thumbnails.length = 0
    },
  }
}
