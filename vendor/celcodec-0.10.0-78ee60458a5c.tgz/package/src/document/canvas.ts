import { diagnostic, type ClipDiagnostic } from '../diagnostics.js'
import type { ClipRow } from '../internal/records.js'
import type { AnimationFrameView } from './types.js'

/** CropFrameUnitKind is independent of CanvasUnit. Never infer one from the other. */
export function animationFrame(
  row: ClipRow,
  width: number,
  height: number,
  dpi: number,
): AnimationFrameView {
  const number = (key: string) => (typeof row[key] === 'number' ? row[key] : undefined)
  const stored = {
    unit: number('CropFrameUnitKind'),
    width: number('CropFrameInnerWidth'),
    height: number('CropFrameInnerHeight'),
    offsetX: number('CropFrameInnerOffsetX'),
    offsetY: number('CropFrameInnerOffsetY'),
    offsetBasePosition: number('CropFrameInnerOffsetBasePosition'),
    optionFlag: number('CropFrameOptionFlag'),
  }
  const diagnostics: ClipDiagnostic[] = []
  const values = [stored.width, stored.height, stored.offsetX, stored.offsetY]
  if (values.every((v) => v === undefined))
    return { stored, pixels: undefined, bounds: undefined, diagnostics }
  if (values.some((v) => v === undefined))
    diagnostics.push(diagnostic('MISSING_COLUMN_VALUE', { field: 'CropFrameInner' }))
  else if (values.some((v) => !Number.isFinite(v)) || stored.width! <= 0 || stored.height! <= 0)
    diagnostics.push(diagnostic('INVALID_CANVAS_FRAME'))
  // Unit conversion is restricted to independently captured native encodings.
  const scale =
    stored.unit === 0
      ? 1
      : stored.unit === 2 && Number.isFinite(dpi) && dpi > 0
        ? dpi / 25.4
        : undefined
  if (scale === undefined)
    diagnostics.push(
      diagnostic('UNSUPPORTED_CANVAS_UNIT', {
        field: 'CropFrameUnitKind',
        unit: stored.unit ?? -1,
      }),
    )
  if (diagnostics.length || scale === undefined)
    return { stored, pixels: undefined, bounds: undefined, diagnostics }
  const pixels = {
    width: stored.width! * scale,
    height: stored.height! * scale,
    offsetX: stored.offsetX! * scale,
    offsetY: stored.offsetY! * scale,
  }
  if (!Object.values(pixels).every(Number.isFinite))
    return {
      stored,
      pixels: undefined,
      bounds: undefined,
      diagnostics: [diagnostic('INVALID_CANVAS_FRAME')],
    }
  const bounds =
    Number.isInteger(stored.offsetBasePosition) &&
    stored.offsetBasePosition! >= 0 &&
    stored.offsetBasePosition! < 9
      ? {
          left:
            (width - pixels.width) / 2 +
            pixels.offsetX +
            (number('CropFrameCropOffsetX') ?? 0) * scale,
          top:
            (height - pixels.height) / 2 +
            pixels.offsetY +
            (number('CropFrameCropOffsetY') ?? 0) * scale,
          width: pixels.width,
          height: pixels.height,
        }
      : undefined
  if (bounds && !Object.values(bounds).every(Number.isFinite))
    return { stored, pixels, bounds: undefined, diagnostics: [diagnostic('INVALID_CANVAS_FRAME')] }
  if (!bounds)
    diagnostics.push(
      diagnostic('UNSUPPORTED_CANVAS_FRAME', {
        field: 'CropFrameInnerOffsetBasePosition',
        value: stored.offsetBasePosition ?? -1,
      }),
    )
  return { stored, pixels, bounds, diagnostics }
}
