import type { ClipDiagnostic } from '../diagnostics.js'
import type { EditOperation, EditOptions } from '../edit/operations.js'
import type { ImageResourceLimits } from '../image-resources.js'
import type { ClipLayer, LayerContentKind } from '../material/types.js'
import type { MaterialDecoderOptions, RasterOptions, RasterSource } from '../material/index.js'
import type { ClipAudioReadResult } from '../native/audio.js'
import type { ContainerLimits } from '../native/container-read.js'
import type { KeyframeTrack } from '../native/keyframes.js'
import type { ExportTrackFrame } from '../native/model.js'
import type { MediaSourceView } from './media.js'
import type { TimelinePlayback } from './playback.js'
import type { LayerProperties } from './properties.js'
import type { Layer3DView } from './scene3d.js'
import type { BinaryHandle, DocumentView, EditPlan, SaveResult, TimelineView } from './types.js'

export interface LayerRasterOptions extends Omit<
  RasterOptions,
  'region' | 'crop' | 'mask' | 'brushPattern'
> {
  /** Explicit native surface selection; no source fallback or rendering is performed. */
  slot?: 'saved' | 'timeline-original' | 'image-original' | 'mask'
}

export interface SessionOptions {
  imageLimits?: ImageResourceLimits
  signal?: AbortSignal
  limits?: Readonly<ContainerLimits>
  maxRows?: number
  maxDepth?: number
  /** Optional canvas area policy, default 50,000² pixels (CSP extent). Independent of decode/render budgets. */
  maxCanvasPixels?: number
  /** Shared raster indices, immutable properties and vector/brush preparations. Default 16 MiB; zero disables retention. */
  maxMaterialCacheBytes?: number
  /** Default copy; borrow requires immutable input until dispose. Transfer input to a Worker before borrowing. */
  ownership?: 'copy' | 'borrow'
  maxPlanBytes?: number
  /** Aggregate native uncompressed mixer bytes retained by live playback evaluators. Default 64 MiB. */
  maxPlaybackBytes?: number
}

/** One immutable source revision. Reopen saved bytes to start the next revision. */
export interface DocumentSession {
  readonly document: DocumentView
  readonly imageLimits: Readonly<ImageResourceLimits> | undefined
  readonly revision: 0
  /** Raw native offscreen coordinates, before placement, transforms and effects.
   * Sources borrow the session's bytes and close automatically with the session. */
  readonly openLayerRaster: (id: string, options?: LayerRasterOptions) => RasterSource
  /** Compile native curves once, then evaluate frames without SQLite or pixel decoding. */
  readonly createPlayback: (timelineId: string) => TimelinePlayback
  readonly copyBinary: (handle: BinaryHandle) => Uint8Array<ArrayBuffer>
  readonly inspectLayer: (
    id: string,
  ) => Record<string, string | number | Uint8Array<ArrayBuffer> | null | undefined>
  readonly read3DLayer: (id: string) => Layer3DView
  readonly readLayerProperties: (id: string) => LayerProperties
  /** Inspect all channels, including unknown names. */
  readonly readKeyframes: (id: number, source?: 'primary' | 'secondary') => KeyframeTrack
  readonly readCelTrack: (id: number) => ExportTrackFrame[]
  readonly readTimeline: (id: string) => {
    timeline: TimelineView
    tracks: {
      trackId: number
      layerId: string
      frames: ExportTrackFrame[]
      diagnostics: ClipDiagnostic[]
    }[]
  }
  readonly readAudio: (layerId: string, timelineId: string) => ClipAudioReadResult
  /** Inspect linked sources without accessing the filesystem or decoding media. */
  readonly readMediaSources: (layerId: string) => MediaSourceView[]
  readonly materialCapabilities: (id: string) => {
    kind: LayerContentKind | undefined
    media: boolean
    /** Reference exists; decode diagnostics determine whether its payload is available. */
    savedPixels: boolean
    savedComposite: boolean
    originalPixels: boolean
    decode: 'inspect-result-diagnostics'
  }
  /** Restore a single layer's material and diagnostics. Await each decode before starting the next on this session. */
  readonly decodeLayer: (
    id: string,
    options?: MaterialDecoderOptions,
  ) => Promise<{
    layer: ClipLayer
    diagnostics: ClipDiagnostic[]
  }>
  /** Snapshot the operations. Refused edits return diagnostics. Cancellation and resource limits reject the promise. */
  readonly planEdits: (
    operations: readonly EditOperation[],
    options?: EditOptions,
  ) => Promise<EditPlan>
  /** Consume this session's allowed plan once. Open the returned bytes to edit the saved revision. */
  readonly save: (plan: EditPlan) => Promise<SaveResult>
  /** Release a pending plan so another can be prepared. */
  readonly discardPlan: (plan: EditPlan) => void
  readonly resources: () => Readonly<{
    closed: boolean
    inputBytes: number
    metadataLayers: number
    metadataTracks: number
    pendingPlanBytes: number
    activeDecodes: number
    decodedCacheBytes: 0
    materialCacheBytes: number
    materialCacheEntries: number
    rasterSources: number
    playbackBytes: number
    playbacks: number
  }>
  readonly dispose: () => void
}
