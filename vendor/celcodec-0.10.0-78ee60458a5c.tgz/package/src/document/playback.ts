import { check } from '../internal/binary.js'
import { compareFrame } from '../internal/frame-boundary.js'
import { num } from '../internal/records.js'
import { sampleKeyframeSegment } from '../internal/keyframe-sampling.js'
import {
  checkCancelled,
  diagnostic,
  rethrowFatal,
  serializeClipError,
  type ClipDiagnostic,
} from '../diagnostics.js'
import {
  readKeyframeTrack,
  type KeyframeClip,
  type KeyframeCurve,
  type KeyframeSample,
  type KeyframeTrack,
} from '../native/keyframes.js'
import type { DocumentView, LayerView, TimelineView } from './types.js'
import type { NativeLayer, NativeTimeline } from './store.js'
import {
  checkPlaybackPolicy,
  resolvePlaybackApplication,
  type PlaybackPolicy,
  type PlaybackApplication,
  type PlaybackLayerOverride,
} from './playback-policy.js'

/** Canvas-style matrix: x' = a*x + c*y + e; y' = b*x + d*y + f. */
export type PlaybackTransform = readonly [
  a: number,
  b: number,
  c: number,
  d: number,
  e: number,
  f: number,
]
export interface PlaybackFrameOptions {
  /** Apply only to descendants of each 2D camera folder. Default: apply. */
  readonly camera?: PlaybackPolicy
  /** Default: document. Affects property curves, never cel assignment or audio timing. */
  readonly layerKeyframes?: PlaybackPolicy
  /** Unique native layer IDs. Each entry overrides only that layer's own settings. */
  readonly layers?: readonly PlaybackLayerOverride[]
}
export interface PlaybackChannel {
  readonly property: string
  readonly axis: string | undefined
  readonly source: 'curve' | 'constant'
  readonly sample: KeyframeSample
}
export interface PlaybackLayer {
  readonly layerId: string
  readonly parentId: string | null
  /** Includes ancestor visibility, clip exposure and cel selection. Undefined means unresolved. */
  readonly visible: boolean | undefined
  /** Legacy stored/intrinsic state. Use keyframeState.applied for this evaluation's decision. */
  readonly keyframesEnabled: boolean
  readonly keyframeState: PlaybackApplication
  readonly cameraState: PlaybackApplication | undefined
  /** Local group opacity; do not flatten this into every child before compositing. */
  readonly opacity: number | undefined
  /** Transform of original material coordinates, including decoded left/top, in document pixels. */
  readonly localTransform: PlaybackTransform | undefined
  /** Source-local evaluation, before ancestor visibility, cel selection or transforms.
   * Used when the same source is rendered in a different hierarchy. */
  readonly localState: Readonly<{
    exposure: boolean | undefined
    cel: PlaybackLayer['cel']
    maskTransform: PlaybackTransform | undefined
    diagnostics: readonly ClipDiagnostic[]
  }>
  /** Ancestor transforms and the requested camera policy are already included. */
  readonly transform: PlaybackTransform | undefined
  /** Independent original-mask coordinates. Undefined also when there is no enabled mask. */
  readonly maskTransform: PlaybackTransform | undefined
  readonly cameraApplied: boolean
  /** Animation folders only: null is an explicit blank; undefined is unresolved. */
  readonly cel:
    Readonly<{ name: string | null | undefined; layerId: string | null | undefined }> | undefined
  readonly channels: readonly PlaybackChannel[]
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface PlaybackFrame {
  readonly timelineId: string
  /** Relative to the timeline playback start. Fractional and negative frames are accepted. */
  readonly frame: number
  readonly inPlaybackRange: boolean
  readonly camera: PlaybackPolicy
  readonly layerKeyframes: PlaybackPolicy
  /** Parent before children, preserving the document's sibling order. No pixel decoding. */
  readonly layers: readonly PlaybackLayer[]
  readonly diagnostics: readonly ClipDiagnostic[]
}
export interface TimelinePlayback {
  readonly timelineId: string
  /** Sum of native uncompressed mixer sizes charged to the session budget, not JS heap size. */
  readonly trackBytes: number
  evaluate(frame: number, options?: PlaybackFrameOptions): PlaybackFrame
  dispose(): void
}

const identity: PlaybackTransform = Object.freeze([1, 0, 0, 1, 0, 0])
function multiply(a: PlaybackTransform, b: PlaybackTransform): PlaybackTransform | undefined {
  const result: PlaybackTransform = [
    a[0] * b[0] + a[2] * b[1],
    a[1] * b[0] + a[3] * b[1],
    a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3],
    a[0] * b[4] + a[2] * b[5] + a[4],
    a[1] * b[4] + a[3] * b[5] + a[5],
  ]
  return result.every(Number.isFinite) ? result : undefined
}
function inverse(m: PlaybackTransform): PlaybackTransform | undefined {
  const d = m[0] * m[3] - m[1] * m[2]
  if (!Number.isFinite(d) || d === 0) return undefined
  const result: PlaybackTransform = [
    m[3] / d,
    -m[1] / d,
    -m[2] / d,
    m[0] / d,
    (m[2] * m[5] - m[3] * m[4]) / d,
    (m[1] * m[4] - m[0] * m[5]) / d,
  ]
  return result.every(Number.isFinite) ? result : undefined
}
const unavailable = (
  code: ClipDiagnostic['code'],
  data?: ClipDiagnostic['data'],
): KeyframeSample => ({ status: 'unavailable', diagnostics: [diagnostic(code, data)] })

/** Curves were validated once while compiling. Binary search keeps seeks independent of key count. */
function sample(curve: KeyframeCurve, frame: number, origin: number): KeyframeSample {
  const keys = curve.keys
  if (!keys.length) return unavailable('INVALID_KEYFRAME_KEYS', { property: curve.property })
  let lo = 0,
    hi = keys.length
  while (lo < hi) {
    const mid = (lo + hi) >>> 1
    if (compareFrame(keys[mid]!.frame, frame, origin) <= 0) lo = mid + 1
    else hi = mid
  }
  const a = keys[Math.max(0, lo - 1)]!,
    b = keys[lo]
  // Numeric property channels hold endpoint values. Tagged cel/audio pre-roll has separate semantics.
  if (lo === 0 && a.tag !== undefined)
    return unavailable('UNSUPPORTED_KEYFRAME_EXTRAPOLATION', { property: curve.property })
  if (
    lo === 0 ||
    !b ||
    compareFrame(a.frame, frame, origin) === 0 ||
    a.interpolation === 'Constant'
  )
    return { status: 'value', value: a.value, tag: a.tag }
  return sampleKeyframeSegment(a, b, frame, curve.property)
}
function channels(clip: KeyframeClip, frame: number, origin: number): PlaybackChannel[] {
  const result: PlaybackChannel[] = clip.curves
    .filter(
      (c) =>
        c.keys.length ||
        !clip.parameters.some(
          (p) =>
            p.property === c.property &&
            (c.axis === undefined || ['Float2', 'Double2'].includes(p.kind)),
        ),
    )
    .map((c) => ({
      property: c.property,
      axis: c.axis,
      source: 'curve',
      sample: sample(c, frame, origin),
    }))
  const seen = new Set(result.map((c) => JSON.stringify([c.property, c.axis])))
  for (const p of clip.parameters) {
    const axes =
      p.values.length === 2 && ['Float2', 'Double2'].includes(p.kind) ? ['X', 'Y'] : [undefined]
    for (const [i, axis] of axes.entries()) {
      if (seen.has(JSON.stringify([p.property, axis]))) continue
      const value = p.values[i]
      result.push({
        property: p.property,
        axis,
        source: 'constant',
        sample:
          typeof value === 'number' &&
          Number.isFinite(value) &&
          (axes.length === 2 || p.values.length === 1)
            ? { status: 'value', value, tag: p.tag }
            : unavailable('UNSUPPORTED_KEYFRAME_PROPERTY', { property: p.property }),
      })
    }
  }
  return result
}
function affine(
  values: readonly PlaybackChannel[],
  prefix: 'Image' | 'Mask',
  diagnostics: ClipDiagnostic[],
): PlaybackTransform | undefined {
  const names = ['Position', 'Center', 'Rotation', 'Scale', 'AspectScale'].map((s) => prefix + s)
  if (!values.some((v) => names.includes(v.property))) return identity
  if (
    values.some(
      (v) =>
        names.includes(v.property) &&
        (['Position', 'Center', 'AspectScale'].some((s) => prefix + s === v.property)
          ? v.axis !== 'X' && v.axis !== 'Y'
          : v.axis !== undefined),
    )
  ) {
    diagnostics.push(
      diagnostic('UNSUPPORTED_PLAYBACK_TRANSFORM', { channel: prefix, reason: 'axis' }),
    )
    return undefined
  }
  const get = (name: string, axis?: string) => {
    const sample = values.find((c) => c.property === prefix + name && c.axis === axis)?.sample
    return sample?.status === 'value' && sample.tag === undefined ? sample.value : undefined
  }
  const px = get('Position', 'X'),
    py = get('Position', 'Y'),
    cx = get('Center', 'X'),
    cy = get('Center', 'Y'),
    rotation = get('Rotation'),
    scale = get('Scale'),
    sx = get('AspectScale', 'X') ?? scale,
    sy = get('AspectScale', 'Y') ?? scale
  if (
    px === undefined ||
    py === undefined ||
    cx === undefined ||
    cy === undefined ||
    rotation === undefined ||
    sx === undefined ||
    sy === undefined ||
    (scale !== undefined && values.some((v) => v.property === prefix + 'AspectScale'))
  ) {
    diagnostics.push(diagnostic('UNSUPPORTED_PLAYBACK_TRANSFORM', { channel: prefix }))
    return undefined
  }
  const angle = (rotation * Math.PI) / 180,
    cos = Math.cos(angle),
    sin = Math.sin(angle),
    a = (cos * sx) / 100,
    b = (sin * sx) / 100,
    c = (-sin * sy) / 100,
    d = (cos * sy) / 100
  const result: PlaybackTransform = [a, b, c, d, px - a * cx - c * cy, py - b * cx - d * cy]
  if (!result.every(Number.isFinite)) {
    diagnostics.push(diagnostic('UNSUPPORTED_PLAYBACK_TRANSFORM', { channel: prefix }))
    return undefined
  }
  return result
}
interface CompiledTrack {
  readonly track: KeyframeTrack | undefined
  readonly diagnostics: readonly ClipDiagnostic[]
}
interface CompiledLayer {
  readonly view: LayerView
  readonly native: NativeLayer
  readonly track: CompiledTrack | undefined
  readonly enabled: boolean
  readonly savedEnabled: boolean | undefined
  readonly savedCamera: boolean | undefined
  readonly hasOpacityCurve: boolean
}
const and = (a: boolean | undefined, b: boolean | undefined): boolean | undefined =>
  a === false || b === false ? false : a === undefined || b === undefined ? undefined : true

/** Internal compiler. Caller owns the lifetime and accounts for native mixer bytes before parsing. */
export function compilePlayback(
  document: DocumentView,
  timeline: TimelineView,
  native: NativeTimeline,
  layerMap: ReadonlyMap<string, NativeLayer>,
  trackBytes: number,
  active: () => void,
  release: () => void,
  signal: AbortSignal,
): TimelinePlayback {
  const byLayer = new Map<string, CompiledTrack>(),
    compiled: CompiledLayer[] = [],
    nativeTracks = new Map(native.tracks.map((t) => [t.attributes.MainId, t]))
  for (const t of timeline.tracks) {
    checkCancelled(signal)
    if (byLayer.has(t.layerId)) {
      byLayer.set(t.layerId, {
        track: undefined,
        diagnostics: [diagnostic('UNSUPPORTED_PLAYBACK_TRACK', { reason: 'multiple-tracks' })],
      })
      continue
    }
    const source = nativeTracks.get(t.id)!
    try {
      check([1000, 2000, 2005, 4001].includes(t.kind), 'UNSUPPORTED_PLAYBACK_TRACK', {
        kind: t.kind,
      })
      const field = source.primary ? 'TrackActionMixer' : 'TrackActionMixer2',
        body = source.primary ?? source.secondary
      check(body, 'MISSING_BINARY_COLUMN', { field })
      const track = readKeyframeTrack(body, num(source.attributes, field + 'Size'), {
        fps: timeline.fps,
        startFrame: timeline.startFrame,
        signal,
      })
      byLayer.set(t.layerId, {
        track: { ...track, clips: [...track.clips].sort((a, b) => a.startFrame - b.startFrame) },
        diagnostics: track.diagnostics,
      })
    } catch (error) {
      rethrowFatal(error)
      byLayer.set(t.layerId, { track: undefined, diagnostics: [serializeClipError(error)] })
    }
  }
  const walk = (items: readonly LayerView[]) => {
    for (const view of items) {
      const native = layerMap.get(view.id)!
      const flag = native.attributes.TimeLineLayerKeyFrameEnabled,
        cameraFlag = native.attributes.Camera2DApplyTransform
      compiled.push({
        view,
        native,
        track: byLayer.get(view.id),
        enabled:
          !!native.attributes.TimeLineLayerKeyFrameEnabled ||
          view.kind === 'camera' ||
          view.kind === 'audio',
        savedEnabled: flag === 0 ? false : flag === 1 ? true : undefined,
        savedCamera: cameraFlag === 0 ? false : cameraFlag === 1 ? true : undefined,
        hasOpacityCurve:
          byLayer
            .get(view.id)
            ?.track?.clips.some((c) => c.curves.some((v) => v.property === 'Opacity')) ?? false,
      })
      walk(view.children)
    }
  }
  walk(document.layers)
  const layerIds = new Set(compiled.map((l) => l.view.id))
  let closed = false
  return Object.freeze({
    timelineId: timeline.id,
    trackBytes,
    evaluate(frame: number, options: PlaybackFrameOptions = {}): PlaybackFrame {
      active()
      check(!closed, 'CLOSED_PLAYBACK')
      checkCancelled(signal)
      check(
        Number.isFinite(frame) && Math.abs(frame) <= Number.MAX_SAFE_INTEGER,
        'INVALID_TIME_VALUE',
      )
      check(
        options &&
          typeof options === 'object' &&
          !Array.isArray(options) &&
          Object.keys(options).every((k) => ['camera', 'layerKeyframes', 'layers'].includes(k)),
        'INVALID_PLAYBACK_OPTIONS',
      )
      const camera = options.camera === undefined ? 'apply' : options.camera,
        layerKeyframes = options.layerKeyframes === undefined ? 'document' : options.layerKeyframes
      checkPlaybackPolicy(camera)
      checkPlaybackPolicy(layerKeyframes)
      const overrides = new Map<string, PlaybackLayerOverride>()
      check(
        options.layers === undefined || Array.isArray(options.layers),
        'INVALID_PLAYBACK_OPTIONS',
      )
      check((options.layers?.length ?? 0) <= compiled.length, 'INVALID_PLAYBACK_OPTIONS')
      for (const entry of options.layers ?? []) {
        check(
          entry && typeof entry === 'object' && !overrides.has(entry.layerId),
          'INVALID_PLAYBACK_OPTIONS',
        )
        check(
          Object.keys(entry).every((k) => ['layerId', 'camera', 'layerKeyframes'].includes(k)),
          'INVALID_PLAYBACK_OPTIONS',
        )
        check(layerIds.has(entry.layerId), 'INVALID_PLAYBACK_OPTIONS')
        if (entry.camera !== undefined) checkPlaybackPolicy(entry.camera)
        if (entry.layerKeyframes !== undefined) checkPlaybackPolicy(entry.layerKeyframes)
        overrides.set(entry.layerId, entry)
      }
      const results: PlaybackLayer[] = [],
        byId = new Map<string, PlaybackLayer>(),
        allDiagnostics: ClipDiagnostic[] = []
      for (const item of compiled) {
        checkCancelled(signal)
        const { view, native, track } = item,
          parent = view.parentId ? byId.get(view.parentId) : undefined,
          override = overrides.get(view.id),
          intrinsic = view.kind === 'camera' || view.kind === 'audio',
          keyframeState = resolvePlaybackApplication(
            override?.layerKeyframes ?? layerKeyframes,
            item.savedEnabled,
            intrinsic,
            native.attributes.TimeLineLayerKeyFrameEnabled == null ? false : undefined,
          ),
          cameraState =
            view.kind === 'camera'
              ? resolvePlaybackApplication(override?.camera ?? camera, item.savedCamera)
              : undefined,
          enabled = keyframeState.applied === true,
          issues: ClipDiagnostic[] = [],
          opacityField =
            item.enabled && native.attributes.TimeLineOriginalLayerOpacity != null
              ? 'TimeLineOriginalLayerOpacity'
              : 'LayerOpacity',
          storedOpacity = native.attributes[opacityField],
          storedVisibility = native.attributes.LayerVisibility
        check(override?.camera === undefined || view.kind === 'camera', 'INVALID_PLAYBACK_OPTIONS')
        check(override?.layerKeyframes === undefined || !intrinsic, 'INVALID_PLAYBACK_OPTIONS')
        if (
          keyframeState.applied === undefined ||
          (cameraState && cameraState.applied === undefined)
        )
          issues.push(
            diagnostic('UNRESOLVED_PLAYBACK_SETTING', {
              field:
                cameraState?.applied === undefined && cameraState
                  ? 'Camera2DApplyTransform'
                  : 'TimeLineLayerKeyFrameEnabled',
            }),
          )
        const validOpacity =
          typeof storedOpacity === 'number' &&
          Number.isFinite(storedOpacity) &&
          storedOpacity >= 0 &&
          storedOpacity <= 256
        if (!validOpacity)
          issues.push(
            diagnostic(storedOpacity == null ? 'MISSING_COLUMN_VALUE' : 'INVALID_LAYER_ATTRIBUTE', {
              field: opacityField,
            }),
          )
        const validVisibility =
          typeof storedVisibility === 'number' &&
          Number.isSafeInteger(storedVisibility) &&
          storedVisibility >= 0
        if (!validVisibility)
          issues.push(
            diagnostic(
              storedVisibility == null ? 'MISSING_COLUMN_VALUE' : 'INVALID_LAYER_ATTRIBUTE',
              { field: 'LayerVisibility' },
            ),
          )
        let exposure: boolean | undefined = true
        let visible: boolean | undefined =
            view.role === 'light-table-reference'
              ? false
              : validVisibility
                ? view.visible
                : undefined,
          values: PlaybackChannel[] = [],
          local: PlaybackTransform | undefined = identity,
          opacity: number | undefined = validOpacity ? storedOpacity / 256 : undefined,
          cel: PlaybackLayer['cel'],
          clip: KeyframeClip | undefined
        const useTrack = !!track && (enabled || view.animation),
          ignoreCamera = cameraState !== undefined && cameraState.applied !== true
        if (
          (ignoreCamera ? item.savedCamera : !enabled && item.savedEnabled) &&
          item.hasOpacityCurve &&
          opacityField !== 'TimeLineOriginalLayerOpacity'
        ) {
          opacity = undefined
          issues.push(diagnostic('MISSING_COLUMN_VALUE', { field: 'TimeLineOriginalLayerOpacity' }))
        }
        if (useTrack && !ignoreCamera) {
          issues.push(...track.diagnostics)
          if (!track.track || track.diagnostics.length) {
            exposure = undefined
            visible = and(visible, undefined)
            local = undefined
            opacity = undefined
          } else {
            const clips = track.track.clips
            let lo = 0,
              hi = clips.length
            while (lo < hi) {
              const mid = (lo + hi) >>> 1
              if (compareFrame(clips[mid]!.startFrame, frame, timeline.startFrame) <= 0)
                lo = mid + 1
              else hi = mid
            }
            const candidate = clips[lo - 1]
            clip =
              candidate && compareFrame(frame, candidate.endFrame, timeline.startFrame) < 0
                ? candidate
                : undefined
            if (!clip) {
              visible = false
              exposure = false
            } else {
              values = channels(clip, frame, timeline.startFrame)
              if (!enabled) values = values.filter((c) => c.property === 'ImageCelName')
              // Interpolation is decided per evaluated segment, including exact native keys.
              issues.push(
                ...clip.diagnostics.filter((d) => d.code !== 'UNSUPPORTED_KEYFRAME_INTERPOLATION'),
              )
              for (const value of values)
                if (value.sample.status === 'unavailable') issues.push(...value.sample.diagnostics)
              if (
                clip.diagnostics.some((d) =>
                  ['UNSUPPORTED_KEYFRAME_STRUCTURE', 'UNSUPPORTED_KEYFRAME_BLEND'].includes(d.code),
                )
              ) {
                local = undefined
                opacity = undefined
                exposure = undefined
                visible = and(visible, undefined)
              } else if (enabled) {
                local = affine(values, 'Image', issues)
                const o = values.find(
                  (c) => c.property === 'Opacity' && c.axis === undefined,
                )?.sample
                if (o) {
                  opacity =
                    o.status === 'value' && o.tag === undefined && o.value >= 0 && o.value <= 100
                      ? o.value / 100
                      : undefined
                  if (opacity === undefined && o.status === 'value')
                    issues.push(diagnostic('INVALID_LAYER_ATTRIBUTE', { field: 'Opacity' }))
                }
              }
            }
          }
        }
        if (
          keyframeState.applied === undefined ||
          (cameraState && cameraState.applied === undefined)
        ) {
          local = undefined
          opacity = undefined
          exposure = undefined
          visible = and(visible, undefined)
        }
        let localCel: PlaybackLayer['cel']
        if (view.animation) {
          const name = clip
            ? values.find((c) => c.property === 'ImageCelName' && c.axis === undefined)?.sample
            : undefined
          const tag =
            visible === false ? null : name?.status === 'value' ? name.tag || null : undefined
          const match =
            typeof tag === 'string'
              ? view.children.findLast((c) => c.role !== 'light-table-reference' && c.name === tag)
              : undefined
          cel = {
            name: tag,
            layerId: tag === null ? null : tag === undefined || !match ? undefined : match.id,
          }
          const localTag =
            exposure === false ? null : name?.status === 'value' ? name.tag || null : undefined
          const localMatch =
            typeof localTag === 'string'
              ? view.children.findLast(
                  (c) => c.role !== 'light-table-reference' && c.name === localTag,
                )
              : undefined
          localCel = {
            name: localTag,
            layerId:
              localTag === null
                ? null
                : localTag === undefined || !localMatch
                  ? undefined
                  : localMatch.id,
          }
          if (cel.layerId === undefined)
            issues.push(diagnostic('UNRESOLVED_PLAYBACK_CEL', { name: tag ?? '' }))
        }
        if (parent) {
          visible = and(visible, parent.visible)
          if (parent.cel)
            visible = and(
              visible,
              parent.cel.layerId === undefined ? undefined : parent.cel.layerId === view.id,
            )
        }
        let cameraApplied = parent?.cameraApplied ?? false
        if (cameraState?.applied) {
          // Each camera contributes its own inverse, in hierarchy order (outer * inner).
          if (!track) local = undefined
          if (local) local = inverse(local)
          // The inverse is expressed around the sampled pivot. CSP can reset a nested
          // camera's display cache without changing its curves, so never use that cache
          // as the pivot for timeline playback (including fractional canvas changes).
          const attributes = item.native.attributes,
            frameX = attributes.Camera2DOriginalFrameCenterX,
            frameY = attributes.Camera2DOriginalFrameCenterY,
            center = (axis: string) => {
              const sample = values.find(
                (c) => c.property === 'ImageCenter' && c.axis === axis,
              )?.sample
              return sample?.status === 'value' && sample.tag === undefined
                ? sample.value
                : undefined
            },
            pivotX = center('X'),
            pivotY = center('Y')
          if (
            local &&
            pivotX !== undefined &&
            pivotY !== undefined &&
            typeof frameX === 'number' &&
            typeof frameY === 'number'
          ) {
            const x = frameX - pivotX,
              y = frameY - pivotY
            if (Number.isFinite(x) && Number.isFinite(y))
              local = [local[0], local[1], local[2], local[3], local[4] + x, local[5] + y]
            else local = undefined
          }
          if (!local) issues.push(diagnostic('UNSUPPORTED_PLAYBACK_CAMERA'))
          cameraApplied = true
        }
        const localIssues = [...issues]
        const parentTransform = parent ? parent.transform : identity,
          transform = parentTransform && local ? multiply(parentTransform, local) : undefined
        if (parentTransform && local && !transform)
          issues.push(diagnostic('UNSUPPORTED_PLAYBACK_TRANSFORM', { reason: 'overflow' }))
        let maskTransform: PlaybackTransform | undefined
        let localMaskTransform: PlaybackTransform | undefined
        if (view.mask === 'enabled') {
          let maskLocal = local
          if (enabled && values.some((c) => c.property.startsWith('Mask'))) {
            const maskIssues: ClipDiagnostic[] = []
            maskLocal = affine(values, 'Mask', maskIssues)
            issues.push(...maskIssues)
            localIssues.push(...maskIssues)
          } else if (
            enabled &&
            local !== identity &&
            !(Number(native.attributes.LayerSelect) & 0x100)
          ) {
            maskLocal = undefined
            issues.push(diagnostic('UNSUPPORTED_PLAYBACK_MASK'))
            localIssues.push(diagnostic('UNSUPPORTED_PLAYBACK_MASK'))
          }
          localMaskTransform = maskLocal
          maskTransform =
            parentTransform && maskLocal ? multiply(parentTransform, maskLocal) : undefined
          if (parentTransform && maskLocal && !maskTransform)
            issues.push(diagnostic('UNSUPPORTED_PLAYBACK_MASK', { reason: 'overflow' }))
        }
        const diagnostics = (view.role === 'light-table-reference' ? [] : issues).map((d) => ({
            ...d,
            ...(d.data ? { data: { ...d.data } } : {}),
            layerId: view.id,
            part: 'timeline' as const,
          })),
          result: PlaybackLayer = {
            layerId: view.id,
            parentId: view.parentId,
            visible,
            keyframesEnabled: item.enabled,
            keyframeState,
            cameraState,
            opacity,
            localTransform: local,
            localState: {
              exposure,
              cel: localCel,
              maskTransform: localMaskTransform,
              diagnostics: (view.role === 'light-table-reference' ? [] : localIssues).map((d) => ({
                ...d,
                layerId: view.id,
                part: 'timeline' as const,
              })),
            },
            transform,
            maskTransform,
            cameraApplied,
            cel,
            channels: values,
            diagnostics,
          }
        results.push(result)
        byId.set(view.id, result)
        allDiagnostics.push(...diagnostics)
      }
      return {
        timelineId: timeline.id,
        frame,
        inPlaybackRange: frame >= 0 && frame < timeline.endFrame - timeline.startFrame,
        camera,
        layerKeyframes,
        layers: results,
        diagnostics: allDiagnostics,
      }
    },
    dispose() {
      if (closed) return
      closed = true
      compiled.length = 0
      byLayer.clear()
      layerIds.clear()
      release()
    },
  })
}
