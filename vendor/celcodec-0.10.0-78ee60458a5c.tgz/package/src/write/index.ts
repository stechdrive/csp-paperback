/** Existing documents are edited through session.planEdits() and session.save(). */
export { createDocument } from '../document/index.js'
export type {
  EditOperation,
  EditOptions,
  LayerAttributes,
  EditableKeyframeProperty,
  PropertyKeyTarget,
  TimelineFrameEdit,
  TrackTarget,
  EditPlan,
  SaveResult,
  ClipCanvasSettings,
  ClipAudioTimeline,
  ExportTrackFrame,
  Pixels,
} from '../document/index.js'
export { clipImagePlacement, validateClipCanvas } from '../native/model.js'
export { encodeRaster, placePixels, reducePixels, png } from '../native/raster.js'
