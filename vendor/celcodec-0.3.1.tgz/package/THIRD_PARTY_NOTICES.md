# Third-party notices

celcodec contains adapted MIT-licensed CLIP format, material and regression
tests from these repositories, inspected at the following revisions:

- csp-paperback: `9256c0326dcbb628ed8c601bf17253c3ca2300dd`,
  https://github.com/stechdrive/csp-paperback
- xsheet-remap: `6fb67280fdebb2ecd93e0fd0e369b47b4f29a6e8`,
  https://github.com/stechdrive/xsheet-remap

Copyright (c) 2025 stechdrive (csp-paperback)

Copyright (c) 2026 stechdrive (xsheet-remap)

The extraction covers containers, BINC, native layer/timeline/audio editing,
raster tiles, text/gradients, brush resolution, vector strokes, effects and
Canvas helpers. Types, diagnostics,
environment boundaries and resource cleanup have been adapted. Per-file source
hashes, comparison results and test omissions are recorded in the source
repository's `docs/provenance.json` and `docs/extraction.md`.

xsheet-remap originally adapted these modules from csp-paperback
`2809271ba06b6ed03322abbc45f8a4e7a81c44ff`, with later effect/diagnostic updates at
`a4547482bcad1a65ca1515072bb7a14269c502f2`. That older port is a comparison source,
not assumed to be equivalent to the current csp-paperback repository.

## Format research and implementation references

The original sources credit these MIT projects. They are research references,
not installed runtime dependencies:

- wamsoft/clipparse, `322a273c0e059d1dee9132af78289efa12a59522`:
  https://github.com/wamsoft/clipparse — Offscreen layout, raster tile permutation
  and reference color blend equations. Native alpha/opacity behavior in
  `src/render` was independently measured; see `docs/compositing.md`.
  Copyright (c) 2026 wamsoft.
- animeops/clip-tools, `8807134932a39a009c980fb29acd1ae934354a7c`:
  https://github.com/animeops/clip-tools — vector curve sampling and brush stamping.
  Copyright (c) 2026 AnimeOps.
- Aodaruma/clipfile-rs, `bd88467fa80e63ad48c6c713fbfb5a8a116d798a` and
  `b3c4aefe3ba944f47f27aaf0777cbffc1038e75c` (`clipfile-svg-v0.2.0`):
  https://github.com/Aodaruma/clipfile-rs — vector layouts, including the modern
  92-byte header. Copyright (c) 2026 Aodaruma.
- dobrokot/clip_to_psd, `e8db68c768f52ec91ba7530820f52537261cbad0`:
  https://github.com/dobrokot/clip_to_psd — text attributes, fill and image-effect
  layout research. The upstream MIT notice reads "Copyright (c) 2024" without
  an additional author name.

## Runtime dependency

fflate 0.8.3, https://github.com/101arrowz/fflate, MIT.
Copyright (c) 2026 Arjun Barrett. The package uses its bounded streaming zlib
decoder and compression helpers. The same MIT permission below applies.
sql.js/WASM is injected by the consumer and is not bundled by celcodec.

## MIT permission notice for the above sources

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## Test data and development tools

The included native vector/effect goldens are controlled synthetic CSP 5.1.5 captures,
distributed by the source repositories under MIT. They contain no production
artwork or third-party brush bitmap. Details are in `test/fixtures/README.md`.
The later `test/fixtures/vector-basic/` data is a new self-authored synthetic
CSP EX 5.1.5 study under this project's MIT license, Copyright 2026 stechdrive;
its README records the independent native captures and preservation boundaries.
Tests and fixtures are not included in the npm tarball. Native timeline/media
captures have separate provenance in `test/native/fixtures/README.md`.
The audited empty seed is MIT-licensed xsheet-remap material and is the sole
CLIP file in the tarball; its provenance and exact hash are in `assets/README.md`.

TypeScript (Apache-2.0), Vitest and its dependencies (their respective licenses),
Node.js type definitions (MIT), sql.js (MIT) and @napi-rs/canvas (MIT) are
development-only. Their versions and integrity records are in the lockfile.
