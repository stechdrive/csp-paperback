# Audited empty seed

`blank.clip` is copied byte-for-byte from xsheet-remap at
`6fb67280fdebb2ecd93e0fd0e369b47b4f29a6e8`,
`packages/adapters/src/clip/blank.clip` (MIT, Copyright 2026 stechdrive).

Size: 240,079 bytes.
SHA-256: `6fb3efa8066af90b2d0e042ddc3d2aee7572691e5cc658f89cdb02467e377a82`.

The upstream author created an empty CSP animation document. The preparation
script removes drawing/preview data, work metadata and unrelated layers. The
audited seed has a root, paper, animation folder and empty raster cel; 864×648
canvas, zero work time, empty author/title fields and only timeline externals.
Its creation CSP version was not recorded; do not infer it from later fixtures.

Regeneration: `python scripts/prepare-seed.py input.clip output.clip` using a
newly authored empty animation document with paper, one animation folder and one
raster cel. It is not a sanitizer for arbitrary production documents. Re-audit
any replacement and update the explicit package hash only after review.

This is the sole CLIP asset allowed in the package. `scripts/package-audit.mjs`
rejects changed seed bytes; Git ignores other CLIP/PSD files by default. The
seed README is included in the npm tarball to retain this provenance.
